# Rejestracja repozytorium jako marketplace Claude Code

## Co to jest

`.claude-plugin/marketplace.json` — manifest wymagany przez `/plugin marketplace add`.
Bez niego Claude Code zwraca dokładnie ten błąd, który dostałeś: „to repozytorium nie
jest platformą handlową". Ten plik go dodaje, wskazując na 32 skille jako osobne
pluginy, każdy w swoim bieżącym katalogu w TYM SAMYM repozytorium (wersja rozwojowa
rozpakowana) — żadne przenoszenie plików nie jest potrzebne.

Zweryfikowany lokalnie: `claude plugin validate <katalog>` → **PASS** (32 unikalne
nazwy, poprawny JSON, wymagane pola `name`/`owner`/`plugins[].source` obecne).

## Gdzie go umieścić

Skopiuj cały folder `.claude-plugin/` (z plikiem `marketplace.json` w środku) do
**katalogu głównego** repozytorium — obok folderów `shared/`, `audyt-systemu-v4/`,
`dr-01-.../` itd., NIE do środka żadnego z nich:

```
<root-repozytorium>/
├── .claude-plugin/
│   └── marketplace.json      ← ten plik
├── shared/
├── audyt-systemu-v4/
├── dr-01-ustroj-konstytucyjny-i-zrodla-prawa/
├── ...
```

## Jak używać (po commicie i pushu)

```
/plugin marketplace add <twoj-user-lub-org>/<nazwa-repo>
/plugin install shared@lex-machina-legal-skills
/plugin install audyt-systemu-v4@lex-machina-legal-skills
# lub pojedynczo dla każdego z 32 wpisanych skilli
```

Ponieważ `source` każdego wpisu to ścieżka względna w TYM SAMYM repo (nie kopia,
nie osobny branch), kolejny `git pull` + reinstalacja pluginu ciągnie zawsze bieżący
stan katalogu — czyli ten sam mechanizm obsłuży też przyszłe aktualizacje (np.
`shared` 3.83 dostarczone dziś), bez ręcznego rozpakowywania ZIP-ów za każdym razem.

## Uwaga o zakresie

Manifest wylicza 32 katalogi obecne w systemie na dzień 2026-09-26 (zweryfikowane
z `manifest.json` tej sesji, pole `source: "plugin"` — wykluczone skille wbudowane
Anthropic: pdf/xlsx/docx/pptx, przykłady i narzędzia typu computer-use/chrome-browser).
Jeśli w repozytorium dodasz/usuniesz/przemianujesz katalog skilla, dopisz albo usuń
odpowiadający wpis w tablicy `plugins[]` — to jedyna ręczna czynność utrzymaniowa.

## Nie jest częścią żadnego skilla

Ten plik i `marketplace.json` NIE wchodzą w skład ZIP-ów `shared.zip` /
`audyt-systemu-v4.zip` dostarczonych osobno (Reguła 7 audytu dotyczy zawartości
POJEDYNCZEGO skilla; ten manifest opisuje CAŁE repozytorium i żyje poza drzewem
każdego z nich).
