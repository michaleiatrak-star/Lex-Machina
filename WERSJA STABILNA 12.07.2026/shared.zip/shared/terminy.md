# Terminy procesowe — tabela referencyjna

## Terminy ZAWITE (nie podlegają przywróceniu)

| Termin | Czynność | Podstawa |
|--------|----------|----------|
| **7 dni** | Sprzeciw od wyroku nakazowego (wykroczenia) | art. 94 KPSW |
| **7 dni** | Wniosek o uzasadnienie wyroku (KPC) | art. 328¹ KPC |
| **7 dni** | Zażalenie (KPC) | art. 394 §2 KPC |
| **7 dni** | Wniosek o uzasadnienie (KPK) | art. 422 §1 KPK |
| **3 dni** | Wniosek o uzasadnienie (KPW) | art. 105 §1 KPW |
| **7 dni** | Apelacja wykroczeniowa | art. 105 §2 KPW |
| **14 dni** | Sprzeciw od nakazu zapłaty | art. 503 §1 KPC |
| **14 dni** | Odpowiedź na pozew | art. 207 §2 KPC |
| **14 dni** | Apelacja cywilna (od doręcz. uzasadn.) | art. 369 §1 KPC |
| **14 dni** | Apelacja karna | art. 445 §1 KPK |
| **14 dni** | Odwołanie od decyzji admin. | art. 129 §2 KPA |
| **14 dni** | Sprzeciw od orzeczenia lekarza ZUS | art. 14 ustawy FUS |
| **14 dni** | Odstąpienie od umowy (internet/poza lokalem) | art. 27 ustawy PK |
| **⚠ 21 dni** | Odwołanie od wypowiedzenia/dyscyplinarki | **art. 264 §1 KP** |
| **30 dni** | Skarga do WSA | art. 53 §1 PPSA |
| **1 miesiąc** | Odwołanie od decyzji ZUS do sądu | art. 477⁹ §1 KPC |
| **6 tygodni** | Zaskarżenie uchwały wspólnoty mieszkaniowej | art. 25 uWŁ |
| **6 miesięcy** | Przyjęcie/odrzucenie spadku | art. 1015 §1 KC |

## Przedawnienia (instrukcyjne)

| Termin | Zakres | Podstawa |
|--------|--------|----------|
| 3 lata | Roszczenia ze stosunku pracy | art. 291 KP |
| 3/6 lat | Roszczenia cywilne ogólne | art. 118 KC |
| 5 lat | Zachowek | art. 1007 KC |
| 5 lat | Wykroczenia (karalność) | art. 45 KW |

## Reguły liczenia
- Start: następny dzień po doręczeniu/ogłoszeniu
- Koniec w sobotę/niedzielę/święto → przesuwa się na następny dzień roboczy
- ZAWITY = wygasa z mocy prawa, sąd nie może przywrócić

## Ostrzeżenie automatyczne
Gdy termin ≤5 dni: 🚨 **PILNE — zostały [n] dni!**
Gdy termin minął: ❌ **TERMIN UPŁYNĄŁ — zawity: brak przywrócenia**
