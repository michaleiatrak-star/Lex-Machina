# IMPLEMENTATION REPORT — Analizator Umów v2.2 Contract Standard

## 1. Decyzja architektoniczna

Dotychczasowy moduł „15 Złotych Reguł” został zastąpiony hierarchicznym standardem `CONTRACT-STANDARD v2.2`.

Powód: lista równorzędnych reguł mieszała kwestie fundamentalne, procesowe, compliance i redakcyjne. W praktyce wada ważności, brak dowodu wykonania i słabszy styl językowy nie mogą mieć tej samej rangi. Nowy model wymusza kolejność analizy odpowiadającą rzeczywistemu audytowi kontraktu:

1. VALIDITY
2. INTERPRETABILITY
3. ENFORCEABILITY
4. EVIDENCE
5. ATTACK RESISTANCE
6. COMPLIANCE & LIFECYCLE
7. DRAFTING QUALITY

## 2. Pliki zmienione

### Dodano

- `references/mod-shared-contract-standard-v2.md`

### Usunięto / zastąpiono

- `references/mod-shared-zlote-reguly-redakcji.md`

### Zmieniono

- `SKILL.md`
- `references/mod-core-checklist.md`
- `references/mod-shared-scorecard.md`
- `references/mod-shared-alt-drafts.md`
- `references/mod-shared-devil-advocate.md`
- dokumentację README

## 3. Integracja z workflow

Nowy standard jest wczytywany przy:

- pełnej analizie umowy,
- poprawie klauzuli,
- generowaniu nowej umowy,
- wariantach A/U/M,
- Devil’s Advocate,
- Contract Attack Simulation,
- Evidence Readiness,
- Enforceability,
- Scorecard.

## 4. Nowa skala ryzyka

Wdrożono priorytety P0–P3:

- P0 — wada fundamentalna, NO-GO,
- P1 — wysokie ryzyko sporu lub nieegzekwowalności,
- P2 — średnie ryzyko operacyjne,
- P3 — jakość redakcyjna.

## 5. Wpływ na Scorecard

Wynik końcowy jest ograniczany przez najcięższe nierozwiązane naruszenia:

- dowolny P0 → maksymalnie 49/100,
- co najmniej dwa P1 → maksymalnie 69/100,
- jeden P1 → maksymalnie 79/100,
- co najmniej pięć P2 → maksymalnie 84/100,
- wynik 85+ tylko przy braku P0 i nierozwiązanych P1.

## 6. Weryfikacja online i źródła metodologiczne

Przy konstrukcji standardu sprawdzono źródła online:

- ISAP — Kodeks cywilny, w tym podstawy dla swobody umów, wykładni i ograniczeń odpowiedzialności kontraktowej;
- ISAP — Kodeks postępowania cywilnego, dla znaczenia dowodów dokumentowych i ciężaru dowodzenia w sporze;
- UOKiK — rejestr klauzul niedozwolonych i materiały dotyczące wzorców umownych;
- Practical Law / Thomson Reuters — checklistowe podejście do redakcji, interpretacji i boilerplate clauses;
- Ken Adams / contract drafting methodology — kategorie języka kontraktowego;
- commercial-legal-pl — baza klauzul i workflow redakcyjne jako warstwa pomocnicza.

## 7. Ocena końcowa

Wdrożenie v2.2 jest silniejsze niż poprzednie v2.1, bo nie dodaje kolejnej checklisty, lecz zmienia logikę oceny. Narzędzie priorytetyzuje teraz ważność, egzekwowalność, dowodowalność i odporność procesową przed stylem oraz compliance nieaktywowanym przez konkretną umowę.
