# MODUŁ SCORECARD — OCENA LICZBOWA I DECYZJA KONTRAKTOWA
## Analizator Umów v2.2 · Moduł Shared

> **Wczytaj gdy:** końcowy raport z pełnej analizy, triage YELLOW/RED, analiza dla zarządu, decyzja podpisywać/negocjować/odrzucić, porównanie wersji umowy, analiza przed wysłaniem finalnej wersji.
>
> **Cel modułu:** zamienić wielowątkową analizę na syntetyczną decyzję: podpisać, podpisać po poprawkach, negocjować, eskalować albo odrzucić.

---

## SC.0 — ZASADA

Scorecard nie zastępuje analizy. Jest jej destylacją.

```text
Najpierw: cytaty, ryzyka, podstawy, poprawki.
Dopiero potem: ocena punktowa.
```

---

## SC.1 — OBSZARY OCENY

Oceń każdy obszar w skali 0–100.

```text
1. LEGAL RISK
   Zgodność z prawem, nieważność, bezskuteczność, abuzywność.

2. LITIGATION RISK
   Ryzyko sporu, podatność na ataki, niejasności, potencjalne koszty procesu.

3. EVIDENCE READINESS
   Czy umowa generuje dowody wykonania, doręczenia, odbioru, zmiany, szkody.

4. ENFORCEABILITY
   Czy klauzule dadzą realny skutek przed sądem lub w negocjacjach spornych.

5. FINANCIAL EXPOSURE
   Kary, odszkodowania, cap liability, odsetki, utracone korzyści, potrącenia.

6. OPERATIONAL RISK
   Czy umowę da się wykonywać bez chaosu: terminy, procedury, role, załączniki.

7. NEGOTIATION POSITION
   Czy pozycja strony chronionej jest wystarczająco silna i realistyczna.

8. LIFECYCLE CONTROL
   Kontrola nad odnowieniem, wypowiedzeniem, aneksami, indeksacją, audytem, exit.
```

---

## SC.2 — WAGI DOMYŚLNE

```text
Legal Risk ............... 20%
Litigation Risk .......... 15%
Evidence Readiness ....... 15%
Enforceability ........... 15%
Financial Exposure ....... 15%
Operational Risk ......... 10%
Negotiation Position ..... 5%
Lifecycle Control ........ 5%
```

Dla umowy wysokiego sporu lub ugody zwiększ:

```text
Litigation Risk + Evidence Readiness + Enforceability = 55–65% łącznie.
```

Dla umowy operacyjnej/SaaS zwiększ:

```text
Operational Risk + Lifecycle Control + Evidence Readiness = 40–50% łącznie.
```

---

## SC.2A — KOREKTA CONTRACT STANDARD v2.2

Przed przeliczeniem końcowym wczytaj `references/mod-shared-contract-standard-v2.md` i uwzględnij najwyższy nierozwiązany priorytet P0–P3.

```text
dowolny nierozwiązany P0 → maksymalny wynik 49, grade D / NO-GO
≥2 nierozwiązane P1     → maksymalny wynik 69, grade C
1 nierozwiązane P1      → maksymalny wynik 79, grade B-
≥5 nierozwiązanych P2   → maksymalny wynik 84, grade B
wyłącznie P3            → brak twardego limitu; wpływ na drafting quality
```

Wynik 85+ jest dopuszczalny tylko, gdy brak P0 i brak nierozwiązanych P1.

---

## SC.3 — PRZELICZENIE

```text
OVERALL SCORE = suma punktów ważonych
GRADE:
  A  = 90–100  podpisywalna po kosmetyce
  B  = 75–89   podpisywalna po ograniczonych poprawkach
  C  = 60–74   wymaga negocjacji kluczowych klauzul
  D  = 40–59   wysokie ryzyko; podpis tylko z decyzją biznesową
  F  = 0–39    nie rekomendować podpisania w obecnym brzmieniu
```

---

## SC.4 — FORMAT WYJŚCIA

```text
CONTRACT SCORECARD

Legal Risk ............... [X]/100
Litigation Risk .......... [X]/100
Evidence Readiness ....... [X]/100
Enforceability ........... [X]/100
Financial Exposure ....... [X]/100
Operational Risk ......... [X]/100
Negotiation Position ..... [X]/100
Lifecycle Control ........ [X]/100
Golden Rules Compliance ... [X]/100

OVERALL SCORE: [X]/100
ZR STATUS: [PASS / WARN / FAIL — podać reguły blokujące]
GRADE: [A/B/C/D/F]

DECYZJA:
[ ] Podpisać
[ ] Podpisać po poprawkach
[ ] Negocjować przed podpisaniem
[ ] Eskalować do zarządu / pełnomocnika
[ ] Nie podpisywać w obecnym brzmieniu
```

---

## SC.5 — TOP LISTY

Dodaj zawsze:

```text
TOP 5 PROBLEMÓW
1. [problem] — skutek: [konkretnie]
2. ...

TOP 5 POPRAWEK
1. [poprawka] — efekt: [co eliminuje]
2. ...

3 KLAUZULE, KTÓRYCH NIE RUSZAĆ
1. [klauzula korzystna]
2. ...
```

---

## SC.6 — ZASADA TRANSPARENTNOŚCI

Jeżeli brakuje danych do oceny liczbowej, wpisz:

```text
Ocena warunkowa: [X]/100
Brakujące dane: [lista]
Wpływ braku danych: score może zmienić się o ±[X] pkt.
```


---

# OVERRIDE v2.2 — KOREKTA CONTRACT STANDARD

Przed końcowym wynikiem wczytaj `references/mod-shared-contract-standard-v2.md`.

Limity punktowe:

| Naruszenie | Maksymalny wynik | Maksymalny grade |
|---|---:|---|
| dowolny nierozwiązany P0 | 49 | D / NO-GO |
| ≥2 nierozwiązane P1 | 69 | C |
| 1 nierozwiązane P1 | 79 | B- |
| ≥5 nierozwiązanych P2 | 84 | B |
| wyłącznie P3 | brak twardego limitu | według jakości |

Wynik 85+ jest dopuszczalny tylko, gdy brak P0 i brak nierozwiązanych P1.

W raporcie końcowym dodaj:

```text
CONTRACT STANDARD STATUS: PASS / CONDITIONAL / FAIL
Najwyższy priorytet ryzyka: P0/P1/P2/P3
Blokujące reguły CS: ...
Decyzja: podpis / negocjacja / odmowa / podpis po akceptacji ryzyka
```
