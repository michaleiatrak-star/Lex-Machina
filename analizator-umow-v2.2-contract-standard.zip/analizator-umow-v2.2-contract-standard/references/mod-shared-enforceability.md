# MODUŁ ENFORCEABILITY — EGZEKWOWALNOŚĆ I SKUTECZNOŚĆ KLAUZUL
## Analizator Umów v2.0 · Moduł Shared

> **Wczytaj gdy:** pełna analiza umowy, analiza klauzul kar, zakazów, limitów odpowiedzialności, wypowiedzeń, odstąpień, potrąceń, zrzeczeń roszczeń, poufności, IP, zakazu konkurencji, ugody, OWU, B2C, UoP, M&A lub gdy użytkownik pyta „czy to się obroni w sądzie”.
>
> **Cel modułu:** odróżnić cztery poziomy: ważność, skuteczność, wykonalność i realną egzekwowalność.

> ⛔ HARD GATE — każdy przepis lub orzeczenie dotyczące nieważności, bezskuteczności, miarkowania, abuzywności, zakazu konkurencji, kary umownej, zrzeczenia roszczeń albo ugody wymaga weryfikacji online. Bez weryfikacji oznacz: ⚠️ [NIEWERYFIKOWANE].

---

## EF.0 — TEST CZTERECH POZIOMÓW

Dla każdej klauzuli wysokiego znaczenia wykonaj test:

```text
1. WAŻNOŚĆ
   Czy klauzula nie jest sprzeczna z ustawą, zasadami współżycia społecznego albo naturą stosunku?

2. SKUTECZNOŚĆ
   Czy strona może się na nią powołać wobec tej konkretnej drugiej strony?

3. WYKONALNOŚĆ
   Czy obowiązek jest opisany tak konkretnie, że można ustalić, co należy zrobić?

4. EGZEKWOWALNOŚĆ
   Czy sąd, arbiter, kontrahent lub organ realnie przyzna skutek, którego oczekuje strona?
```

---

## EF.1 — FORMAT OCENY KLAUZULI

```text
ENFORCEABILITY CHECK

Klauzula: §[X] — [cytat dosłowny]
Funkcja klauzuli: [np. kara, wypowiedzenie, limit odpowiedzialności]

Ważność: TAK / NIE / WĄTPLIWE
Skuteczność wobec drugiej strony: TAK / NIE / WĄTPLIWE
Wykonalność techniczna: TAK / NIE / WĄTPLIWE
Egzekwowalność procesowa: WYSOKA / ŚREDNIA / NISKA

Ryzyko korekty przez sąd: LOW / MED / HIGH / CRITICAL
Element decydujący: [jedno zdanie]
Kontrargument drugiej strony: [jedno zdanie]
Rekomendacja: [zmiana]
Gotowe brzmienie: [pełna klauzula]
```

---

## EF.2 — KATALOG KLAUZUL PODWYŻSZONEGO RYZYKA

### EF-1 Kara umowna

Sprawdź:

```text
□ Czy kara dotyczy zobowiązania niepieniężnego?
□ Czy jest proporcjonalna do wartości umowy?
□ Czy ma cap?
□ Czy nalicza się dziennie bez limitu?
□ Czy przysługuje obu stronom, czy tylko jednej?
□ Czy zastrzeżono odszkodowanie uzupełniające?
□ Czy kara może być miarkowana?
```

Ocena:

```text
Kara może być ważna, ale nisko egzekwowalna, jeżeli jest rażąco wygórowana, automatyczna, bez capu i oderwana od rzeczywistej szkody.
```

### EF-2 Limit odpowiedzialności

Sprawdź:

```text
□ Czy limit obejmuje wszystkie podstawy odpowiedzialności?
□ Czy wyłącza szkody umyślne?
□ Czy obejmuje poufność, IP, RODO, rażące niedbalstwo?
□ Czy limit jest zbyt niski wobec funkcji umowy?
□ Czy druga strona może twierdzić, że limit narusza naturę stosunku?
```

### EF-3 Wypowiedzenie i odstąpienie

Sprawdź:

```text
□ Czy przesłanki są konkretne?
□ Czy termin wykonania prawa jest określony?
□ Czy skutek jest jasny: ex nunc / ex tunc?
□ Czy wymaga wezwania do usunięcia naruszenia?
□ Czy skutek finansowy po rozwiązaniu jest określony?
```

### EF-4 Zrzeczenie roszczeń / ugoda

Sprawdź:

```text
□ Czy strony wiedzą, czego się zrzekają?
□ Czy zakres zrzeczenia jest jednoznaczny?
□ Czy obejmuje roszczenia przyszłe, nieznane lub nieoznaczone?
□ Czy nie narusza praw pracowniczych lub konsumenckich?
□ Czy nie ma błędu co do stanu faktycznego?
```

### EF-5 Zakaz konkurencji / non-solicit

Sprawdź:

```text
□ Czy zakres terytorialny, czasowy i przedmiotowy jest proporcjonalny?
□ Czy przewidziano wynagrodzenie, jeśli wymagane?
□ Czy zakaz chroni realny interes, czy blokuje aktywność zawodową?
□ Czy kara za naruszenie jest proporcjonalna?
```

### EF-6 Klauzule B2C / OWU

Sprawdź:

```text
□ Czy postanowienie nie kształtuje praw konsumenta sprzecznie z dobrymi obyczajami?
□ Czy nie rażąco narusza interesów konsumenta?
□ Czy nie znajduje analogii w rejestrze klauzul niedozwolonych?
□ Czy konsument otrzymał regulamin przed zawarciem umowy?
```

---

## EF.3 — SKALA EGZEKWOWALNOŚCI

```text
WYSOKA
  Klauzula konkretna, proporcjonalna, zgodna z prawem, dowodowo zabezpieczona.

ŚREDNIA
  Klauzula zasadniczo poprawna, ale wymaga doprecyzowania albo ma ryzyko redukcji.

NISKA
  Klauzula prawdopodobnie zostanie ograniczona, zmiarkowana, pominięta albo trudna do wykazania.

KRYTYCZNA
  Wysokie ryzyko nieważności, bezskuteczności albo całkowitego braku praktycznego skutku.
```

---

## EF.4 — OUTPUT KOŃCOWY

```text
EGZEKWOWALNOŚĆ — PODSUMOWANIE

Najmniej egzekwowalna klauzula: §[X]
Powód: [jedno zdanie]
Skutek praktyczny: [co realnie stanie się w sporze]
Ryzyko sądowej korekty: [LOW/MED/HIGH/CRITICAL]
Najważniejsza poprawka: [jedno zdanie]
Gotowe brzmienie: [pełna treść]
```
