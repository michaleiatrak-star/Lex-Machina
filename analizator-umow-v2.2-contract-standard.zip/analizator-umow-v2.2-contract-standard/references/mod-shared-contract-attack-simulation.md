# MODUŁ CONTRACT-ATTACK-SIMULATION — SYMULACJA ATAKU NA UMOWĘ
## Analizator Umów v2.0 · Moduł Shared

> **Wczytaj gdy:** przed finalnym raportem pełnej analizy, przed wysłaniem projektu drugiej stronie, przy sporze, ugodzie, umowie wysokiej wartości, M&A, zakazie konkurencji, B2C, UoP, PZP, klauzulach kar, IP, RODO, odpowiedzialności lub gdy użytkownik pyta „jak druga strona to zaatakuje”.
>
> **Różnica wobec Devil Advocate:** Devil Advocate bada perspektywę kontrahenta biznesowo-negocjacyjnie. Contract Attack Simulation bada **jak profesjonalny pełnomocnik procesowy podważy dokument przed sądem, arbitrem, organem albo w negocjacjach spornych.**

> ⛔ HARD GATE — każda podstawa prawna i każde orzeczenie użyte jako argument ataku albo kontrargumentu wymaga weryfikacji online. Bez weryfikacji oznacz: ⚠️ [NIEWERYFIKOWANE].

---

## CAS.0 — ZAŁOŻENIE ROBOCZE

Analizuj umowę tak, jakby po 2 latach doszło do sporu, a druga strona wynajęła pełnomocnika, którego celem jest:

```text
□ unieważnić klauzulę,
□ ograniczyć jej skutek,
□ opóźnić wykonanie,
□ obniżyć karę lub odpowiedzialność,
□ zakwestionować doręczenia i odbiory,
□ zakwestionować wysokość roszczenia,
□ przerzucić winę,
□ wykorzystać niejasności przeciw autorowi dokumentu.
```

---

## CAS.1 — 8 LINII ATAKU

### ATAK-01 Nieważność

Pytania:

```text
□ Czy klauzula może być sprzeczna z ustawą?
□ Czy narusza zasadę swobody umów przez sprzeczność z naturą stosunku?
□ Czy narusza zasady współżycia społecznego?
□ Czy forma czynności jest niewłaściwa?
□ Czy podmiot był prawidłowo reprezentowany?
```

### ATAK-02 Bezskuteczność

Pytania:

```text
□ Czy klauzula jest ważna abstrakcyjnie, ale nieskuteczna wobec tej strony?
□ Czy jest semiimperatywna norma chroniąca pracownika/konsumenta/najemcę?
□ Czy brak doręczenia OWU/regulaminu uniemożliwia powołanie się na postanowienie?
□ Czy zgoda była wymagana i nie została skutecznie udzielona?
```

### ATAK-03 Abuzywność / nierównowaga

Pytania:

```text
□ Czy postanowienie jednostronnie kształtuje prawa i obowiązki?
□ Czy druga strona może wskazać rażącą dysproporcję?
□ Czy postanowienie jest ukryte w OWU lub załączniku?
□ Czy brak było realnej negocjacji?
```

### ATAK-04 Contra proferentem / wykładnia przeciw autorowi

Pytania:

```text
□ Czy umowę przygotowała jedna strona?
□ Czy klauzula ma co najmniej dwie racjonalne interpretacje?
□ Czy definicje są niespójne?
□ Czy pojęcia otwarte nie mają mierników?
□ Czy załączniki zmieniają sens klauzul głównych?
```

### ATAK-05 Sprzeczności i odesłania

Pytania:

```text
□ Czy § odsyła do nieistniejącego §?
□ Czy załącznik ma inną treść niż umowa główna?
□ Czy definicje są używane przed zdefiniowaniem?
□ Czy kolejność dokumentów rozstrzyga konflikt?
□ Czy klauzule przetrwania kolidują z wygaśnięciem umowy?
```

W razie wykrycia: uruchom lub odwołaj się do `mod-spojnosc-odeslan.md`.

### ATAK-06 Brak dowodu

Pytania:

```text
□ Jak strona udowodni doręczenie?
□ Jak udowodni odbiór?
□ Jak udowodni zakres szkody?
□ Jak udowodni wykonanie lub niewykonanie?
□ Jak udowodni umocowanie osoby operacyjnej?
```

W razie wykrycia: uruchom lub odwołaj się do `mod-shared-evidence-readiness.md`.

### ATAK-07 Nadużycie prawa / nieproporcjonalność

Pytania:

```text
□ Czy egzekwowanie klauzuli w pełnym zakresie wygląda represyjnie?
□ Czy kara lub sankcja jest oderwana od szkody?
□ Czy strona silniejsza wykorzystuje przewagę kontraktową?
□ Czy wykonanie obowiązku było obiektywnie niemożliwe lub nadmiernie utrudnione?
```

### ATAK-08 Redukcja ekonomiczna / miarkowanie

Pytania:

```text
□ Czy kara może być zmniejszona?
□ Czy odszkodowanie może zostać ograniczone z powodu braku adekwatnego związku przyczynowego?
□ Czy utracone korzyści są zbyt spekulatywne?
□ Czy roszczenie jest nadmierne wobec wartości kontraktu?
```

---

## CAS.2 — FORMAT ATAKU

Dla każdej realnej linii ataku użyj formatu:

```text
ATAK-[nr]: [nazwa]

Cel oponenta:
[co chce osiągnąć]

Punkt zaczepienia w umowie:
„[cytat dosłowny]”

Teza ataku:
[argument pełnomocnika drugiej strony]

Siła ataku:
LOW / MED / HIGH / CRITICAL

Szansa powodzenia:
[0–100%] — szacunek jakościowy, nie gwarancja

Element decydujący:
[jeden fakt/zwrot/brak, który przesądza]

Kontrargument:
[jak bronić klauzuli]

Poprawka prewencyjna:
[co zmienić]

Gotowe brzmienie:
[pełna treść klauzuli]
```

---

## CAS.3 — RANKING ATAKÓW

Na końcu dodaj:

```text
TOP 5 ATAKÓW NA UMOWĘ

1. [atak] — siła: [HIGH] — powód: [krótko]
2. [atak]
3. [atak]
4. [atak]
5. [atak]

NAJWAŻNIEJSZA POPRAWKA OBRONNA:
[jedno zdanie]
```

---

## CAS.4 — ZASADA REALIZMU PROCESOWEGO

Nie mnoż ataków teoretycznych. Oznacz tylko te, które profesjonalny pełnomocnik miałby realny interes podnieść.

```text
Atak jest istotny, jeżeli może zmienić wynik sporu, kwotę roszczenia, ciężar dowodu, termin wymagalności albo pozycję negocjacyjną.
```
