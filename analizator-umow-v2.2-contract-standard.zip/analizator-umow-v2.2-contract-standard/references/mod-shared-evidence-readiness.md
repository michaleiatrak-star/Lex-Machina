# MODUŁ EVIDENCE-READINESS — GOTOWOŚĆ DOWODOWA UMOWY
## Analizator Umów v2.0 · Moduł Shared

> **Wczytaj gdy:** każda pełna analiza umowy, każda umowa o wartości istotnej dla klienta, umowa długoterminowa, umowa IT/SaaS, B2B, najem, podwykonawstwo, PZP, ugoda, zakaz konkurencji, M&A, relacja sporna albo ryzyko późniejszego procesu.
>
> **Cel modułu:** odpowiedzieć nie tylko „czy klauzula jest zgodna z prawem”, lecz przede wszystkim: **czy po 6, 12 lub 36 miesiącach da się udowodnić wykonanie, naruszenie, doręczenie, odbiór, zmianę, wymagalność i wysokość roszczenia.**
>
> **Nie zastępuje:** mod-shared-devil-advocate.md ani mod-shared-ryzyko-kwant.md. Ten moduł bada materiał dowodowy, nie tylko ryzyko prawne lub finansowe.

> ⛔ HARD GATE — każda podstawa prawna dotycząca ciężaru dowodu, formy czynności, dokumentu, podpisu, doręczeń, dowodu z dokumentu, eIDAS, KPC/KC/KP/RODO → weryfikuj online w źródle urzędowym przed podaniem. Bez weryfikacji oznacz: ⚠️ [NIEWERYFIKOWANE].

---

## ER.0 — PYTANIE GŁÓWNE

Dla każdej istotnej klauzuli odpowiedz:

```text
Czy po powstaniu sporu strona chroniona będzie w stanie wykazać:
  1. że obowiązek istniał,
  2. że druga strona znała obowiązek,
  3. że termin rozpoczął bieg,
  4. że doręczenie lub zgłoszenie było skuteczne,
  5. że świadczenie wykonano albo nie wykonano,
  6. że szkoda / kara / wynagrodzenie jest policzalne,
  7. że osoba działająca była umocowana,
  8. że dokument, log lub e-mail jest autentyczny.
```

Jeżeli odpowiedź na którekolwiek pytanie brzmi „nie wiadomo” → oznacz lukę dowodową.

---

## ER.1 — MAPA DOWODOWA UMOWY

Sporządź tabelę:

```text
MAPA DOWODOWA

Obszar: [np. odbiór prac / doręczenia / zmiana zakresu / płatność]
Klauzula: §[X]
Fakt do udowodnienia: [co trzeba wykazać]
Dowód przewidziany w umowie: [jaki dokument/log/protokół/e-mail]
Dowód brakujący: [czego nie ma]
Ryzyko procesowe: LOW / MED / HIGH / CRITICAL
Rekomendacja: [konkretna zmiana]
Gotowe brzmienie: [pełna treść klauzuli]
```

---

## ER.2 — 8 KATEGORII GOTOWOŚCI DOWODOWEJ

### ER-1 Komunikacja i doręczenia

Sprawdź:

```text
□ Czy wskazano kanały komunikacji: e-mail, system, list, ePUAP, platforma?
□ Czy wskazano adresy do doręczeń i procedurę ich zmiany?
□ Czy doręczenie elektroniczne wymaga potwierdzenia odbioru?
□ Czy wiadomość wysłana poza wskazany kanał jest skuteczna?
□ Czy określono moment skuteczności: wysłanie, doręczenie, odczyt, potwierdzenie?
□ Czy jest fallback przy awarii systemu lub zmianie adresu?
```

Alert:

```text
Jeżeli skuteczność doręczenia zależy wyłącznie od wysłania e-maila bez potwierdzenia lub logu, oznacz MED/HIGH — zależnie od wagi skutku.
```

Modelowa klauzula:

```text
„Oświadczenia i zgłoszenia składane w wykonaniu Umowy wymagają formy dokumentowej i są skuteczne wyłącznie po doręczeniu na adresy wskazane w §[X]. W przypadku poczty elektronicznej za dowód doręczenia uznaje się automatyczne potwierdzenie dostarczenia wiadomości do serwera odbiorcy, potwierdzenie odbioru przez odbiorcę albo log systemowy potwierdzający przyjęcie zgłoszenia. Zmiana adresu wymaga uprzedniego zawiadomienia drugiej Strony w sposób przewidziany w niniejszym paragrafie.”
```

### ER-2 Odbiory, akceptacja i reklamacje

Sprawdź:

```text
□ Czy jest protokół odbioru?
□ Czy odbiór może być częściowy?
□ Czy milczenie oznacza akceptację? Po jakim terminie?
□ Czy zastrzeżenia muszą być konkretne?
□ Czy brak zastrzeżeń zamyka późniejsze zarzuty?
□ Czy odrzucenie odbioru wymaga uzasadnienia?
□ Czy jest procedura ponownego odbioru?
```

Modelowa klauzula:

```text
„Zamawiający w terminie [X] dni roboczych od otrzymania przedmiotu odbioru podpisze protokół odbioru albo przekaże Wykonawcy pisemne, konkretne i weryfikowalne zastrzeżenia. Brak przekazania zastrzeżeń w tym terminie oznacza odbiór bez zastrzeżeń, o ile Wykonawca wykaże doręczenie przedmiotu odbioru zgodnie z §[X].”
```

### ER-3 Płatności i wymagalność

Sprawdź:

```text
□ Czy wynagrodzenie jest policzalne bez uznaniowości?
□ Czy faktura jest warunkiem płatności czy tylko dokumentem księgowym?
□ Czy termin płatności liczony jest od faktury, doręczenia faktury, odbioru czy wykonania?
□ Czy są warunki zawieszające wymagalność?
□ Czy są dowody wykonania warunków płatności?
□ Czy są zasady potrąceń i reklamacji faktur?
```

Alert:

```text
Termin „30 dni od wystawienia faktury” bez obowiązku doręczenia faktury i bez relacji z odbiorem oznacz jako MED/HIGH.
```

### ER-4 Zmiany zakresu, aneksy, change request

Sprawdź:

```text
□ Czy każda zmiana zakresu wymaga zatwierdzenia?
□ Kto może zatwierdzać zmianę?
□ Czy e-mail wystarczy?
□ Czy brak odpowiedzi oznacza zgodę?
□ Czy zmiana zakresu automatycznie zmienia termin i wynagrodzenie?
□ Czy istnieje rejestr zmian?
```

Modelowa klauzula:

```text
„Każda zmiana zakresu świadczenia wymaga zgłoszenia Change Request zawierającego opis zmiany, wpływ na termin, wpływ na wynagrodzenie oraz osobę zatwierdzającą. Zmiana jest skuteczna dopiero po akceptacji przez osoby uprawnione wskazane w Załączniku nr [X], w formie dokumentowej, chyba że Umowa wymaga formy pisemnej.”
```

### ER-5 Logi IT, systemy, SaaS, SLA

Sprawdź:

```text
□ Czy system przechowuje logi zdarzeń?
□ Jak długo?
□ Kto ma dostęp do logów?
□ Czy logi są eksportowalne?
□ Czy SLA liczone jest na podstawie obiektywnych danych?
□ Czy wyłączenia SLA są dokumentowane?
□ Czy downtime wymaga zgłoszenia klienta, czy wynika z monitoringu?
```

Modelowa klauzula:

```text
„Dostawca przechowuje logi zdarzeń istotnych dla wykonania Umowy przez okres co najmniej [X] miesięcy od ich powstania. Logi obejmują w szczególności: datę i godzinę zdarzenia, identyfikator użytkownika lub systemu, rodzaj zdarzenia oraz status operacji. Na żądanie Klienta Dostawca udostępnia eksport logów w zakresie niezbędnym do weryfikacji SLA, incydentu lub rozliczenia.”
```

### ER-6 Podpisy, umocowanie i reprezentacja

Sprawdź:

```text
□ Czy osoba podpisująca jest wskazana jako reprezentant lub pełnomocnik?
□ Czy załączono pełnomocnictwo?
□ Czy osoby operacyjne mogą składać oświadczenia wiążące?
□ Czy limit kwotowy pełnomocnictwa jest wystarczający?
□ Czy podpis elektroniczny spełnia wymaganą formę?
```

Alert:

```text
Jeżeli osoby operacyjne mogą akceptować odbiory, zmiany lub reklamacje, ale nie określono ich umocowania, oznacz MED/HIGH.
```

### ER-7 Archiwizacja i retencja dokumentów

Sprawdź:

```text
□ Czy określono okres przechowywania dokumentów kontraktowych?
□ Czy załączniki są integralną częścią umowy?
□ Czy wersje dokumentów są numerowane?
□ Czy strony przechowują korespondencję i protokoły?
□ Czy dokumentacja może być udostępniona po zakończeniu umowy?
```

### ER-8 Ciężar dowodu i domniemania kontraktowe

Sprawdź:

```text
□ Czy umowa przewiduje domniemanie odbioru?
□ Czy umowa przewiduje domniemanie doręczenia?
□ Czy domniemania są proporcjonalne i obronią się w sporze?
□ Czy druga strona ma realną możliwość obalenia domniemania?
□ Czy klauzula nie przerzuca ciężaru dowodu w sposób ryzykowny w B2C lub stosunku pracowniczym?
```

---

## ER.3 — SKALA OCENY

```text
LOW      — umowa przewiduje jednoznaczny dokument/log/protokół i procedurę.
MED      — dowód istnieje, ale procedura jest niepełna albo zależy od zachowania drugiej strony.
HIGH     — kluczowy fakt będzie trudny do wykazania bez dodatkowych dowodów zewnętrznych.
CRITICAL — roszczenie lub obrona może upaść z powodu braku dowodu.
```

---

## ER.4 — OUTPUT OBOWIĄZKOWY

W raporcie końcowym dodaj:

```text
GOTOWOŚĆ DOWODOWA — PODSUMOWANIE

Ocena ogólna: [0–100]
Największa luka dowodowa: [opis]
Najbardziej ryzykowna klauzula: §[X]
Najważniejszy brakujący dowód: [np. protokół, log, potwierdzenie odbioru]
Priorytetowa poprawka: [jedno zdanie]
Gotowa klauzula naprawcza: [pełna treść]
```

---

## ER.5 — ZASADA PRIORYTETU

Jeżeli klauzula jest prawnie poprawna, ale niewykonalna dowodowo, oznacz ją jako problem.

```text
Legalnie poprawna ≠ procesowo użyteczna.
```
