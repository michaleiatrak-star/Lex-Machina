# MODUŁ SHARED-CONTRACT-STANDARD-v2 — HIERARCHICZNY STANDARD ANALIZY I REDAKCJI UMÓW

Wersja: 2.2  
Status: nadrzędny standard jakościowy dla analizy, redakcji, negocjacji i finalnego scorecardu.  
Zastępuje: równorzędną listę „15 Złotych Reguł”.  
Cel: wymusić ocenę umowy w kolejności odpowiadającej rzeczywistej analizie sądu, pełnomocnika procesowego, audytora transakcyjnego i osoby zarządzającej wykonaniem kontraktu.

---

## CS.0 — ZASADA HIERARCHII

Nie wszystkie uchybienia mają tę samą wagę. System ma oceniać umowę od fundamentów prawnych do jakości redakcyjnej:

1. **VALIDITY** — czy umowa istnieje i jest ważna.
2. **INTERPRETABILITY** — jak zostanie odczytana przez sąd lub kontrahenta.
3. **ENFORCEABILITY** — czy obowiązki da się wykonać i wymusić.
4. **EVIDENCE** — czy wykonanie, naruszenie, odbiór, zgoda i zmiana dadzą się udowodnić.
5. **ATTACK RESISTANCE** — jak dokument przetrwa atak przeciwnika, sądu lub regulatora.
6. **COMPLIANCE & LIFECYCLE** — czy aktywują się wymogi regulacyjne i operacyjne.
7. **DRAFTING QUALITY** — czy język i struktura są profesjonalne, spójne i użyteczne.

**Reguła nadrzędna:** uchybienie wyższego poziomu blokuje pozytywną ocenę, nawet gdy poziomy niższe są poprawne.

---

## CS.1 — MACIERZ KRYTYCZNOŚCI P0–P3

Każdą uwagę klasyfikuj według skutku prawnego, procesowego i biznesowego.

| Priorytet | Znaczenie | Typowy skutek | Decyzja kontraktowa |
|---|---|---|---|
| **P0** | wada fundamentalna | nieważność, brak essentialia, brak umocowania, sprzeczność z ustawą, niemożność wykonania | **NIE PODPISYWAĆ** bez poprawy |
| **P1** | wysokie ryzyko sporu / przegranej | nieegzekwowalność, brak dowodu, asymetria bez uzasadnienia, sprzeczność klauzul | poprawić przed podpisem / warunek negocjacyjny |
| **P2** | średnie ryzyko operacyjne | nieprecyzyjny termin, brak procedury, niepełna dokumentacja wykonania | poprawić lub zaakceptować świadomie |
| **P3** | jakość redakcyjna | język, numeracja, zbędna złożoność, styl | poprawić przy redakcji finalnej |

**Zakaz rozmywania:** P0/P1 nie wolno ukrywać jako „uwagi redakcyjnej”.

---

# POZIOM I — VALIDITY

Pytanie główne: **czy umowa w ogóle istnieje prawnie i może wywołać zamierzone skutki?**

## V1 — Essentialia negotii i minimalna treść zobowiązania

Sprawdź, czy umowa pozwala ustalić co najmniej:

- strony,
- przedmiot świadczenia,
- świadczenie wzajemne / wynagrodzenie albo mechanizm jego ustalenia,
- czas trwania albo mechanizm zakończenia,
- formę, jeżeli wymagana jest prawem lub zastrzeżona przez strony.

**FAIL/P0:** brak elementu koniecznego dla danego typu umowy albo brak możliwości ustalenia świadczenia.

## V2 — Forma prawna i rygor formy

Sprawdź, czy czynność wymaga formy szczególnej: pisemnej, dokumentowej, elektronicznej, aktu notarialnego, podpisów kwalifikowanych, zgód korporacyjnych lub formy dla przeniesienia praw.

**FAIL/P0:** naruszenie formy zastrzeżonej pod rygorem nieważności albo brak formy wymaganej dla skutku rozporządzającego.

## V3 — Umocowanie stron i reprezentacja

Sprawdź:

- KRS/CEIDG/pełnomocnictwa,
- sposób reprezentacji,
- zgody korporacyjne,
- ograniczenia prokury/pełnomocnictwa,
- podpisy załączników i aneksów.

**FAIL/P0 lub P1:** osoba podpisująca nie ma wykazanego umocowania albo zakres umocowania nie obejmuje czynności.

## V4 — Zgodność z ustawą, naturą stosunku i zasadami współżycia społecznego

Sprawdź, czy klauzula nie zmierza do obejścia prawa, nie narusza przepisów bezwzględnie obowiązujących i mieści się w granicach swobody umów.

**FAIL/P0:** klauzula sprzeczna z normą bezwzględnie obowiązującą lub obejście prawa.

## V5 — Brak niedopuszczalnego wyłączenia odpowiedzialności

Sprawdź zwłaszcza limity odpowiedzialności, wyłączenia odpowiedzialności, kary umowne, indemnity i disclaimery.

**FAIL/P0/P1:** wyłączenie odpowiedzialności za szkodę wyrządzoną umyślnie, obejście ochrony konsumenckiej, obejście prawa pracy albo przerzucenie ryzyka w sposób sprzeczny z ustawą.

---

# POZIOM II — INTERPRETABILITY

Pytanie główne: **jak sąd, kontrahent i pełnomocnik odczytają tę umowę?**

## I1 — Definicje i konsekwencja terminologiczna

Każde pojęcie pisane wielką literą powinno mieć definicję albo oczywisty sens z kontekstu. Ta sama rzecz nie może być nazywana różnymi nazwami bez powodu.

**FAIL/P1/P2:** definicje kolizyjne, martwe, nieużywane albo używane w dwóch znaczeniach.

## I2 — Jednoznaczność dyspozycji

Każda klauzula powinna dawać odpowiedź:

- kto,
- co,
- kiedy,
- komu,
- w jakiej formie,
- pod jakim warunkiem,
- z jakim skutkiem.

**FAIL/P1:** klauzula dopuszcza dwa konkurencyjne odczytania istotne dla świadczenia, ceny, odpowiedzialności lub rozwiązania umowy.

## I3 — Brak sprzeczności wewnętrznych

Sprawdź konflikt między:

- definicjami a częścią operacyjną,
- umową główną a załącznikami,
- klauzulą ogólną a szczególną,
- harmonogramem a terminami w treści,
- SLA/KPI a mechanizmem kar.

**FAIL/P1:** dwa postanowienia prowadzą do różnych rezultatów prawnych.

## I4 — Hierarchia dokumentów i lex specialis

Umowa musi wskazywać, które dokumenty mają pierwszeństwo w razie konfliktu: umowa główna, załączniki, OWU, zamówienie, oferta, SLA, DPA, SOW.

**FAIL/P1/P2:** brak hierarchii przy wielu dokumentach kontraktowych.

## I5 — Contra proferentem i ryzyko autora wzorca

Jeżeli klauzula pochodzi od jednej strony, szczególnie z wzorca/OWU/regulaminu, niejednoznaczność obciąża autora. W analizie zawsze wskaż, która strona ponosi ryzyko interpretacyjne.

**FAIL/P1:** jednostronny wzorzec zawiera niejasne obowiązki, sankcje lub ograniczenia praw drugiej strony.

## I6 — Kategoria języka kontraktowego

Rozróżniaj:

- obowiązek,
- uprawnienie,
- zakaz,
- warunek,
- deklarację faktu,
- politykę/procedurę,
- definicję,
- oświadczenie i zapewnienie.

**FAIL/P2:** klauzula miesza obowiązek z deklaracją albo uprawnienie z automatycznym skutkiem.

---

# POZIOM III — ENFORCEABILITY

Pytanie główne: **czy obowiązki da się wykonać, wymusić i rozliczyć?**

## E1 — Obowiązek mierzalny

Każdy obowiązek powinien mieć mierzalny standard wykonania: zakres, rezultat, jakość, KPI/SLA, dokumentację albo kryterium odbioru.

**FAIL/P1:** obowiązek jest deklaracją bez kryterium weryfikacji.

## E2 — Termin mierzalny

Termin powinien być datą, liczbą dni, zdarzeniem obiektywnie weryfikowalnym albo mechanizmem ustalenia terminu.

**FAIL/P1/P2:** „niezwłocznie”, „w rozsądnym terminie”, „jak najszybciej” bez doprecyzowania przy obowiązku istotnym.

## E3 — Sankcja określona i proporcjonalna

Sankcja powinna wynikać z konkretnego naruszenia, mieć sposób obliczenia i relację do wartości ryzyka.

**FAIL/P1:** kara za naruszenie niepieniężne opisana zbyt szeroko, sankcja rażąco asymetryczna albo brak mechanizmu naliczania.

## E4 — Procedura wykonania i eskalacji

Dla obowiązków krytycznych musi istnieć procedura: zgłoszenie, termin reakcji, osoba/kanał, akceptacja, reklamacja, cure period, eskalacja, rozwiązanie umowy.

**FAIL/P1/P2:** brak procedury przy SLA, odbiorach, zmianach zakresu, reklamacjach, naruszeniach bezpieczeństwa.

## E5 — Mechanizmy wyjścia

Umowa długoterminowa musi mieć jasne zasady zakończenia: wypowiedzenie zwykłe, nadzwyczajne, skutki rozwiązania, rozliczenie, zwrot materiałów, ciągłość usług, migracja danych.

**FAIL/P1:** brak realnej ścieżki wyjścia albo jednostronny lock-in bez uzasadnienia.

---

# POZIOM IV — EVIDENCE

Pytanie główne: **jak udowodnić wykonanie, naruszenie, odbiór, zgodę i zmianę?**

## D1 — Dowód wykonania

Każde istotne świadczenie powinno mieć dowód wykonania: protokół, raport, log, e-mail, potwierdzenie w systemie, repozytorium, metadane, billing, ticket.

**FAIL/P1:** obowiązek istotny ekonomicznie bez przewidzianego śladu dowodowego.

## D2 — Dowód odbioru / akceptacji

Odbiór powinien mieć formę, termin, kryteria, procedurę zastrzeżeń i skutek milczenia, jeżeli strony chcą go wprowadzić.

**FAIL/P1:** brak procedury odbioru przy dziele, projekcie IT, wdrożeniu, pracach budowlanych, deliverables.

## D3 — Dowód zgłoszenia i doręczenia

Umowa powinna określać kanały doręczeń, skuteczność doręczenia, adresy, osoby kontaktowe, zmianę adresu, doręczenia elektroniczne i awarie kanału.

**FAIL/P1:** roszczenia zależą od zawiadomienia, ale brak reguł doręczenia.

## D4 — Dowód zgody, akceptacji i change request

Zmiany zakresu, ceny, terminu, odbioru, odstępstw i waiverów muszą mieć ślad: podpis, e-mail z autoryzowanego adresu, system ticketowy, aneks, CR.

**FAIL/P1:** strony mogą faktycznie zmienić zakres bez śladu umożliwiającego rozliczenie.

## D5 — Ciężar dowodu i dostęp do danych

Sprawdź, kto realnie będzie posiadał dowody i czy druga strona ma do nich dostęp. W razie asymetrii dodaj obowiązek archiwizacji i udostępnienia.

**FAIL/P1:** dowody są wyłącznie u strony przeciwnej bez obowiązku przechowania/udostępnienia.

## D6 — Retencja dokumentów i ślad audytowy

Dla umów długoterminowych, regulowanych lub technologicznych określ minimalny okres przechowywania dokumentów, logów, raportów i akceptacji.

**FAIL/P2/P1:** brak retencji przy sporze wysokiego ryzyka albo compliance.

---

# POZIOM V — ATTACK RESISTANCE

Pytanie główne: **jak dokument zostanie zaatakowany przez przeciwnika, sąd albo regulatora?**

## A1 — Test pełnomocnika przeciwnika

Dla klauzul istotnych wskaż najprostszy atak drugiej strony:

- nieważność,
- abuzywność,
- brak uzgodnienia,
- niejednoznaczność,
- brak dowodu,
- brak proporcjonalności,
- sprzeczność z dokumentami towarzyszącymi.

**FAIL/P1:** istnieje prosty, wiarygodny atak bez kontrargumentu w treści umowy.

## A2 — Test sędziego

Sprawdź, co sąd najpewniej uzna za udowodnione wyłącznie z dokumentu i typowego materiału dowodowego. Nie zakładaj idealnej współpracy świadków.

**FAIL/P1:** wynik sprawy zależy głównie od zeznań, mimo że można było zbudować dowód dokumentowy.

## A3 — Test regulatora / organu

Jeżeli aktywuje się B2C, PZP, RODO, AI, ESG, AML, cyber, prawo pracy, konkurencja lub sektor regulowany — sprawdź, jak organ oceni klauzulę.

**FAIL/P0/P1:** klauzula naraża na sankcję administracyjną, rejestr klauzul niedozwolonych, kontrolę lub decyzję regulatora.

## A4 — Test obejścia prawa i pozorności

Sprawdź, czy konstrukcja nie maskuje stosunku pracy, omija ochrony konsumenta, przerzuca ustawowych obowiązków albo tworzy pozorną niezależność.

**FAIL/P0/P1:** forma kontraktu jest sprzeczna z rzeczywistym modelem wykonywania.

## A5 — Test nadużycia prawa i proporcjonalności

Sprawdź, czy strona silniejsza nie uzyskuje uprawnienia, które formalnie mieści się w umowie, ale w praktyce może być nadużyciem.

**FAIL/P1/P2:** jednostronna, niekontrolowana swoboda zmiany ceny, zakresu, sankcji, regulaminu lub standardu świadczenia.

---

# POZIOM VI — COMPLIANCE & LIFECYCLE

Pytanie główne: **czy aktywują się wymogi regulacyjne i czy umowę da się obsłużyć po podpisaniu?**

## C1 — Compliance aktywowany, nie domyślny

RODO, ESG, AI Act, cyber, PZP, B2C, AML, sankcje, sektor finansowy, ubezpieczenia, prawo pracy i konkurencja uruchamiaj tylko wtedy, gdy wynikają z typu umowy, stron, danych, branży albo przedmiotu świadczenia.

**FAIL/P1:** aktywna regulacja została pominięta.

## C2 — Lifecycle: kalendarz obowiązków

Dla umowy po analizie wygeneruj listę terminów, powiadomień, przeglądów, renewali, okresów wypowiedzenia, obowiązków raportowych, retencji i warunków rozwiązania.

**FAIL/P2/P1:** umowa jest formalnie dobra, ale niewykonalna operacyjnie bez ręcznego monitoringu.

## C3 — Governance i odpowiedzialność operacyjna

Wskaż właściciela obowiązku po stronie klienta: prawny, finansowy, HR, IT, compliance, sprzedaż, zarząd.

**FAIL/P2:** brak przypisania odpowiedzialności za obowiązki krytyczne.

---

# POZIOM VII — DRAFTING QUALITY

Pytanie główne: **czy dokument jest napisany jasno, spójnie i profesjonalnie?**

## Q1 — Plain language bez utraty precyzji

Upraszczaj język, ale nie kosztem skutku prawnego. Jeżeli prostsze brzmienie pogarsza mierzalność albo egzekwowalność, pierwszeństwo ma precyzja.

## Q2 — Aktywne zdania i jasny podmiot

Preferuj: „Wykonawca zapłaci”, „Zamawiający przekaże”, „Strony podpiszą”. Unikaj konstrukcji bezosobowych przy obowiązkach.

## Q3 — Spójność struktury i odesłań

Weryfikuj numerację, załączniki, definicje, cross-reference, tabele, harmonogramy i wersje dokumentów.

## Q4 — Minimalizm bez luk

Usuń powtórzenia i deklaracje bez skutku, ale nie usuwaj procedur dowodowych, odbiorowych, sankcyjnych i compliance.

---

# CS.2 — OBOWIĄZKOWY FORMAT UŻYCIA W RAPORCIE

Dla każdej istotnej uwagi stosuj format:

```text
[CS: poziom/reguła] [Priorytet: P0/P1/P2/P3]
Ustalenie: ...
Ryzyko: ...
Dlaczego to ma znaczenie: ...
Rekomendacja: ...
Proponowana klauzula / poprawka: ...
Dowód/źródło weryfikacji: ...
```

Przykład:

```text
[CS: D2 — dowód odbioru] [Priorytet: P1]
Ustalenie: Umowa przewiduje odbiór prac, ale nie określa terminu na zgłoszenie zastrzeżeń ani skutku milczenia.
Ryzyko: Spór o wymagalność wynagrodzenia i datę wykonania.
Rekomendacja: Dodać procedurę odbioru z terminem, kanałem, kryteriami i skutkiem braku zastrzeżeń.
```

---

# CS.3 — WPŁYW NA SCORECARD

Standard CS koryguje wynik końcowy silniej niż dotychczasowe ZR:

| Naruszenie | Maksymalny wynik | Maksymalny grade |
|---|---:|---|
| dowolny nierozwiązany **P0** | 49 | D / NO-GO |
| ≥2 nierozwiązane **P1** | 69 | C / podpis warunkowy tylko po decyzji ryzyka |
| 1 nierozwiązane **P1** | 79 | B- |
| ≥5 nierozwiązanych **P2** | 84 | B |
| wyłącznie P3 | brak twardego limitu | zależnie od jakości |

**Reguła decyzyjna:** wynik 85+ jest możliwy tylko, gdy brak P0 i brak nierozwiązanych P1.

---

# CS.4 — TRYBY PRACY

## Pełna analiza umowy

Obowiązkowo zastosuj wszystkie poziomy CS.1–CS.7, ale compliance tylko w zakresie aktywowanym.

## Poprawa fragmentu

Minimum: Interpretability, Enforceability, Evidence, Drafting Quality oraz Attack Resistance dla klauzul wysokiego ryzyka.

## Generowanie umowy

Najpierw VALIDITY i Essentialia, potem Enforceability/Evidence, dopiero potem styl.

## Warianty A/U/M

Każdy wariant oznacz:

- agresywny — wyższa ochrona jednej strony, ale możliwy wzrost A1/A5,
- umiarkowany — najlepszy bilans egzekwowalności i akceptowalności,
- minimalny — najprostszy, ale nie może schodzić poniżej V/E/D minimum.

## Devil's Advocate / Contract Attack Simulation

Atak ma być mapowany bezpośrednio do A1–A5 oraz odpowiednich V/I/E/D.

---

# CS.5 — MAPOWANIE NA MODUŁY SYSTEMU

| Poziom CS | Moduły wspierające |
|---|---|
| VALIDITY | CORE, WYKLADNIA, moduły domenowe, HARD GATE |
| INTERPRETABILITY | WYKLADNIA, SPOJNOSC-ODESLAN, ALT-DRAFTS |
| ENFORCEABILITY | ENFORCEABILITY, CORE, RYZYKO-KWANT |
| EVIDENCE | EVIDENCE-READINESS, LIFECYCLE, analiza sądowa systemowa |
| ATTACK RESISTANCE | DEVIL-ADVOCATE, CONTRACT-ATTACK-SIMULATION, analiza sądowa systemowa |
| COMPLIANCE & LIFECYCLE | RODO, AI-ACT, ESG, PZP, B2C, LIFECYCLE |
| DRAFTING QUALITY | ALT-DRAFTS, SPOJNOSC-ODESLAN, baza klauzul |

---

# CS.6 — ŹRÓDŁA METODOLOGICZNE I WERYFIKACYJNE

Moduł nie cytuje przepisów z pamięci. Przed podaniem treści przepisu lub sygnatury stosuj globalny HARD GATE.

Źródła metodologiczne użyte przy konstrukcji standardu:

- ISAP — Kodeks cywilny: swoboda umów, wykładnia oświadczeń woli, odpowiedzialność kontraktowa, forma czynności.
- ISAP — Kodeks postępowania cywilnego: ciężar dowodzenia w praktyce procesowej i znaczenie dowodów dokumentowych.
- UOKiK — rejestr klauzul niedozwolonych i materiały o wzorcach umownych.
- Practical Law / Thomson Reuters — podejście checklistowe do planowania, redakcji, interpretacji i boilerplate clauses.
- Ken Adams / A Manual of Style for Contract Drafting — rozróżnienie kategorii języka kontraktowego.
- Repozytorium commercial-legal-pl — baza klauzul i workflow redakcyjne jako warstwa pomocnicza, nie nadrzędna.

---

# CS.7 — ZASADA KOŃCOWA

Dobra umowa nie jest tylko jasna. Dobra umowa jest:

1. ważna,
2. interpretowalna,
3. egzekwowalna,
4. dowodowalna,
5. odporna na atak,
6. zgodna regulacyjnie,
7. operacyjnie obsługiwalna,
8. dopiero na końcu elegancko napisana.

Jeżeli te wartości są w konflikcie, kolejność powyżej rozstrzyga priorytet.
