# Analizator Umów v2.2 — Contract Standard Edition

## Cel wersji

Wersja v2.2 zastępuje wcześniejsze „Złote Reguły” hierarchicznym standardem oceny umów.

Nowy standard porządkuje analizę według kolejności:

1. VALIDITY — ważność i istnienie umowy,
2. INTERPRETABILITY — interpretacja przez sąd i strony,
3. ENFORCEABILITY — wykonalność i egzekwowalność,
4. EVIDENCE — dowodowalność wykonania i naruszeń,
5. ATTACK RESISTANCE — odporność na atak przeciwnika, sądu i regulatora,
6. COMPLIANCE & LIFECYCLE — regulacje i obsługa po podpisaniu,
7. DRAFTING QUALITY — jakość redakcyjna.

## Najważniejsza zmiana

Nie wszystkie błędy są równe. W v2.2 każda uwaga otrzymuje priorytet:

- P0 — wada fundamentalna,
- P1 — wysokie ryzyko sporu,
- P2 — średnie ryzyko operacyjne,
- P3 — redakcja.

## Główny plik modułu

`references/mod-shared-contract-standard-v2.md`

## Decyzja końcowa

Scorecard został dostosowany do standardu P0–P3. Wynik 85+ jest możliwy tylko przy braku P0 i nierozwiązanych P1.
