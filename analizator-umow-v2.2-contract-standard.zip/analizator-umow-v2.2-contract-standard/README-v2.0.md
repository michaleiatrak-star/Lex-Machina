# Analizator Umów v2.0 — wersja procesowo-dowodowa

Ta wersja rozszerza v1.7 o cztery moduły, które wzmacniają analizę umów pod kątem przyszłego sporu, egzekwowalności i realnej użyteczności dowodowej.

## Nowe moduły

1. `references/mod-shared-evidence-readiness.md`  
   Gotowość dowodowa: doręczenia, odbiory, logi, płatności, change request, archiwizacja, ciężar dowodu.

2. `references/mod-shared-enforceability.md`  
   Test: ważność → skuteczność → wykonalność → egzekwowalność.

3. `references/mod-shared-contract-attack-simulation.md`  
   Symulacja profesjonalnego ataku procesowego na umowę: nieważność, bezskuteczność, abuzywność, contra proferentem, brak dowodu, miarkowanie.

4. `references/mod-shared-scorecard.md`  
   Końcowa ocena 0–100, grade A–F oraz decyzja: podpisać / negocjować / odrzucić.

## Nowy workflow pełnej analizy

```text
TRIAGE → CORE-CHECKLIST → MODUŁ DOMENOWY → EVIDENCE-READINESS →
ENFORCEABILITY → RYZYKO-KWANT → CONTRACT-ATTACK-SIMULATION →
DEVIL-ADVOCATE → NEGOCJACJE → LIFECYCLE → SCORECARD → RAPORT
```

## Najważniejsza zmiana metodologiczna

Umowa nie jest oceniana tylko pod kątem poprawności prawnej. System wymusza także ocenę:

- czy klauzula da realny skutek,
- czy da się udowodnić fakty potrzebne do jej użycia,
- jak druga strona zaatakuje klauzulę w sporze,
- czy rekomendacja końcowa jest obroniona liczbowym scorecardem.

## Zakaz uproszczonej rekomendacji

Pełna rekomendacja „podpisywalna” wymaga wykonania co najmniej:

```text
CORE + EVIDENCE-READINESS + ENFORCEABILITY + SCORECARD
```
