# ONLINE VERIFICATION — v2.2

Data: 2026-06-07

Weryfikacja online została wykonana dla metodologii i punktów kontrolnych użytych w Contract Standard v2.2.

## Źródła sprawdzone

1. ISAP — Kodeks cywilny, tekst ujednolicony, Dz.U. 1964 nr 16 poz. 93.
2. ISAP — Kodeks postępowania cywilnego, tekst ujednolicony, Dz.U. 1964 nr 43 poz. 296.
3. ISAP — ustawa o prawach konsumenta, tekst ujednolicony, Dz.U. 2014 poz. 827.
4. UOKiK — strona o niedozwolonych klauzulach.
5. Rejestr UOKiK — rejestr klauzul niedozwolonych.
6. Practical Law / Thomson Reuters — Effective Commercial Contract Drafting oraz materiały o boilerplate clauses.

## Wniosek

Standard v2.2 jest spójny z praktyczną kolejnością audytu kontraktu: najpierw ważność i skuteczność, następnie interpretacja, egzekwowalność, dowodowalność, odporność na atak, compliance i dopiero na końcu jakość redakcyjna.

Moduł nie zawiera fikcyjnych sygnatur ani nieweryfikowanych cytatów przepisów. Jeżeli w przyszłej analizie użytkownik oczekuje cytowania przepisu albo orzeczenia, nadal obowiązuje globalny HARD GATE i weryfikacja w aktualnym źródle urzędowym.
