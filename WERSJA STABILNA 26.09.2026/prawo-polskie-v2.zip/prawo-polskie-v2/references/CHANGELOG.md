# CHANGELOG — prawo-polskie-v2

- 6.30 (2026-09-23, AUDYT-2026-09-23b): Zasady workflow i sekcja Weryfikacja: ISAP → kanon E-1…E-5; ROUTING-MAP: instrukcje „weryfikuj w ISAP” → ELI (RZĄD 1); wpisy historyczne bez zmian.
- 6.29 (2026-09-22, F-195): ROUTING-MAP — wiersz MONITORING Ordynacji podatkowej: zamiast ⬛ sześć nowelizacji po t.j. 2026/622 z terminami z artykułów końcowych (RZĄD 1 ELI): 825 — 24.09.2026, 846 — 1.10.2026, 1154 — 16.09.2026 (w mocy), 875 i 1098 — 1.01.2027, 1206 — 11.01.2027. ⛔ 875, 1098, 1206 nie występowały wcześniej w żadnym rejestrze systemu.
- 6.28 (2026-09-22, F-195): ROUTING-MAP — tabela MONITORING przejrzana przez artykuły końcowe w ELI (RZĄD 1): KPK 2026/638 (w mocy 28.05.2026) i PrBud 2025/1847 art. 1 pkt 1 i 3 (w mocy 20.09.2026) usunięte; wiersz DR-03 KPK 2026.638 uzupełniony o stan; 2026/516 — reszta ustawy od 30.04.2026 (nie 16.04.2026); OP 2026/622 oznaczona ⬛ (t.j., nie nowelizacja; terminy bez źródła). Licznik zbiorczy nieprzeliczany — adnotacja pod licznikiem.
- 6.27 (2026-09-22, F-193): ROUTING-MAP — wiersz ustawy zasiłkowej (t.j. 2026/854): dopisana cezura 1.01.2027 dla art. 17 ust. 1d–1e (L4 z jednego tytułu) i art. 9 ust. 4 wprowadzonych Dz.U. 2026 poz. 26; art. 17 ust. 1–1c od 13.04.2026 (RZĄD 1 ELI, art. 43 ustawy). Kolejność wg reguły użytkownika: mapa zbiorcza przed modułami DR.
- 6.26 (2026-09-16, F-189): ROUTING-MAP — wiersz alkohol/tytoń: t.j. ustawy tytoniowej `2024/1162` → `2026/1214` (ogłoszony 16.09.2026; T15 NEWER_TJ; RZĄD 1).
- 6.25 (2026-09-16, F-189): ROUTING-MAP — ustawa o przeciwdziałaniu przemocy domowej: wygasły t.j. `2021/1249` → `2024/1673` w dwóch wierszach (KK art. 207; przemoc domowa szczegółowo) — RZĄD 1; T27.
- 6.24 (2026-09-16, F-189): ROUTING-MAP — T31 (RZĄD 1): PODMIANY AKTU usunięte w 5 wierszach (UOKiK → 2025/1714; Prawo energetyczne → 2026/43; „Prawo gazowe” → Prawo energetyczne 2026/43; charakterystyka energetyczna → 2024/101; rolnictwo ekologiczne → 2023/1235); nazwy wierszy poprawione (ustawa o zapewnianiu dostępności 2024/1411; PUSP + ustawa o kuratorach sądowych 2026/200); nowy wiersz — ustawa o opłacie skarbowej (2025/1154).
- 6.23 (2026-09-16, F-189): ROUTING-MAP — wiersze F-190: podatek od kopalin → nowy moduł dr-06; poz. 516 → sekcja w dr-09 (pokryte); działalność lecznicza — numer t.j. w modułach dr-10. Znacznik T28-OK przy wierszu dokumentującym podmianę aktu.
- 6.22 (2026-09-16, F-189): ROUTING-MAP — T5 widmowe pokrycie (AUDYT-2026-09-16b), RZĄD 1 ELI: 11 wskaźników przepiętych na moduły z treścią; ⛔ podmiany aktu: podatek od wydobycia kopalin `2024/44` (t.j. ustawy o rehabilitacji) → `2026/454`, `2024/1564` to Prawo o adwokaturze (wiersz łączył ją z zawodami medycznymi); tytuł „ustawa o ubezpieczeniach obowiązkowych lekarzy” → ustawa o ubezpieczeniach obowiązkowych, UFG i PBUK; `2026/638` KPK — w mocy od 28.05.2026; widma oznaczone (kopaliny, `2026/516`).
- 6.21 (2026-09-16, F-189): T12: pole YAML `changelog:` (numer 6.18 przy version 6.20) skrócone do odesłania (ZASADA 15). Treść bez zmian.
- 6.20 (2026-09-13b): ROUTING-MAP — do wierszy PPWR i EUDR dopisane wyniki weryfikacji uzupelniajacej. PPWR: ustawa o gospodarce opakowaniami (Dz.U. 2026 poz. 619 t.j.) NIE ZOSTALA dostosowana - zero nowelizacji po t.j. z 30.04.2026, ostatnia zmiana z 9.01.2026 dotyczy systemu kaucyjnego bez odeslan do rozp. 2025/40; luka w egzekwowaniu, nie w obowiazku. EUDR: przeszukanie ELI po tytule dalo zero polskich aktow - wynik negatywny wylacznie w zakresie tytulu, do monitorowania blizej 30.12.2026
- 6.19 (2026-09-13): ROUTING-MAP — dopisane do sekcji DR-09 dwa ROZPORZADZENIA UE BEZPOSREDNIO STOSOWANE: PPWR (UE) 2025/40, CELEX 32025R0040, stosuje sie od 12.08.2026 (juz obowiazuje), uchyla dyrektywe 94/62/WE; EUDR (UE) 2023/1115, CELEX 32023R1115, wersja skonsolidowana 02023R1115-20251226, data stosowania 30.12.2026 / 30.06.2027 dla mikro i malych przedsiebiorstw. EUDR dopisany takze do tabeli MONITORING jako akt jeszcze niestosowany (⏳ OCZEKUJE) z ostrzezeniem o DWUKROTNYM przesunieciu daty. Zaktualizowany licznik DR-09 (27 -> 29 aktow, razem 31) i slowa kluczowe routingu (9 -> 11). Oba akty ✅ VER RZAD 1 2026-09-13 przez EUR-Lex
- 6.18 (2026-09-10r, O-10): cezury czasowe dla 2026/346 (w zycie 30.09.2028) i zwolnienia grupowe 2025/570 na 2026/1195
- 6.17 (2026-09-10q, F-135): ROUTING-MAP: wiersz KP art. 94 par. 3 opatrzony cezura czasowa reformy antymobbingowej - vacatio legis do 4.11.2026
- 6.16 (2026-09-10o, F-181): ROUTING-MAP: ARiMR 2025/1363 na 2026/942 (RZAD 1)
- 6.15 (2026-09-10j): ROUTING-MAP:685 — nazwa i łańcuch przepisane po wykryciu DWÓCH PODMIAN AKTU (2022/2162 opisane jako nowa ustawa o medycynie laboratoryjnej, a jest t.j. STAREJ ustawy z 2001; 2023/1517 opisane jako stara ustawa, a jest rozporządzeniem MSWiA)
- 6.14 (2026-09-10i): ROUTING-MAP:646 — PODWÓJNY BŁĄD skorygowany: wiersz delegowania kierowców twierdził „brak t.j." i opisywał Dz.U. 2025 poz. 797 jako nowelizację; 2025/797 JEST tekstem jednolitym tej ustawy (✅ RZĄD 1)
- 6.13 (2026-09-10h): ROUTING-MAP: wiersz ustawy refundacyjnej uzupełniony o KROK 2C (Dz.U. 2026 poz. 791) i o wskazanie kanałów wykazu leków refundowanych — wykaz NIE jest aktem Dz.U.
- 6.12 (2026-09-10g): ROUTING-MAP — wiersz „POŚ Szczegóły" rozstrzygnięty; zakres modułu ustalony jako warstwa proceduralna, akty (UOOŚiS 2026/670, POŚ 2025/647, ochrona przyrody 2026/13, KK 2025/383, KPA 2025/1691) zweryfikowane w RZĘDZIE 1 z listami nowelizacji po tekstach jednolitych
- 6.11 (2026-09-10f): ROUTING-MAP: domknięte 13 pozycji oznaczonych do weryfikacji po odczycie RZĄD 1. TRZECI BŁĄD PODMIANY AKTU skorygowany — „ustawa antylichwiarska Dz.U. 2023 poz. 1028" to wygasły t.j. ustawy o KREDYCIE KONSUMENCKIM; poprawnie Dz.U. 2022 poz. 2339. Zamknięty sygnał ❌ NUMER BŁĘDNY przy KPK. Antymobbingowa 2026/1046 podniesiona z RZĘDU 2B do RZĘDU 1. Dopisane listy nowelizacji po tekście jednolitym (KK 4, KPK 5, VAT 5, antykorupcyjna 2, trzeźwość 2, UDIP 1, łowieckie 1, zarządzanie kryzysowe 1)
- 6.10 (2026-09-10e): ROUTING-MAP: +2 wiersze (przekształcenie UW 2005 i 2018) oraz nowa sekcja nagłówkowa KOLEJNOŚĆ AKTUALIZACJI REJESTRÓW — praca idzie od źródła urzędowego przez mapę zbiorczą do modułów DR, przy zachowaniu zakazu traktowania ROUTING-MAP jako źródła weryfikacji (F-141)
- 6.9 (2026-09-10d, F-148a/F-135/F-141): ROUTING-MAP: 9 wierszy rozstrzygniętych w RZĘDZIE 1 (F-135, F-141), 1 błąd podmiany aktu skorygowany (F-148a: ustawa antyterrorystyczna 2024/1474 → 2025/194)
- 6.8 (2026-09-01i, flaga F-155): **propagacja trzech korekt tekstów jednolitych do mapy
  centralnej.** Ustawa o świadczeniu wspierającym: Dz.U. 2023 poz. 1429 → **Dz.U. 2026 poz. 873 t.j.**;
  ustawa o wyrobach medycznych (dwa wiersze, w tym jeden z adnotacją „zweryfikuj t.j. na ISAP"):
  → **Dz.U. 2024 poz. 1620 t.j.**; ustawa „Aktywny Rodzic": zapis „brak dotąd ogłoszonego t.j.,
  cytować jako Dz.U. 2024 poz. 858 ze zm." był NIEAKTUALNY, a poz. **2026.532** figurowała tam
  BŁĘDNIE wśród nowelizacji — to obwieszczenie z 27.03.2026 ogłaszające tekst jednolity
  ✅ [VER: api.sejm.gov.pl/eli, 2026-09-01]. Wykryte przeglądem 16 map w żywym ELI; T3 wyłapał
  rozjazd mapy lokalnej z centralną po poprawieniu map dziedzinowych.
- 6.7 (2026-08-28) — domknięto F-108 do **52/52 B+/COV**: centralny routing wskazuje current-state indeksy KW, SUS, ustawy zasiłkowej i zwolnień grupowych; KW otrzymał także fizyczny moduł brakującego zakresu art. 65–69. `COV` pozostaje rozdzielone od `FULL`, a konkretna jednostka nadal podlega fresh/temporal gate.

- 6.6 — F-108 P1: zarejestrowano osobne moduły UFG/PBUK, opłat w sprawach karnych i fundacji rodzinnej; rozdzielono błędnie połączone metryki KC (Dz.U. 2026 poz. 795) i ustawy UFG/PBUK (Dz.U. 2026 poz. 783). (2026-08-27)

- 6.5 — F-108/46: rejestracja modułu DR-02; historycznych liczników nie przedstawia się jako pomiaru aktualnego pokrycia. (2026-08-27)

- 6.4 (2026-08-26): skorygowano fałszywe metryki PUSA (`2024/1297` →
  `2024/1267`), POŚ (`2026/670`, akt OOŚ → `2025/647` t.j. POŚ), Prawa
  lotniczego i ustawy o timeshare; dodano routing zakresów F-86.
- 6.3 (2026-08-26): zsynchronizowano ROUTING-MAP z aktualnymi tekstami
  jednolitymi i centralną mapą Dz.U.; usunięto luki wykryte przez T11.

> Lokalizacja kanoniczna historii wersji tego skilla (ZASADA 15 w
> `audyt-systemu-v4/SKILL.md`). Plik założony 2026-08-23g przy okazji naprawy
> F-123 — skill był na wersji 6.1 bez żadnego pliku historii i bez pola
> `changelog:` w YAML.
>
> ⛔ **LUKA JAWNA — wersje 1.x–6.1 NIE zostały odtworzone.** Nie ma ich w żadnym
> pliku tego skilla; jedynym śladem jest `audyt-systemu-v4/references/AUDIT-JOURNAL.md`.
> Odtwarzanie ich z pamięci byłoby zmyślaniem — dokładnie ten błąd, który w sesji
> 2026-08-20z3 (F-102) groził dopisaniem pięciu nieistniejących wpisów do
> `pisma-procesowe-v3`. Kto potrzebuje historii sprzed 6.2: `grep -n "prawo-polskie-v2"
> audyt-systemu-v4/references/AUDIT-JOURNAL.md`.

- 6.2 (2026-08-23g, sesja audytowa audyt-systemu-v4, flaga F-123): zapisana
  DECYZJA o zakresie `shared/PRAWO-HARDGATE.md` w tym skillu. Rozstrzygnięcie
  rozdzielne: `SKILL.md` — bramka NIE obowiązuje (czysta fasada routingu, nie
  twierdzi nic o treści prawa, bramka odpala się w DR-skillu, w którym przepis
  faktycznie pada); `ROUTING-MAP.md` — podlega reżimowi mapy (FAZA 3 A–D +
  ZASADA 8 + REGUŁA 3), bo nosi numery i statusy Dz.U., czyli weryfikowalne
  twierdzenia o stanie prawnym, a błędny numer propaguje się w każdą sprawę
  przechodzącą przez ten routing (klasa F-82). Dopisany wyzwalacz wygaśnięcia
  decyzji: pierwsze twierdzenie o TREŚCI prawa w którymkolwiek pliku skilla
  przywraca obowiązek bramki. Powód zapisania decyzji, a nie samego jej
  podjęcia: bez utrwalenia ten sam pomiar `grep` wracałby jako nowe zgłoszenie
  w każdym kolejnym audycie. Przy okazji: stopka przestała nieść własny numer
  wersji (niosła „5.2" przy `version: 6.1` — rozjazd o dziewięć wersji),
  zgodnie z decyzją generalną F-102(C); `version` ujęty w cudzysłów
  (profilaktyka pułapki float, F-102(B)). Pełny opis:
  `audyt-systemu-v4/references/AUDIT-JOURNAL.md`, wpis AUDYT-2026-08-23g.
