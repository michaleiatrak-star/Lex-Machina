# Moduł — Fundusz Sprawiedliwości / pomoc pokrzywdzonym

## Akt prawny
**Ustawa z 07.07.2005 r. o państwowej kompensacie przysługującej ofiarom niektórych przestępstw**
- Dz.U. 2016 poz. 325 (t.j.)
  ✅ VER: isap.sejm.gov.pl [2026-05-31] — weryfikuj aktualny t.j.

**Fundusz Sprawiedliwości (Fundusz Pomocy Pokrzywdzonym oraz Pomocy Postpenitencjarnej):**
- Rozporządzenie MS z 13.09.2017 r. w sprawie Funduszu Pomocy Pokrzywdzonym oraz Pomocy
  Postpenitencjarnej – Funduszu Sprawiedliwości — **t.j. Dz.U. 2025 poz. 1298**
  ✅ [VER] RZĄD 1 2026-09-16 (ELI: t.j. obowiązujący; pierwotny Dz.U. 2017 poz. 1760 ma status
  „akt posiada tekst jednolity" — powoływać t.j.)

**Weryfikacja: ELI (RZĄD 1) i sprawiedliwosc.gov.pl/fundusz-sprawiedliwosci**

## Zakres — Kompensata państwowa
Ofiara może otrzymać kompensatę od Skarbu Państwa gdy:
1. Poniosła uszczerbek na zdrowiu lub śmierć w wyniku przestępstwa popełnionego umyślnie z użyciem przemocy
2. Sprawca jest nieznany, niewypłacalny lub sąd umorzył postępowanie
3. Wniosek złożono w TERMINIE PODWÓJNYM (⚠️ POPRAWKA 2026-07-27,
   FAZA 3E/ZASADA 14 — poprzednia wersja upraszczała do "3 lata od
   przestępstwa"): 3 LATA od dnia UJAWNIENIA SIĘ SKUTKÓW przestępstwa,
   NIE PÓŹNIEJ jednak niż w terminie 5 LAT od dnia jego POPEŁNIENIA —
   pod rygorem wygaśnięcia uprawnienia. Potwierdzone w 3+ zgodnych
   źródłach (spes.org.pl, gov.pl/po-suwalki, arch.ms.gov.pl)

**Wysokość:** do 25 000 zł (uszczerbek) lub do 60 000 zł (śmierć osoby bliskiej).

## Fundusz Sprawiedliwości
Fundusz celowy MF/MS finansuje:
- Pomoc pokrzywdzonym i świadkom (prawna, psychologiczna, materialna)
- Instytucje Centrum Pomocy Rodzinom i Osobom Pokrzywdzonym Przestępstwem
- Pomoc postpenitencjarną dla byłych skazanych

## Zasady absolutne
```
Kompensata: Subsydiarna — po wyczerpaniu innych źródeł odszkodowania
Termin: PODWÓJNY — 3 lata od ujawnienia się skutków, max 5 lat od czynu (prekluzja!)
Wniosek: Sąd rejonowy miejsca zamieszkania wnioskodawcy
```
## Weryfikacja online
```
web_search: "kompensata państwowa ofiara przestępstwa ustawa Dz.U. 2016 poz. 325"
web_search: "Fundusz Sprawiedliwości pomoc pokrzywdzonym 2025 wniosek"
```
