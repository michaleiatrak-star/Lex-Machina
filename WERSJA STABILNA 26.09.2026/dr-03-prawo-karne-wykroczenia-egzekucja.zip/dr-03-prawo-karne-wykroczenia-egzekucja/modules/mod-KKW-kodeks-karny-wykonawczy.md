# mod-KKW-kodeks-karny-wykonawczy.md — Kodeks karny wykonawczy

✅ NAPRAWA 2026-08-14 (F-75): plik od utworzenia (2026-05-28) nosił
WEWNĘTRZNĄ nazwę "mod-BZ-sluzba-wiezienna-wykonawcze.md" niezgodną z
nazwą na dysku — naprawione. WAŻNIEJSZE: moduł nie zawierał ANI JEDNEGO
artykułu KKW (potwierdzone raportem zewnętrznym, `references/raporty-
pokrycia-2026-08-13/raport-pokrycia-KKW.md`) — był czysto generycznym
szablonem proceduralnym. Sekcje 1-12 PONIŻEJ (oryginalna treść) zostały
ZACHOWANE jako użyteczna warstwa strategiczna, ale POPRZEDZONE nową
sekcją 0 z realną treścią merytoryczną trzech najpilniejszych instytucji
KKW wskazanych przez raport.

Status: moduł prawa polskiego klasy wzorcowej. Stan metodyczny: 2026-05-28
(sekcje 1-12), 2026-08-14 (sekcja 0, nowa). Źródła prawa muszą być
każdorazowo weryfikowane w ELI (RZĄD 1) / Dzienniku Ustaw; LEX/Legalis
dopuszczalne pomocniczo przy braku praktycznego dostępu do aktu albo
dla komentarza.

> ⛔ HARDGATE — zweryfikuj aktualny t.j. na ISAP. Akt bazowy: KKW,
> Dz.U. 2025 poz. 911 t.j.

---

## 0. TREŚĆ MERYTORYCZNA KKW (nowa sekcja 2026-08-14, F-75) — trzy
priorytetowe instytucje zweryfikowane 6+ zgodnymi źródłami (lexlege.pl,
arslege.pl, gofin.pl, e-prawnik.pl, kancelarie: rajewiczjakub.pl,
adwokatpatrycjazielinska.pl, adwokatmdp.pl, ryszardkalisz.pl,
radcaslask.pl, palestra.pl)

### 0.1. WARUNKOWE PRZEDTERMINOWE ZWOLNIENIE (Oddział 11, art. 159-163)
— ⭐⭐⭐ najwyższy priorytet praktyczny, kancelaria ma już doświadczenie
z tą instytucją (sprawa Marek Petelski — art. 161 § 4, ryzyko
6-miesięcznego okresu przed ponownym wnioskiem)

```
⭐ PRZESŁANKI MATERIALNE (art. 77-82 KK, poza zakresem tego modułu —
  już opisane w mod-KK-art69-84-warunkowe-zawieszenie-zwolnienie.md):
  pozytywna prognoza kryminologiczna po odbyciu wymaganego minimum
  kary. TEN moduł pokrywa WYŁĄCZNIE stronę proceduralną z KKW.

⭐⭐⭐ ART. 161 §1-2 — KTO MOŻE ZŁOŻYĆ WNIOSEK: skazany, jego obrońca,
  DODATKOWO (§2) dyrektor zakładu karnego LUB sądowy kurator zawodowy
  (⭐ krąg SZERSZY niż tylko sam skazany/obrońca)

⭐⭐⭐ ART. 161 §3-4 — TERMIN KARENCJI PO ODMOWIE (⭐⭐⭐ KLUCZOWY
  przepis praktyczny, uzależniony od WYMIARU KARY — dwa różne okresy).
  ⛔ NAPRAWIONE 2026-08-22 (weryfikacja HYBRID-VAL, RZĄD 1: lexlege.pl
  stan prawny na 17.08.2026, Dz.U. 2025 poz. 911 t.j. — poprzednia wersja
  tej sekcji cytowała próg 3 lata/3+6 mies., co jest STARĄ wersją
  przepisu sprzed nowelizacji z 7.07.2022 (Dz.U. 2022 poz. 2600); wyniki
  wyszukiwania są w tej materii silnie zaśmiecone nieaktualnymi/
  archiwalnymi kopiami przepisu — przy każdej kolejnej weryfikacji tego
  artykułu wymagane bezpośrednie potwierdzenie ISAP/lexlege z datą
  "stan prawny na", NIE poleganie na pierwszym trafieniu wyszukiwarki):
  §3: kara/suma kar NIE PRZEKRACZA 5 LAT — wniosek złożony przed
    upływem 6 MIESIĘCY od wydania postanowienia o odmowie NIE JEST
    rozpoznawany aż do upływu tego okresu
  §4: kara/suma kar PRZEKRACZA 5 LAT — wniosek złożony przed upływem
    ROKU od wydania postanowienia o odmowie NIE JEST rozpoznawany aż
    do upływu tego okresu
  ⚠️ UWAGA HISTORYCZNA — sprawa Marka Petelskiego: jeśli ta sprawa była
    prowadzona PRZED 7.07.2022 (data nowelizacji Dz.U. 2022 poz. 2600) lub
    dotyczyła stanu prawnego sprzed tej daty, mogła zasadnie opierać się
    na WCZEŚNIEJSZEJ wersji przepisu (próg 3 lata, terminy 3/6 mies.) —
    ta wcześniejsza wersja NIE jest już aktualna i nie należy jej
    stosować do spraw bieżących. Sama nazwa "6-miesięczna karencja przy
    karze >3 lata" w oryginalnej notatce nie odpowiada ŻADNEJ znanej
    wersji przepisu (ani starej: >3 lata→6 mies. nie istniało w tej
    kombinacji, ani nowej: próg to 5 lat nie 3) — możliwe przekłamanie
    przy sporządzaniu notatki, wymaga weryfikacji z aktami sprawy przy
    następnym jej wykorzystaniu
  ⭐ PUŁAPKA: karencja dotyczy wniosku SKAZANEGO LUB JEGO OBROŃCY —
    NIE dotyczy wniosków składanych przez dyrektora ZK/kuratora, które
    mogą być składane bez tego ograniczenia czasowego

⭐⭐ ART. 161 §1 — POSIEDZENIE: odbywa się W ZAKŁADZIE KARNYM. Prawo
  udziału: prokurator, skazany, obrońca, oraz inne osoby uprawnione do
  złożenia wniosku (jeśli go złożyły)

⭐⭐ ART. 162 §1 — SĄD WYSŁUCHUJE przedstawiciela administracji ZK i
  kuratora (jeśli składał wniosek), UWZGLĘDNIA ugodę z mediacji.
  ⭐⭐ PRZY PRZESTĘPSTWACH SEKSUALNYCH (art. 197-203 KK, w związku z
  zaburzeniami preferencji seksualnych) — warunkowe zwolnienie NIE
  MOŻE być udzielone BEZ opinii BIEGŁYCH (⭐ obligatoryjna opinia
  biegłych, nie fakultatywna)

⭐⭐⭐ ART. 162 §2-3 — ZASKARŻALNOŚĆ: na postanowienie w PRZEDMIOCIE
  warunkowego zwolnienia PRZYSŁUGUJE ZAŻALENIE, rozpoznawane w
  TERMINIE 14 DNI. Na postanowienie ODMAWIAJĄCE — zażalenie
  przysługuje TAKŻE dyrektorowi ZK/kuratorowi, jeśli oni składali
  wniosek (⭐ legitymacja zaskarżenia rozszerzona na wnioskodawców
  spoza kręgu skazany/obrońca)

⭐⭐ ART. 160 — ODWOŁANIE warunkowego zwolnienia (⭐ już PO jego
  udzieleniu — sytuacja odwrotna): OBLIGATORYJNE gdy zwolniony w
  okresie próby: popełnił przestępstwo UMYŚLNE zakończone
  prawomocną karą pozbawienia wolności BEZ zawieszenia; uchyla się od
  obowiązków/dozoru/środków karnych; RAŻĄCO naruszył porządek prawny.
  §8: w razie odwołania — okres spędzony na wolności NIE zalicza się
  na poczet kary (⭐ istotna, dotkliwa konsekwencja praktyczna). Na
  postanowienie o odwołaniu — PRZYSŁUGUJE ZAŻALENIE.
```

### 0.2. ODROCZENIE I PRZERWA WYKONANIA KARY (Oddział 10, art. 150-158a)
— ⭐⭐⭐ bardzo częsty temat praktyczny (choroba, sytuacja rodzinna)

```
⭐⭐⭐ ROZRÓŻNIENIE KLUCZOWE: ODROCZENIE dotyczy kary JESZCZE
  NIEROZPOCZĘTEJ (skazany jeszcze na wolności), PRZERWA dotyczy kary
  JUŻ ODBYWANEJ (skazany już w ZK, wraca na wolność na czas przerwy)
  — ⭐ to nie synonimy, mylenie ich to częsty błąd formalny pisma

⭐⭐⭐ ART. 150 — PRZESŁANKI OBLIGATORYJNE odroczenia (⭐ sąd MUSI
  odroczyć, brak uznaniowości):
  §1: choroba PSYCHICZNA lub inna CIĘŻKA CHOROBA uniemożliwiająca
    wykonywanie kary — odroczenie DO CZASU USTANIA przeszkody (⭐ BEZ
    górnego limitu czasowego, w przeciwieństwie do art. 151 niżej)
  §2: definicja "ciężkiej choroby" — stan, w którym umieszczenie w ZK
    MOŻE ZAGRAŻAĆ ŻYCIU lub spowodować POWAŻNE niebezpieczeństwo dla
    zdrowia (⭐ BRAK zamkniętego katalogu chorób — zawsze wymaga OPINII
    BIEGŁEGO z zakresu odpowiedniej specjalizacji medycznej, oceniającej
    NIE TYLKO chorobę samą w sobie, ale KONKRETNE zagrożenie wynikające
    z warunków IZOLACYJNYCH — orzecznictwo SA Kraków/Lublin)

⭐⭐⭐ ART. 151 — PRZESŁANKI FAKULTATYWNE (⭐ sąd MOŻE, nie musi, z
  limitem czasowym DO 1 ROKU):
  - natychmiastowe wykonanie kary pociągnęłoby dla skazanego LUB jego
    RODZINY zbyt ciężkie skutki (⭐ najczęstsza w praktyce — obejmuje
    m.in. jedynego żywiciela rodziny, opiekę nad bliskim, trudności
    gospodarcze — ⚠️ NIE obejmuje samej niemożności spłaty kredytu
    jako samodzielnej przesłanki, wg części orzecznictwa)
  - przeludnienie zakładów karnych w skali KRAJU (⭐ przesłanka
    systemowa, rzadko stosowana praktycznie)
  ⭐⭐ Odroczeniu NIE PODLEGAJĄ niektóre kategorie skazanych — ⚠️
  dokładny katalog wyłączeń NIE zweryfikowany w tej sesji, punkt
  startowy

⭐⭐⭐ ART. 153 — PRZERWA W WYKONANIU KARY (⭐ analogiczna konstrukcja
  do odroczenia, ale dla kary JUŻ ROZPOCZĘTEJ):
  §1: OBLIGATORYJNA przy przesłance z art. 150 §1 (ciężka choroba) —
    DO CZASU ustania przeszkody
  §2: FAKULTATYWNA przy "ważnych względach rodzinnych lub osobistych"
    (⭐ szerzej sformułowana niż art. 151, ale stosuje się ODPOWIEDNIO
    art. 151 §3-5) — ⚠️ UWAGA: od nowelizacji z 2011 r. WZGLĘDY
    ZDROWOTNE zostały USUNIĘTE z tej fakultatywnej podstawy — obecnie
    przerwa "zdrowotna" możliwa TYLKO przez art. 150 §1 (ciężka
    choroba, próg WYŻSZY niż dawne "względy zdrowotne")
  §2a: wniosek MOŻE złożyć TAKŻE dyrektor zakładu karnego
  §3: NIE MOŻNA udzielić KOLEJNEJ przerwy przed upływem ROKU od
    zakończenia poprzedniej i powrotu do ZK — WYJĄTEK: choroba
    psychiczna, inna ciężka choroba, INNY wypadek losowy
  §5: sądem WŁAŚCIWYM dla DALSZYCH przerw jest sąd, który udzielił
    PIERWSZEJ przerwy (⭐ ciągłość właściwości)

⚠️ POZOSTAJE DO POGŁĘBIENIA: dokładny katalog wyłączeń podmiotowych z
  odroczenia (art. 150a i pokrewne), procedura wniosku krok po kroku
  (art. 153a i n.) — punkt startowy.
```

### 0.3. SYSTEM DOZORU ELEKTRONICZNEGO (Rozdział VIIa, art. 43a-43zf)
— ⭐⭐ rosnące znaczenie jako alternatywa dla pozbawienia wolności

```
⭐⭐ ART. 43b — DEFINICJE: dozór elektroniczny = kontrola zachowania
  skazanego PRZY UŻYCIU ŚRODKÓW TECHNICZNYCH. TRZY formy:
  - DOZÓR STACJONARNY: przebywanie w określone dni/godziny we
    WSKAZANYM miejscu (⭐ najpopularniejsza forma — odpowiednik
    "aresztu domowego" jako sposobu odbywania kary)
  - DOZÓR ZBLIŻENIOWY: zachowanie MINIMALNEJ odległości od WSKAZANEJ
    osoby (⭐ typowo przy przestępstwach przeciwko rodzinie/przemocy)
  - DOZÓR MOBILNY: (⚠️ dokładna definicja NIE potwierdzona w tej
    sesji — kontrola przemieszczania się skazanego w sposób ciągły,
    punkt startowy)

⭐⭐ STRUKTURA ROZDZIAŁU (5 oddziałów, ⚠️ numeracja Oddziału 2a
  potwierdzona jako "43la-43ln" w jednym źródle — MOŻLIWA rozbieżność
  względem ogólnego zakresu 43a-43zf, wymaga weryfikacji przy
  konkretnej sprawie):
  Oddział 1 — przepisy ogólne (definicje, zakres stosowania — w tym
    DO sprawców objętych środkiem ZABEZPIECZAJĄCYM połączonym z
    dozorem, nie tylko skazanych)
  Oddział 2 — rozpoczęcie dozoru elektronicznego (⭐ warunek: warunki
    TECHNICZNE muszą pozwalać — liczba/zasięg nadajników i
    rejestratorów; PRZY NIEDOBORZE — priorytet dla dozorów mobilnych
    orzeczonych jako środek zabezpieczający; ⭐ przy WSPÓLNYM
    zamieszkiwaniu z innymi pełnoletnimi — wymagana ich PISEMNA ZGODA
    złożona do sądu/komisji penitencjarnej)
  Oddział 2a — warunki i tryb orzekania o zezwoleniu
  Oddział 3 — obowiązki i prawa skazanego
  Oddział 4 — czynności podmiotów wykonujących dozór
  Oddział 5 — zakończenie dozoru — ⭐ UCHYLENIE zezwolenia (art.
    43zaa obligatoryjne, 43zab fakultatywne) SKUTKUJE zaliczeniem NA
    POCZET kary WYŁĄCZNIE okresu faktycznie objętego dozorem — I
    KLUCZOWE: ponowne udzielenie zezwolenia w TEJ SAMEJ sprawie JEST
    NIEDOPUSZCZALNE (⭐⭐ nieodwracalna konsekwencja — jedna szansa)

⭐⭐ WNIOSEK: składają skazany i jego obrońca, ORAZ prokurator i
  kurator sądowy oraz dyrektor ZK — ⚠️ CZŁONKOWIE RODZINY skazanego
  NIE MOGĄ składać wniosku samodzielnie (⭐ różnica względem
  warunkowego zwolnienia, gdzie krąg jest inny)

⚠️ POZOSTAJE DO POGŁĘBIENIA: dokładne przesłanki materialne
  kwalifikujące do dozoru elektronicznego (rodzaj/wymiar kary, zgoda
  skazanego), pełna treść Oddziału 2a i 3 — punkt startowy do
  pogłębienia przy konkretnej sprawie.
```

### 0.4. PRAWA I OBOWIĄZKI SKAZANEGO (Oddział 4, art. 101-120) — dodano
2026-08-20 (naprawa F-75, druga pozostała pozycja raportu zewnętrznego)

```
⭐⭐⭐ ART. 102 — KATALOG PRAW skazanego (⭐ katalog otwarty, "w
  szczególności", najważniejsze pozycje):
  pkt 1 — odpowiednie ze względu na zachowanie zdrowia wyżywienie,
    odzież, warunki bytowe, pomieszczenia oraz świadczenia zdrowotne i
    warunki higieny
  pkt 2 — wynagrodzenie związane z zatrudnieniem oraz ubezpieczenie
    społeczne, a także pomoc w uzyskiwaniu świadczeń inwalidzkich
  pkt 5 — kształcenie, samokształcenie i wykonywanie twórczości
    własnej, a za zgodą dyrektora ZK — wytwarzanie i zbywanie
    wykonanych przedmiotów
  pkt 6 — korzystanie z urządzeń i zajęć kulturalno-oświatowych i
    sportowych, radia, telewizji, książek i prasy
  pkt 7 — komunikowanie się z obrońcą, pełnomocnikiem, właściwym
    kuratorem sądowym oraz wybranym przedstawicielem
  pkt 10 — składanie WNIOSKÓW, SKARG i PRÓŚB organowi właściwemu do
    ich rozpatrzenia (⭐⭐⭐ podstawa prawna dla całej praktyki
    skargowej skazanego — orzecznictwo SN cytowane w doktrynie)

⭐⭐⭐ ART. 103 — SKAZANI MAJĄ PRAWO kierować SKARGI do organów
  powołanych na podstawie RATYFIKOWANYCH przez RP umów międzynarodowych
  dot. ochrony praw człowieka (⭐⭐⭐ droga do ETPCz i podobnych organów —
  odrębna od skargi krajowej do sądu penitencjarnego; kontrola
  korespondencji z ETPCz podlega SZCZEGÓLNEJ ochronie — orzecznictwo
  ETPCz cytowane wielokrotnie w doktrynie)

⭐⭐ ART. 104 — GRANICA korzystania z praw: musi następować w sposób NIE
  NARUSZAJĄCY praw innych osób oraz NIE ZAKŁÓCAJĄCY ustalonego w ZK
  porządku (⭐ klauzula ogólna ograniczająca)

⭐⭐⭐ ART. 105 §1 — utrzymywanie WIĘZI: skazanemu NALEŻY umożliwiać
  utrzymywanie więzi PRZEDE WSZYSTKIM z rodziną i innymi osobami
  bliskimi przez: WIDZENIA, KORESPONDENCJĘ, ROZMOWY TELEFONICZNE,
  PACZKI i PRZEKAZY PIENIĘŻNE, a w uzasadnionych wypadkach za zgodą
  dyrektora ZK — również inne środki łączności
  §2 — skazany CUDZOZIEMIEC może prowadzić korespondencję z właściwym
  urzędem KONSULARNYM (lub przedstawicielstwem dyplomatycznym) oraz
  korzystać z widzeń z urzędnikiem konsularnym
  §3 — ZAKRES i SPOSÓB kontaktów (nadzór nad widzeniami, CENZURA
  korespondencji, kontrolowanie rozmów) UZALEŻNIONE od rodzaju/typu ZK
  oraz wymogów indywidualnego oddziaływania, Z WYJĄTKIEM prawa do
  otrzymywania paczek (⭐ paczki NIE podlegają temu różnicowaniu)
  §4 — dyrektor ZK decyduje o: ZATRZYMANIU korespondencji, CENZUROWANIU
  korespondencji (w ZK typu półotwartego/otwartego), KONTROLOWANIU
  rozmów — Z WYJĄTKIEM przypadków z art. 8 §3 (prawo do obrońcy) oraz
  art. 8a §2-3 (korespondencja skazanego), JEŻELI wymagają tego
  względy BEZPIECZEŃSTWA ZK lub PORZĄDKU PUBLICZNEGO — dyrektor
  INFORMUJE skazanego o zatrzymaniu korespondencji, MOŻE zezwolić na
  przekazanie WAŻNEJ wiadomości z zatrzymanej korespondencji

⭐⭐ ART. 105a — WIDZENIA — mechanika szczegółowa:
  §1: widzenie trwa 60 MINUT, TYLKO JEDNO widzenie dziennie (z
    zastrzeżeniami art. 90 pkt 6 i art. 91 pkt 8)
  §2: MAKSYMALNIE 2 osoby PEŁNOLETNIE mogą uczestniczyć; liczba
    NIEPEŁNOLETNICH — BEZ OGRANICZEŃ (pod opieką osoby pełnoletniej)
  §3: skazani z art. 87a (⚠️ kategoria niezidentyfikowana w tej sesji)
    MAJĄ PRAWO do DODATKOWEGO widzenia z dziećmi
  §4: widzenie z osobą NIEBĘDĄCĄ członkiem rodziny/bliskim — WYMAGA
    zezwolenia dyrektora ZK
  §5: widzenia pod NADZOREM funkcjonariusza, przy oddzielnym stoliku
  §7: w razie naruszenia ustalonych zasad — widzenie MOŻE być przerwane
    lub zakończone przed czasem
  §9: ograniczenia z §1, 2, 5 NIE MAJĄ zastosowania do widzeń z
    obrońcą (art. 8 §3) i osobami z art. 105 §2 (urzędnik konsularny)

⭐⭐ ART. 104a — UDZIAŁ skazanych w USUWANIU skutków sytuacji
  kryzysowych i klęsk żywiołowych — NA WNIOSEK właściwego organu
  gminy, ZA ZGODĄ dyrektora ZK [⚠️ dalsza treść nie zbadana
  szczegółowo]

⭐⭐⭐ ART. 116 §1 — OBOWIĄZKI skazanego: przestrzeganie przepisów
  określających zasady i tryb wykonywania kary, ustalonego w ZK
  PORZĄDKU oraz wykonywania POLECEŃ przełożonych — W SZCZEGÓLNOŚCI
  niezwłoczne ZAWIADOMIENIE przełożonego o CHOROBIE własnej i
  zauważonych OBJAWACH chorobowych u innego skazanego
  §2-6 — KONTROLA OSOBISTA skazanego (⭐⭐⭐ szeroko cytowana w
  orzecznictwie ETPCz/SN/SO/SR, 7 pozycji wg doktryny): polega na
  OGLĘDZINACH ciała oraz SPRAWDZENIU odzieży, bielizny, obuwia i
  posiadanych przedmiotów (§3) — oględziny ciała/sprawdzenie odzieży w
  POMIESZCZENIU, BEZ osób postronnych i osób ODMIENNEJ PŁCI, wykonywane
  przez osobę TEJ SAMEJ PŁCI. Kontrola MOŻE być przeprowadzona w
  KAŻDYM czasie — dopuszczalne NARUSZENIE plomb gwarancyjnych i
  USZKODZENIE przedmiotów w niezbędnym zakresie (§4). Przedmioty
  ZNALEZIONE, których skazany NIE MOŻE posiadać — ZATRZYMANIE; z
  ustalonym właścicielem — DEPOZYT lub przesłanie na koszt skazanego
  (§5). ⭐⭐⭐ SKARGA na kontrolę osobistą (odesłanie systemowe do art.
  223h w Rozdziale XVb, analogiczna konstrukcja): przysługuje do
  właściwego SĄDU PENITENCJARNEGO w TERMINIE 7 DNI od przeprowadzenia
  kontroli, W CELU zbadania ZASADNOŚCI, LEGALNOŚCI oraz PRAWIDŁOWOŚCI
  — składana NA PIŚMIE za pośrednictwem dyrektora ZK/aresztu. Sąd
  ORZEKA o nieuwzględnieniu LUB stwierdzeniu bezzasadności/nielegalności/
  nieprawidłowości — W RAZIE stwierdzenia wadliwości sąd ZAWIADAMIA
  prokuratora oraz właściwego dyrektora okręgowego SW

⭐⭐ ART. 117 — LECZENIE ODWYKOWE skazanego uzależnionego (⚠️ pełna
  treść nie zbadana w tej sesji — cytowana w doktrynie jako szeroko
  omawiana w orzecznictwie SA/SN); ART. 118 §1 — jeżeli wykonywanie
  kary MOŻE ZAGRAŻAĆ życiu skazanego lub spowodować POWAŻNE
  niebezpieczeństwo dla zdrowia, dyrektor ZK NA WNIOSEK lekarza
  NIEZWŁOCZNIE powiadamia sędziego penitencjarnego (⭐⭐ mechanizm
  ostrzegawczy, punkt wyjścia dla odroczenia/przerwy z art. 150-151
  opisanych w sekcji 0.2)

⭐⭐ ART. 119 — sprawcy przestępstw z art. 197-203 KK popełnionych W
  ZWIĄZKU z zaburzeniami preferencji seksualnych OBEJMUJE SIĘ, ZA JEGO
  ZGODĄ, odpowiednim LECZENIEM i REHABILITACJĄ; W RAZIE BRAKU zgody —
  o STOSOWANIU leczenia/rehabilitacji ORZEKA sąd penitencjarny (⭐⭐
  powiązanie z opinią biegłych obligatoryjną przy warunkowym zwolnieniu
  tej kategorii skazanych, patrz sekcja 0.1 wyżej)

⚠️ POZOSTAJE DO POGŁĘBIENIA: pełna treść art. 105b (telefon), 106
  (wolność religii), 108 (bezpieczeństwo osobiste, nadzór), 113
  (⚠️ niezidentyfikowana treść w tej sesji), pełny katalog art. 102
  poza już wymienionymi punktami — punkt startowy.
```

### 0.5. KARY DYSCYPLINARNE (Oddział 9, art. 142-149) — dodano
2026-08-20 (naprawa F-75, ostatnia pozycja raportu zewnętrznego)

```
⭐⭐⭐ ART. 142 §1 — ODPOWIEDZIALNOŚĆ DYSCYPLINARNA za ZAWINIONE
  naruszenie nakazów/zakazów wynikających z ustawy, regulaminu lub
  innych przepisów wykonawczych ALBO ustalonego w ZK/miejscu pracy
  PORZĄDKU — zwane "PRZEKROCZENIEM" (⭐⭐⭐ wymóg ZAWINIENIA — element
  subiektywny, nie odpowiedzialność obiektywna)
  §2 — jeżeli przekroczenie zawiera ZNAMIONA WYKROCZENIA, skazany
  podlega ODPOWIEDZIALNOŚCI DYSCYPLINARNEJ, CHYBA że wykroczenie
  popełniono W CZASIE POBYTU POZA obrębem ZK (⭐⭐⭐ zasada wyłączności
  reżimu dyscyplinarnego wewnątrz ZK, z wyjątkiem dla zdarzeń "na
  zewnątrz" — te podlegają zwykłemu reżimowi wykroczeniowemu)

⭐⭐⭐ ART. 143 §1 — KATALOG kar dyscyplinarnych (⭐⭐⭐ zamknięty, od
  najłagodniejszej do najsurowszej, gradacja istotna dla oceny
  proporcjonalności):
  pkt 1 — NAGANA (⭐ najłagodniejsza)
  pkt 2 — pozbawienie WSZYSTKICH lub NIEKTÓRYCH niewykorzystanych
    nagród/ulg ALBO zawieszenie ich wykonania, NA OKRES DO 3 MIESIĘCY
  pkt 3 — pozbawienie korzystania z udziału w NIEKTÓRYCH zajęciach
    [⚠️ pełna treść pkt 3 nie w pełni zbadana]
  pkt 8 (⭐⭐⭐ NAJSUROWSZA, osobno obwarowana gwarancjami — patrz art.
    145 §3 niżej) — OSADZENIE pojedynczo w celi + UNIEMOŻLIWIENIE
    kontaktu z innymi skazanymi; W TRAKCIE jej wykonywania skazanego
    POZBAWIA SIĘ możliwości: (1) korzystania z widzeń i
    samoinkasujących aparatów telefonicznych, (2) korzystania ze
    sprzętu audiowizualnego/komputerowego, (3) BEZPOŚREDNIEGO
    uczestniczenia WSPÓLNIE z innymi w nabożeństwach/spotkaniach
    religijnych/nauce religii — NA ŻĄDANIE skazanego NALEŻY jednak
    umożliwić bezpośrednie uczestnictwo w nabożeństwie w warunkach
    UNIEMOŻLIWIAJĄCYCH kontakt z innymi, (4) korzystania z zajęć
    kulturalno-oświatowych [⚠️ dalszy katalog ograniczeń §3 nie w
    pełni wyczerpany]. §3 — karę tę WYMIERZA SIĘ skazanemu, KTÓRY
    dopuścił się NARUSZENIA NIETYKALNOŚCI CIELESNEJ lub CZYNNEJ
    NAPAŚCI na funkcjonariusza/pracownika ZK, ORAZ MOŻNA wymierzyć za
    inne przekroczenie naruszające W POWAŻNYM STOPNIU dyscyplinę i
    porządek (⭐⭐ dwustopniowa przesłanka: obligatoryjna dla napaści,
    fakultatywna dla innych poważnych naruszeń)

⭐⭐⭐ ART. 144 §1 — KOMPETENCJA: kary z art. 143 §1 pkt 4, 5 i 7-8
  wymierza WYŁĄCZNIE dyrektor ZK; INNE kary — RÓWNIEŻ osoba przez
  niego upoważniona (⭐⭐ najsurowsze kary zastrzeżone dla samego
  dyrektora, bez możliwości delegacji)
  §2 — kary wymierza się Z URZĘDU lub na PISEMNY wniosek przełożonego
  §3 — decyzja MUSI zawierać DOKŁADNE określenie przekroczenia
  §4 — decyzja SPORZĄDZANA NA PIŚMIE, PODAWANA do wiadomości skazanemu
    (a gdy względy wychowawcze przemawiają — RÓWNIEŻ innym skazanym/
    osobom) — analogicznie dla decyzji o UCHYLENIU, DAROWANIU,
    ODROCZENIU, ZAMIANIE, ZAWIESZENIU lub PRZERWANIU kary, oraz o
    ODSTĄPIENIU od ukarania
  §5 — na decyzje z §1 PRZYSŁUGUJE SKARGA (⭐⭐⭐ podstawowy środek
    zaskarżenia ukarania dyscyplinarnego, patrz też sędzia penitencjarny
    niżej)

⭐⭐⭐ ART. 145 §1 — DYREKTYWY WYMIARU: uwzględnia się stopień
  ZAWINIENIA i ZASADY INDYWIDUALIZACJI — W SZCZEGÓLNOŚCI rodzaj i
  okoliczności czynu, stosunek do przekroczenia, DOTYCHCZASOWĄ postawę,
  cechy osobowości i STAN ZDROWIA skazanego oraz CELE WYCHOWAWCZE
  §2 — PRZED wymierzeniem: WYSŁUCHUJE SIĘ obwinionego, ZAPOZNAJE się z
  opinią WYCHOWAWCY, w razie potrzeby — RÓWNIEŻ z opinią składającego
  wniosek i INNYCH osób oraz ZEZNANIAMI świadków — postępowanie MOŻE
  odbywać się W OBECNOŚCI innych skazanych, jeśli przemawiają za tym
  względy wychowawcze (⭐⭐⭐ gwarancje proceduralne minimum —
  odpowiednik prawa do obrony w postępowaniu dyscyplinarnym)
  §3 — PRZED wymierzeniem kary z art. 143 §1 pkt 8 (izolacja) — LEKARZ
  ALBO PSYCHOLOG wydaje PISEMNĄ opinię o ZDOLNOŚCI skazanego do
  odbycia tej kary; PRZY BRAKU zdolności — stosuje się art. 146 §3.
  WYMIERZENIE tej kary POWYŻEJ 14 DNI wymaga ZGODY sędziego
  penitencjarnego (⭐⭐⭐ dodatkowa gwarancja sądowa dla najdłuższej
  izolacji)
  §4-5 — PRZED wymierzeniem kar z art. 143 §1 pkt 4-5 skazanemu,
  któremu ZE WZGLĘDU na stan zdrowia zezwolono na dodatkowe zakupy/
  paczki/dietę — ZASIĘGA SIĘ opinii lekarza co do SKUTKÓW dla zdrowia;
  dyrektor PODEJMUJE decyzję o EWENTUALNYM odroczeniu wykonania

⭐⭐ ART. 146 §1 — ZASADA JEDNEJ KARY: za JEDNO przekroczenie wymierza
  się TYLKO JEDNĄ karę dyscyplinarną; GDY skazany popełnił WIĘCEJ
  przekroczeń, ZANIM został ukarany za którekolwiek z nich — wymierza
  się JEDNĄ karę, ODPOWIEDNIO SUROWSZĄ (⭐⭐ zasada konsumpcji, analogia
  do kary łącznej)

⭐⭐⭐ ART. 147 §1 — PRZEDAWNIENIE KARALNOŚCI (⭐⭐⭐ dwa terminy
  alternatywne, KRÓTSZE OGRANICZAJĄ): NIE MOŻNA wymierzyć kary, jeżeli
  od dnia POWZIĘCIA przez przełożonego wiadomości o przekroczeniu
  upłynęło 14 DNI LUB od dnia POPEŁNIENIA przekroczenia — 30 DNI. NIE
  MOŻNA rozpocząć WYKONYWANIA kary dyscyplinarnej po upływie 14 DNI od
  jej wymierzenia (⭐⭐⭐ trzeci, odrębny termin — na WYKONANIE, nie
  tylko wymierzenie)
  §2 — terminy NIE BIEGNĄ, jeżeli skazany przebywa POZA obrębem ZK
  BEZ zezwolenia, LUB w związku z LECZENIEM wynikłym z samouszkodzenia
  lub zasadnego zastosowania środków przymusu bezpośredniego, A TAKŻE
  w okresie ZAWIESZENIA wykonania kary dyscyplinarnej
  §3 — przedawnienie WYKONANIA nie biegnie W CZASIE wykonywania TAKIEJ
  SAMEJ kary, wymierzonej WCZEŚNIEJ

⭐⭐⭐ ART. 148 (z materiału wtórnego, ⚠️ dokładny numer artykułu do
  potwierdzenia) — wymierzoną karę dyscyplinarną WYKONUJE SIĘ
  BEZZWŁOCZNIE. SĘDZIA PENITENCJARNY MOŻE: WSTRZYMAĆ wykonanie kary
  NA CZAS potrzebny do wyjaśnienia okoliczności uzasadniających jej
  wymierzenie, A TAKŻE UCHYLIĆ karę dyscyplinarną Z POWODU jej
  NIEZASADNOŚCI [⚠️ dalsza treść przepisu, w tym dokładny zakres
  kompetencji "lub przekaza..." — urwana w źródle, NIE w pełni
  potwierdzona] (⭐⭐⭐ KLUCZOWY mechanizm kontroli sądowej — sędzia
  penitencjarny jako organ NADZORU nad decyzjami dyrektora ZK w
  sprawach dyscyplinarnych, komplementarny do skargi z art. 144 §5)

⚠️ POZOSTAJE DO POGŁĘBIENIA: pełny katalog art. 143 §1 (pkt 4-7 poza
  już wymienionymi), dokładna treść art. 148-149, tryb i termin skargi
  z art. 144 §5 (czy to skarga do sędziego penitencjarnego, czy inny
  organ — NIE jednoznacznie potwierdzone w tej sesji, wymaga
  rozróżnienia od mechanizmu z art. 148 wyżej).
```

---

### 0.6. POSTĘPOWANIE WYKONAWCZE (Rozdział IV, art. 9-31) — dodano
2026-08-22, kontynuacja domykania luk wg mapy pokrycia (F-83)

```
✅ Zweryfikowane RZĄD 1: arslege.pl, lexlege.pl, przepisy.gofin.pl —
zgodne przy każdym cytowanym artykule, stan Dz.U. 2025 poz. 911 t.j.
Struktura: Oddział 1 (Wykonywanie orzeczeń, 9-17a), Oddział 2
(Postępowanie przed sądem, 18-24), Oddział 3 (Postępowanie egzekucyjne,
25-31 — ⚠️ POPRAWKA: mapa pokrycia BŁĘDNIE podawała górną granicę jako
"25-43"; art. 32 i dalsze to już Rozdział V "Nadzór penitencjarny",
oddzielny temat).
```

**ODDZIAŁ 1 — WYKONYWANIE ORZECZEŃ (art. 9-17a)**

```
⭐⭐⭐ ART. 9 — WYKONALNOŚĆ ORZECZEŃ (moment rozpoczęcia postępowania
  wykonawczego — fundament całego rozdziału):
  §1: postępowanie wykonawcze wszczyna się BEZZWŁOCZNIE, gdy orzeczenie
    stało się wykonalne
  §2: wyrok oraz postanowienia z art. 420 KPK (uzupełnienie wyroku)
    dot. przepadku/dowodów rzeczowych — wykonalne z chwilą
    UPRAWOMOCNIENIA, chyba że ustawa stanowi inaczej
  §3: postanowienie W POSTĘPOWANIU WYKONAWCZYM — wykonalne z chwilą
    WYDANIA (⭐ różnica względem §2 — natychmiastowa wykonalność jako
    zasada), chyba że sąd wydający lub sąd zażaleniowy wstrzyma
    wykonanie; ODMOWA wstrzymania NIE WYMAGA uzasadnienia
  §4: złożenie wniosku o wydanie postanowienia w post. wykonawczym NIE
    WSTRZYMUJE wykonania orzeczenia, którego dotyczy — chyba że sąd w
    szczególnie uzasadnionych wypadkach postanowi inaczej
  §5: w posiedzeniu ws. wstrzymania wykonania orzeczenia — prawo
    udziału PROKURATORA, jeżeli wstrzymanie skutkowałoby ZWOLNIENIEM
    skazanego z aresztu/ZK (⭐ szczególne zabezpieczenie interesu
    publicznego przy zwolnieniach)

⭐⭐ ART. 10 — WYKONAWCY POLECEŃ SĄDU: Policja wykonuje polecenia sądu
  w zakresie postępowania wykonawczego; ODPOWIEDNIO stosuje się do
  Żandarmerii Wojskowej/dowódcy wojskowego (gdy skazany jest
  żołnierzem, z wyjątkiem TSW dyspozycyjnie)

⭐⭐⭐ ART. 26 (⚠️ Oddział 3, ale kluczowo powiązany) — DO TYTUŁÓW
  EGZEKUCYJNYCH stosuje się ODPOWIEDNIO art. 776-795 KPC (⭐ pomost
  między KKW a KPC — istotne przy egzekucji roszczeń cywilnych,
  grzywny, świadczenia pieniężnego, należności sądowych zasądzonych w
  postępowaniu karnym)

⚠️ POZOSTAJE DO POGŁĘBIENIA: pełna treść art. 11-17a (liczenie
  terminów kary w tygodniach/miesiącach/latach — zasada 7/30/365 dni
  potwierdzona źródłowo, ale bez pełnego rozbicia pozostałych
  artykułów), art. 13 (rozstrzyganie wątpliwości co do wykonania
  orzeczenia — zażalenie przysługuje).
```

**ODDZIAŁ 2 — POSTĘPOWANIE PRZED SĄDEM (art. 18-24)**

```
⭐⭐⭐ ART. 19-20 — TRYB ORZEKANIA I ZASKARŻANIA (rdzeń proceduralny
  całego postępowania wykonawczego):
  Art. 19 §1: sąd orzeka NA WNIOSEK prokuratora, skazanego lub jego
    obrońcy oraz innych uprawnionych, LUB Z URZĘDU
  Art. 20 §1: w postępowaniu wykonawczym sąd orzeka JEDNOOSOBOWO (⭐
    zasada ogólna, różni się od zwykłego postępowania karnego)
  Art. 20 §2: zażalenie wnosi się do sądu, KTÓRY WYDAŁ zaskarżone
    postanowienie; przekazywane BEZZWŁOCZNIE zarządzeniem do sądu
    wyższej instancji, CHYBA że sąd orzekający w tym samym składzie
    PRZYCHYLI SIĘ do zażalenia (⭐ mechanizm autokontroli, analogiczny
    do art. 395 KPC)
  Art. 20 §3: sąd wyższej instancji rozpoznaje zażalenie JEDNOOSOBOWO
  Art. 20 §4: sąd wyższej instancji rozpoznaje zażalenie w TERMINIE 21
    DNI od przekazania przez sąd I instancji (⭐⭐⭐ termin instrukcyjny,
    NIE zawity — brak sankcji za przekroczenie, potwierdzone w
    doktrynie jako świadome odstąpienie ustawodawcy od terminu
    stanowczego z uwagi na czasochłonność doręczeń)

⭐⭐ ART. 21 — PROKURATOR JAKO STRONA w postępowaniu przed sądem;
  może składać wnioski, w wypadkach wskazanych ustawą — wnosić
  zażalenia na postanowienia wydane w postępowaniu wykonawczym

⭐⭐⭐ ART. 22 — PRAWO I OBOWIĄZEK UDZIAŁU W POSIEDZENIU SĄDU:
  §1: KRĄG UPRAWNIONYCH do udziału (gdy ustawa tak stanowi):
    prokurator, skazany, obrońca, sądowy kurator zawodowy, pokrzywdzony,
    oraz inne osoby z art. 19 §1. W posiedzeniu sądu WYŻSZEJ instancji
    — te same osoby co w I instancji
  §1a: NIESTAWIENNICTWO osób należycie zawiadomionych NIE WSTRZYMUJE
    rozpoznania sprawy, Z WYJĄTKIEM obrońcy w wypadkach obrony
    obligatoryjnej (art. 8 §2) — chyba że sąd orzeka NA KORZYŚĆ lub
    ZGODNIE z wnioskiem skazanego (⭐ pułapka: obecność obrońcy może być
    warunkiem ważności posiedzenia, ale tylko przy niekorzystnym dla
    skazanego rozstrzygnięciu)
  §2: sąd MOŻE dopuścić do udziału również INNE osoby

⭐⭐ ART. 23 — SPROWADZENIE SKAZANEGO na posiedzenie sądu (fakultatywne
  zarządzenie sądu); możliwość zlecenia przesłuchania sądowi wezwanemu
  w okręgu pobytu skazanego

⭐⭐⭐ ART. 24 — ZMIANA LUB UCHYLENIE PRZEZ SĄD POPRZEDNIEGO
  POSTANOWIENIA (⭐⭐⭐ mechanizm wzruszalności rozstrzygnięć wykonawczych
  poza zwykłym środkiem zaskarżenia):
  §1: przy UJAWNIENIU nowych lub poprzednio nieznanych okoliczności
    istotnych dla rozstrzygnięcia — sąd MOŻE w KAŻDYM CZASIE zmienić
    lub uchylić poprzednie postanowienie
  §2: NIEDOPUSZCZALNA zmiana/uchylenie NA NIEKORZYŚĆ skazanego PO
    UPŁYWIE 6 MIESIĘCY od uprawomocnienia się postanowienia (⭐ termin
    ochronny dla skazanego, analogiczny funkcjonalnie do zakazu
    reformationis in peius w czasie)
  §3: zażalenie na postanowienie z §1 PRZYSŁUGUJE TYLKO gdy
    przysługiwało również na postanowienie PODLEGAJĄCE zmianie/uchyleniu
    (⭐ zasada pochodności zaskarżalności — jeśli pierwotne postanowienie
    było niezaskarżalne, to i jego zmiana/uchylenie też)

⚠️ ODESŁANIE PRAKTYCZNE (forum sędziowskie, nieformalne, wymaga
  dalszej weryfikacji przy konkretnej sprawie): typowe zastosowania
  art. 24 — umorzenie/zawieszenie postępowania (zażalenie przysługuje,
  postanowienie natychmiast wykonalne, bez konieczności posiedzenia),
  zatarcie skazania (analogicznie). Art. 3 §3a (poza zakresem tej
  sekcji, Rozdział II): na postanowienie w przedmiocie WŁAŚCIWOŚCI w
  postępowaniu wykonawczym zażalenie NIE PRZYSŁUGUJE.
```

**ODDZIAŁ 3 — POSTĘPOWANIE EGZEKUCYJNE (art. 25-31)**

```
⭐⭐⭐ ART. 25 — WŁAŚCIWOŚĆ PRZEPISÓW EGZEKUCYJNYCH wg rodzaju
  należności:
  §1: egzekucję zasądzonych ROSZCZEŃ CYWILNYCH, orzeczonej GRZYWNY,
    ŚWIADCZENIA PIENIĘŻNEGO oraz NALEŻNOŚCI SĄDOWYCH prowadzi się wg
    przepisów KPC (⭐ podstawowy tryb — komornik sądowy)
  (⚠️ dokładna treść §2 i dalszych ustępów art. 25 dot. rozróżnienia
    przepadku/nawiązki NIE w pełni potwierdzona w tej sesji — punkt
    startowy do pogłębienia)

⭐⭐⭐ ART. 26 — EGZEKUCJA PRZEPADKU I NAWIĄZKI na rzecz Skarbu Państwa:
  prowadzi ją NACZELNIK URZĘDU SKARBOWEGO wg przepisów o postępowaniu
  egzekucyjnym w ADMINISTRACJI (⭐ tryb administracyjny, NIE cywilny —
  kluczowa różnica względem art. 25 — inny organ egzekucyjny, inna
  procedura)

⭐⭐ ART. 31 — SKARGA PAULIAŃSKA na rzecz Skarbu Państwa: w razie
  dokonania przez dłużnika Skarbu Państwa CZYNNOŚCI PRAWNEJ Z
  POKRZYWDZENIEM WIERZYCIELA, z powództwem występuje PREZES SĄDU
  OKRĘGOWEGO lub NACZELNIK URZĘDU SKARBOWEGO w sprawach, w których
  wykonuje orzeczenie (⭐ odpowiednik art. 527 i n. KC, ale z odrębną
  legitymacją procesową — nie sam wierzyciel, tylko organ publiczny)

⚠️ POZOSTAJE DO POGŁĘBIENIA: pełna treść art. 27-30 (szczegóły
  postępowania egzekucyjnego — zabezpieczenie majątkowe wykonawcze,
  środki pieniężne na rachunkach depozytowych Ministra Finansów wg
  wzmianki w innym miejscu ustawy) — punkt startowy przy konkretnej
  sprawie egzekucyjnej.
```

## 0T. TERMINY KKW — warstwa proceduralna (odtworzone 2026-09-16, F-189)

✅ [VER] RZĄD 1 2026-09-16 — odczyt treści `Dz.U. 2025 poz. 911`.
Tabela kanoniczna: `shared/terminy.md`, sekcja „Postępowanie wykonawcze karne (KKW)".

| Termin | Czynność | Podstawa |
|---|---|---|
| **7 dni** | skarga skazanego — od dnia, w którym **dowiedział się o zdarzeniu**; po terminie pozostawia się bez rozpoznania, chyba że uchybienie nastąpiło z przyczyn od skazanego niezależnych | art. 6 § 4 KKW |
| **7 dni** | skarga na decyzję organu — od ogłoszenia lub doręczenia; wnoszona **do organu, który wydał decyzję** | art. 7 § 3 KKW |
| **14 dni** | rozpoznanie zażalenia na postanowienie w przedmiocie warunkowego zwolnienia | art. 162 § 2 KKW |
| **6 miesięcy / rok** | ⛔ **KARENCJA** po odmowie warunkowego zwolnienia (kara do 5 lat / ponad 5 lat) | art. 161 § 3–4 KKW |
| **rok** | ⛔ **KARENCJA** na kolejną przerwę — od ukończenia poprzedniej i powrotu do ZK (wyjątki: choroba psychiczna, inna ciężka choroba, wypadek losowy) | art. 153 § 3 KKW |
| **do roku / do 3 lat po urodzeniu dziecka** | odroczenie wykonania kary; dłuższy okres wobec kobiety ciężarnej i osoby samotnie sprawującej opiekę nad dzieckiem | art. 151 § 1 KKW |
| **do roku / do 3 lat** | rozłożenie grzywny na raty (3 lata — wypadki szczególne, zwłaszcza znaczna grzywna) | art. 49 § 1–2 KKW |

⛔ **Karencja to NIE termin zawity.** Wniosek złożony przed upływem okresu z art. 161
§ 3–4 **nie przepada** — „nie rozpoznaje się go aż do upływu tego okresu".
Wcześniejsze złożenie niczego nie traci i niczego nie przyspiesza.

⛔ **Art. 152 KKW — uchylony.**

⚠️ **Art. 6 § 2–3 KKW:** skazany ma obowiązek uzasadnić żądanie w stopniu
umożliwiającym rozpoznanie i dołączyć dokumenty; organ może pozostawić pismo bez
rozpoznania z czterech powodów (te same podstawy faktyczne, wyrazy wulgarne lub
obelżywe albo gwara przestępców, brak uzasadnienia, oczywista bezzasadność).

---

## ROZGRANICZENIE (sekcja 0)

| Temat | Gdzie |
|---|---|
| Przesłanki materialne warunkowego zwolnienia (art. 77-82 KK) | `mod-KK-art69-84-warunkowe-zawieszenie-zwolnienie.md` — NIE duplikować |
| Poręczenie majątkowe / tymczasowe aresztowanie (inny etap postępowania — przed wyrokiem) | `mod-poreczenie-majatkowe-kaucja-karna.md`, `mod-KPK-srodki-zapobiegawcze-tymczasowe-aresztowanie.md` |

## ŁĄCZ Z (sekcja 0)

| Sytuacja | Skill / Moduł |
|---|---|
| Pismo: wniosek o warunkowe zwolnienie, odroczenie/przerwę kary, zezwolenie na dozór elektroniczny | `pisma-procesowe-v3` |
| Orzecznictwo penitencjarne | `orzeczenia-sadowe-v2` |

---

## SEKCJE ORYGINALNE (2026-05-28) — szablon strategiczny, zachowany
poniżej bez zmian jako warstwa uzupełniająca do sekcji 0 powyżej

## 1. Akty i źródła do weryfikacji
- Ustawa o Służbie Więziennej
- Kodeks karny wykonawczy
- akty wykonawcze Ministra Sprawiedliwości
- KPA/PPSA w sprawach administracyjnych osadzonych

Nie cytuj literalnego brzmienia przepisu bez aktualnego sprawdzenia źródła. Przed użyciem artykułu ustal:

- akt i Dz.U.,
- status obowiązywania,
- wersję temporalną na dzień zdarzenia,
- wersję na dzień sporządzania pisma,
- przepisy przejściowe,
- właściwy organ i tryb zaskarżenia.

## 2. Zakres spraw
- skargi skazanych
- warunki odbywania kary
- decyzje dyrektora jednostki
- odpowiedzialność dyscyplinarna
- przepustki
- widzenia
- opieka zdrowotna
- zabezpieczenie dowodów naruszeń

## 3. Intake
Ustal obowiązkowo:

1. kto jest stroną / uczestnikiem / funkcjonariuszem / organem,
2. jaki akt, czynność albo zaniechanie jest kwestionowane,
3. data czynności, doręczenia, powzięcia wiadomości i termin do reakcji,
4. organ pierwszej instancji i organ odwoławczy,
5. czy sprawa jest administracyjna, cywilna, karna, dyscyplinarna, służbowa albo mieszana,
6. czy istnieje dokument urzędowy: decyzja, postanowienie, zarządzenie, protokół, notatka, polecenie, uchwała,
7. czy zachodzi ryzyko prekluzji, przedawnienia, bezczynności albo bezskuteczności środka.

## 4. Mapa proceduralna
Stosuj ścieżkę:

`zdarzenie/czynność → kwalifikacja prawna → właściwość organu → środek zwykły → środek nadzwyczajny → kontrola sądowa → wykonanie rozstrzygnięcia → odpowiedzialność odszkodowawcza/dyscyplinarna`

W sprawach publicznoprawnych zawsze rozważ równolegle:

- środek w toku sprawy,
- skargę na bezczynność/przewlekłość,
- wniosek o wstrzymanie wykonania,
- zabezpieczenie dowodów,
- odpowiedzialność funkcjonariusza/organu,
- dostęp do akt i informacji publicznej,
- ochronę danych osobowych i informacji niejawnych.

## 5. Warunki skuteczności
Sprawdź:

- termin,
- właściwość organu/sądu,
- legitymację,
- interes prawny albo faktyczny,
- podpis,
- pełnomocnictwo,
- opłatę,
- odpisy,
- załączniki,
- dowód doręczenia,
- wskazanie żądania,
- wskazanie zarzutów,
- relację dowód → fakt → norma.

## 6. Matryca dowodowa
Dla każdego faktu zbuduj tabelę:

| Fakt | Dowód | Źródło | Siła | Luka | Ryzyko |
|---|---|---|---|---|---|

Typowe dowody:

- decyzje, postanowienia, protokoły, notatki, zarządzenia,
- korespondencja z organem,
- nagrania, zdjęcia, logi, metadane,
- zeznania świadków,
- dokumentacja medyczna/techniczna/księgowa,
- opinie biegłych,
- akty prawa miejscowego,
- wydruki z BIP, rejestrów, systemów publicznych.

## 7. Zarzuty typowe
Rozważ co najmniej:

- naruszenie właściwości,
- naruszenie prawa do udziału w sprawie,
- brak podstawy prawnej,
- błędna wykładnia przepisu,
- dowolna ocena dowodów,
- brak uzasadnienia,
- nieproporcjonalność,
- nierówne traktowanie,
- naruszenie zaufania do organu,
- naruszenie terminów,
- brak rozpoznania istoty sprawy,
- pominięcie dowodu,
- wadliwe pouczenie.

## 8. Kontrargumenty organu / strony przeciwnej
Przewiduj:

- formalny brak legitymacji,
- spóźnienie środka,
- brak interesu prawnego,
- domniemanie prawidłowości dokumentu urzędowego,
- uznaniowość organu,
- tajemnicę ustawowo chronioną,
- bezpieczeństwo publiczne,
- brak szkody albo związku przyczynowego,
- nieadekwatność środka.

## 9. Strategia
Priorytety:

1. zabezpiecz termin i dowód doręczenia,
2. uzyskaj akta i pełną podstawę rozstrzygnięcia,
3. oddziel zarzuty formalne od materialnych,
4. wskaż fakty decydujące, nie wszystkie fakty,
5. buduj żądanie główne i ewentualne,
6. przygotuj wariant: organ → sąd administracyjny/cywilny/karny/dyscyplinarny,
7. oceń, czy korzystniejsze jest uchylenie, zmiana, stwierdzenie nieważności, wznowienie, odszkodowanie lub skarga.

## 10. Orzecznictwo
Nie wpisuj fikcyjnych sygnatur. Szukaj tylko realnych orzeczeń w:

- SN / NSA / TK,
- CBOSA,
- Portalu Orzeczeń Sądów Powszechnych,
- orzeczeniach sądów dyscyplinarnych, jeżeli publicznie dostępne,
- LEX/Legalis pomocniczo.

Każde orzeczenie oceniaj według: aktualność, hierarchia sądu, analogiczność stanu faktycznego, linia dominująca/odmienna.

## 11. Ryzyka
Oceń:

- ryzyko zwrotu/odrzucenia,
- ryzyko spóźnienia,
- ryzyko braku legitymacji,
- ryzyko niewykazania faktu,
- ryzyko niedopuszczalności dowodu,
- ryzyko uznania organu,
- ryzyko kosztowe,
- ryzyko retorsji służbowej/dyscyplinarnej,
- ryzyko równoległych postępowań.

## 12. Quality gate
Przed odpowiedzią lub pismem zastosuj:

- `shared/POLISH-LAW-FINAL-COMPLETENESS-GATE.md`,
- `shared/ISAP-AUDIT-PROTOCOL.md`,
- `shared/TEMPORAL-LAW-CHECK.md`,
- `shared/LEGAL-QUALITY-GATE.md`,
- `shared/RISK-ASSESSMENT.md`, jeżeli istnieje,
- `shared/FORMAL-CHECK.md`, jeżeli powstaje pismo.
