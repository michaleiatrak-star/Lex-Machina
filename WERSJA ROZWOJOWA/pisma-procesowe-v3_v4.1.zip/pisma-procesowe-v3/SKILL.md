---
name: pisma-procesowe-v3
version: 4.3
type: executive-pisma
status: production
description: |
  Modularny framework do pism procesowych na poziomie kancelaryjnym.
  Pipeline: W1 (rama + CLAIM-VALIDATION + RED-TEAM) → W2 (projekt +
  executive summary + timing + doktryna + ATAK-NA-DRAFT) → W3
  (PODMIOT-GATE → ISAP → orzeczenia → fakty → walidacja A–J z triggerami
  → LEGAL-QUALITY-GATE → AUDYT-KONCOWY z COURT-SIMULATION → PEER-REVIEW
  + POST-VALIDATION) → .docx.
  Engines specjalistyczne z matrycą aktywacji: appellate-v8 (apelacja),
  prosecution-v8 (prokuratura), rebuttal-v9 (riposta), theory-of-case
  (≥2 roszczenia), V10 engines (matryca 4 warunków).
  Poziom: kancelaryjny — każde pismo przechodzi przez 4-etapową kontrolę
  jakości (LEGAL-QUALITY-GATE, AUDYT-KONCOWY, PEER-REVIEW, POST-VALIDATION).
compatibility: "Wymaga narzędzi: web_search, web_fetch"
changelog:
  - "4.6: MOD-PORCJOWANIE-DOWODOW.md wpisany do W1.2c jako KROK PD0 przed
    MOD-MACIERZ-DOWOD-TEZA. Trigger: STATUS ≥ OSTRZEŻENIE (≥6 plików lub
    >100 KB materiału) → PD1/PD2 plan partii → STOP. STATUS KRYTYCZNE →
    ⛔ HARD GATE (≥30 plików lub >800 KB) — nie uruchamia macierzy bez planu.
    Macierz D×T budowana per partia; checkpoint PD4 po każdej; PD6 synteza
    finalna po ostatniej partii zasila W1.3."
  - "4.5: MOD-MACIERZ-DOWOD-TEZA.md (nowy plik kanoniczny shared/).
    Uzupełnia MOD-SELEKCJA-DOWODOW (kierunek Teza→Dowód) o skan dwukierunkowy:
    MT1 (inwentaryzacja) → MT2 (SKAN-A: każdy dowód pod wszystkie tezy;
    SKAN-B: każda teza pod wszystkie dowody) → MT3 (klasyfikacja K/R/W/RK) →
    MT4 (raport z macierzą D×T, pokryciem tez, lukami, dowodami wielofunkcyjnymi) →
    MT5 (zasilenie W1.3). Pozycja w pipeline: W1.2c, po CLAIM-VALIDATION
    i MOD-STRATEGIA-WYBOR, przed W1.3. STOP po MT4 — wymaga zatwierdzenia.
    ZAKAZ-1C: nie przechodzić do W1.3 bez zatwierdzonej macierzy (gdy ≥2 dowody).
    Kluczowa cecha: jeden dowód może i powinien obsługiwać wiele tez jednocześnie
    (klasa W — wielofunkcyjny); w sekcji Na dowód powołuje się go raz z listą tez."
  - "4.4: Trzy nowe moduły / rozszerzenia po analizie sprawy VII P 94/25.
    (1) MOD-PRACODAWCA-RZECZYWISTY.md (nowy, w modules/) — sekwencja PR1-PR4
    dla spraw wielopodmiotowych: przyznanie odrębności → kryteria faktyczne →
    orzecznictwo SN (II PK 50/13, I PK 179/14, II PK 170/11) → zasilenie W1.3.
    Trigger: ≥2 podmioty / różne KRS na umowach / zmiana nazwy pracodawcy.
    (2) MOD-DOWODY.md — rozszerzony o D6 (eksploracja dowodów wielowarstwowych:
    XLS z ciągłą numeracją, tabele rekrutacyjne po dacie spornej, korespondencja
    komunikatorami z tabelaryzacją granicznych dat HP/HPG, osobisty akt organu
    pracodawcy jako niedopuszczenie do pracy) i D7 (antycypacja zarzutów —
    P1/P2/P3/P4 z gotowymi szablonami kontrargumentów).
    (3) SKILL.md: W1.3 rozszerzony o obowiązkową bramkę D6 i antycypację zarzutów;
    W1.4b dodany (tabela dla roszczeń narastających z precyzyjnymi datami
    wymagalności odsetek i klauzulą przyrostową art. 316 §1 KPC);
    W2.1 rozszerzony o MOD-PRACODAWCA-RZECZYWISTY z triggerem podmiotowym.
    Przyczyna: analiza porównawcza wersji generowanej (6,8/10) i wersji
    poprawionej przez użytkownika (9,1/10) w sprawie VII P 94/25."
  - "4.3: Dodano krok D5 (analiza własnych słabości i ryzyk RP/RD/RPC)
    do MOD-ATAK-NA-DRAFT v1.1.0 i do sekwencji W2.4 w SKILL.md.
    Naprawiono ZASADĘ 7: output jako pełne ZIPy skilli, nie luźne pliki."
  - "4.2: NAPRAWA KRYTYCZNA — W2.4 MOD-ATAK-NA-DRAFT.
    Root cause błędu: sekcja W2.4 odsyłała do view() pliku
    shared/MOD-ATAK-NA-DRAFT.md który nie istniał — co powodowało ciche
    pominięcie kroku bez sygnalizacji błędu, model kontynuował do W3.
    Naprawy: (1) Utworzono brakujący plik kanoniczny
    shared/MOD-ATAK-NA-DRAFT.md v1.0.0 z protokołem D1-D4 i RAPORTEM D.
    (2) Wzmocniono zapis W2.4 w SKILL.md: dodano ⛔⛔⛔ HARD GATE,
    explicit sekwencję D1→D2→D3→D4→RAPORT D, klauzulę obsługi błędu
    view() (zatrzymaj się zamiast cicho pomijać), ZAKAZ-9 w automacie
    stanów. (3) Dodano W2.4 jako blokujący krok do SELF-CHECK
    (przed dotychczasowym PODMIOT-GATE). (4) Zaktualizowano STAN 2
    automatu stanów z explicit rozwinięciem sekwencji W2.4."
  - "4.1: POZIOM KANCELARYJNY — integracja 12 wcześniej izolowanych modułów
    jakości i redakcji z pipeline'm W1–W3.
    (1) W2.1: dodano MOD-TIMING (strategia czasowa złożenia — macierz T1–T5)
    i MOD-DOKTRYNA (hierarchia D-1..D-4: orzeczenie > doktryna; komentarze
    Gniewek/Gudowski/Manowska/Feliga) jako moduły z konkretnymi triggerami.
    (2) W2.2: wstawiony hook MOD-INTRO (executive summary 2–5 zdań / max 150
    słów) jako element struktury pisma — obowiązkowy przy pozwie, apelacji,
    piśmie >3 str.; sędzia czyta ramę poznawczą przed uzasadnieniem.
    (3) W3.4 Blok C: MOD-KONCENTRACJA (limity orientacyjne per typ pisma:
    pozew ≤8-14 str., apelacja ≤10 str., riposta ≤5 str.; WARN/ALERT bez
    blokady) i QUALITY-CHECK (kontrola redakcyjna + logiczna + executive
    summary) wpięte jako obowiązkowe pod-kroki Bloku C.
    (4) W3.4: wszystkie 6 modułów warunkowych otrzymały twarde triggery
    (ZAWSZE gdy X — NIE 'zależnie od sprawy'): TERM-CALC, PREKLUZJA-DOWODOWA,
    DOWODY-METODOLOGIA, ROSZCZENIA, STRATEGIA-PROCESOWA, ISAP-AUDIT-PROTOCOL.
    EXPERT-OPINION-AUDIT dodany z triggerem: opinia biegłego w aktach.
    (5) W3.4 po Bloku E: LEGAL-QUALITY-GATE (bramka PASS/PASS-WITH-WARNING/FAIL
    — kryteria: brak podstawy prawnej, stary Dz.U., brak orzeczeń, brak ryzyka
    dezaktualizacji); FAIL = ⛔ BLOKADA .docx.
    (6) W3.6a: LEGAL-QUALITY-GATE jako Krok 2 (przed AUDYT-KONCOWY punktowym);
    sekwencja: COURT-SIMULATION → LEGAL-QUALITY-GATE → AUDYT-KONCOWY 0-10.
    (7) Nowy krok W3.7 PEER REVIEW + POST-VALIDATION — ostatni checkpoint
    kancelaryjny przed .docx: MOD-PEER-REVIEW (4 role: adwokat diabła /
    sędzia / klient / spójność wewnętrzna; aktywny gdy WPS>50k lub ≥3
    żądania lub apelacja SN/SA; PEER-STOP = blokada .docx) + POST-VALIDATION
    (zawsze; FAZA 1: auto-raport braków; FAZA 2: wstawienie danych).
    (8) Automat stanów STAN 3 aktualizowany: W3.7 jako osobny etap między
    W3.6a a .docx.
    (9) SELF-CHECK: 5 nowych pól (LEGAL-QUALITY-GATE, W3.7 PEER-REVIEW,
    W3.7 POST-VALIDATION, MOD-INTRO, MOD-KONCENTRACJA).
    (10) MODUŁY-MAPA: 10 nowych wpisów z konkretnymi wiadomościami i triggerami:
    MOD-TIMING, MOD-DOKTRYNA, MOD-INTRO, ISAP-AUDIT-PROTOCOL, LEGAL-QUALITY-GATE,
    MOD-KONCENTRACJA, QUALITY-CHECK, RISK-ASSESSMENT, EXPERT-OPINION-AUDIT,
    ORZECZENIA-HIERARCHIA, MOD-PEER-REVIEW, POST-VALIDATION.
    (11) Pliki kanoniczne shared: 7 nowych wpisów view z triggerami."
  - "4.0: PEŁNY AUDYT SYSTEMU — 10 napraw strukturalnych (K1-K4, P1-P6, U1-U2)."
  - "3.9: FIX KRYTYCZNY — PODMIOT-GATE nie był wykonywany przed W3.1."
  - "3.8: PODMIOT-GATE rozszerzony na sąd/organ. W2.4 MOD-ATAK-NA-DRAFT."
  - "3.7: W1.6 MOD-RED-TEAM-WLASNY. W3.6a AUDYT-KONCOWY. REGUŁA FINALNA."
  - "3.6: W3.0 PODMIOT-GATE — bramka KRS/CEIDG/BIP."
  - "3.5: W3.2 ZAKRES-STOSOWANIA dla orzeczeń."
  - "3.4: AUTO-WYPEŁNIENIE z MOD-SELEKCJA-DOWODOW."
  - "3.3: MOD-MAPA-PRZEPISOW → W1.2b."
  - "3.2: MOD-WARIANTY-POZWU."
  - "3.1: MOD-REDAKCJA."
---
description: |
  Modularny framework do pism procesowych (pozew, apelacja, zażalenie,
  sprzeciw, pismo przygotowawcze i inne) w sprawach cywilnych,
  pracowniczych, karnych i administracyjnych. Stosuj gdy użytkownik
  prosi o pismo sądowe lub opisuje konflikt prawny.
  Model: W1 rama → W1.6 red-team tez → W2 projekt → W2.4 atak na draft
  → W3 weryfikacja ze źródeł (HARDGATE/ISAP) → W3.0 PODMIOT-GATE
  (spółki/CEIDG/sąd-organ) → W3.6a audyt punktowy 0-10 → .docx.
  ⛔ PODMIOT-GATE (W3.0) jest PIERWSZYM krokiem W3 — blokuje W3.1.
  CLAIM-VALIDATION (W1.2a) — obowiązkowe przed W1.3.
  Engines specjalistyczne: appellate-v8 (apelacja), prosecution-v8
  (prokuratura), rebuttal-v9 (riposta), theory-of-case (≥2 roszczenia),
  court-simulation (W3.6a). V10 engines: matryca 4 warunków aktywacji.
  MOD-REDAKCJA (Test A): gate R.4b (PODMIOT, AUDYT, HYBRID).
  MOD-ETAPY: opakowuje W1–W3, nie zastępuje automatu stanów.
  Przepisy i orzeczenia wyłącznie z oficjalnych źródeł. Nigdy z pamięci.
compatibility: "Wymaga narzędzi: web_search, web_fetch (weryfikacja przepisów i orzeczeń online)"
changelog:
  - "4.0: PEŁNY AUDYT SYSTEMU — 10 napraw strukturalnych i optymalizacji.
    (1) K1: MOD-ROUTE zdeprecjonowany jako główny router — przepisany jako
    pomocnicza matryca informacyjna bez własnej sekwencji ładowania;
    KROK 0 (Testy A/B/C) jest jedynym routerem.
    (2) K2: 8 martwych engines (theory-of-case, appellate-v8, rebuttal-v9,
    court-simulation, admin-pleading-v8, prosecution-v8, opponent-attack-v9,
    formal-validator) wpisane do MODUŁY-MAPA z konkretnymi warunkami aktywacji
    i sekwencją wywołania; court-simulation zintegrowany z W3.6a/AUDYT-KONCOWY.
    (3) K3: CLAIM-VALIDATION dodane do MODUŁY-MAPA (W1.2a, zawsze) i do sekcji
    pliki kanoniczne shared; oznaczone ⛔ OBOWIĄZKOWE w W1.2a.
    (4) P1: MOD-REDAKCJA — nowy krok R.4b GATE JAKOŚCI po R.4 i przed R.5:
    PODMIOT-GATE (uproszczony), AUDYT-KONCOWY (2 kategorie), HYBRID-VALIDATION;
    ścieżka Test A przestaje być wolna od kontroli jakości.
    (5) P2: V10 engines — formalna matryca 4 warunków aktywacji (A/B/C/D);
    'gdy sprawa wymaga głębokiej analizy' zastąpione konkretnym testem decyzyjnym;
    V10 wywołuje się łącznie z opponent-attack-v9 i checklist.
    (6) P3: MOD-ETAPY — dodana REGUŁA PIERWSZEŃSTWA (opakowuje W1–W3, nie
    zastępuje); mapowanie Etap→W1/W2/W3; CLAIM-VALIDATION w Etapie 2;
    PODMIOT-GATE w Etapie 6; wszystkie ZAKAZY-1..8 obowiązują.
    (7) P5: Blok J MOD-WALIDACJA — ujednolicono A–I → A–J we wszystkich
    miejscach SKILL.md; W3.4 zawiera explicit wywołanie FSL i LSL przed Blokiem J.
    (8) P6: formal-validator i opponent-pleading-audit-checklist-v9 włączone
    do MODUŁY-MAPA i do SELF-CHECK jako pola obowiązkowe.
    (9) SELF-CHECK rozszerzony o: FORMAL-VALIDATOR, Blok J, COURT-SIMULATION,
    weryfikację engines specjalistycznych per typ pisma.
    (10) U1: MOD-OPLATY tabela OP-1 — dodany nagłówek WERYFIKACJA OBOWIĄZKOWA
    z instrukcją web_fetch ISAP; stawki oznaczone jako orientacyjne."
  - "3.9: FIX KRYTYCZNY — weryfikacja podmiotów (PODMIOT-GATE) nie była
    wykonywana przed redakcją w W3. Przyczyna: PODMIOT-GATE był opisany
    w W3.0 jako opis narracyjny, ale automat stanów (STAN 3) traktował go
    jako opcjonalny element w nawiasie, SELF-CHECK nie miał pola blokującego,
    a HARD GATE W3 nie miał warunku wejścia. Poprawki: (1) STAN 3 w automacie
    stanów przepisany — PODMIOT-GATE z własnym ⛔ i twardym STOP blokującym W3.1;
    (2) SELF-CHECK — nowe pole obowiązkowe z blokadą;
    (3) HARD GATE W3 — dodany explicit warunek wejścia;
    (4) ZAKAZ-8: zakaz przechodzenia do W3.1 bez zamkniętego W3.0;
    (5) REGUŁA NAPRAWY — nowy scenariusz dla pominięcia PODMIOT-GATE."
  - "3.8: PODMIOT-GATE (W3.0) rozszerzony na sąd/organ. W2.4 MOD-ATAK-NA-DRAFT."
  - "3.7: W1.6 MOD-RED-TEAM-WLASNY. W3.6a AUDYT-KONCOWY. REGUŁA FINALNA."
  - "3.6: W3.0 PODMIOT-GATE — bramka KRS/CEIDG/BIP."
  - "3.5: W3.2 ZAKRES-STOSOWANIA dla orzeczeń."
  - "3.4: AUTO-WYPEŁNIENIE z MOD-SELEKCJA-DOWODOW."
  - "3.3: MOD-MAPA-PRZEPISOW → W1.2b."
  - "3.2: MOD-WARIANTY-POZWU."
  - "3.1: MOD-REDAKCJA."
---

# Pisma Procesowe v3 — Model Trzech Wiadomości

---

## ⛔⛔⛔ HARD GATE ZERO — BEZWZGLĘDNY AUTOMAT STANÓW ⛔⛔⛔

> To jest pierwsza instrukcja. Wykonaj ją zanim przeczytasz cokolwiek innego.

---

### ⛔⛔⛔ PROTOKÓŁ CHECKPOINT — OBOWIĄZUJE PRZEZ CAŁĄ ROZMOWĘ ⛔⛔⛔

```
DEFINICJA CHECKPOINT:
  Po każdym kroku oznaczonym [CP] model MUSI:
  1. Wyświetlić raport CP (format poniżej)
  2. ZAKOŃCZYĆ ODPOWIEDŹ
  3. NIE kontynuować do następnego kroku bez wiadomości użytkownika

FORMAT RAPORTU CP:
  ┌─────────────────────────────────────────────────────────┐
  │ ✅ CHECKPOINT [nazwa] — ZAKOŃCZONY                       │
  │ Wykonane: [lista kroków]                                │
  │ Wyniki: [kluczowe ustalenia]                            │
  │ Problemy: [lista ⚠️ lub BRAK]                           │
  │                                                         │
  │ ➡️ Czy kontynuować do [następny krok]?                  │
  │    Odpowiedz: "tak" / "ok" / lub uwagi                  │
  └─────────────────────────────────────────────────────────┘

⛔ ZAKAZ-CP: model NIE może przejść do następnego etapu
   bez wiadomości użytkownika po każdym [CP].
   Nawet gdy użytkownik napisał "rób wszystko automatycznie" —
   ZAKAZ-CP jest nadrzędny. Checkpointy zapewniają kontrolę jakości.

WYJĄTEK: gdy użytkownik w tej samej wiadomości co trigger pisma napisał
   "bez checkpointów" lub "automatycznie bez zatwierdzeń" —
   wtedy zastosuj TRYB-AUTO (patrz sekcja TRYB-AUTO poniżej).
   Domyślnie: TRYB CHECKPOINT aktywny.

TRYB-AUTO (tylko gdy explicite zlecony):
   Wykonuj wszystkie kroki sekwencyjnie, ale wyświetl RAPORT KOŃCOWY
   z wynikami wszystkich CP przed generowaniem .docx.
   Wyniki każdego CP wbuduj inline w odpowiedź (nie przerywaj).
```

---

**AUTOMAT STANÓW — jedyna dozwolona sekwencja:**

```
STAN 0: Routing (Test A → Test B → Test C)

STAN 1: W1 — Rama i strategia
  → W1.1 Typ i tryb
  → W1.2 Teza centralna (wstępna)
  → W1.2a CLAIM-VALIDATION [CP-1a]
      view /mnt/skills/user/shared/CLAIM-VALIDATION.md
      ⛔ STOP [CP-1a] po zakończeniu → raport → czekaj na użytkownika

  → W1.2b MOD-STRATEGIA-WYBOR ⛔ (gdy ≥2 ścieżki LUB anomalia podmiotowa) [CP-1b]
      view /mnt/skills/user/shared/MOD-STRATEGIA-WYBOR.md
      S1 (ścieżki) → S2 (ocena ataków) → S3 (ranking+rekomendacja) →
      S4 (struktura) → S5 (RAPORT użytkownikowi)
      ⛔ Ścieżka z atakiem 🔴 bez kontrargumentu = PORZUĆ lub EWENTUALNA
      ⛔ STOP [CP-1b] → raport S5 → czekaj na zatwierdzenie użytkownika
      Po zatwierdzeniu: zaktualizuj W1.2 jeśli zmienił się wybór

  → W1.2c SKAN KOMPLETNOŚCI + PORCJOWANIE + MACIERZ ⛔ (gdy ≥2 dowody)

      KROK W1.2c-PRE (ABSOLUTNIE PIERWSZY — przed wszystkim): [CP-1c-skan]
        ⛔ HARD GATE — wykonaj PRZED PD0 i PRZED macierzą
        view /mnt/skills/user/shared/MOD-SKAN-DOWODOW-KOMPLETNY.md
        → SD-GATE-0: czy plik faktycznie wgrany gdy wzmianka o załącznikach?
          NIE → ⛔ BLOKADA W1.3 i W2 — zażądaj plików, nie kontynuuj
        → SD-INW: zinwentaryzuj WSZYSTKIE pliki (ZIP → zawartość, nie kontener)
        → SD-READ: odczytaj KAŻDĄ STRONĘ (PDF per str., XLSX per zakładkę,
          ODT z obrazami: każdy obraz, protokół sądowy: każde zdanie)
        → SD-VER: kompletność potwierdzona → wygeneruj SD-REJ ✅
        → SD-GATE-4: jeśli SD-VER ≠ KOMPLET → BLOKADA W2, wróć do SD-READ
        ⛔ Pominięcie strony/zakładki/obrazu ODT = BŁĄD KRYTYCZNY
        ⛔ Szczególnie: protokoły sądowe → KAŻDE zdanie zeznań → SD-FAKTY
        ⛔ STOP [CP-1c-skan] → raport SD-VER pełny → czekaj na użytkownika

      KROK W1.2c-PD0 (PO SD-VER KOMPLET — zawsze):
        view /mnt/skills/user/shared/MOD-PORCJOWANIE-DOWODOW.md → PD0 (skan wstępny).
        STATUS BEZPIECZNY → kontynuuj do MOD-MACIERZ-DOWOD-TEZA.
        STATUS ≥ OSTRZEŻENIE → PD1 → PD2 (plan partii) → ⛔ STOP [CP-PD].
          Po P1: macierz częściowa (Di z P1 × Tj) → PD4 (checkpoint) → ⛔ STOP [CP-PD].
          Po Pn: macierz pełna → PD6 (synteza) → zasilenie W1.3.
        STATUS KRYTYCZNE → ⛔ HARD GATE → nie uruchamiaj macierzy bez planu.

      KROK W1.2c-MACIERZ (gdy STATUS BEZPIECZNY lub po zatwierdzeniu planu P1): [CP-1c-macierz]
        view /mnt/skills/user/shared/MOD-MACIERZ-DOWOD-TEZA.md
        MT1 (inwentaryzacja tez+dowodów z bieżącej partii) →
        MT2 (skan dwukierunkowy) → MT3 (klasyfikacja K/R/W/RK) →
        MT4 (RAPORT macierzy D×T)
        ⛔ STOP [CP-1c-macierz] → wyświetl macierz → czekaj na zatwierdzenie
        Po zatwierdzeniu: MT5 → zasilenie W1.3

  → W1.3 Mapa przepisów + tezy (lista robocza ⚠️ nieweryfikowane)
  → W1.6 RED-TEAM (gdy aktywny — sprawa złożona / ≥3 żądania / WPS>50k)
      view /mnt/skills/user/shared/MOD-RED-TEAM-WLASNY.md
  → W1 RAPORT KOŃCOWY (typ pisma, teza centralna, ścieżka strategiczna,
      lista przepisów roboczych, lista dowodów z funkcją, słabości wykryte)
  ⛔ STOP [CP-W1] → wyświetl raport W1 → czekaj na zatwierdzenie użytkownika
  ⛔ ZAKAZ: nie przechodzij do STAN 1.5 bez wiadomości "ok"/"kontynuuj"/uwag

STAN 1.5: PRE-W2-VERIFICATION-GATE ⛔ BLOKUJE W2 [CP-PRE-W2]
  view /mnt/skills/user/shared/PRE-W2-VERIFICATION-GATE.md
  PRE-W2.A → PRE-W2.B (sąd online — web_search/web_fetch) →
  PRE-W2.C (pozwany KRS — ekrs.ms.gov.pl) →
  PRE-W2.D (cross-check numerów rejestrowych z akt) →
  PRE-W2.E RAPORT PRE-W2
  ⛔ STOP [CP-PRE-W2] → wyświetl raport PRE-W2 → czekaj na użytkownika
  GATE-OK/WARN: po zatwierdzeniu → W2.1
  GATE-STOP: czekaj na wyjaśnienie → aktualizuj raport → ponów → W2.1

STAN 2: W2 — Projekt pisma
  → W2.1 Moduły (WYŁĄCZNIE dane z raportu PRE-W2 dla podmiotów i adresów)
  → W2.2 Redakcja + MOD-INTRO (obowiązkowy: pozew/apelacja/>3str) +
          MOD-TIMING (gdy timing istotny) + MOD-DOKTRYNA (gdy doktryna w uzasadnieniu)
  → W2.3 Lista placeholderów ⚠️[WERYFIKACJA W3]
  → ⛔ W2.4 MOD-ATAK-NA-DRAFT (OBLIGATORYJNY — ZAWSZE, BEZ WYJĄTKU) [CP-ATAK]
      view /mnt/skills/user/shared/MOD-ATAK-NA-DRAFT.md
      D1 (słabości własne) → D2 (ataki przeciwnika) → D3 (luki dowodowe) →
      D5 (ryzyka RP/RD/RPC) → D4 (rekomendacje)
      ⛔ STOP [CP-ATAK] → wyświetl RAPORT D → czekaj na użytkownika
      ATAK-OK/UWAGI: po zatwierdzeniu → W3
      ATAK-STOP: czekaj na wyjaśnienie → popraw projekt → ponów D4 → W3

STAN 3: W3 — Weryfikacja + walidacja
  ⛔ PODMIOT-GATE (W3.0) — ZAWSZE PIERWSZY [CP-PODMIOT]
      zweryfikuj KAŻDY ⚠️POD (strona + sąd/organ) online
      ⛔ STOP [CP-PODMIOT] → raport statusów ✅/⚠️/⛔ per podmiot → czekaj
      → dopiero po zamknięciu: W3.1

  → W3.1 ISAP — web_fetch/web_search KAŻDEGO ⚠️[artykuł] z W2
      ⛔ ZAKAZ: żaden artykuł bez własnego wywołania web_fetch w tej odpowiedzi
  → W3.2 Orzecznictwo — orzeczenia-sadowe-v2 dla KAŻDEGO [ORZECZENIE: opis]
      ⛔ ZAKAZ: żadna sygnatura bez weryfikacji online — nawet "oczywiste"
  → W3.3 Fakty — FAKTY_v2.md (F0-F3: każdy fakt → źródło w aktach)
  → W3.4 Walidacja — MOD-WALIDACJA_v2 (bloki A–J)
      view /mnt/skills/user/shared/MOD-WALIDACJA_v2.md
      + FACT-SOURCE-LOCK + LEGAL-STATUS-LOCK (prereq. Bloku J)
      + MOD-KONCENTRACJA (limity objętości per typ pisma)
      + QUALITY-CHECK (redakcja + logika + executive summary)
  → W3.5 LEGAL-QUALITY-GATE [CP-QUALITY]
      view /mnt/skills/user/shared/LEGAL-QUALITY-GATE.md
      PASS → W3.6
      PASS-WITH-WARNING → W3.6 (zaznacz ostrzeżenia)
      FAIL → ⛔ BLOKADA .docx → wróć do W3.1/W3.2 → popraw
      ⛔ STOP [CP-QUALITY] → wyświetl wynik gate → czekaj
  → W3.6 Pismo finalne (wszystkie ⚠️ zamknięte, sygnatury z W3.2)
  → W3.6a AUDYT-KOŃCOWY [CP-AUDYT]
      COURT-SIMULATION → LEGAL-QUALITY-GATE → audyt punktowy 0-10
      ⛔ STOP [CP-AUDYT] → wyświetl wyniki → czekaj
      audyt ≥7/10 każda kategoria → W3.7
      audyt <7/10 → wskaż kategorie → popraw → ponów audyt
  → W3.7 PEER-REVIEW + POST-VALIDATION [CP-PEER]
      view /mnt/skills/user/shared/MOD-PEER-REVIEW.md (gdy WPS>50k / ≥3 żądania / apelacja)
      view /mnt/skills/user/shared/POST-VALIDATION.md (zawsze)
      FAZA 1: auto-raport braków
      FAZA 2: wstawienie danych / zamknięcie ⬛
      ⛔ STOP [CP-PEER] → wyświetl wyniki → czekaj
      PEER-STOP → ⛔ BLOKADA .docx → popraw → ponów
      PEER-OK → generuj .docx
```

**MAPA CHECKPOINTÓW — kompletna lista:**

```
[CP-1a]          CLAIM-VALIDATION — zawsze
[CP-1b]          MOD-STRATEGIA-WYBOR — gdy ≥2 ścieżki lub anomalia podmiotowa
[CP-1c-skan]     SD-VER (skan plików) — gdy wgrane pliki
[CP-PD]          PORCJOWANIE — gdy STATUS ≥ OSTRZEŻENIE
[CP-1c-macierz]  MACIERZ D×T — gdy ≥2 dowody
[CP-W1]          RAPORT W1 KOŃCOWY — zawsze
[CP-PRE-W2]      PRE-W2-VERIFICATION-GATE — zawsze
[CP-ATAK]        MOD-ATAK-NA-DRAFT — zawsze
[CP-PODMIOT]     PODMIOT-GATE W3.0 — zawsze
[CP-QUALITY]     LEGAL-QUALITY-GATE — zawsze
[CP-AUDYT]       AUDYT-KOŃCOWY — zawsze
[CP-PEER]        PEER-REVIEW + POST-VALIDATION — zawsze

ŁĄCZNIE: 8 checkpointów obowiązkowych + 4 warunkowe
⛔ Każdy = osobna wiadomość kończąca odpowiedź + oczekiwanie na użytkownika
```

**ZAKAZY BEZWZGLĘDNE automatu — ŻADEN NIE MA WYJĄTKU:**

```
⛔ ZAKAZ-CP (NADRZĘDNY): Po każdym [CP] zakończ odpowiedź i czekaj.
            NIE ma wyjątku nawet gdy użytkownik napisał "rób wszystko".
            Checkpoint = fizyczna granica między etapami. Bez wiadomości
            użytkownika model nie ma podstawy do przejścia dalej.

⛔ ZAKAZ-1: NIE generuj projektu pisma (W2) bez ukończonego W1 i zatwierdzenia przez użytkownika.
⛔ ZAKAZ-1C: NIE przechodzij do W1.3 bez zamkniętej W1.2c (MOD-MACIERZ-DOWOD-TEZA)
            gdy użytkownik dostarczył ≥2 dowody. Macierz D×T musi być zatwierdzona.
            Pominięcie = pismo niewykorzystuje wielofunkcyjnych dowodów i ma luki.
⛔ ZAKAZ-1B: NIE generuj projektu pisma (W2) bez zamkniętego PRE-W2-VERIFICATION-GATE.
            GATE-OK lub GATE-WARN = wymagane; GATE-STOP = blokada W2 do odpowiedzi użytkownika.
            ⛔ Adres sądu/organu z pamięci modelu = ZAKAZ użycia w W2 bez weryfikacji PRE-W2.B.
            ⛔ KRS/NIP pozwanego z pamięci = ZAKAZ użycia w W2 bez weryfikacji PRE-W2.C.
            ⛔ Argument prawny oparty na tożsamości/odmienności podmiotów = ZAKAZ bez PRE-W2.D.
⛔ ZAKAZ-2: NIE wstawiaj żadnego numeru Dz.U. ani sygnatury orzeczenia w W2.
            Każdy przepis w W2 = ⚠️[art. X ustawa — WERYFIKACJA W3]
            Każde orzeczenie w W2 = [ORZECZENIE: opis → WERYFIKACJA W3]
⛔ ZAKAZ-3: NIE generuj pisma finalnego (.docx) bez ukończonego W3.
⛔ ZAKAZ-4: NIE łącz dwóch wiadomości w jednej odpowiedzi (np. W1+W2 w jednym kroku).
⛔ ZAKAZ-5: NIE cytuj przepisów ani orzeczeń z pamięci na żadnym etapie.
            Każdy artykuł KPK/KK/KPC/KC/KP/KPA — weryfikacja ISAP w W3.
⛔ ZAKAZ-6: NIE używaj orzeczenia gdy zakres stanów faktycznych nie obejmuje pisma
            (patrz KROK 3a ZAKRES-STOSOWANIA w W3.2).
⛔ ZAKAZ-7: NIE wpisuj danych rejestrowych podmiotów (NIP, KRS, REGON, adres siedziby,
            skład zarządu, forma prawna, sposób reprezentacji) z pamięci ani bez weryfikacji
            w KRS (ekrs.ms.gov.pl) lub CEIDG. Dane podane przez użytkownika = ⚠️POD
            do weryfikacji w W3.0. Wyjątek: osoba fizyczna nieprowadząca działalności.
⛔ ZAKAZ-8: NIE przechodzij do W3.1 (weryfikacja przepisów) bez uprzedniego wykonania
            W3.0 PODMIOT-GATE dla KAŻDEGO podmiotu ⚠️POD — zarówno stron jak i sądu/organu.
            Kolejność W3 jest bezwzględna: W3.0 → W3.1 → W3.2 → W3.3 → W3.4 → W3.5 → W3.6.
⛔ ZAKAZ-9: NIE przechodzij do W3 bez wyświetlonego RAPORTU D z W2.4 MOD-ATAK-NA-DRAFT.
            W2.4 jest OBLIGATORYJNY — brak pliku MOD-ATAK-NA-DRAFT.md nie zwalnia z kroku;
            jeśli view() zwróci błąd — zatrzymaj się i poinformuj użytkownika.
            Pominięcie W2.4 = błąd krytyczny; powróć do W2.4 i wykonaj retroaktywnie.
⛔ ZAKAZ-10: NIE generuj W2 (projektu pisma) bez ukończonego W1.2c-PRE
            (MOD-SKAN-DOWODOW-KOMPLETNY). SD-VER musi mieć status KOMPLET.
            Zakaz obejmuje sytuację gdy użytkownik wspomina o załącznikach/dowodach
            ale ich nie wgrał — w takim wypadku: STOP, zażądaj plików, nie generuj.
            ⛔ Pominięcie choćby jednej strony / zakładki / obrazu ODT = BŁĄD KRYTYCZNY.
            ⛔ Protokoły sądowe: każde zdanie zeznań świadka = osobny wpis SD-FAKTY.
            W2.4 jest OBLIGATORYJNY — brak pliku MOD-ATAK-NA-DRAFT.md nie zwalnia z kroku;
            jeśli view() zwróci błąd — zatrzymaj się i poinformuj użytkownika.
            Pominięcie W2.4 = błąd krytyczny; powróć do W2.4 i wykonaj retroaktywnie.
```

**REGUŁA AUTODIAGNOZY — sprawdź przed każdą odpowiedzią:**

```
ŚLEDŹ AKTYWNE CHECKPOINTY — przed każdą odpowiedzią:
  □ Który [CP] jest aktualnie otwarty?
  □ Czy użytkownik potwierdził poprzedni [CP]?
  □ Czy mam podstawę do przejścia do następnego kroku?

  NIE → wyświetl przypomnienie: "Czekam na potwierdzenie [CP-X] przed kontynuacją."
  TAK → kontynuuj do następnego kroku → wykonaj → [CP-następny] → STOP

Czy użytkownik prosił o pismo procesowe / zażalenie / pozew / apelację?
  TAK → czy [CP-1a] CLAIM-VALIDATION zamknięty?
          NIE → wykonaj CLAIM-VALIDATION → [CP-1a] → STOP
          TAK → czy [CP-1c-skan] SD-VER zamknięty (gdy pliki)?
                  NIE → dokończ skanowanie → [CP-1c-skan] → STOP
                  TAK → czy [CP-1c-macierz] macierz D×T zatwierdzona?
                          NIE → wykonaj macierz → [CP-1c-macierz] → STOP
                          TAK → czy [CP-W1] rama zatwierdzona?
                                  NIE → wyślij raport W1 → [CP-W1] → STOP
                                  TAK → czy [CP-PRE-W2] zamknięty?
                                          NIE → PRE-W2 gate → [CP-PRE-W2] → STOP
                                          TAK → czy [CP-ATAK] zamknięty?
                                                  NIE → MOD-ATAK-NA-DRAFT → [CP-ATAK] → STOP
                                                  TAK → W3 → [CP-PODMIOT] → ...
```

**REGUŁA NAPRAWY — gdy naruszono automat:**

```
Jeśli wykryjesz, że pominąłeś W1 lub W2 lub W3:
  → STOP natychmiast
  → Poinformuj użytkownika o naruszeniu
  → Wróć do brakującego etapu
  → NIE kontynuuj od miejsca pominięcia

Jeśli wykryjesz, że wykonałeś W3.1 bez uprzedniego W3.0 PODMIOT-GATE:
  → STOP natychmiast
  → Poinformuj użytkownika o pominięciu weryfikacji podmiotów
  → Wykonaj W3.0 PODMIOT-GATE teraz — dla wszystkich ⚠️POD
  → Dopiero po jego zamknięciu wróć do W3.1
  → NIE traktuj wyników W3.1 jako ważnych, jeśli podmiot/sąd okazał się błędny
```

> ⛔ HARD GATE — ZAKAZ CYTOWANIA PRAWA I ORZECZEŃ Z PAMIĘCI
> Żaden artykuł, numer Dz.U., stawka, termin ustawowy, kara ani sygnatura orzeczenia
> nie może być podany bez weryfikacji online. Dotyczy wszystkich trzech wiadomości.
> Procedura: view /mnt/skills/user/shared/PRAWO-HARDGATE.md

---

## ZASADA GŁÓWNA — MODEL TRZECH WIADOMOŚCI

Każde pismo procesowe powstaje w trzech izolowanych wiadomościach. Żadna nie może być pominięta. Żadna nie może być połączona z inną.

```
W1 — RAMA I STRATEGIA
     Co dowodzimy, czym, jakie przepisy (lista robocza ⚠️ nieweryfikowane)
     → checkpoint: użytkownik zatwierdza ramę przed redakcją
     → STOP po W1 — czekaj na odpowiedź użytkownika

W2 — PROJEKT PISMA
     Pełna redakcja procesowa. Przepisy jako ⚠️[WERYFIKACJA W3].
     Sygnatury orzeczeń: ZAKAZ — tylko placeholder [ORZECZENIE: opis → W3]
     → STOP po W2 — nie pytaj użytkownika, przejdź do W3 automatycznie

W3 — WERYFIKACJA ZE ŹRÓDEŁ + WALIDACJA
     web_fetch dla każdego ⚠️ → zamknięcie przez zweryfikowane cytaty z ISAP
     web_fetch dla każdego [ORZECZENIE] → sygnatura + teza + URL ze źródła
     MOD-WALIDACJA (bloki A–I) → raport formalny
     Pismo finalne z pełnymi oznaczeniami Dz.U.
     → .docx generowany WYŁĄCZNIE po zamknięciu W3
```

> ZASADA IZOLACJI: W2 NIE MOŻE zawierać żadnego pełnego oznaczenia Dz.U. ani żadnej sygnatury orzeczenia.
> Każde takie wstawienie w W2 jest błędem krytycznym — przepis nieweryfikowany = przepis nieistniejący.

---

## KROK 0 — ROUTING (wykonaj przed uruchomieniem modelu)

> Kolejność wykonania: Test A → Test B → Test C. Test A ma priorytet —
> jeśli dotyczy, pomija pozostałe testy.

### Test A — Czy to redakcja istniejącego pisma (nie tworzenie nowego)?

```
TAK, gdy WSZYSTKIE są prawdą:
  ✓ Użytkownik dostarczył treść GOTOWEGO pisma (wklejona / plik)
  ✓ Żądanie dotyczy formy/stylu/długości/tonu, nie nowej argumentacji
  ✓ Nie proszono o dodanie nowych przepisów/orzeczeń/zarzutów

Sygnały: "popraw to pismo", "zredaguj", "skróć", "wzmocnij ton", "przeredaguj
na bardziej stanowczy/neutralny/negocjacyjny", "wygładź styl", "sprawdź i
popraw" (po raporcie z KROK F przewodnika).

→ TAK: przejdź do `modules/MOD-REDAKCJA.md` — NIE wykonuj W1-W2-W3, NIE
  sprawdzaj Testu B/C.
→ NIE: przejdź do Testu B.

Test A ma priorytet — jeśli użytkownik dostarczył gotowe pismo i prosi
o poprawki formy, nie kwalifikuj tego jako "pismo proste" (Test B) ani
nie uruchamiaj W1 (Test C) — to są ścieżki dla pism PISANYCH OD ZERA.
```

### Test B — Czy to pismo proste?

Pismo proste = spełnia WSZYSTKIE trzy warunki:
1. Jedno żądanie procesowe
2. Jedna podstawa prawna (nie wymaga analizy wielowątkowej)
3. Należy do katalogu: sprzeciw od nakazu (art. 503 KPC), zarzuty od nakazu
   (art. 493 KPC), wniosek o klauzulę (art. 781 KPC), wniosek o wszczęcie
   egzekucji (art. 797 KPC), zabezpieczenie (art. 730 KPC), zwolnienie od kosztów
   (art. 102 KSCU), uzasadnienie wyroku (art. 328¹ KPC), przywrócenie terminu
   (art. 168 KPC), wezwanie przedsądowe (art. 455 KC), wgląd do akt (art. 9 KPC),
   doręczenie przez komornika (art. 139¹ KPC), sprzeciw od orzeczenia referendarza
   (art. 398²² KPC).

→ TAK na wszystkie 3: zaproponuj `pisma-proste-v2` i zapytaj użytkownika.
→ NIE na którykolwiek: przejdź do Testu C i kontynuuj model trzech wiadomości.

### Test C — Intake (dane minimalne)

Przed W1 ustal minimum — brakujące dane = jedno pytanie zbiorcze:

```
□ TYP PISMA:    [pozew / apelacja / sprzeciw / wniosek / riposta / zawiadomienie]
□ DZIEDZINA:    [cywilna / pracownicza / karna / administracyjna / gospodarcza]
□ STRONY:       [powód/wnioskodawca + pozwany/uczestnik]
□ ETAP:         [nowa sprawa / sprawa w toku — sygnatura: ___]
□ CEL:          [co osiągnąć tym pismem]
□ MATERIAŁY:    [czy użytkownik dostarczył dokumenty/akta — TAK/NIE]
```

Po uzyskaniu danych stron — oznacz każdy podmiot prowadzący działalność jako ⚠️POD.
Weryfikacja ⚠️POD następuje w W3.0 (PODMIOT-GATE). W W1 i W2 stosuj dane
dostarczone przez użytkownika z adnotacją ⚠️POD — nigdy nie wpisuj danych
rejestrowych z pamięci (NIP, KRS, REGON, adres, skład zarządu).

Gdy brak danych: view /mnt/skills/user/shared/INTAKE-GAP.md

---

## WIADOMOŚĆ 1 — RAMA I STRATEGIA

> ⛔ HARD GATE W1:
> NIE redaguj treści pisma w tej wiadomości.
> NIE podawaj pełnych numerów Dz.U.
> NIE podawaj sygnatur orzeczeń.
> Po ukończeniu W1 — ZATRZYMAJ SIĘ i czekaj na zatwierdzenie przez użytkownika.
> Przejście do W2 wymaga wyraźnej zgody: "tak" / "dalej" / "redaguj" / "ok".

> Cel W1: ustalić co dowodzimy, czym, i jakie przepisy będą potrzebne (lista robocza).

### W1.1 — Typ i tryb pisma

```
TYP PISMA:      [nazwa]
SĄD / ORGAN:    [nazwa — właściwość orientacyjna, weryfikacja w W3]
TRYB:           [uproszczony / zwykły / nakazowy / KPA / PPSA]
OPŁATA:         orientacyjna [kwota ⚠️ — weryfikacja w W3]
TERMIN ZAWITY:  [data lub "brak" — weryfikacja w W3]
```

### W1.2 — Teza centralna

Jedno zdanie:
```
"Dowodzimy że [X], co skutkuje [Y], na podstawie [dziedzina prawa]."
```

### W1.2a — CLAIM-VALIDATION (przed mapą przesłanek)

> ⛔ OBOWIĄZKOWE — wykonaj przed W1.3. Pomiń tylko gdy pismo nie zawiera
> żadnych twierdzeń faktycznych strony (praktycznie: nigdy).
> Wywołaj: `view /mnt/skills/user/shared/CLAIM-VALIDATION.md`

Przed zbudowaniem mapy przesłanka → dowód wykonaj weryfikację twierdzeń strony:

- Dla każdego twierdzenia faktycznego z opisu sprawy i dostarczonych dokumentów
  wykonaj kroki C1–C4 z MOD-CLAIM-VALIDATION.
- Twierdzenie `[⛔ SPRZECZNE]` → zastąp twierdzeniem wynikającym z materiału; poinformuj użytkownika.
- Twierdzenie `[⛔ NIEUDOWODNIONE]` → oznacz jako lukę; nie buduj na nim przesłanki;
  wpisz do W1.5 jako ⬛ BRAK ISTOTNY lub BRAK KRYTYCZNY zależnie od wagi.
- Wyświetl Raport Walidacji Twierdzeń jeśli wykryto błędy.

> Engines specjalistyczne — wywołaj PRZED W1.2 gdy aktywne (patrz MODUŁY-MAPA):
> ```
> view references/engines/theory-of-case-engine.md      (≥2 roszczenia / apelacja)
> view references/engines/appellate-engine-v8.md        (⛔ obowiązkowy przy apelacji)
> view references/engines/rebuttal-drafting-engine-v9.md (riposta / odpowiedź)
> view references/engines/prosecution-complaint-engine-v8.md (⛔ obowiązkowy: zażalenie do prokuratury)
> view references/engines/opponent-pleading-attack-engine-v9.md (analiza pisma przeciwnika)
> ```

### W1.2b — MOD-STRATEGIA-WYBOR (obligatoryjna ocena i ranking ścieżek)

> ⛔ HARD GATE W1.2b — dla każdego pisma złożonego gdy ≥2 ścieżki prawne
> lub anomalia podmiotowa w materiale dowodowym.
>
> Wywołaj: `view /mnt/skills/user/shared/MOD-STRATEGIA-WYBOR.md`
>
> Moduł jest NADRZĘDNY wobec MOD-WARIANTY-POZWU — wywołuje go wewnętrznie
> jako generator kart. Nie wywołuj MOD-WARIANTY-POZWU samodzielnie.

Jeśli warunek aktywacji spełniony:
1. S1 — zidentyfikuj WSZYSTKIE ścieżki (w tym anomalie podmiotowe: różne KRS/NIP)
2. S2 — oceń każdą ścieżkę pod kątem ataku przeciwnika (OCENA-A/B/C)
3. S3 — wygeneruj ranking z rekomendacją; ścieżka z atakiem 🔴 bez kontrargumentu
         → PORZUĆ lub EWENTUALNA — nigdy GŁÓWNA
4. S4 — wybierz strukturę pisma (Scenariusz 1/2/3)
5. S5 — wyświetl RAPORT STRATEGII użytkownikowi; czekaj na zatwierdzenie
6. Po zatwierdzeniu: zaktualizuj W1.2 (teza centralna) jeśli zmienił się wybór;
   zapisz wynik do MOD-HISTORIA-STRATEGII PRZED W1.3

⛔ ZASADA BEZWZGLĘDNA: Ścieżka z atakiem 🔴 bez kontrargumentu NIE może być
ścieżką główną. System OBLIGATORYJNIE rekomenduje ścieżkę silniejszą — użytkownik
może to zmienić, ale decyzja musi być explicite, nie domyślna.

Jeśli warunek aktywacji NIE jest spełniony — pomiń ten krok, przejdź do W1.3.

### W1.3 — Mapa: cel → przesłanka → dowód

> TRYB AUTO-WYPEŁNIENIA: jeśli przed W1 wykonano KROK 4a.5 (analizator-dowodow-v3
> → MOD-SELEKCJA-DOWODOW), ta mapa jest WSTĘPNIE WYPEŁNIONA automatycznie —
> zatwierdź lub zmień konkretne pola (np. inny DOC-ID). Możesz też oznaczyć
> przesłankę jako "pomijam świadomie" (decyzja strategiczna). Puste pole
> "Dowód" = LUKA — patrz W1.5. Przepisy jako ⚠️ do weryfikacji w W3.
>
> TRYB RĘCZNY: jeśli KROK 4a.5 nie był wykonany (brak analizatora) — wypełnij
> mapę ręcznie jak dotychczas.
>
> ⛔ BRAMKA D6 (OBOWIĄZKOWA gdy dostarczone tabele/XLS/zrzuty komunikatorów):
> Przed wypełnieniem mapy wykonaj D6.1–D6.5 z MOD-DOWODY:
>   D6.1 — ciągłość numeracji / wspólna kadra w arkuszach XLS
>   D6.2 — daty w tabelach zezwoleń / opłat po dacie spornej
>   D6.3 — tabelaryzacja korespondencji komunikatorami (graniczne daty HP/HPG,
>           wiadomości gotowości do pracy, osobisty akt Prezesa/organu)
>   D6.4 — spis zdawczo-odbiorczy akt jako dowód jednego archiwum
> Wynik D6 zasila przesłanki i dowody W1.3 bezpośrednio.
>
> ⛔ ANTYCYPACJA ZARZUTÓW (OBOWIĄZKOWA przy ≥2 ścieżkach lub ataku 🔴/🟠):
> Dla każdego przewidywanego zarzutu przeciwnika — dopisz sekcję antycypacji
> do uzasadnienia W2 (wzór: MOD-DOWODY D7). Antycypacja w piśmie głównym
> jest silniejsza procesowo niż obalenie w replice.

Dla każdego żądania:

```
┌─────────────────────────────────────────────────────────────────┐
│ ŻĄDANIE [nr]: [treść żądania]                                   │
├─────────────────────────────────────────────────────────────────┤
│ Przesłanka A: [co musimy udowodnić]                             │
│   Dowód:      [dokument / zeznanie / fakt bezsporny]            │
│   Siła:       [A=dokument urzędowy / B=prywatny / C=pośredni]  │
│ Przesłanka B: [co musimy udowodnić]                             │
│   Dowód:      [...]                                             │
│   Siła:       [...]                                             │
├─────────────────────────────────────────────────────────────────┤
│ Słabe punkty: [co przeciwnik może zaatakować —                  │
│               z RYZYKO-A i RYZYKO-B z MOD-SELEKCJA-DOWODOW]    │
│ Luki:         [czego brakuje — ⬛ z MOD-SELEKCJA-DOWODOW §2.3]  │
└─────────────────────────────────────────────────────────────────┘
```

### W1.4 — Lista robocza przepisów (⚠️ nieweryfikowane)

```
⚠️ [ustawa / kodeks] art. [X] §[Y] — cel użycia: [po co w piśmie]
⚠️ [ustawa / kodeks] art. [X] §[Y] — cel użycia: [po co w piśmie]
⚠️ [orzeczenie opisowo: "wyrok SN dot. X"] — cel użycia: [teza do wsparcia]

UWAGA: Wszystkie pozycje oznaczone ⚠️ wymagają weryfikacji w W3.
Numery Dz.U., daty aktów i sygnatury zostaną ustalone dopiero w W3.
```

### W1.4b — Tabela szczegółowa dla roszczeń pieniężnych narastających

> AKTYWUJ gdy: roszczenie pieniężne obejmuje wiele miesięcy, narasta do daty wyroku,
> LUB powiązane jest z konkretnymi zdarzeniami zewnętrznymi (np. datami refundacji,
> datami wypłat, datami decyzji administracyjnych).

```
Dla każdego roszczenia pieniężnego narastającego:

  KOLUMNY TABELI:
  Okres | Stawka/mc | Liczba miesięcy | Kwota brutto | Odsetki od (data wymagalności)

  ZASADA ODSETEK:
    - Data wymagalności = data wynikająca z umowy / regulaminu / ustawy
      (np. "do 10. dnia następnego miesiąca" → odsetki od 11. dnia)
    - NIE używaj ogólnego "z odsetkami ustawowymi" — wskaż konkretną datę
      wymagalności dla każdej transzy

  ROSZCZENIA POWIĄZANE Z WYDARZENIAMI ZEWNĘTRZNYMI (np. refundacje PFRON):
    Lp. | Miesiąc / wniosek | Dzień zdarzenia (np. data refundacji z SUDOP) |
    Kwota zdarzenia | Kwota roszczenia | Odsetki od

  KLAUZULA PRZYROSTOWA (gdy roszczenie narasta do wyroku):
    Powołaj art. 316 §1 KPC — sąd wydaje wyrok wg stanu w chwili zamknięcia rozprawy.
    Sformułuj żądanie: "za każdy kolejny miesiąc do dnia ogłoszenia wyroku — kwota
    wzrasta o [X] zł brutto / miesiąc."
```

### W1.5 — Braki krytyczne

> Jeśli wykonano KROK 4a.5 (MOD-SELEKCJA-DOWODOW) — braki są tu wstępnie
> wpisane automatycznie (LUKA KRYTYCZNA → BRAK KRYTYCZNY, LUKA ISTOTNA →
> BRAK ISTOTNY). Uzupełnij lub zmień opis.

```
⬛ BRAK KRYTYCZNY: [opis — bez tego pisma nie można złożyć]
⬛ BRAK ISTOTNY:   [opis — osłabi pismo]
⬛ BRAK TECHNICZNY:[opis — można uzupełnić w W2/W3]
```

### W1.6 — MOD-RED-TEAM-WLASNY (gate przed redakcją)

> Wywołaj: `view /mnt/skills/user/shared/MOD-RED-TEAM-WLASNY.md`

Sprawdź warunek aktywacji (§ nagłówek modułu — wielopodmiotowość, ciągłość
stosunku prawnego, roszczenie pieniężne, subsumcja złożona, dowód
wieloznaczny). Jeśli aktywny:

- R1 test nadinterpretacji dowodu (dla dowodów z >1 interpretacją w W1.3),
- R2 proaktywny test pełnomocnika przeciwnika dla każdej głównej tezy —
  tezy oznaczone "TAK" w polu "zmienić brzmienie?" PRZEPISZ w W1.2/W1.3
  przed kontynuacją,
- R3 test sędziego — tezy retoryczne skróć/usuń, tezy konieczne rozbuduj,
- R4 ważenie roszczeń A–D (gdy pismo zawiera >1 roszczenie) — zapisz
  rejestr pisania per roszczenie, zasili to W2,
- R5 test "czy to nie szkodzi?" — stosowany właściwie w W2 dla argumentów
  pobocznych, ale liście wyzwalaczy zanotuj już teraz,
- R6 konstrukcje ewentualne — sprawdź listę wyzwalaczy, dopisz żądanie
  ewentualne do W1.3 jeśli aktywne.

Wygeneruj RAPORT R (format w module). Jeśli STATUS = 🔴 — wróć do W1.2/W1.3,
przepisz oznaczone tezy, powtórz R2/R3 dla przepisanych tez. NIE przechodź
do checkpointu W1→W2 z RAPORTEM R w stanie 🔴.

Jeśli warunek aktywacji NIE jest spełniony — pomiń ten krok, przejdź do
checkpointu bez wzmianki (analogicznie do W1.2b).

### Checkpoint W1 → W2

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ RAMA GOTOWA — [typ pisma] dla [strona] przeciwko [strona]
Teza: [jedno zdanie]
Wariant: [nazwa wybranego wariantu — gdy W1.2b aktywny] | Styl: [styl_sugerowany — gdy W1.2b aktywny]
Żądań: [n] | Przepisów do weryfikacji: [n] ⚠️ | Orzeczeń do weryfikacji: [n]
Dowodów zatwierdzonych: [n] ✅ | Z ostrzeżeniami: [n] ⚠️ | Luki: [n] ⬛
Ostrzeżeń krzyżowych: [n] 🔴 [gdy >0: lista aspektów których dotyczyły]
Braków krytycznych: [n] 🔴
RED-TEAM (W1.6): [✅ GOTOWE / 🔴 WYMAGA PRZEBUDOWY / — nie aktywny dla tego pisma]

Czy rama jest poprawna? Mogę przejść do redakcji pisma (W2)?
Jeśli brakuje danych — podaj je teraz, uzupełnię ramę przed redakcją.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

⛔ NIE PRZECHODZIJ DO W2 bez wyraźnej zgody użytkownika lub odpowiedzi "tak" / "dalej" / "redaguj".
⛔ Nawet gdy użytkownik dał wcześniej materiały i kontekst — W1 musi być zatwierdzone oddzielnie.
⛔ Pośpiech użytkownika ("od razu pisz", "pomiń ramę") NIE zwalnia z W1 — wykonaj W1 i czekaj.

---

## ⛔⛔⛔ PRE-W2-VERIFICATION-GATE — BRAMKA OBOWIĄZKOWA PRZED W2 ⛔⛔⛔

> **Wywołaj:** `view /mnt/skills/user/shared/PRE-W2-VERIFICATION-GATE.md`
>
> ⛔ HARD GATE — BEZWZGLĘDNY. Wykonaj PO zatwierdzeniu W1 przez użytkownika,
> PRZED W2.1. NIE można pominąć. NIE ma wyjątków (nawet "prosta sprawa",
> "mam to z pamięci", "użytkownik podał dane"). Dane z pamięci modelu nigdy
> nie są wystarczające dla nagłówka pisma.
>
> **Co weryfikuje:**
> - PRE-W2.B: adres i wydział sądu/organu — web_search OBOWIĄZKOWY
> - PRE-W2.C: dane rejestrowe pozwanego — KRS/NIP/adres z rejestru
> - PRE-W2.D: każdy numer KRS/NIP z akt — do której spółki należy?
>             Rozbieżność KRS ≠ NIP w tym samym dokumencie → STOP, wyjaśnij
>
> **Efekt:** Raport PRE-W2 (widoczny użytkownikowi) z danymi zweryfikowanymi.
> W2.1 używa WYŁĄCZNIE danych z raportu PRE-W2, nie z pamięci modelu.
>
> ⛔ ZAKAZ-PRE-W2: NIE wstawiaj do W2 żadnego adresu sądu, KRS, NIP, REGON,
> adresu pozwanego bez uprzedniej weryfikacji w PRE-W2. Naruszenie = błąd
> krytyczny — powróć do PRE-W2 i wykonaj retroaktywnie.
>
> **Przykłady błędów wyeliminowanych przez ten gate:**
> - SR Katowice-Zachód VII Wydział Pracy: ul. Warszawska 45 (nie ul. Lompy 14)
> - KRS 0000796445 = Human Park sp. z o.o.; HPG ma KRS 0001025052 — bez
>   sprawdzenia rejestru model błędnie zbudował argument "ten sam KRS"

---

## WIADOMOŚĆ 2 — PROJEKT PISMA

> ⛔ HARD GATE W2:
> Wykonaj W2 wyłącznie po zatwierdzeniu W1 przez użytkownika ORAZ po zamknięciu
> PRE-W2-VERIFICATION-GATE (GATE-OK lub GATE-WARN).
> W2 NIE MOŻE zawierać: żadnego numeru Dz.U., żadnej sygnatury orzeczenia.
> Każdy przepis = ⚠️[art. X ustawa — WERYFIKACJA W3]
> Każde orzeczenie = [ORZECZENIE: opis → WERYFIKACJA W3]
> Dane podmiotowe (sąd, pozwany, KRS, NIP, adres) = WYŁĄCZNIE z raportu PRE-W2.
> Po ukończeniu W2 — przejdź do W3 automatycznie (nie pytaj użytkownika o zgodę).

> Cel W2: pełna redakcja procesowa pisma w oparciu o zatwierdzoną ramę z W1.
> Fakty: wyłącznie z materiałów użytkownika. Braki = ⬛ [UZUPEŁNIJ: opis]

> ⛔ HARD GATE — FAKTY:
> Czy użytkownik dostarczył materiały źródłowe?
>   TAK → MOD-FAKTY uruchomi się w W3 po weryfikacji prawnej
>   NIE → stosuj zasadę nadrzędną: żaden fakt bez źródła z opisu użytkownika

### W2.1 — Moduły do wczytania przed redakcją

```
view /mnt/skills/user/pisma-procesowe-v3/modules/MOD-SZABLONY.md   (zawsze)
view /mnt/skills/user/pisma-procesowe-v3/modules/MOD-DOWODY.md     (gdy są dowody)
view /mnt/skills/user/pisma-procesowe-v3/modules/MOD-OBAL.md       (gdy riposta/odpowiedź)
view /mnt/skills/user/pisma-procesowe-v3/modules/MOD-OPLATY.md     (gdy pismo wszczynające)
view /mnt/skills/user/pisma-procesowe-v3/modules/MOD-ADMIN.md      (gdy sprawa adm./KPA/WSA)
view /mnt/skills/user/shared/MOD-TIMING.md                         (gdy timing złożenia jest istotny:
                                                                     pierwsza rozprawa <14 dni /
                                                                     wniosek dowodowy grożący prekluzją /
                                                                     korzystne postanowienie do utrwalenia)
view /mnt/skills/user/shared/MOD-DOKTRYNA.md                       (gdy uzasadnienie powołuje
                                                                     komentarze lub literaturę —
                                                                     hierarchia: orzeczenie > doktryna)
view /mnt/skills/user/shared/MOD-MACIERZ-DOWOD-TEZA.md             (gdy ≥2 dowody — wczytaj
                                                                     dla zasilenia sekcji "Na dowód":
                                                                     dowody wielofunkcyjne powołuj
                                                                     raz z listą tez; luki z MT4
                                                                     wstaw do ⬛ BRAK ISTOTNY/KRYTYCZNY)
view /mnt/skills/user/pisma-procesowe-v3/modules/MOD-PRACODAWCA-RZECZYWISTY.md
                                                                    (⛔ OBOWIĄZKOWE gdy: w materiale
                                                                     widoczne są ≥2 podmioty / różne KRS
                                                                     na umowach / zmiana nazwy pracodawcy /
                                                                     argument o tożsamości pracodawcy —
                                                                     wykonaj PR1→PR4 przed W1.3)
```

### W2.2 — Struktura pisma (obowiązkowa)

> Przed redakcją: sprawdź czy pismo wymaga executive summary (pozew, apelacja,
> pismo >3 str.) — jeśli tak, wygeneruj je przez `view /mnt/skills/user/shared/MOD-INTRO.md`
> i wstaw jako pierwsze akapity (przed [ŻĄDANIA]).
> QUALITY-CHECK §5 i MOD-PEER-REVIEW ROLA 2 (PR-B1) weryfikują obecność intro w W3.

```
[NAGŁÓWEK]
  Sąd / Organ: ⚠️POD[nazwa i adres — WERYFIKACJA W3.0 PODMIOT-GATE]
  Powód/Wnioskodawca: [dane — lub ⬛]
  Pozwany/Uczestnik:  [dane — lub ⬛]
  Sygnatura akt: [jeśli sprawa w toku — lub ⬛]
  Wartość przedmiotu sporu: ⚠️[kwota — weryfikacja reguł obliczania W3]

[OZNACZENIE PISMA]
  [Pozew / Apelacja / Sprzeciw / Wniosek / ...]

[EXECUTIVE SUMMARY — gdy wymagany przez MOD-INTRO]
  2–5 zdań (max 150 słów): kto i czego żąda, kluczowy fakt, podstawa prawna,
  teza centralna z W1.2. Wstaw przed petitum.

[ŻĄDANIA]
  Wnoszę o:
  1. [precyzyjne żądanie główne]
  2. [żądanie ewentualne — jeśli dotyczy]

[UZASADNIENIE]
  Stan faktyczny: [fakty z materiałów — lub ⬛]
  Podstawa prawna: ⚠️[art. X ustawa — WERYFIKACJA W3]
  Dowody: [lista z W1.3]

[WNIOSKI DOWODOWE]
  Na podstawie ⚠️[art. 217/232/258 KPC lub art. 167 KPK — WERYFIKACJA W3]:
  1. [dowód — dokument / świadek / biegły]

[PODPIS]
  [miejscowość, data]
  [imię i nazwisko / pełnomocnik]
```

### W2.3 — Lista kontrolna placeholderów (obowiązkowa)

Po ukończeniu redakcji — sporządź listę wszystkich wstawionych placeholderów:

```
PRZEPISY DO WERYFIKACJI W W3:
⚠️ P1: art. [X] [ustawa] — użycie: [gdzie w piśmie]
⚠️ P2: art. [X] [ustawa] — użycie: [gdzie w piśmie]
...

ORZECZENIA DO WERYFIKACJI W W3:
⚠️ O1: [opis orzeczenia] — teza do wykazania: [co ma udowodnić]
⚠️ O2: [opis orzeczenia] — teza do wykazania: [co ma udowodnić]
...

POLA DO UZUPEŁNIENIA:
⬛ [n] pól wymaga danych od użytkownika
```

### W2.4 — MOD-ATAK-NA-DRAFT (gate na gotowym tekście)

> ⛔⛔⛔ HARD GATE W2.4 — BEZWZGLĘDNY, BEZ WYJĄTKU ⛔⛔⛔
> Ten krok jest OBLIGATORYJNY. Nie ma warunku aktywacji. Każdy draft przez niego przechodzi.
> NIE WOLNO przejść do W3 bez wykonania W2.4 i wyświetlenia RAPORTU D.
> NIE WOLNO wygenerować .docx bez zamkniętego W2.4.
> Pośpiech użytkownika, prosta sprawa, brak prośby — ŻADNE z nich nie jest wyjątkiem.

> Wywołaj: `view /mnt/skills/user/shared/MOD-ATAK-NA-DRAFT.md`
> (plik istnieje od v1.0.0 2026-06-21; jeśli view() zwróci błąd — zatrzymaj się
> i poinformuj użytkownika o brakującym pliku zamiast cicho pomijać krok)

**Sekwencja W2.4 (wykonaj w tej kolejności):**

1. `view /mnt/skills/user/shared/MOD-ATAK-NA-DRAFT.md`
2. D1 — skan zdań kategorycznych → naprawa redakcyjna samodzielnie
3. D2 — test pełnomocnika akapit po akapicie → naprawa redakcyjna dla 🟡/🟢;
         dla 🔴/🟠 bez pokrycia dowodowego → oznacz jako ⬛ LUKA D4
4. D3 — skan sprzeczności międzyakapitowych → naprawa redakcyjna samodzielnie
5. D5 — analiza własnych słabości i ryzyk (RP prawne / RD dowodowe / RPC procesowe)
         → 🔴/🟠: zdanie ubezpieczające lub zmiana konstrukcji; 🟡: notacja w RAPORCIE D
6. D4 — weryfikacja luk dowodowych → jeśli ⬛ LUKA D4 klasy 🔴/🟠: STOP
7. Wyświetl RAPORT D (obligatoryjny — nawet gdy wynik ✅)

**Rozgałęzienie po RAPORCIE D:**
- ATAK-OK / ATAK-UWAGI → przejdź do W3 automatycznie
- ATAK-STOP (⬛ LUKA D4 🔴/🟠) → STOP; zadaj pytania użytkownikowi;
  czekaj na odpowiedź; dopiero po niej uzupełnij draft i przejdź do W3

⛔ ZAKAZ-9 (nowy): NIE przechodzij do W3 bez wyświetlonego RAPORTU D z W2.4.
   Naruszenie = błąd krytyczny pipeline — powróć do W2.4 i wykonaj go retroaktywnie.

---

## WIADOMOŚĆ 3 — WERYFIKACJA ZE ŹRÓDEŁ + WALIDACJA

> ⛔ HARD GATE W3:
> NIE generuj pisma finalnego ani .docx przed ukończeniem W3.
> ⛔⛔ PODMIOT-GATE (W3.0) MUSI być wykonany JAKO PIERWSZY w W3 — przed W3.1.
>     NIE przechodzij do weryfikacji przepisów (W3.1) bez zamkniętego PODMIOT-GATE.
>     Każdy ⚠️POD bez statusu ✅/⚠️/⛔ = blokada W3.1.
> Każdy ⚠️Pn musi mieć wpis ✅ lub ⛔ w raporcie.
> Każdy ⚠️On musi mieć sygnaturę + URL ze źródła lub ⛔ BRAK.
> Każdy ⚠️POD musi mieć wpis ✅/⚠️/⛔ z PODMIOT-GATE.
> Dopiero po zamknięciu wszystkich ⚠️ — pismo finalne + .docx.

### W3.0 — PODMIOT-GATE (weryfikacja danych podmiotów przed W3.1)

> ⛔ OBOWIĄZKOWE — wykonaj jako pierwsze w W3, przed weryfikacją przepisów.
> Dotyczy każdego podmiotu będącego stroną lub uczestnikiem pisma:
> powoda, pozwanego, wnioskodawcy, uczestnika, interwenienta — ORAZ
> sądu/organu z nagłówka pisma (adresata). Dane podmiotu z pamięci lub
> od użytkownika = ⚠️POD do weryfikacji. Sąd/organ z W2.2 = ⚠️POD zawsze,
> niezależnie od tego, czy użytkownik podał nazwę czy system ją dobrał.

```
DLA KAŻDEGO PODMIOTU OZNACZONEGO ⚠️POD:

KROK P1 — IDENTYFIKACJA REJESTRU:
  Podmiot prowadzący działalność:
    → spółka (sp. z o.o., S.A., sp.k., sp.j., SKA, P.SA, sp. cyw.) → KRS
    → osoba fizyczna prowadząca działalność → CEIDG
    → fundacja / stowarzyszenie → KRS
    → osoba fizyczna (konsument / pracownik) → brak rejestru → dane z akt/umów
    → organ publiczny (urząd, sąd, prokuratura) → BIP / oficjalna strona

KROK P2 — WERYFIKACJA ONLINE:
  KRS:   web_fetch → https://ekrs.ms.gov.pl/rdf/pd/search_df?
                     lub web_search: "[nazwa spółki] KRS NIP REGON"
         Potwierdzić: nazwa pełna (firma), forma prawna, KRS, NIP, REGON,
                      adres siedziby, aktualny skład zarządu/reprezentacja,
                      sposób reprezentacji (jednoosobowo / łącznie)
  CEIDG: web_fetch → https://aplikacja.ceidg.gov.pl/
         lub web_search: "[imię nazwisko] NIP CEIDG działalność gospodarcza"
         Potwierdzić: imię, nazwisko, NIP, adres do doręczeń,
                      status (aktywna/zawieszona/wykreślona)
  SĄD/ORGAN: web_search: "[nazwa sądu/organu] adres właściwość wydział"
         lub web_fetch → https://bip.ms.gov.pl (wyszukiwarka sądów)
         lub https://www.gov.pl (wykaz urzędów/organów administracji)
         Potwierdzić: pełna aktualna nazwa (sądy łączą się/zmieniają
                      nazwy), adres do doręczeń, właściwy WYDZIAŁ dla
                      danego typu sprawy (cywilny/pracy/gospodarczy/
                      karny/rodzinny), oraz że to faktycznie sąd
                      WŁAŚCIWY MIEJSCOWO i RZECZOWO dla sprawy (nie tylko
                      że istnieje) — błędny wydział lub sąd niewłaściwy
                      to wada formalna pisma, nie tylko błąd adresowy.
         Dla prokuratury: https://www.gov.pl/web/pk — analogicznie
                      (jednostka właściwa + adres).

KROK P3 — KLASYFIKACJA:
  ✅ PODMIOT-OK:    dane potwierdzone online — wstaw do pisma
  ⚠️ PODMIOT-WARN: dane częściowo potwierdzone (np. adres zmieniony) —
                    wstaw potwierdzone, oznacz rozbieżność
  ⛔ PODMIOT-CRIT: dane niezgodne lub podmiot nieznaleziony —
                    BLOKADA generowania pisma; poinformuj użytkownika

KROK P4 — UPRASZCZANIE NAGŁÓWKA (po potwierdzeniu):
  Reguła: w nagłówku pisma i miejscach oznaczenia stron stosuj WYŁĄCZNIE:
    → pełna firma (nazwa rejestrowa) z rejestru
    → forma prawna zgodna z rejestrem (nie skróty nieformalne)
    → NIP (zawsze) + KRS (dla spółek) + REGON (gdy wymagany)
    → aktualny adres siedziby z rejestru (nie adres kancelarii)
  Reguła upraszczania: jeśli pełna nazwa jest długa, stosuj skrót TYLKO
    gdy jest zarejestrowany (np. "HPG sp. z o.o." tylko gdy taki skrót
    figuruje w KRS). W przeciwnym razie: pełna nazwa przy pierwszym
    wystąpieniu, następnie: "pozwany" / "spółka".

FORMAT RAPORTU bloku POD:
  ✅ POD-1: [nazwa] — KRS: [nr] | NIP: [nr] | REGON: [nr]
             adres: [ulica, kod, miasto] — ✅ zgodny z rejestrem [data]
             reprezentacja: [sposób] przez [imię nazwisko, funkcja]
  ⚠️ POD-2: [nazwa] — NIP: [nr] ✅ | adres: ⚠️ ZMIANA — w rejestrze:
             [nowy adres]; w aktach sprawy: [stary adres]
  ⛔ POD-3: [nazwa] — NIE ZNALEZIONO w KRS/CEIDG
             → BLOKADA; użytkownik musi potwierdzić dane ręcznie
  ✅ POD-S1: [Sąd/Organ] — adres: [...] | wydział: [...] | właściwość:
             ✅ potwierdzona miejscowo i rzeczowo [data weryfikacji]
  ⛔ POD-S2: [Sąd/Organ] — ⛔ NIEWŁAŚCIWY dla sprawy (np. zły wydział
             lub zła właściwość miejscowa) → BLOKADA, wskaż właściwy sąd
```

⛔ ZAKAZ-7: Nie wpisuj do pisma danych podmiotu (NIP, KRS, REGON, adres,
forma prawna, skład zarządu) bez weryfikacji w KRS lub CEIDG. Nie wpisuj
nazwy/adresu/wydziału sądu lub organu bez weryfikacji jego aktualności
i właściwości miejscowej/rzeczowej dla sprawy.
Dane podane przez użytkownika lub przejęte z dokumentów = ⚠️POD do weryfikacji.
Wyjątek: osoba fizyczna nieprowadząca działalności — dane z akt sprawy
lub oświadczenia strony, oznacz jako [DANE Z AKT — nieweryfikowane w rejestrze].

### W3.1 — Weryfikacja przepisów (ISAP)

Dla każdego ⚠️Pn z listy W2.3:

```
  KROK 1: web_fetch → https://isap.sejm.gov.pl (szukaj aktu po nazwie / Dz.U.)
  KROK 2: Potwierdź: tytuł aktu, numer Dz.U., data tekstu jednolitego
  KROK 3: Odczytaj brzmienie artykułu ze źródła — nie parafrazuj z pamięci
  KROK 4: Sprawdź: czy artykuł nie był nowelizowany po dacie zdarzenia?
  KROK 5: Zapisz: "art. [X] [ustawa] (Dz.U. [rok] poz. [nr] t.j.)" + URL

FORMAT RAPORTU bloku P:
  ✅ P1: art. [X] [ustawa] (Dz.U. [rok] poz. [nr]) — URL: [...]
  ✅ P2: art. [X] [ustawa] (Dz.U. [rok] poz. [nr]) — URL: [...]
  ⛔ P3: [opis] — BRAK DOSTĘPU / NIE ZNALEZIONO
          → pozostaw ⚠️ w piśmie z adnotacją [WYMAGA RĘCZNEJ WERYFIKACJI]
```

### W3.2 — Weryfikacja orzeczeń

Dla każdego ⚠️On z listy W2.3:

```
  KROK 1: web_search → "[opis orzeczenia] sygnatura site:orzeczenia.ms.gov.pl"
           lub: web_search → "[opis orzeczenia] sygnatura site:sn.pl"
  KROK 2: web_fetch → URL z wyników → potwierdź sygnaturę i tezę
  KROK 3: Odczytaj tezę ze źródła — nie parafrazuj z pamięci

  KROK 3a — ZAKRES-STOSOWANIA (NOWY — obowiązkowy):
    Odczytaj stan faktyczny orzeczenia ze źródła.
    Odpowiedz: czy stan faktyczny orzeczenia jest analogiczny do stanu w piśmie?
    Pytania kontrolne:
      □ Czy orzeczenie dotyczy tego samego typu podmiotu?
      □ Czy orzeczenie dotyczy tego samego przepisu w tym samym kontekście?
      □ Czy orzeczenie nie ma ograniczonego zakresu (np. wyłącznie prywatyzacja,
        wyłącznie art. 47 KP, wyłącznie określony typ umowy)?
      □ Czy doktryna orzeczenia jest utrwalona czy odosobniona?

    Klasyfikacja:
      ✅ ZAKRES-OK:      stan faktyczny analogiczny → dopuszcz
      ⚠️ WARN-ZAKRES:   orzeczenie z ograniczonym zakresem stosowania →
                        wskaż ograniczenie w piśmie, szukaj orzeczenia
                        o szerszym zakresie jako wsparcie lub zamiennik
      ⛔ ZAKAZ-ZAKRES:  stan faktyczny orzeczenia NIE obejmuje pisma →
                        orzeczenia NIE wolno użyć; wstaw ⬛ [UZUPEŁNIJ]

  KROK 4: Sprawdź datę — czy linia orzecznicza aktualna po ewentualnych zmianach prawa?
  KROK 5: Zapisz: "wyrok [sąd] z [data], sygn. [nr], teza: [dosłownie ze źródła]"
           URL źródłowy obowiązkowy

FORMAT RAPORTU bloku O:
  ✅ O1: wyrok SN z [data], sygn. [nr] — URL: [...] — teza: [...]
         ZAKRES: ✅ analogiczny
  ✅ O2: wyrok SA [miasto] z [data], sygn. [nr] — URL: [...] — teza: [...]
         ZAKRES: ⚠️ WARN — orzeczenie z kontekstu prywatyzacji (III PZP 2/06);
                 użyto pomocniczo — mocniejsze wsparcie: I PK 311/07 + I PK 179/14
  ⛔ O3: [opis orzeczenia] — NIE ZNALEZIONO w oficjalnej bazie
          → ZAKAZ użycia w piśmie. Wstaw ⬛ [UZUPEŁNIJ: orzeczenie potwierdzające X]
```

⛔ ZAKAZ-6: Nie używaj orzeczenia gdy ZAKRES-STOSOWANIA = ZAKAZ-ZAKRES.
Nie cytuj orzeczeń na podstawie samej tezy bez weryfikacji stanu faktycznego.
Orzeczenia z ograniczonym zakresem (WARN-ZAKRES) można użyć tylko pomocniczo,
z jawnym wskazaniem ograniczenia i równoległym silniejszym orzeczeniem.

view /mnt/skills/user/orzeczenia-sadowe-v2/SKILL.md   (gdy potrzebne szerokie wyszukiwanie)

### W3.3 — MOD-FAKTY (gdy pismo z dostarczonych materiałów)

```
Czy użytkownik dostarczył materiały źródłowe?
  TAK → view /mnt/skills/user/shared/FAKTY_v2.md
        Procedura F1/F2/F3 — weryfikacja każdego faktu w piśmie
        ⛔ FIKCJA lub ⛔ BRAK ŹRÓDŁA → BLOKADA finalizacji
  NIE → pomiń W3.3
```

### W3.4 — MOD-WALIDACJA (zawsze)

```
view /mnt/skills/user/shared/MOD-WALIDACJA_v2.md
```

Wykonaj wszystkie bloki A–J. Raport walidacyjny obowiązkowy:

```
BLOK A — wymogi proceduralne (właściwość, strony, opłata, podpis)
BLOK B — spójność wewnętrzna (fakty ↔ dowody, kwoty, daty)
BLOK C — styl procesowy (oceny moralne, ogólne negacje, precyzja wniosków)
         Po Bloku C zawsze: view /mnt/skills/user/shared/MOD-KONCENTRACJA.md
         → raport długości per typ pisma (WARN/ALERT gdy za długie)
         → view /mnt/skills/user/shared/QUALITY-CHECK.md (kontrola redakcyjna + logiczna)
         → QUALITY-CHECK §5: view /mnt/skills/user/shared/MOD-INTRO.md (executive summary)
BLOK D — terminy i prekluzja
         view /mnt/skills/user/shared/TERM-CALC.md (zawsze gdy termin zawity lub
         środek zaskarżenia lub przedawnienie)
BLOK E — logika prawna (przepis + fakt + dowód dla każdego roszczenia)
         view /mnt/skills/user/shared/ROSZCZENIA.md (gdy ≥2 roszczenia lub żądanie ewentualne)
BLOK F — ryzyka procesowe (co można zaatakować, przyznania niekorzystne)
         view /mnt/skills/user/shared/RISK-ASSESSMENT.md (zawsze)
BLOK G — intertemporalność (brzmienie na datę zdarzenia)
         view /mnt/skills/user/shared/ISAP-AUDIT-PROTOCOL.md (gdy akty mogły być
         nowelizowane między datą zdarzenia a datą pisma)
BLOK H — zgodność z materiałem źródłowym (zakaz fabrykowania faktów)
BLOK I — skrzyżowanie pismo ↔ dostarczone dowody
         view /mnt/skills/user/shared/DOWODY-METODOLOGIA.md (gdy ≥3 dowody lub
         dowód pośredni/ryzykowny)
         view /mnt/skills/user/shared/PREKLUZJA-DOWODOWA.md (gdy pismo w toku
         postępowania lub sprawa gospodarcza)
         view /mnt/skills/user/shared/EXPERT-OPINION-AUDIT.md (gdy w aktach jest
         opinia biegłego lub pismo kwestionuje biegłego)
BLOK J — weryfikacja statusu prawnego aktów (FSL/LSL) — nowość v2.0:
          przed Blokiem J wywołaj:
          view /mnt/skills/user/shared/FACT-SOURCE-LOCK.md
          view /mnt/skills/user/shared/LEGAL-STATUS-LOCK.md
```

Moduły proceduralne shared (wczytaj zawsze przed blokami):
```text
view /mnt/skills/user/shared/TRYBY-PROCESOWE.md
view /mnt/skills/user/shared/FORMAL-CHECK.md
view /mnt/skills/user/shared/BRAKI-FORMALNE.md
view /mnt/skills/user/shared/WARUNKI-SKUTECZNOSCI.md
view /mnt/skills/user/shared/RISK-ASSESSMENT.md
view /mnt/skills/user/shared/QUALITY-CHECK.md
```

Moduły jakości prawnej (zawsze po BLOK E):
```text
view /mnt/skills/user/shared/LEGAL-QUALITY-GATE.md   (bramka: PASS/PASS-WITH-WARNING/FAIL
                                                       — blokuje .docx gdy FAIL)
view /mnt/skills/user/shared/ORZECZENIA-HIERARCHIA.md (gdy pismo powołuje orzecznictwo)
```

Moduły warunkowe (triggery obowiązkowe — NIE "zależnie od sprawy"):
```text
view /mnt/skills/user/shared/TERM-CALC.md            → ZAWSZE gdy: termin zawity / środek
                                                        zaskarżenia / przedawnienie roszczenia
view /mnt/skills/user/shared/PREKLUZJA-DOWODOWA.md   → ZAWSZE gdy: pismo po pierwszym /
                                                        sprawa gospodarcza / twierdzenia nowe
view /mnt/skills/user/shared/DOWODY-METODOLOGIA.md   → ZAWSZE gdy: ≥3 dowody w sprawie /
                                                        dowód pośredni lub kontekstowy
view /mnt/skills/user/shared/ROSZCZENIA.md           → ZAWSZE gdy: ≥2 roszczenia /
                                                        żądanie ewentualne / alternatywne
view /mnt/skills/user/shared/STRATEGIA-PROCESOWA.md  → ZAWSZE gdy: pismo kończące etap /
                                                        ryzyko procesowe WYSOKIE lub KRYTYCZNE
view /mnt/skills/user/shared/ISAP-AUDIT-PROTOCOL.md  → ZAWSZE gdy: akty mogły być nowelizowane
                                                        między datą zdarzenia a datą pisma
view /mnt/skills/user/shared/EXPERT-OPINION-AUDIT.md → ZAWSZE gdy: opinia biegłego w aktach /
                                                        pismo kwestionuje biegłego
```

### W3.5 — HYBRID-VALIDATION (zawsze po walidacji)

```
view /mnt/skills/user/shared/HYBRID-VALIDATION.md
```

FAZA 1: auto-raport braków 🔴/🟡/🔵 bez pytania o zgodę
FAZA 2: użytkownik podaje dane per numer → precyzyjne wstawienie
FAZA 3: licznik ⬛ + docx gdy kompletne

### W3.6 — Pismo finalne

Po zamknięciu wszystkich ⚠️ — wydaj wersję finalną:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RAPORT W3
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PRZEPISY:   ✅ [n] zweryfikowane | ⛔ [n] brak dostępu
ORZECZENIA: ✅ [n] zweryfikowane | ⛔ [n] nie znaleziono
WALIDACJA:  [GOTOWE DO ZŁOŻENIA / WYMAGA POPRAWEK / BLOKADA]
POLA ⬛:    [n] do uzupełnienia

STATUS PISMA: [GOTOWE / PROJEKT — uzupełnij przed złożeniem]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### W3.6a — AUDYT-KONCOWY (gate przed .docx)

> Wywołaj: `view /mnt/skills/user/shared/AUDYT-KONCOWY.md`

Wykonuj zawsze, niezależnie od typu pisma — bez warunku aktywacji.

**Krok 1 — COURT-SIMULATION (przed punktową oceną):**
```
view /mnt/skills/user/pisma-procesowe-v3/references/engines/court-simulation-engine.md
```
Wykonaj 10 pytań symulacji sądu. Wyniki zasilają bezpośrednio kategorię
"Realizm sądowy" w AUDYT-KONCOWY (nie wykonuj obu niezależnie).

**Krok 2 — LEGAL-QUALITY-GATE (bramka jakości prawa):**
```
view /mnt/skills/user/shared/LEGAL-QUALITY-GATE.md
```
Wynik: PASS → kontynuuj; PASS-WITH-WARNING → zaznacz w raporcie;
FAIL → ⛔ BLOKADA .docx — wróć do W3.1 dla problematycznych przepisów.

**Krok 3 — AUDYT-KONCOWY (6 kategorii 0–10):**
Oceń pismo finalne w 6 kategoriach (0–10, z uzasadnieniem). Jeśli
KTÓRAKOLWIEK kategoria <7/10 — STATUS = 🔴 BLOKADA: NIE generuj .docx,
wskaż poprawkę, wykonaj ją, powtórz ocenę tej kategorii.

---

### W3.7 — PEER REVIEW + POST-VALIDATION (krok kancelaryjny przed .docx)

> Wykonuj po AUDYT-KONCOWY ze statusem ✅ ZAMKNIĘTE.
> To jest ostatni jakościowy checkpoint przed finalną prezentacją — symuluje
> "drugiego adwokata" i pełną walidację spójności.

**Krok 1 — MOD-PEER-REVIEW (gdy warunek aktywacji spełniony):**
```
Aktywuj gdy CHOĆBY JEDNO jest prawdą:
  □ wartość przedmiotu sporu > 50 000 zł
  □ pismo zawiera ≥3 żądania
  □ pismo jest apelacją / zażaleniem do SN/SA
  □ użytkownik użył zwrotu "peer review" / "adwokat diabła" / "sprawdź jeszcze raz"

Jeśli aktywny:
view /mnt/skills/user/shared/MOD-PEER-REVIEW.md

Wykonaj 4 role: Adwokat diabła (ATAK-n), Sędzia (UWAGA-SĄDU-n),
Klient (INTERES-KLIENTA-n), Audyt spójności (SPÓJNOŚĆ-n).
Wynik: PEER-OK / PEER-UWAGI / PEER-STOP.
PEER-STOP = ⛔ BLOKADA .docx — wykonaj wskazaną korektę, powtórz ocenę.
```

**Krok 2 — POST-VALIDATION (zawsze):**
```
view /mnt/skills/user/shared/POST-VALIDATION.md

FAZA 1: automatyczny raport braków 🔴/🟡/🔵 (bez pytania o zgodę)
FAZA 2: wstaw dane użytkownika per numer → jeśli brak → ⬛
Braki 🔴 blokują finalizację.
```

Po W3.7 — jeśli pismo gotowe:
- ⛔ STRIP-VER-GATE → view /mnt/skills/user/shared/WERYFIKACJA-SLAD.md § STRIP-VER-GATE
  Wykonaj SVG-1 → SVG-2 → SVG-3 przed generowaniem pliku.
  Blokada: nie wywołuj docx/SKILL.md dopóki SVG-1–SVG-3 niezamknięte.
- view /mnt/skills/public/docx/SKILL.md → generuj .docx → present_files
- view /mnt/skills/user/shared/raport-sytuacyjny-integracja.md → propozycja Raportu Sytuacyjnego

---

## SELF-CHECK PRZED KAŻDĄ ODPOWIEDZIĄ (obowiązkowy)

```
⛔ NAJPIERW: STATUS CHECKPOINTÓW — które [CP] są otwarte/zamknięte?
   [CP-1a]         CLAIM-VALIDATION:       ⬜ OCZEKUJE / ✅ ZAMKNIĘTY
   [CP-1b]         MOD-STRATEGIA-WYBOR:    ⬜ / ✅ / N/D
   [CP-1c-skan]    SD-VER KOMPLET:         ⬜ / ✅ / N/D
   [CP-1c-macierz] MACIERZ D×T:            ⬜ / ✅ / N/D
   [CP-W1]         RAMA W1:                ⬜ / ✅
   [CP-PRE-W2]     PRE-W2-GATE:            ⬜ / ✅
   [CP-ATAK]       MOD-ATAK-NA-DRAFT:      ⬜ / ✅
   [CP-PODMIOT]    PODMIOT-GATE W3.0:      ⬜ / ✅
   [CP-QUALITY]    LEGAL-QUALITY-GATE:     ⬜ / ✅
   [CP-AUDYT]      AUDYT-KOŃCOWY:          ⬜ / ✅
   [CP-PEER]       PEER-REVIEW + PV:       ⬜ / ✅

   ⛔ Pierwszy ⬜ = STOP. Wykonaj ten CP. Nie idź dalej.
```

```
□ ⛔ MOD-SKAN-DOWODOW-KOMPLETNY (W1.2c-PRE) — wykonaj jako PIERWSZY:
   SD-GATE-0: czy wzmianka o załącznikach + faktyczny brak pliku? → STOP
   SD-INW: WSZYSTKIE pliki zinwentaryzowane (ZIP = zawartość)?
   SD-READ: KAŻDA strona/zakładka/obraz przeanalizowana?
   SD-VER: status KOMPLET przed W1.3 i W2?
   Protokół sądowy: wszystkie zeznania per zdanie → SD-FAKTY?
   SD-GATE-4: blokada W2 aktywna dopóki SD-VER ≠ KOMPLET?
   NIE do któregokolwiek → STOP. Nie generuj pisma.
   view: /mnt/skills/user/shared/MOD-SKAN-DOWODOW-KOMPLETNY.md
□ ⛔ PRE-W2-VERIFICATION-GATE: czy zamknięty (GATE-OK/WARN) przed W2.1?
   NIE → STOP. NIE generuję W2. Wykonaj PRE-W2-GATE:
         view /mnt/skills/user/shared/PRE-W2-VERIFICATION-GATE.md
   Kontrola szczegółowa:
   □ PRE-W2.B: adres sądu/wydziału zweryfikowany przez web_search? ✅/⛔
   □ PRE-W2.C: KRS i NIP pozwanego zweryfikowane w rejestrze? ✅/⛔
   □ PRE-W2.D: każdy numer KRS/NIP z akt sprawdzony do której spółki należy? ✅/⛔
   □ Żaden adres sądu ani dane KRS/NIP nie pochodzą z pamięci modelu? ✅/⛔
□ ⛔ MOD-MACIERZ-DOWOD-TEZA (W1.2c): czy macierz D×T zatwierdzona przez użytkownika?
   Gdy ≥2 dowody dostarczone:
   □ MT1: lista tez T1..Tn i dowodów D1..Dm sporządzona?
   □ MT2: skan dwukierunkowy (A: każdy dowód→tezy; B: każda teza→dowody) wykonany?
   □ MT3: każde powiązanie sklasyfikowane (K/R/W/RK)?
   □ MT4: raport wyświetlony (tabela + pokrycie + luki + wielofunkcyjne)?
   □ STOP po MT4 — użytkownik zatwierdził lub podjął decyzje RK?
   □ MT5: W1.3 zasilone danymi z macierzy?
   NIE → STOP. NIE przechodzę do W1.3. Wykonaj W1.2c retroaktywnie.
□ ⛔ MOD-STRATEGIA-WYBOR (W1.2b): czy raport S5 wyświetlony i zatwierdzony?
   Gdy warunek aktywacji (≥2 ścieżki lub anomalia podmiotowa):
   □ S1: wszystkie ścieżki zidentyfikowane (w tym anomalie KRS/NIP)?
   □ S2: każda ścieżka oceniona pod kątem ataku przeciwnika?
   □ S3: ścieżka z atakiem 🔴 bez kontrargumentu oznaczona PORZUĆ/EWENTUALNA?
   □ S4: struktura pisma wybrana (Scenariusz 1/2/3, nie ZABRONIONY)?
   □ S5: raport wyświetlony, użytkownik zatwierdził lub zmodyfikował?
   NIE → STOP. NIE przechodzę do W1.3. Wykonaj W1.2b retroaktywnie.
□ Jestem w stanie W1 i nie mam zatwierdzenia → NIE generuję W2. STOP.
□ Jestem w stanie W2 i wstawiam Dz.U. lub sygnaturę → BŁĄD KRYTYCZNY. Usuń, wstaw ⚠️.
□ ⛔ W2.4 ATAK-NA-DRAFT: czy RAPORT D został wyświetlony?
   NIE → STOP. NIE przechodzę do W3. Wykonuję W2.4 teraz (view MOD-ATAK-NA-DRAFT.md).
   W2.4 jest OBLIGATORYJNY — brak pliku nie zwalnia; brak aktywacji użytkownika nie zwalnia.
□ Jestem w stanie W3 i nie zamknąłem wszystkich ⚠️ → NIE generuję .docx. STOP.
□ ⛔ W3.0 PODMIOT-GATE: czy KAŻDY podmiot oznaczony ⚠️POD (strona + sąd/organ) ma status ✅/⚠️/⛔?
   NIE → STOP. NIE przechodzę do W3.1. Wykonuję PODMIOT-GATE teraz.
□ Każdy ⚠️Pn z listy W2.3 ma wpis ✅ lub ⛔ w raporcie W3?
□ Każdy ⚠️On z listy W2.3 ma wpis ✅ lub ⛔ w raporcie W3?
□ MOD-FAKTY przeszedł bez ⛔ FIKCJA i bez ⛔ BRAK ŹRÓDŁA (gdy dostarczono materiały)?
□ HYBRID-VALIDATION Block Zero zamknięty (wynik ✅)?
□ FORMAL-VALIDATOR (checklists) — uruchomiony jako uzupełnienie HYBRID w W3.5?
□ BLOK J MOD-WALIDACJA — twierdzenia o statusie aktów przeszły przez FSL/LSL?
□ LEGAL-QUALITY-GATE (W3.6a Krok 2) — wynik PASS lub PASS-WITH-WARNING (nie FAIL)?
□ COURT-SIMULATION (W3.6a) — 10 pytań wykonanych i wbudowanych w AUDYT-KONCOWY?
□ AUDYT-KONCOWY (W3.6a) wykonany i wszystkie kategorie ≥7/10?
□ W3.7 PEER-REVIEW — wykonany gdy warunek aktywacji spełniony (wynik ≠ PEER-STOP)?
□ W3.7 POST-VALIDATION — wykonany, braki 🔴 zaadresowane lub ⬛ wpisane?
□ MOD-INTRO — executive summary wstawiony gdy typ pisma tego wymaga?
□ MOD-KONCENTRACJA — pismo mieści się w limicie orientacyjnym (nie ALERT)?
□ Engines specjalistyczne aktywowane per MODUŁY-MAPA?
   (apelacja → appellate-v8 ✅/N/D; prokuratoria → prosecution-v8 ✅/N/D;
    riposta → rebuttal-v9 ✅/N/D; V10 gdy ≥1 warunek aktywacji ✅/N/D)
Którykolwiek = NIE → STOP. Nie oznaczaj pisma jako gotowego.
```

### REGUŁA FINALNA (merytoryczna, niezależna od kontroli automatu stanów wyżej)

Przed wydaniem pisma finalnego odpowiedz na każde pytanie:

```
1. Jaki jest najsilniejszy argument przeciwnika?            [...]
2. Czy pismo już na niego odpowiada?                        TAK/NIE
3. Czy każda teza ma dowód?                                 TAK/NIE
4. Czy każda teza jest potrzebna do rozstrzygnięcia?         TAK/NIE
5. Czy nie ma twierdzeń zbyt kategorycznych?                TAK/NIE
6. Czy dane podmiotów ORAZ sądu/organu są zweryfikowane online przez PRE-W2-GATE? TAK/NIE
   (nie z pamięci modelu — z web_search/web_fetch per PRE-W2.B i PRE-W2.C)
7. Czy pismo rozdziela fakt od interpretacji?                TAK/NIE
8. Czy roszczenia słabsze (C/D) mają konstrukcję ewentualną? TAK/NIE
9. Czy sąd może przepisać ustalenia faktyczne z pisma do
   uzasadnienia wyroku bez dodatkowej pracy redakcyjnej?     TAK/NIE
10. Czy przeciwnik może jednym dokumentem obalić istotną tezę? TAK/NIE
11. Czy W2.4 (ATAK-NA-DRAFT) zamknięty ze statusem ✅ albo
    z odpowiedzią użytkownika na każdą słabość z 🔴?           TAK/NIE
```

Pyt. 10 = TAK → pismo wymaga przebudowy: wróć do W1.6 (R2) dla tej tezy.
Którekolwiek z pyt. 2–9, 11 = NIE → wskaż poprawkę i wykonaj przed
wydaniem pisma jako finalnego.

---

## MODUŁY — MAPA WCZYTYWANIA

```
MODUŁ                  WIADOMOŚĆ  KIEDY
─────────────────────────────────────────────────────────────────────────────
PRE-W1 — PRZYGOTOWANIE
─────────────────────────────────────────────────────────────────────────────
INTAKE-GAP             przed W1   gdy brak danych krytycznych
MOD-ETAPY              przed W1   gdy ≥10 dokumentów / akta wielotomowe /
                                   pismo wysokiego ryzyka (apelacja, AO,
                                   skarga kasacyjna); MOD-ETAPY OPAKOWUJE
                                   W1–W3: Etap 1–4 = przygotowanie W1,
                                   Etap 5 = W2, Etap 6 = W3; automat stanów
                                   obowiązuje identycznie wewnątrz MOD-ETAPY

─────────────────────────────────────────────────────────────────────────────
W1 — RAMA I STRATEGIA
─────────────────────────────────────────────────────────────────────────────
CLAIM-VALIDATION       W1.2a      zawsze gdy pismo opiera się na twierdzeniach
                                   faktycznych strony (praktycznie: zawsze);
                                   view /mnt/skills/user/shared/CLAIM-VALIDATION.md
MOD-WARIANTY-POZWU     W1.2b      gdy aktywny (≥2 aspekty główne / sygnał
                                   wieloznaczności / żądanie wariantów)
MOD-RED-TEAM-WLASNY    W1.6       gdy aktywny (wielopodmiotowość / ciągłość
                                   stosunku prawnego / roszczenie pieniężne /
                                   subsumcja złożona / dowód wieloznaczny)

─────────────────────────────────────────────────────────────────────────────
W2 — PROJEKT PISMA
─────────────────────────────────────────────────────────────────────────────
MOD-SZABLONY           W2.1       zawsze gdy redagujesz pismo
MOD-DOWODY             W2.1       gdy użytkownik dostarczył dowody/dokumenty
MOD-OBAL               W2.1       gdy riposta / odpowiedź na pozew / obalanie
MOD-OPLATY             W2.1       gdy pismo wszczynające postępowanie
MOD-ADMIN              W2.1       gdy sprawa adm./KPA/PPSA/WSA/NSA
MOD-TIMING             W2.1       gdy timing złożenia jest istotny (pierwsza
                                   rozprawa <14 dni / prekluzja / korzystne
                                   postanowienie); view shared/MOD-TIMING.md
MOD-DOKTRYNA           W2.1       gdy uzasadnienie powołuje komentarze lub
                                   literaturę prawniczą; view shared/MOD-DOKTRYNA.md
MOD-INTRO              W2.2       executive summary — zawsze przy: pozew /
                                   apelacja / pismo >3 str.; view shared/MOD-INTRO.md
MOD-ATAK-NA-DRAFT      W2.4       zawsze — bez warunku aktywacji

─────────────────────────────────────────────────────────────────────────────
W3 — WERYFIKACJA + WALIDACJA
─────────────────────────────────────────────────────────────────────────────
PODMIOT-GATE           W3.0       ⛔ ZAWSZE PIERWSZY w W3 — blokuje W3.1
MOD-PRAWO              W3.1       wbudowany w procedurę ⚠️Pn (hardgate + isap)
ISAP-AUDIT-PROTOCOL    W3.1       gdy akty mogły być nowelizowane między datą
                                   zdarzenia a datą pisma; view shared/ISAP-AUDIT-PROTOCOL.md
MOD-ORZE               W3.2       wbudowany w procedurę ⚠️On (→ orzeczenia-sadowe-v2)
ORZECZENIA-HIERARCHIA  W3.2       gdy pismo powołuje orzecznictwo; view shared/ORZECZENIA-HIERARCHIA.md
MOD-FAKTY / FAKTY_v2   W3.3       gdy pismo z dostarczonych materiałów źródłowych
MOD-WALIDACJA A–J      W3.4       zawsze — bloki A–J z triggerami per blok (patrz §W3.4)
LEGAL-QUALITY-GATE     W3.4/W3.6a bramka jakości prawa: PASS/WARN/FAIL
                                   view shared/LEGAL-QUALITY-GATE.md
MOD-KONCENTRACJA       W3.4(C)    ocena długości pisma per typ; view shared/MOD-KONCENTRACJA.md
QUALITY-CHECK          W3.4(C)    kontrola redakcyjna + logiczna; view shared/QUALITY-CHECK.md
RISK-ASSESSMENT        W3.4(F)    zawsze; view shared/RISK-ASSESSMENT.md
EXPERT-OPINION-AUDIT   W3.4(I)    gdy opinia biegłego w aktach; view shared/EXPERT-OPINION-AUDIT.md
HYBRID-VALIDATION      W3.5       zawsze — auto-raport braków
FORMAL-VALIDATOR       W3.5       uzupełnienie HYBRID; view references/checklists/formal-validator.md
COURT-SIMULATION       W3.6a K1   zawsze → zasila "Realizm sądowy" w AUDYT-KONCOWY
AUDYT-KONCOWY          W3.6a K3   zawsze — punktowy audyt 0-10, gate przed .docx
MOD-PEER-REVIEW        W3.7 K1    gdy: WPS>50k / ≥3 żądania / apelacja SN-SA /
                                   "adwokat diabła"; view shared/MOD-PEER-REVIEW.md
POST-VALIDATION        W3.7 K2    zawsze; view shared/POST-VALIDATION.md

─────────────────────────────────────────────────────────────────────────────
ŚCIEŻKA TEST A — REDAKCJA (zamiast W1-W2-W3)
─────────────────────────────────────────────────────────────────────────────
MOD-REDAKCJA           Test A     gotowe pismo + prośba o styl/ton/długość;
                                   po R.4 zawsze: PODMIOT-GATE (dla podmiotów
                                   w redagowanym piśmie) + AUDYT-KONCOWY
                                   (uproszczony: kategorie Fakty i Spójność)
                                   + HYBRID-VALIDATION

─────────────────────────────────────────────────────────────────────────────
ENGINES SPECJALISTYCZNE — MATRYCA AKTYWACJI
─────────────────────────────────────────────────────────────────────────────
theory-of-case-engine  W1.2       aktywny gdy: pismo złożone (>2 roszczenia)
                                   LUB apelacja LUB sprawa wieloinstancyjna;
                                   buduje narrację PRZED mapą przesłanka→dowód;
                                   view references/engines/theory-of-case-engine.md

appellate-engine-v8    W1/W2      ⛔ OBOWIĄZKOWY gdy: typ pisma = apelacja /
                                   zażalenie / skarga kasacyjna; zastępuje
                                   ogólną strukturę W2.2 matrycą zarzutów;
                                   view references/engines/appellate-engine-v8.md

rebuttal-drafting-v9   W1/W2      aktywny gdy: typ pisma = riposta / odpowiedź
                                   na pozew / odpowiedź na apelację;
                                   view references/engines/rebuttal-drafting-engine-v9.md

admin-pleading-v8      W1/W2      aktywny gdy: sprawa adm. i pismo złożone
                                   (odwołanie + WSA lub NSA); uzupełnia MOD-ADMIN;
                                   view references/engines/admin-pleading-engine-v8.md

prosecution-v8         W1/W2      ⛔ OBOWIĄZKOWY gdy: zażalenie na prokuraturę /
                                   subsydiarny AO; zastępuje ogólną strukturę W2.2;
                                   view references/engines/prosecution-complaint-engine-v8.md

opponent-attack-v9     W1.2       aktywny gdy: mamy pismo przeciwnika DO OBALENIA
                                   (nie tylko jako kontekst); wywołaj PRZED MOD-OBAL;
                                   view references/engines/opponent-pleading-attack-engine-v9.md

OPPONENT-CHECKLIST     W1.2       wywołaj łącznie z opponent-attack-v9;
                                   view references/checklists/opponent-pleading-audit-checklist-v9.md

─────────────────────────────────────────────────────────────────────────────
ENGINES V10 — ANALIZA PISM PRZECIWNIKA (matryca aktywacji)
─────────────────────────────────────────────────────────────────────────────
Aktywuj WSZYSTKIE 6 engines V10 gdy spełniony ≥1 warunek:
  □ pismo oparte na analizie ≥2 pism procesowych przeciwnika, LUB
  □ sprawa trwa >6 miesięcy i przeciwnik złożył ≥3 pisma, LUB
  □ apelacja od wyroku niekorzystnego (potrzeba analizy uzasadnienia), LUB
  □ sprzeczności między pismami przeciwnika są kluczowym argumentem.

contradiction-v10      W1.2       view references/engines/contradiction-intelligence-engine-v10.md
self-destructive-v10   W1.2       view references/engines/self-destructive-admissions-engine-v10.md
timeline-conflict-v10  W1.2       view references/engines/timeline-conflict-engine-v10.md
cross-pleading-v10     W1.2       view references/engines/cross-pleading-consistency-engine-v10.md
strategic-collapse-v10 W1.2       view references/engines/strategic-theory-collapse-engine-v10.md
judicial-cred-v10      W1.2       view references/engines/judicial-credibility-simulation-engine-v10.md
```

Pliki kanoniczne shared (kolejność ładowania w W3):
```
view /mnt/skills/user/shared/PRAWO-HARDGATE.md
view /mnt/skills/user/shared/INTAKE-GAP.md
view /mnt/skills/user/shared/CLAIM-VALIDATION.md             (W1.2a, zawsze)
view /mnt/skills/user/shared/HYBRID-VALIDATION.md
view /mnt/skills/user/shared/MOD-WALIDACJA_v2.md             (bloki A–J)
view /mnt/skills/user/shared/FAKTY_v2.md
view /mnt/skills/user/shared/FACT-SOURCE-LOCK.md             (Blok J prerequisite)
view /mnt/skills/user/shared/LEGAL-STATUS-LOCK.md            (Blok J prerequisite)
view /mnt/skills/user/shared/LEGAL-QUALITY-GATE.md           (W3.4/W3.6a — bramka jakości prawa)
view /mnt/skills/user/shared/POST-VALIDATION.md              (W3.7 K2 — zawsze)
view /mnt/skills/user/shared/MOD-PEER-REVIEW.md              (W3.7 K1 — warunkowo)
view /mnt/skills/user/shared/MOD-INTRO.md                    (W2.2 — pozew/apelacja/>3str)
view /mnt/skills/user/shared/MOD-KONCENTRACJA.md             (W3.4 Blok C — zawsze)
view /mnt/skills/user/shared/MOD-DOKTRYNA.md                 (W2.1 — gdy doktryna w uzasadnieniu)
view /mnt/skills/user/shared/MOD-TIMING.md                   (W2.1 — gdy timing istotny)
view /mnt/skills/user/shared/raport-sytuacyjny-integracja.md
view /mnt/skills/user/shared/MOD-WARIANTY-POZWU.md           (W1.2b, gdy aktywny)
view /mnt/skills/user/shared/MOD-RED-TEAM-WLASNY.md          (W1.6, gdy aktywny)
view /mnt/skills/user/shared/MOD-ATAK-NA-DRAFT.md            (W2.4, zawsze)
view /mnt/skills/user/shared/AUDYT-KONCOWY.md                (W3.6a, zawsze)
view /mnt/skills/user/shared/MOD-PRIORYTETY-ASPEKTOW.md      (wejście do W1.2b)
view /mnt/skills/user/shared/MOD-MAPA-PRZEPISOW.md           (Podstawa/Ryzyko w W1.2b)
view /mnt/skills/user/shared/MOD-HISTORIA-STRATEGII.md       (zapis wariantów W1.2b)
```

---

## INTEGRACJA Z INNYMI SKILLAMI

| Potrzeba | Skill | Kiedy |
|---|---|---|
| Orzecznictwo SN/SA (szerokie wyszukiwanie) | `orzeczenia-sadowe-v2` | W3.2 gdy wiele orzeczeń do weryfikacji |
| Analiza dowodów przed W1 | `analizator-dowodow-v3` | gdy duże akta, wiele dowodów |
| Analiza sprawy przed W1 | `analiza-sadowa-v6` | gdy użytkownik nie wie od czego zacząć |
| Proste pismo 1-wątkowe | `pisma-proste-v2` | po pozytywnym Teście A |
| Redakcja/poprawa gotowego pisma (styl, ton, długość) | MOD-REDAKCJA (ten skill) | po pozytywnym Teście C — bez W1-W2-W3 |
| Wyjaśnienie dla laika | `przewodnik-prawny-v2` | gdy użytkownik zagubiony |

---

## DODATEK — CONTRADICTION INTELLIGENCE (V10)

Przy analizie pism przeciwnika (riposta, apelacja, odpowiedź) — w W1 obowiązkowo uruchom:

```
view /mnt/skills/user/pisma-procesowe-v3/modules/MOD-OBAL.md
```

Hard gate: nie przygotowuj repliki, odpowiedzi ani apelacji bez sprawdzenia w W1.2
(mapa cel → przesłanka → dowód) czy przeciwnik nie zawarł twierdzeń wzajemnie sprzecznych,
dorozumianych przyznań albo twierdzeń szkodliwych dla własnej teorii sprawy.

### Matryca aktywacji V10 — aktywuj WSZYSTKIE 6 modułów gdy ≥1 warunek spełniony:

```
WARUNEK A: pismo oparte na analizie ≥2 pism procesowych przeciwnika
WARUNEK B: sprawa trwa >6 miesięcy i przeciwnik złożył ≥3 pisma
WARUNEK C: apelacja od wyroku niekorzystnego (analiza uzasadnienia sądu)
WARUNEK D: sprzeczności między pismami przeciwnika są kluczowym argumentem

⛔ NIE pomijaj V10 gdy warunki spełnione — to najdroższa analitycznie
   część systemu, ale wykrywa to, czego żaden inny moduł nie wykryje.
```

Moduły V10 (wczytaj wszystkie razem — wzajemnie się zasilają):
```
view /mnt/skills/user/pisma-procesowe-v3/references/engines/contradiction-intelligence-engine-v10.md
view /mnt/skills/user/pisma-procesowe-v3/references/engines/self-destructive-admissions-engine-v10.md
view /mnt/skills/user/pisma-procesowe-v3/references/engines/timeline-conflict-engine-v10.md
view /mnt/skills/user/pisma-procesowe-v3/references/engines/cross-pleading-consistency-engine-v10.md
view /mnt/skills/user/pisma-procesowe-v3/references/engines/strategic-theory-collapse-engine-v10.md
view /mnt/skills/user/pisma-procesowe-v3/references/engines/judicial-credibility-simulation-engine-v10.md
```

Po wczytaniu V10 wywołaj też:
```
view /mnt/skills/user/pisma-procesowe-v3/references/engines/opponent-pleading-attack-engine-v9.md
view /mnt/skills/user/pisma-procesowe-v3/references/checklists/opponent-pleading-audit-checklist-v9.md
```

---

## OBSŁUGA PISMA ADMINISTRACYJNEGO (KPA/PPSA/WSA/NSA)

Ładuj `MOD-ADMIN` w W2 zawsze gdy sprawa dotyczy:
- wniosku do organu, odwołania od decyzji, zażalenia na postanowienie, ponaglenia,
- skargi na bezczynność, skargi do WSA, skargi kasacyjnej do NSA,
- wznowienia, nieważności, uchylenia lub zmiany decyzji,
- postępowań: budowlanych, środowiskowych, PZP/KIO, transportowych, sanitarnych,
  URE/UKE/UOKiK/UODO.

Przy obszernych aktach administracyjnych W1 rozszerz o:
- identyfikacja aktu/czynności i środka prawnego,
- rekonstrukcja faktów i zarzuty proceduralne,
- zarzuty materialne.
