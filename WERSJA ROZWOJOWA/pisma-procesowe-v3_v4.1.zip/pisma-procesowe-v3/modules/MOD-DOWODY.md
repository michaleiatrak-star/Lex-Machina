# MOD-DOWODY — Hierarchia i Łańcuch Dowodowy

*Ładuj gdy: użytkownik dostarczył dokumenty / akta / dowody do analizy*
*Powiązany skill: `analizator-dowodow-v3` — użyj gdy dużo dowodów lub potrzebna pełna ocena*

---

## D1 — Hierarchia dowodów (4 poziomy)

### Poziom A — Dokumenty urzędowe (moc najwyższa)
Protokoły sądowe z sygnaturą/datą/godziną, wyniki kontroli organów państwowych,
wpisy do rejestrów, orzeczenia prawomocne, potwierdzenia z metadanymi
elektronicznymi, akty notarialne, decyzje administracyjne.

**Jak powoływać:** "(protokół z dnia [data], godz. [X], str. [Y])"

### Poziom B — Zeznania pod rygorem odpowiedzialności
Zeznania świadków z protokołu sądowego lub prokuratorskiego.
**Oceniaj:** spójność wewnętrzna, spójność zewnętrzna (z A), interes procesowy,
spontaniczność odpowiedzi.

**Jak powoływać:** "(zeznanie świadka [imię], protokół z dnia [data], godz. [X])"

### Poziom C — Dokumenty prywatne stron
Pisma, maile, wiadomości, nagrania, zdjęcia, faktury, umowy prywatne.
**Wartość:** gdy strona sama je złożyła (działa przeciw niej) lub są niesprzeczne z A i B.

**Jak powoływać:** "(pismo z dnia [data], zał. nr [X])"

### Poziom D — Twierdzenia bez dowodu
Zdania strony bez poparcia dowodowego.
**Reakcja:** wskazuj brak dowodu → żądaj przedstawienia (art. 248 KPC)
lub stosuj art. 233 §2 KPC (odmowa oceniana na niekorzyść).

---

## D2 — Budowa łańcucha dowodowego

Dla każdego roszczenia/tezy:

```
ROSZCZENIE / TEZA:
[treść]
  ↓
PRZEPIS PRAWNY (zweryfikowany — patrz MOD-PRAWO):
[art. X §Y — co wymaga udowodnienia]
  ↓
DOWÓD Z AKT (poziom A lub B):
[nazwa, data, str./godz.]
  ↓
ORZECZENIE ANALOGICZNE (opcjonalnie — via orzeczenia-sadowe-v2):
[sąd, data, sygnatura, podobieństwo X/5]
  ↓
WNIOSEK DLA SĄDU:
[konkretna konkluzja]
```

---

## D3 — Weryfikacja kompletności łańcucha

Przed napisaniem pisma sprawdź dla każdego roszczenia:

```
ROSZCZENIE: [treść]
┌─ Przepis: [zweryfikowany online]              → OK / BRAK
├─ Dowód A/B: [z akt, str./data]                → OK / BRAK
├─ Podobna sprawa: [sygnatura, podobień. X/5]   → OK / BRAK / ZBĘDNE
├─ Twierdzenie przeciwnika: [zidentyfikowane]   → OK / BRAK / N/D
└─ Obalenie twierdzenia: [typ A/B/C/D/E/F]      → OK / BRAK / N/D

STATUS:
✓ KOMPLETNY → można pisać
⚠ NIEKOMPLETNY → wskaż lukę i sposób jej uzupełnienia
✗ BRAK PODSTAWY → nie umieszczaj w piśmie
```

---

## D4 — Sekcja "Na dowód" w piśmie

Format obligatoryjny:

```
Na dowód powyższego powołuję:
1. [Nazwa dowodu] — [lokalizacja: str. X akt / zał. nr Y]
   na okoliczność: [co konkretnie wykazuje]
2. [Kolejny dowód] — [lokalizacja]
   na okoliczność: [...]
```

> ⚠ Brak wskazania okoliczności → sąd może oddalić wniosek dowodowy
> ⚠ Dowód bez faktu w stanie faktycznym → nieaktywny procesowo

---

## D5 — Kiedy delegować do analizatora-dowodow-v3

Deleguj do `analizator-dowodow-v3` gdy:
- Akta liczą więcej niż 10 dokumentów
- Istnieją sprzeczności między dowodami
- Użytkownik prosi o pełną ocenę wartości dowodowej
- Potrzebna jest ocena 0–10 i hierarchia A–D dla każdego dowodu

Wyniki z `analizatora-dowodow-v3` integruj wg reguł:
- Alerty LEGAL (zakaz dowodowy, prekluzja) → pomiń dowód w sekcji "Na dowód"
- Alerty FORM (brak oryginału, brak daty) → wyjaśnij lub pomiń
- Alerty SPOJ (konflikty) → wyjaśnij w stanie faktycznym lub pomiń słabszy
- Dowody 0–3/10 → nie powoływać (obniżają wiarygodność)

## Integracja shared/DOWODY-METODOLOGIA

Przy każdej analizie materiału dowodowego wczytaj:

```text
view /mnt/skills/user/shared/DOWODY-METODOLOGIA.md
view /mnt/skills/user/shared/PREKLUZJA-DOWODOWA.md
```

Nie klasyfikuj dowodu wyłącznie opisowo. Każdy dowód musi być przypisany do faktu istotnego prawnie i przesłanki prawnej.

---

## D6 — Protokół eksploracji dowodów wielowarstwowych (NOWE v1.1)

> **Trigger:** użytkownik dostarczył ≥1 plik XLS/XLSX z wieloma arkuszami LUB
> tabelę operacyjną (pracownicy, zezwolenia, kandydaci, korespondencja) LUB
> zrzuty ekranu z komunikatorów datowane w różnych okresach.
>
> **Cel:** wydobyć z tych dowodów informacje o ciągłości organizacyjnej,
> tożsamości pracodawcy i gotowości do pracy — które byłyby pominięte przy
> pobieżnym czytaniu.

### D6.1 — Tabele operacyjne jako dowód tożsamości pracodawcy

Gdy w materiale są arkusze XLS/XLSX z danymi pracowników lub operacyjnymi:

```
KROK D6.1.A — IDENTYFIKACJA ARKUSZY:
  Dla każdego pliku XLS/XLSX: wylistuj wszystkie arkusze i ich rozmiary.
  Szukaj: arkusze z podobną strukturą kolumn dla różnych podmiotów
  (np. "Pracownicy HP" + "Pracownicy HP Global" w jednym pliku).

KROK D6.1.B — CIĄGŁOŚĆ NUMERACJI:
  Sprawdź kolumnę numeracji wewnętrznej (Ser. Nr, Nr, ID, lp).
  Jeśli numeracja między arkuszami jest CIĄGŁA (brak resetu po dacie zmiany podmiotu):
    → Dowód: jeden system prowadził ewidencję obu podmiotów bez przerwy.
    → Wniosek: brak faktycznego wyodrębnienia operacyjnego.
    → Zanotuj: "numeracja ciągła od [rok] bez resetu po [data przejścia]"

KROK D6.1.C — WSPÓLNA KADRA:
  Czy te same osoby (po nazwisku / numerze) pojawiają się w arkuszach
  różnych podmiotów? → Dowód braku wyodrębnienia personelu.
  Czy ta sama osoba pełni funkcję kierowniczą w obu podmiotach? → art. 31 KP.

KROK D6.1.D — BRAK PRZEJĘCIA:
  Czy w dniu formalnej zmiany podmiotu jest widoczna jakakolwiek przerwa
  (brak wpisów, inna struktura, reset numeracji)?
  NIE → Dowód, że podmiot nie był faktycznie zmieniony operacyjnie.
```

### D6.2 — Tabele rekrutacyjne / zezwolenia jako dowód zakresu obowiązków i ciągłości

```
KROK D6.2.A — IDENTYFIKACJA WŁAŚCICIELA ARKUSZA:
  Jeśli arkusz ma zakładkę z imieniem pracownika ("p.Michał Rwanda", "Sławomir",
  "Prezes Nepal") → to zeznanie o podziale pracy między pracownikami.
  Jeśli powód ma swoje arkusze przez cały okres → dowód ciągłości obowiązków.

KROK D6.2.B — DATY OPŁAT / SKŁADANIA / OTRZYMANIA:
  Czy daty opłat i złożeń przekraczają datę rzekomego rozwiązania stosunku pracy?
  Jeśli TAK → dowód kontynuowania czynności po dacie spornej.
  Zanotuj konkretne daty z tabel.

KROK D6.2.C — KLIENCI (kolumna "dod.info" / "zakład"):
  Czy ci sami klienci (Kwangjin, YSP, KFTP) pojawiają się w arkuszach
  dla obu podmiotów? → Dowód braku zmiany działalności operacyjnej.
```

### D6.3 — Komunikatory (WhatsApp / RCS / SMS) jako dowód ciągłości i gotowości

```
KROK D6.3.A — TABELARYZACJA KORESPONDENCJI:
  Dla każdego zrzutu ekranu: data (z metadanych lub treści) | nadawca | treść (streszczenie) |
  podmiot w umowie powoda w tej dacie | wartość dowodowa.

KROK D6.3.B — GRANICZNE DATY:
  Identyfikuj wiadomości w okolicach daty spornego przejścia między podmiotami.
  Jeśli te same osoby wysyłają te same typy wiadomości bez przerwy przed i po → ciągłość.
  Przykład: Nawrot wysyła dane kandydatów 29.06.2023 (ostatni dzień HP) i
            Yurij wysyła dane 09.08.2023 (HP Global) → brak przerwy operacyjnej.

KROK D6.3.C — GOTOWOŚĆ DO PRACY (wiadomości po dacie spornej):
  Czy są wiadomości gdzie powód deklaruje gotowość do pracy? → art. 81 §1 KP.
  Jeśli wiadomość odebrana (potwierdzenie odczytu) i brak odpowiedzi merytorycznej:
    → Dowód: przeszkoda po stronie pracodawcy (milczenie na wyraźne zgłoszenie).
  Jeśli pracodawca odpowiedział odcinając kontakt (osobista wiadomość Prezesa):
    → Kluczowy dowód: akt organu pracodawcy (art. 31 KP) odmawiający kontaktu
      = niedopuszczenie do pracy z przyczyn dotyczących pracodawcy.
    → Zanotuj: data, godzina, potwierdzenie odczytu, treść.

KROK D6.3.D — RAPORT TABELARYCZNY:
  Wygeneruj tabelę: Data | Nadawca | Treść | Podmiot powoda wtedy | Wartość | Teza
  (wzór z sekcji IV pisma VII P 94/25 — tabela ciągłości HP/HPG)
```

### D6.4 — Spis zdawczo-odbiorczy akt jako dowód jednego archiwum

```
Jeśli w materiale jest spis zdawczo-odbiorczy akt osobowych:
  - Ile wierszy (ilu pracowników) obejmuje?
  - Dla jakiego podmiotu jest wystawiony?
  - Czy obejmuje pracowników przypisanych do obu podmiotów bez rozgraniczenia?
  TAK → Dowód: jedno wspólne archiwum akt osobowych = brak wyodrębnienia.
```

### D6.5 — Wynik D6: zestawienie dla W1.3

```
Po wykonaniu D6.1–D6.4, zasilaj W1.3 (mapa cel→przesłanka→dowód)
następującymi elementami:

TEZA: Ciągłość organizacyjna / tożsamość pracodawcy rzeczywistego
  Przesłanka A: Jeden system kadrowy (wspólna baza, ciągła numeracja)
    Dowód: [arkusz XLS — opis + konkretne kolumny/daty]
  Przesłanka B: Ten sam personel kierowniczy i współpracownicy
    Dowód: [names z arkuszy + protokoły z rozpraw]
  Przesłanka C: Identyczne czynności operacyjne bez przerwy
    Dowód: [tabela z D6.3.D — daty graniczne HP/HPG]
  Przesłanka D: Jedno archiwum akt osobowych
    Dowód: [spis zdawczo-odbiorczy — liczba wierszy, podmiot]

TEZA: Gotowość do pracy i przeszkoda po stronie pracodawcy
  Przesłanka A: Czynna manifestacja gotowości
    Dowód: [wiadomości do Prezesa z D6.3.C — data, potwierdzenie odczytu]
  Przesłanka B: Przeszkoda ze strony pracodawcy
    Dowód: [osobista wiadomość Prezesa odmawiająca kontaktu — data, art. 31 KP]
    Dowód: [pismo kancelarii zamykające wszystkie kanały]
```

---

## D7 — Antycypacja zarzutów (NOWE v1.1)

> **Trigger:** pismo zawiera ≥2 ścieżki prawne LUB teza przewiduje atak 🔴/🟠.
>
> **Zasada:** każdy istotny zarzut przeciwnika powinien być wprost wyartykułowany
> w uzasadnieniu pisma i obalony — zanim pełnomocnik go podniesie.
> To silniejsze procesowo niż obalenie dopiero w replice.

### Format antycypacji:

```
[ANTYCYPACJA ZARZUTU X]

Pozwany może podnieść, że [treść przewidywanego zarzutu].

Zarzut ten jest chybiony z [liczba] powodów:

Po pierwsze, [kontrargument faktyczny + dowód].

Po drugie, [kontrargument prawny + przepis/orzeczenie].

Po trzecie (jeśli dotyczy), [kontrargument procesowy].
```

### Triggery dla antycypacji w sprawach pracowniczych:

```
ZARZUT-P1: "Dwie spółki to odrębne podmioty / brak pracodawcy grupowego"
  → Antycypuj gdy: sprawa wielopodmiotowa, teza o tożsamości pracodawcy
  → Kontratak: NIE twierdzimy, że grupa = pracodawca; twierdzimy który
    z dwóch podmiotów jest pracodawcą rzeczywistym (por. SN II PK 50/13)

ZARZUT-P2: "Gotowość nie była czynna / pracownik nie stawił się fizycznie"
  → Antycypuj gdy: roszczenie z art. 81 §1 KP bez fizycznych stawień
  → Kontratak: (1) standard SN — czynna manifestacja woli, nie fizyczna obecność;
    (2) przeszkoda po stronie pracodawcy eliminuje konieczność fizycznego stawiennictwa;
    (3) błędne przeświadczenie pracodawcy o ustaniu stosunku nie pozbawia
    prawa do wynagrodzenia (por. SO Łódź VIII Pa 155/21)

ZARZUT-P3: "Brak regulaminu wynagradzania / premia nie jest regulaminowa"
  → Antycypuj gdy: roszczenie o premię bez pisemnego regulaminu
  → Kontratak: utrwalona praktyka zakładowa = element prawa pracy (art. 9 §1 KP);
    dowód: zeznania świadka o regularnych wypłatach; wniosek z art. 248 KPC

ZARZUT-P4: "Porozumienie o rozwiązaniu skutecznie zakończyło stosunek pracy"
  → Antycypuj gdy: pracodawca powołuje się na porozumienie zawarte po konwersji umowy
  → Kontratak: art. 25¹ §3 KP działa z mocy samego prawa — porozumienie zawarte
    po konwersji nie może „cofnąć" bezterminowości; wymagane było wypowiedzenie
    z zachowaniem trybu art. 30 i nast. KP
```

