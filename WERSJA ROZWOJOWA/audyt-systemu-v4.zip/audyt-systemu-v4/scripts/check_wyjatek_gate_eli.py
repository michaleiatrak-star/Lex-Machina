#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
T20 — check_wyjatek_gate_eli.py
Wsparcie narzędziowe dla bramki WYJ-GATE (shared/MOD-WYJATEK-GATE.md, flaga F-144).

CO ROBI — trzy z czterech zamiatań bramki
  S1 (--article)    zakres sąsiedztwa: jednostka nadrzędna (tytuł/dział/
                    rozdział), artykuł poprzedzający i następujący oraz
                    WSZYSTKIE artykuły z indeksem górnym przy tym samym
                    i sąsiednim numerze (art. X, X¹, X², …). To jedyny krok,
                    który w kazusie 111 wystarczyłby do wykrycia art. 770¹ k.c.
  S2 (--edges)      krawędzie jednostki: PIERWSZY i OSTATNI artykuł jednostki
                    nadrzędnej — tam stoją klauzule zakresowe i wyłączenia
                    („przepisów niniejszego działu nie stosuje się do…").
  S3 (--references) akty powiązane z rejestru ELI: materiał do wykrycia lex
                    specialis leżącego POZA aktem głównym.
  S4                przepisy przejściowe — poza zakresem narzędzia, procedura
                    w MOD-OS-CZASU-PRZESLANEK OŚ-5.4.

CZEGO NIE ROBI — świadomie
  ⛔ NIE ocenia wpływu. Klasyfikacja „wyłącza / zawęża / odsyła" jest decyzją
     merytoryczną i pozostaje po stronie analizy. Skrypt, który by ją zgadywał,
     produkowałby fasadę.
  ⛔ NIE wybiera wersji czasowej za operatora. Podaj identyfikator aktu
     (tekst jednolity) obowiązującego na datę zdarzenia. Data służy wyłącznie
     do opisania wyniku i do ostrzeżenia, gdy metryka aktu jest późniejsza.
  ⛔ NIE jest źródłem prawa i nie zastępuje HARD GATE.

STATUS WERYFIKACJI
  Ścieżki offline (parser S1, krawędzie S2, parser referencji S3) są
  przetestowane: `--selftest` = 8/8 PASS.
  Ścieżka sieciowa (api.sejm.gov.pl/eli) NIE została uruchomiona na żywym
  API — środowisko wykonawcze audytu nie ma tej domeny na liście dozwolonej.
  Do czasu uruchomienia u dewelopera traktuj gałąź sieciową jako
  ⚠️ NIEZWERYFIKOWANĄ (zakres otwarty flagi F-144).

UŻYCIE
  python3 check_wyjatek_gate_eli.py --act DU/1964/93 --article 770 --date 2011-02-20
  python3 check_wyjatek_gate_eli.py --fixture tekst.html --article 770 --edges
  python3 check_wyjatek_gate_eli.py --act DU/1964/93 --references
  python3 check_wyjatek_gate_eli.py --selftest

KODY WYJŚCIA
  0 — zakres zbudowany
  2 — błąd API / brak dostępu do sieci (ta sama konwencja co audit_tj_inventory.py)
  3 — artykuł nieznaleziony w tekście
  4 — błąd użycia
"""

import argparse
import json
import re
import sys
import unicodedata

ELI_BASE = "https://api.sejm.gov.pl/eli/acts"

SUPERSCRIPT = {"¹": "1", "²": "2", "³": "3", "⁴": "4", "⁵": "5",
               "⁶": "6", "⁷": "7", "⁸": "8", "⁹": "9", "⁰": "0"}

HEADING_RE = re.compile(
    r"(TYTU[ŁL]|DZIA[ŁL]|ROZDZIA[ŁL]|KSI[ĘE]GA)\s+([IVXLCDM]+[a-z]?|\d+[a-z]?)",
    re.IGNORECASE)

ART_RE = re.compile(
    r"Art\.\s*(\d+)\s*(?:<sup>\s*(\d+)\s*</sup>|\(\s*(\d+)\s*\)|([¹²³⁴⁵⁶⁷⁸⁹⁰]+))?",
    re.IGNORECASE)


# --------------------------------------------------------------------------
# parser
# --------------------------------------------------------------------------

def strip_tags(html):
    """Usuwa znaczniki, zachowując <sup> jako marker indeksu górnego."""
    html = re.sub(r"(?is)<(script|style).*?</\1>", " ", html)
    html = re.sub(r"(?i)<sup[^>]*>", "<sup>", html)
    html = re.sub(r"(?i)</sup\s*>", "</sup>", html)
    html = re.sub(r"(?is)<(?!/?sup)[^>]+>", " ", html)
    html = html.replace("&nbsp;", " ").replace("&#160;", " ")
    return re.sub(r"[ \t]+", " ", html)


def norm_index(m):
    """Zwraca indeks górny artykułu jako tekst albo '' gdy go nie ma."""
    sup, paren, uni = m.group(2), m.group(3), m.group(4)
    if sup:
        return sup.strip()
    if paren:
        return paren.strip()
    if uni:
        return "".join(SUPERSCRIPT.get(c, "") for c in uni)
    return ""


def parse_units(text):
    """Lista jednostek: (numer:int, indeks:str, pozycja:int, nagłówek nadrzędny)."""
    headings = [(m.start(), " ".join(m.group(0).split()).upper())
                for m in HEADING_RE.finditer(text)]

    def heading_for(pos):
        current = None
        for start, label in headings:
            if start <= pos:
                current = label
            else:
                break
        return current

    units = []
    seen = set()
    for m in ART_RE.finditer(text):
        num = int(m.group(1))
        idx = norm_index(m)
        key = (num, idx)
        if key in seen:
            continue
        seen.add(key)
        units.append({"numer": num, "indeks": idx, "pozycja": m.start(),
                      "jednostka_nadrzedna": heading_for(m.start()),
                      "etykieta": f"art. {num}" + (f"^{idx}" if idx else "")})
    units.sort(key=lambda u: (u["numer"], int(u["indeks"] or 0)))
    return units


def build_scope(units, article, index=""):
    """Zakres minimalny US-2 wokół wskazanego artykułu."""
    target = [u for u in units if u["numer"] == article and u["indeks"] == index]
    if not target:
        return None
    t = target[0]
    numbers = sorted({u["numer"] for u in units})
    if article not in numbers:
        return None
    i = numbers.index(article)
    wanted = {article}
    if i > 0:
        wanted.add(numbers[i - 1])
    if i < len(numbers) - 1:
        wanted.add(numbers[i + 1])
    scope = [u for u in units if u["numer"] in wanted]
    return {"cel": t, "zakres": scope}


def build_edges(units, article):
    """S2 — pierwszy i ostatni artykuł jednostki nadrzędnej celu."""
    target = [u for u in units if u["numer"] == article]
    if not target:
        return None
    head = target[0]["jednostka_nadrzedna"]
    same = [u for u in units if u["jednostka_nadrzedna"] == head]
    if not same:
        return None
    return {"jednostka_nadrzedna": head, "pierwszy": same[0], "ostatni": same[-1]}


def parse_references(data):
    """S3 — spłaszcza odpowiedź ELI /references do listy aktów powiązanych."""
    out = []
    if isinstance(data, dict):
        for rel, items in data.items():
            if not isinstance(items, list):
                continue
            for it in items:
                if not isinstance(it, dict):
                    continue
                out.append({
                    "relacja": rel,
                    "id": it.get("id") or "{}/{}/{}".format(
                        it.get("publisher", "?"), it.get("year", "?"),
                        it.get("pos", "?")),
                    "tytul": (it.get("title") or "").strip(),
                    "data": it.get("date") or "",
                })
    out.sort(key=lambda r: (r["relacja"], r["id"]))
    return out


# --------------------------------------------------------------------------
# wejście
# --------------------------------------------------------------------------

def fetch_eli_text(act_id):
    """Pobiera tekst aktu z ELI. Gałąź NIEZWERYFIKOWANA na żywym API."""
    import urllib.error
    import urllib.request
    parts = act_id.strip("/").split("/")
    if len(parts) != 3:
        raise SystemExit("Format --act: PUBLISHER/ROK/POZYCJA, np. DU/1964/93")
    url = "{}/{}/{}/{}/text.html".format(ELI_BASE, *parts)
    try:
        with urllib.request.urlopen(url, timeout=60) as r:
            return r.read().decode("utf-8", errors="replace"), url
    except Exception as exc:                       # noqa: BLE001
        print("BŁĄD API ELI: {}\nURL: {}".format(exc, url), file=sys.stderr)
        print("Gałąź sieciowa nie została zweryfikowana na żywym API — "
              "wykonaj US-2 ręcznie i oznacz źródło wg PRAWO-HARDGATE.",
              file=sys.stderr)
        sys.exit(2)


def fetch_eli_references(act_id):
    """Pobiera rejestr odesłań ELI. Gałąź NIEZWERYFIKOWANA na żywym API."""
    import urllib.request
    parts = act_id.strip("/").split("/")
    if len(parts) != 3:
        raise SystemExit("Format --act: PUBLISHER/ROK/POZYCJA, np. DU/1964/93")
    url = "{}/{}/{}/{}/references".format(ELI_BASE, *parts)
    try:
        with urllib.request.urlopen(url, timeout=60) as r:
            return json.loads(r.read().decode("utf-8", errors="replace")), url
    except Exception as exc:                       # noqa: BLE001
        print("BŁĄD API ELI: {}\nURL: {}".format(exc, url), file=sys.stderr)
        print("Gałąź sieciowa nie została zweryfikowana na żywym API — "
              "wykonaj S3 ręcznie i oznacz źródło wg PRAWO-HARDGATE.",
              file=sys.stderr)
        sys.exit(2)


def render_edges(edges):
    print("  S2 krawędzie jednostki ({}):".format(
        edges["jednostka_nadrzedna"] or "⚠️ nieustalona"))
    print("    - pierwszy: {:<12} (zakres/definicje?)  →  DO OCENY".format(
        edges["pierwszy"]["etykieta"]))
    print("    - ostatni:  {:<12} (wyłączenia/odesłania?) →  DO OCENY".format(
        edges["ostatni"]["etykieta"]))
    print("    \u2691 Klauzule wylaczajace (\u201enie stosuje sie\u201d, "
          "\u201estosuje sie odpowiednio\u201d)\n"
          "       stoja zwykle na krawedziach jednostki, nie przy przepisie, "
          "ktory wylaczaja.")


def render_references(refs, act_label, source):
    print("WYJ-GATE / S3 — akty powiązane (materiał, NIE ocena)")
    print("  akt:     {}".format(act_label))
    print("  źródło:  {}".format(source))
    if not refs:
        print("  ⚠️ rejestr odesłań pusty — to NIE dowodzi braku lex specialis.")
        print("     Akt sektorowy, który nie odsyła wprost, tu się nie pojawi.")
        return
    print("  pozycji: {}".format(len(refs)))
    for r in refs:
        print("    - [{}] {} {} {}".format(
            r["relacja"], r["id"], r["data"], r["tytul"][:70]))
    print("  \u26d4 Kazda pozycje zamknij wpisem \u201ebrak wplywu\u201d "
          "albo nazwanym skutkiem.")


def render(result, act_label, date, source):
    cel = result["cel"]
    nadrz = cel["jednostka_nadrzedna"] or "⚠️ jednostka nadrzędna nieustalona"
    print("WYJ-GATE / S1 — zakres sąsiedztwa (wygenerowany maszynowo)")
    print("  akt:        {}".format(act_label))
    print("  jednostka:  {}".format(cel["etykieta"]))
    print("  stan na:    {}".format(date or "⬛ DATA NIEPODANA"))
    print("  nadrzędna:  {}".format(nadrz))
    print("  źródło:     {}".format(source))
    print("  sąsiedzi (status i wpływ = ocena merytoryczna, RĘCZNA):")
    for u in result["zakres"]:
        mark = "  ← CEL" if u is cel else ""
        flag = "  ⚑ INDEKS GÓRNY" if u["indeks"] and u is not cel else ""
        print("    - {:<12} status: ?   wpływ: ?{}{}".format(
            u["etykieta"], flag, mark))
    idx = [u for u in result["zakres"] if u["indeks"] and u is not cel]
    if idx:
        print("  ⚑ UWAGA: w zakresie są jednostki z indeksem górnym. To typowe "
              "miejsce\n     lex specialis dodanego nowelizacją — sprawdź je "
              "przed konkluzją.")
    print("  ⛔ Skrypt NIE ocenia wpływu. Milczenie o sąsiedzie nie jest "
          "odpowiedzią negatywną.")


# --------------------------------------------------------------------------
# selftest
# --------------------------------------------------------------------------

FIXTURE = """
<html><body>
<p>TYTUŁ XXIII. Umowa agencyjna</p>
<p>Art. 758. Przez umowę agencyjną ...</p>
<p>Art. 764<sup>1</sup>. W razie rozwiązania umowy ...</p>
<p>TYTUŁ XXIV. Umowa komisu</p>
<p>Art. 765. Przez umowę komisu ...</p>
<p>Art. 769. Jeżeli komisant zapłacił ...</p>
<p>Art. 770. Komisant nie ponosi odpowiedzialności za ukryte wady fizyczne
rzeczy, jak również za jej wady prawne, jeżeli przed zawarciem umowy podał
to do wiadomości kupującego ...</p>
<p>Art. 770<sup>1</sup>. Do umowy sprzedaży rzeczy ruchomej zawartej przez
komisanta z osobą fizyczną ... stosuje się przepisy o sprzedaży
konsumenckiej.</p>
<p>Art. 771. Komisant, który bez upoważnienia ...</p>
<p>TYTUŁ XXV. Umowa przewozu</p>
<p>Art. 774. Przez umowę przewozu ...</p>
</body></html>
"""


FIXTURE_REFS = {
    "Akty zmieniające": [
        {"id": "DU/2002/1176", "year": 2002, "pos": 1176, "publisher": "DU",
         "date": "2002-07-27",
         "title": "Ustawa o szczegolnych warunkach sprzedazy konsumenckiej "
                  "oraz o zmianie Kodeksu cywilnego"},
        {"id": "DU/2014/827", "year": 2014, "pos": 827, "publisher": "DU",
         "date": "2014-05-30", "title": "Ustawa o prawach konsumenta"},
    ],
    "Akty odsylajace": [
        {"id": "DU/2022/2337", "year": 2022, "pos": 2337, "publisher": "DU",
         "date": "2022-11-04", "title": "Ustawa zmieniajaca ustawe o prawach "
                                        "konsumenta"},
    ],
}


def selftest():
    text = strip_tags(FIXTURE)
    units = parse_units(text)
    checks = []

    labels = [u["etykieta"] for u in units]
    checks.append(("parser widzi art. 770^1 jako osobną jednostkę",
                   "art. 770^1" in labels))

    res = build_scope(units, 770)
    checks.append(("zakres zbudowany dla art. 770", res is not None))

    scope_labels = [u["etykieta"] for u in res["zakres"]] if res else []
    checks.append(("art. 770^1 JEST w zakresie S1 art. 770",
                   "art. 770^1" in scope_labels))
    checks.append(("sąsiedzi 769 i 771 w zakresie",
                   "art. 769" in scope_labels and "art. 771" in scope_labels))
    checks.append(("jednostka nadrzędna rozpoznana jako TYTUŁ XXIV",
                   res is not None and (res["cel"]["jednostka_nadrzedna"] or "")
                   .startswith("TYTUŁ XXIV")))

    edges = build_edges(units, 770)
    checks.append(("S2 zwraca krawedzie jednostki",
                   edges is not None and edges["pierwszy"]["etykieta"] == "art. 765"
                   and edges["ostatni"]["etykieta"] == "art. 771"))

    refs = parse_references(FIXTURE_REFS)
    checks.append(("S3 splaszcza rejestr odeslan", len(refs) == 3))
    checks.append(("S3 widzi ustawe konsumencka z 2002 r.",
                   any(r["id"] == "DU/2002/1176" for r in refs)))

    ok = 0
    for name, passed in checks:
        print("{} {}".format("PASS" if passed else "FAIL", name))
        ok += bool(passed)
    print("---\n{}/{} PASS".format(ok, len(checks)))
    if ok == len(checks):
        print("\nPodgląd wyniku na fixture:")
        render(res, "DU/1964/93 (fixture)", "2011-02-20", "wbudowany FIXTURE")
    return 0 if ok == len(checks) else 1


# --------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        description="T20 — zakres US-2 (bramka sąsiedztwa redakcyjnego)")
    ap.add_argument("--act", help="identyfikator ELI, np. DU/1964/93")
    ap.add_argument("--fixture", help="lokalny plik HTML zamiast API")
    ap.add_argument("--article", type=int, help="numer artykułu")
    ap.add_argument("--index", default="", help="indeks górny celu, np. 1")
    ap.add_argument("--date", help="data zdarzenia (YYYY-MM-DD), opisowa")
    ap.add_argument("--edges", action="store_true",
                    help="dodaj zamiatanie S2 (krawedzie jednostki)")
    ap.add_argument("--references", action="store_true",
                    help="zamiatanie S3 (rejestr odeslan ELI); wymaga --act")
    ap.add_argument("--refs-fixture", help="lokalny JSON zamiast API (S3)")
    ap.add_argument("--json", action="store_true", help="wynik jako JSON")
    ap.add_argument("--selftest", action="store_true",
                    help="test parsera na wbudowanym fixture")
    args = ap.parse_args()

    if args.selftest:
        sys.exit(selftest())

    if args.references:
        if args.refs_fixture:
            with open(args.refs_fixture, encoding="utf-8") as fh:
                data, src = json.load(fh), args.refs_fixture
        elif args.act:
            data, src = fetch_eli_references(args.act)
        else:
            print("--references wymaga --act albo --refs-fixture",
                  file=sys.stderr)
            sys.exit(4)
        render_references(parse_references(data), args.act or src, src)
        if args.article is None:
            sys.exit(0)

    if args.article is None or not (args.act or args.fixture):
        ap.print_usage()
        print("Wymagane: --article oraz --act albo --fixture", file=sys.stderr)
        sys.exit(4)

    if args.fixture:
        with open(args.fixture, encoding="utf-8", errors="replace") as fh:
            html = fh.read()
        source, act_label = args.fixture, args.act or args.fixture
    else:
        html, source = fetch_eli_text(args.act)
        act_label = args.act

    units = parse_units(strip_tags(html))
    result = build_scope(units, args.article, args.index)
    if result is None:
        print("Nie znaleziono art. {} w tekście. Sprawdź, czy podany akt to "
              "wersja obowiązująca na datę zdarzenia.".format(args.article),
              file=sys.stderr)
        sys.exit(3)

    edges = build_edges(units, args.article) if args.edges else None

    if args.json:
        payload = dict(result)
        if edges:
            payload["krawedzie"] = edges
        print(json.dumps(payload, ensure_ascii=False, indent=2, default=str))
    else:
        render(result, act_label, args.date, source)
        if edges:
            render_edges(edges)
    sys.exit(0)


if __name__ == "__main__":
    main()
