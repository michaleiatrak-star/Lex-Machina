# WIDGET-MENU — Interaktywne menu wyboru elementów audytu

> **14 pozycji**. Pozycja 11 tworzy zadanie cykliczne, pozycja 13 sprawdza zgodność
> preferencji z kontraktem routera, pozycja 14 instaluje serwery MCP w **Claude Desktop**
> (FAZA 0E, od 6.144); wszystkie trzy są akcjami, nie fazami audytu, i nie wchodzą do presetu
> „Pełny audyt”.

## Cel
Widget React renderowany przez `show_widget` — pozwala użytkownikowi wybrać jeden lub więcej elementów audytu przed jego uruchomieniem. Eliminuje potrzebę przepisywania poleceń tekstowych.

---

## Kiedy renderować

Renderuj widget gdy:
- Użytkownik wywołuje audyt bez precyzowania zakresu: *"przeprowadź audyt"*, *"audytuj system"*
- Użytkownik pyta *"co możesz sprawdzić"* / *"jakie masz opcje audytu"*
- Użytkownik chce audyt częściowy ale nie wie jak go nazwać

**Nie renderuj** gdy użytkownik podał już konkretny tryb: *"audytuj analizator-umow"*, *"sprawdź description"*.

---

## Kod widgetu

```jsx
import { useState } from "react";

const AUDIT_ITEMS = [
  {
    id: "inventory",
    group: "Podstawowe",
    label: "📋 Inwentaryzacja systemu",
    desc: "Lista wszystkich skilli, rozmiary, status vs snapshot",
    phase: "FAZA 1"
  },
  {
    id: "paths",
    group: "Zależności",
    label: "🔗 Spójność ścieżek",
    desc: "Weryfikacja czy view/load wskazują na istniejące pliki",
    phase: "FAZA 2A"
  },
  {
    id: "versions",
    group: "Zależności",
    label: "🔄 Wersje cross-referencji",
    desc: "Sprawdzenie czy skille nie odwołują się do starych wersji",
    phase: "FAZA 2B"
  },
  {
    id: "description",
    group: "Jakość",
    label: "📏 Description (limit 200)",
    desc: "Walidacja obecności i długości pola description",
    phase: "FAZA 2C / MOD-DESCRIPTION"
  },
  {
    id: "interlinie",
    group: "Czystość kodu",
    label: "↕️ Zbędne interlinie",
    desc: "Wykrycie i usunięcie wielokrotnych pustych linii",
    phase: "MOD-INTERLINIE"
  },
  {
    id: "wstawki",
    group: "Czystość kodu",
    label: "🗑️ Wstawki opisowe",
    desc: "Usunięcie tautologicznych wstawek narracyjnych bez wartości operacyjnej",
    phase: "MOD-WSTAWKI"
  },
  {
    id: "dzu",
    group: "Prawo",
    label: "📖 Mapa Dz.U.",
    desc: "Weryfikacja nowych t.j. i aktualizacja statusów aktów prawnych",
    phase: "FAZA 3"
  },
  {
    id: "antihalucynacje",
    group: "Prawo",
    label: "🛡️ Testy antyhalucynacyjne",
    desc: "Brak hardkodowanych Dz.U. bez źródła + PRAWO-HARDGATE",
    phase: "FAZA 4"
  },
  {
    id: "scoring",
    group: "Raport",
    label: "🏆 Scoring skilli",
    desc: "Ocena 0–10 dla każdego skilla wg kryteriów jakości",
    phase: "FAZA 5"
  },
  {
    id: "raport",
    group: "Raport",
    label: "📄 Raport audytu",
    desc: "Generowanie raportu wg szablonu AUDIT-JOURNAL",
    phase: "FAZA 6"
  },
  {
    id: "harmonogram",
    group: "Automatyzacja",
    label: "⏰ Zadanie cykliczne — cotygodniowa weryfikacja ISAP",
    desc: "Utwórz w Cowork scheduled task: TRYB DZU co tydzień + raport + gotowy .skill (blok map pokrycia — po zamknięciu F-83)",
    phase: "SCHEDULED-TASK-COWORK.md"
  },
  {
    id: "references",
    group: "Raport",
    label: "💾 Aktualizacja references",
    desc: "Zapis do AUDIT-JOURNAL.md, mapa Dz.U. i WARN-OTWARTE.md",
    phase: "FAZA 7"
  },
  {
    id: "pamiec-trwala",
    group: "Automatyzacja",
    label: "🧠 Kontrakt routera w preferencjach",
    desc: "Porównaj preferencje z UP routera i zaproponuj tekst do Ustawień (bez zapisu do pamięci)",
    phase: "PAMIEC-TRWALA-ROUTER.md"
  },
  {
    id: "mcp-instalacja",
    group: "Konektory MCP",
    label: "🔌 Instalacja serwerów MCP",
    badge: "Claude Desktop",
    desc: "Lista wyboru 11 serwerów (akty i orzecznictwo, rejestry, podatki/dane) → instalacja wybranych: na komputerze z Claude Desktop dopisanie do konfiguracji, w piaskownicy rozszerzenie .mcpb. CEIDG: link do klucza (dane.biznes.gov.pl/pl/portal/034872), sam klucz można wkleić w kolejnej wiadomości",
    phase: "FAZA 0E"
  }
];

const GROUPS = [...new Set(AUDIT_ITEMS.map(i => i.group))];

const PRESETS = [
  { label: "Pełny audyt", ids: AUDIT_ITEMS.filter(i => !["harmonogram", "pamiec-trwala", "mcp-instalacja"].includes(i.id)).map(i => i.id) },
  { label: "Tylko czystość", ids: ["interlinie", "wstawki", "description"] },
  { label: "Tylko zależności", ids: ["inventory", "paths", "versions"] },
  { label: "Tylko prawo", ids: ["dzu", "antihalucynacje"] },
  { label: "Raport i zapis", ids: ["scoring", "raport", "references"] },
  { label: "Automatyzacja", ids: ["harmonogram", "pamiec-trwala"] }
];

export default function AuditMenu() {
  const [selected, setSelected] = useState(new Set());
  const [sent, setSent] = useState(false);

  const toggle = (id) => {
    setSelected(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const applyPreset = (ids) => setSelected(new Set(ids));

  const handleStart = () => {
    if (selected.size === 0) return;
    const labels = AUDIT_ITEMS
      .filter(i => selected.has(i.id))
      .map(i => i.label.replace(/^[^\s]+ /, ""));
    const msg = `Uruchom audyt dla następujących elementów:\n${labels.map((l, i) => `${i+1}. ${l}`).join("\n")}`;
    if (window.sendPrompt) {
      window.sendPrompt(msg);
      setSent(true);
    }
  };

  if (sent) return (
    <div style={{padding:"2rem",textAlign:"center",fontFamily:"system-ui"}}>
      <div style={{fontSize:"2rem",marginBottom:"0.5rem"}}>✅</div>
      <p style={{color:"#374151",fontWeight:600}}>Audyt uruchomiony dla {selected.size} elementów</p>
    </div>
  );

  return (
    <div style={{fontFamily:"system-ui,sans-serif",maxWidth:680,margin:"0 auto",padding:"1.25rem"}}>
      <h2 style={{margin:"0 0 0.25rem",fontSize:"1.1rem",color:"#111827",fontWeight:700}}>
        🔍 Wybierz elementy audytu
      </h2>
      <p style={{margin:"0 0 1rem",fontSize:"0.8rem",color:"#6B7280"}}>
        Możesz wybrać dowolną kombinację lub skorzystać z presetu.
      </p>

      {/* Presety */}
      <div style={{display:"flex",flexWrap:"wrap",gap:"0.4rem",marginBottom:"1.25rem"}}>
        {PRESETS.map(p => (
          <button key={p.label} onClick={() => applyPreset(p.ids)}
            style={{padding:"0.3rem 0.75rem",fontSize:"0.75rem",borderRadius:999,
              border:"1.5px solid #D1D5DB",background:"#F9FAFB",cursor:"pointer",
              color:"#374151",fontWeight:500,transition:"all 0.15s"}}
            onMouseOver={e=>e.target.style.borderColor="#6366F1"}
            onMouseOut={e=>e.target.style.borderColor="#D1D5DB"}>
            {p.label}
          </button>
        ))}
        <button onClick={() => setSelected(new Set())}
          style={{padding:"0.3rem 0.75rem",fontSize:"0.75rem",borderRadius:999,
            border:"1.5px solid #FCA5A5",background:"#FEF2F2",cursor:"pointer",
            color:"#DC2626",fontWeight:500}}>
          Wyczyść
        </button>
      </div>

      {/* Grupy */}
      {GROUPS.map(group => (
        <div key={group} style={{marginBottom:"1rem"}}>
          <div style={{fontSize:"0.7rem",fontWeight:700,color:"#9CA3AF",
            textTransform:"uppercase",letterSpacing:"0.05em",marginBottom:"0.4rem"}}>
            {group}
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:"0.35rem"}}>
            {AUDIT_ITEMS.filter(i => i.group === group).map(item => {
              const active = selected.has(item.id);
              return (
                <div key={item.id} onClick={() => toggle(item.id)}
                  style={{display:"flex",alignItems:"flex-start",gap:"0.75rem",
                    padding:"0.6rem 0.85rem",borderRadius:8,cursor:"pointer",
                    border:`1.5px solid ${active ? "#6366F1" : "#E5E7EB"}`,
                    background: active ? "#EEF2FF" : "#FAFAFA",
                    transition:"all 0.15s"}}>
                  <div style={{width:18,height:18,borderRadius:4,flexShrink:0,
                    border:`2px solid ${active ? "#6366F1" : "#D1D5DB"}`,
                    background: active ? "#6366F1" : "white",
                    display:"flex",alignItems:"center",justifyContent:"center",
                    marginTop:1}}>
                    {active && <span style={{color:"white",fontSize:12,lineHeight:1}}>✓</span>}
                  </div>
                  <div style={{flex:1}}>
                    <div style={{fontSize:"0.85rem",fontWeight:600,
                      color: active ? "#4338CA" : "#1F2937"}}>
                      {item.label}
                      {item.badge && <span style={{marginLeft:"0.5rem",padding:"0.1rem 0.45rem",
                        borderRadius:999,fontSize:"0.68rem",fontWeight:700,verticalAlign:"middle",
                        background:"#FEF3C7",color:"#92400E",border:"1px solid #FCD34D"}}>
                        🖥️ działa w {item.badge}</span>}
                    </div>
                    <div style={{fontSize:"0.75rem",color:"#6B7280",marginTop:2}}>
                      {item.desc}
                      <span style={{marginLeft:"0.4rem",fontSize:"0.7rem",
                        color:"#9CA3AF",fontStyle:"italic"}}>[{item.phase}]</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ))}

      {/* Footer */}
      <div style={{marginTop:"1.25rem",display:"flex",alignItems:"center",
        justifyContent:"space-between",paddingTop:"1rem",
        borderTop:"1px solid #E5E7EB"}}>
        <span style={{fontSize:"0.8rem",color:"#6B7280"}}>
          {selected.size === 0 ? "Nic nie wybrano" :
           `Wybrano: ${selected.size} element${selected.size>1?"y/ów":""}`}
        </span>
        <button onClick={handleStart} disabled={selected.size===0}
          style={{padding:"0.5rem 1.25rem",borderRadius:8,fontWeight:600,
            fontSize:"0.85rem",cursor:selected.size===0?"not-allowed":"pointer",
            border:"none",background:selected.size===0?"#E5E7EB":"#6366F1",
            color:selected.size===0?"#9CA3AF":"white",transition:"all 0.2s"}}>
          ▶ Uruchom audyt
        </button>
      </div>
    </div>
  );
}
```

---

## Pozycja 11 — obsługa wyboru (⚠️ INNA niż pozostałe pozycje)

Pozycje 1-10 i 12 uruchamiają fazę audytu. Pozycja **11 (`harmonogram`) nie
audytuje niczego** — tworzy zadanie cykliczne w Cowork. To jedyna droga
uruchomienia (obok wyraźnej prośby użytkownika); ⛔ zadania nie proponuje się
automatycznie. Po jej wybraniu:

1. Wczytaj `references/SCHEDULED-TASK-COWORK.md`.
2. Sprawdź WARUNEK URUCHOMIENIA (§ 1 tego pliku): praca w Cowork **oraz**
   brak wcześniej utworzonego zadania. ⛔ Jeśli nie masz pewności co do
   drugiego warunku — **zapytaj jednym zdaniem**, nie zakładaj.
3. Potwierdź jednym zdaniem nazwę i częstotliwość, dopiero wtedy utwórz zadanie,
   wklejając **dosłownie** treść z § 2A (Description) i § 2B (prompt).
   ⛔ Nie parafrazuj — treść jest kanoniczna.
4. Blok map pokrycia (§ 3) dopisuj do promptu **wyłącznie** po zamknięciu
   flagi **F-83** w `WARN-OTWARTE.md`. Dopóki F-83 otwarta — pomiń i odnotuj.
5. Odnotuj w `AUDIT-JOURNAL.md`: utworzono / odmówiono / już istniało.

Pozycja 11 może być wybrana **razem** z pozycjami audytowymi — wtedy wykonaj
najpierw audyt, a utworzenie zadania na końcu, żeby zadanie opierało się na
świeżym wyniku.

---

## Pozycja 13 — obsługa wyboru

Pozycja **13 (`pamiec-trwala`) nie audytuje niczego i niczego nie zapisuje**:

1. Wczytaj `references/PAMIEC-TRWALA-ROUTER.md`.
2. Porównaj preferencje użytkownika z UP-1…UP-6 routera (treść, nie wersja).
3. Pokaż rozbieżności i proponowany tekst do wklejenia w Ustawienia → Profil.
4. Odnotuj wynik w `AUDIT-JOURNAL.md`, jeżeli host pozwala na zapis.

⛔ Zakaz zapisu bloków dyrektyw do pamięci trwałej hosta (odrzuca je
klasyfikator; ponowienie = obchodzenie zabezpieczenia).

---

## Integracja z SKILL.md

W sekcji `## TRYBY WYWOŁANIA` dodaj:

```
### TRYB INTERAKTYWNY (menu wyboru)
Wywołanie: "przeprowadź audyt" / "audytuj system" (bez precyzowania zakresu)
→ Załaduj WIDGET-MENU.md → renderuj widget → czekaj na wybór użytkownika
→ Po otrzymaniu wyboru: uruchom tylko wskazane fazy/moduły
```

Wywołanie widgetu w kodzie:
```
view audyt-systemu-v4/widgets/WIDGET-MENU.md
→ skopiuj kod JSX → show_widget(...)
```
