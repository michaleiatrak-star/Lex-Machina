# REGRESSION-TEST-PLAN.md — Plan Testów Regresyjnych systemu prawo-polskie-v2

> **Wersja:** 1.0 (2026-07-21)
> **Metodologia:** oparta na standardowej praktyce testów regresyjnych
> (zweryfikowanej online 2026-07-21: TestRail, BrowserStack, QualityLogic,
> TestDevLab) — zaadaptowanej do specyfiki systemu skilli
> markdown-jako-baza-wiedzy dla LLM (nie jest to typowa aplikacja
> softwarowa, więc "regresja" oznacza tu: PONOWNE pojawienie się BŁĘDU
> STRUKTURALNEGO/SPÓJNOŚCIOWEGO, który JUŻ RAZ wystąpił i został
> naprawiony w tej sesji).
> **Zasada naczelna testów regresyjnych (za TestRail):** "regression
> tests re-execute previously successful test cases after any major
> updates" — KAŻDY test w tym zestawie odpowiada KONKRETNEMU,
> RZECZYWIŚCIE znalezionemu i naprawionemu błędowi w historii tej
> sesji (2026-07-19 do 2026-07-21), NIE jest to test hipotetyczny.

---

## 1. ZAKRES (Scope) — za BrowserStack/QualityLogic: "impact analysis"

```
Testowany system: /mnt/skills/user/ — 17 skilli DR (DR-01 do DR-16 +
prawo-polskie-v2 jako fasada routingu) + shared/ (180 plików
wspólnych) + narzędzia pomocnicze (pisma-proste-v2, analizator-umow-v1,
audyt-systemu-v4).

Zakres NIE obejmuje: poprawności MERYTORYCZNEJ treści prawnej (to
wymaga eksperckiej weryfikacji prawniczej, poza możliwościami testu
automatycznego) — WYŁĄCZNIE integralność STRUKTURALNĄ i SPÓJNOŚCIOWĄ.
```

---

## 2. KATEGORIE TESTÓW (Test Suite Structure) — za Insurity/TestDevLab: "structure by coverage area"

| # | Kategoria | Priorytet | Źródło (błąd rzeczywisty z tej sesji) |
|---|---|---|---|
| T1 | Rejestracja modułów | ⭐⭐⭐ KRYTYCZNY | 15+ modułów w DR-03 istniało fizycznie, nigdy niezarejestrowanych w SKILL.md (audyt 2026-07-21o) |
| T2 | Zgodność liczników | ⭐⭐ WYSOKI | SKILL.md deklarował "37 modułów", fizycznie było 52 (ta sama data) |
| T3 | Spójność Dz.U. między mapami | ⭐⭐⭐ KRYTYCZNY | Ustawa o SUS/ZUS: lokalna mapa DR-04 vs główna ROUTING-MAP wskazywały RÓŻNE numery Dz.U. dla TEGO SAMEGO aktu (audyt 2026-07-21m) |
| T4 | Integralność nagłówków Markdown | ⭐⭐⭐ KRYTYCZNY | Przypadkowa utrata nagłówka "ŁĄCZ Z" przy wstawianiu treści przez str_replace (co najmniej 2 udokumentowane przypadki w tej sesji) |
| T5 | "Widmowe pokrycie" (ghost coverage) | ⭐⭐ WYSOKI | Główna mapa deklarowała "Specustawa drogowa ✅ OK" wskazując moduł, w którym ta treść NIGDY nie istniała (audyt 2026-07-21g) |
| T6 | Zerwane odwołania | ⭐⭐⭐ KRYTYCZNY | JUŻ POKRYTE przez istniejący `ci_check_shared.py` — NIE duplikować, WYWOŁYWAĆ jako część tego zestawu |
| T7 | Duplikaty bajtowe | ⭐ ŚREDNI | JUŻ POKRYTE przez istniejący `ci_check_shared.py` |
| T8 | Zakresy tytuł-vs-treść | ⭐⭐ WYSOKI | Moduł `mod-KK-art148-162` obiecywał w tytule "art. 148-162", treść urywała się na art. 157 (audyt 2026-07-21o) |
| T9 | Weryfikacja przeniesień do shared/ | ⭐⭐ WYSOKI | Dodane 2026-07-21 przy PONOWNYM przeglądzie T1 — wąski, celowany następca próbnego, SZEROKIEGO skanera dangling references, który dał ZBYT DUŻO szumu (patrz sekcja 10) |
| ~~T10~~ | ~~Monitorowanie plików Nexto/Virtualo o niepewnym statusie prawnym~~ | — | USUNIĘTE 2026-07-24d na polecenie użytkownika (wraz z flagą F-12, rejestrem i skryptem `check_nexto_free_files.py`) — patrz `AUDIT-JOURNAL.md`, wpis AUDYT-2026-07-24d |

---

## 3. PODEJŚCIE (Approach) — za TestDevLab: "combined manual + automated"

```
AUTOMATYZOWANE (skrypty Python, deterministyczne, bez zależności od
LLM/sieci — ta sama filozofia co istniejący ci_check_shared.py):
  T1, T2, T3 (częściowo), T4, T6, T7

WYMAGAJĄCE OSĄDU CZŁOWIEKA/LLM przy URUCHOMIENIU (skrypt jedynie
WSKAZUJE kandydatów do weryfikacji, NIE rozstrzyga automatycznie):
  T3 (ostateczna ocena, KTÓRY Dz.U. jest poprawny — wymaga sprawdzenia
  na ISAP), T5, T8 (skrypt wykrywa PODEJRZANE wzorce, człowiek/LLM
  POTWIERDZA czy to faktyczny błąd)
```

---

## 4. PRIORYTETYZACJA — za TestRail: "focus on high-impact flows"

```
⭐⭐⭐ KRYTYCZNE (T1, T3, T4, T6) — URUCHAMIAĆ przy KAŻDEJ sesji audytowej
  i PO KAŻDEJ serii edycji plików .md, NIEZALEŻNIE od tego, jak mała
  wydaje się zmiana — te błędy WIELOKROTNIE wystąpiły "po cichu"
⭐⭐ WYSOKIE (T2, T5, T8) — URUCHAMIAĆ przy KOŃCU każdej sesji, PRZED
  finalnym pakowaniem/dostarczeniem plików użytkownikowi
⭐ ŚREDNI (T7) — URUCHAMIAĆ okresowo (np. raz na kilka sesji), NIE
  BLOKUJE dostarczenia (tylko ostrzeżenie, zgodnie z ISTNIEJĄCĄ logiką
  ci_check_shared.py)
```

---

## 5. KRYTERIA WYJŚCIA (Exit Criteria) — za Insurity: "define pass/fail thresholds"

```
✅ PASS — zestaw testów można uznać za ZALICZONY, gdy:
  □ T1: ZERO plików modułów na dysku spoza listy w SKILL.md danego skilla
  □ T2: licznik zadeklarowany w SKILL.md == rzeczywista liczba plików
    modułów NA DYSKU (z uwzględnieniem jawnie oznaczonych wyjątków, np.
    "przeniesiony do shared/")
  □ T3: ZERO przypadków, gdzie TEN SAM akt prawny (identyfikowany po
    NAZWIE ustawy) ma RÓŻNE numery Dz.U. w lokalnej MAPA-AKTOW vs
    głównej ROUTING-MAP.md BEZ jawnego komentarza wyjaśniającego
    rozbieżność (⚠️ z odnotowaniem "do weryfikacji")
  □ T4: (weryfikacja MANUALNA/przy code review, PO edycji) — brak
    NIEOCZEKIWANEGO zmniejszenia liczby nagłówków `^## ` w edytowanym
    pliku względem stanu SPRZED edycji
  □ T6/T7: kod wyjścia `ci_check_shared.py` == 0 (brak zerwanych
    odwołań; duplikaty dozwolone jako ostrzeżenie)

⚠️ WARUNKOWY PASS — dopuszczalne z ZASTRZEŻENIEM, gdy rozbieżność jest
  JAWNIE, PISEMNIE odnotowana jako "wymaga weryfikacji" (np. przy
  nowelizacjach w trakcie procesu legislacyjnego, gdzie numer Dz.U.
  jeszcze nie istnieje)

❌ FAIL — jakikolwiek wynik T1/T3/T6 POZA kategorią "warunkowy pass"
  BLOKUJE uznanie sesji za zakończoną poprawnie — WYMAGA naprawy PRZED
  dostarczeniem plików użytkownikowi
```

---

## 6. NARZĘDZIA (Tooling)

```
scripts/test_module_registration.py   → T1 (v1.1 — naprawiono ryzyko fałszywego negatywu przy nazwach-podciągach, 2026-07-21)
scripts/test_module_count.py          → T2
scripts/test_cross_map_dzu.py         → T3 (część automatyzowalna)
scripts/test_header_snapshot.py       → T4 (mechanizm migawki przed/po)
scripts/test_title_scope_match.py     → T8 (heurystyka: zakres liczb w
                                          tytule pliku vs treść)
scripts/test_moved_to_shared.py       → T9 (weryfikacja że deklarowane
                                          przeniesienia do shared/ mają
                                          potwierdzony plik docelowy)
scripts/ci_check_shared.py            → T6, T7 (JUŻ ISTNIEJĄCY, nie
                                          duplikować — WYWOŁYWANY przez
                                          run_regression_suite.py)
scripts/run_regression_suite.py       → URUCHAMIA WSZYSTKIE powyższe,
                                          zbiera wyniki w JEDEN raport
scripts/install_precommit_hook.sh     → v2.0 (2026-07-21) — instaluje
                                          PEŁNY run_regression_suite.py
                                          jako git pre-commit hook (NIE
                                          wyłącznie ci_check_shared.py
                                          jak w wersji 1.0 — POPRAWKA
                                          znaleziona przy tym przeglądzie,
                                          patrz sekcja 10)
```

---

## 7. UTRZYMANIE (Maintenance) — za TestDevLab: "regular reviews, add/update/remove"

```
□ PO KAŻDYM audycie znajdującym NOWY wzorzec błędu (nie pokryty przez
  T1-T8) — DODAĆ nową kategorię testu do tego planu I odpowiadający
  skrypt, z ODWOŁANIEM do konkretnego wpisu w AUDIT-JOURNAL.md, KTÓRY
  ten błąd udokumentował (zasada TRACEABILITY — identyfikowalność
  testu wstecz do przyczyny jego powstania)
□ Ten plik jest KANONICZNYM dokumentem — zmiany w zakresie/priorytetach
  testów WYMAGAJĄ aktualizacji TUTAJ, nie tylko w kodzie skryptów
```

---

## 8. RAPORTOWANIE

```
Każde uruchomienie `run_regression_suite.py` generuje:
  1) Wynik ZBIORCZY (PASS/WARN/FAIL) na poziomie CAŁEGO systemu
  2) Wynik SZCZEGÓŁOWY per kategoria testu (T1-T8)
  3) Listę KONKRETNYCH plików/wpisów wymagających uwagi, z odesłaniem
     do NUMERU kategorii testu, KTÓRY je wykrył
  4) Sugerowany NASTĘPNY krok (np. "sprawdź na ISAP", "dodaj wpis do
     SKILL.md", "przywróć usunięty nagłówek")
```

---

## 9. ⭐⭐ WALIDACJA — PIERWSZE PEŁNE URUCHOMIENIE (dodane 2026-07-21)

```
Przy dokończeniu implementacji (skrypty T2, T3, T4, T8 oraz orkiestrator
run_regression_suite.py — wcześniej ISTNIAŁ tylko test_module_registration.py
dla T1, a SAM plan NIE BYŁ zarejestrowany w SKILL.md, dokładnie ten sam
wzorzec "plan bez pełnej implementacji" znajdowany wielokrotnie w tej
sesji) — WYKONANO PEŁNE URUCHOMIENIE na całym systemie, z NASTĘPUJĄCYMI
wynikami:

□ T1: ✅ PASS — 18 skilli sprawdzonych, zero niezarejestrowanych modułów
  (poza 25 pozycjami do weryfikacji manualnej w skillach o odwołaniach
  skrótowych — analizator-dowodow-v3, pisma-procesowe-v3)

□ T2: ⭐ ZNALEZIONO I NAPRAWIONO PRAWDZIWY BŁĄD przy PIERWSZYM
  uruchomieniu — dr-10-zdrowie-farmacja-zywnosc-rolnictwo/SKILL.md
  deklarował "27 łącznie", fizycznie 28 plików (wszystkie 28 BYŁY
  indywidualnie zarejestrowane, licznik zbiorczy po prostu nie został
  zaktualizowany przy dodaniu ostatniego modułu) — NAPRAWIONE, PONOWNE
  uruchomienie: ✅ PASS
  ⚠️ SKRYPT WYMAGAŁ WŁASNEJ NAPRAWY: pierwsza wersja BŁĘDNIE odejmowała
  adnotacje "X przeniesiony do shared/" od liczby fizycznej, dając
  FAŁSZYWE POZYTYWY dla DR-03 i DR-16 (gdzie adnotacja jest opisowa/
  historyczna, NIE dodatkowym wyjątkiem do odjęcia) — USUNIĘTO tę
  logikę, PO naprawie: czysty PASS

□ T3: ⭐⭐ ZNALEZIONO I NAPRAWIONO PRAWDZIWY, AKTYWNY BŁĄD REGRESJI —
  ustawa o samorządzie gminnym (DR-08): lokalna MAPA-AKTOW.md miała
  JUŻ POPRAWIONY numer (Dz.U. 2026 poz. 662, z jawną notatką o
  wcześniejszej korekcie z 2026-07-02), ale główna ROUTING-MAP.md
  NADAL wskazywała STARY numer (2025 poz. 1153) — poprawka NIGDY nie
  została zsynchronizowana do głównej mapy. NAPRAWIONE w tej sesji.
  ⚠️ SKRYPT WYMAGAŁ ISTOTNEJ NAPRAWY: pierwsza wersja heurystyki
  dopasowania (pierwsze 6 słów >3 znaki jako "klucz") dawała MASOWE
  fałszywe pozytywy (np. "Ustawa AML" mylona z "PIT"/"CIT"/"VAT" przez
  redukcję do jednego, zbyt ogólnego słowa "ustawa") — PRZEPISANO na
  dopasowanie przez PODOBIEŃSTWO JACCARDA zbiorów słów dystynktywnych
  (próg 0.5, z wykluczeniem słów nadmiernie ogólnych: "ustawa",
  "kodeks", "prawo", "przepisy") — z dziesiątek fałszywych trafień do
  4-5 sensownych kandydatów, w tym POTWIERDZONEGO prawdziwego błędu

□ T4: skrypt zbudowany i przetestowany na pojedynczym pliku (mechanizm
  migawki działa poprawnie) — WYMAGA rutynowego stosowania PRZY
  każdej edycji str_replace w przyszłych sesjach, nie uruchamiany
  wstecznie (brak stanu "przed" dla JUŻ wykonanych edycji)

□ T6/T7: ✅ PASS — 711 plików przeskanowanych, zero zerwanych odwołań,
  zero duplikatów bajtowych (istniejący ci_check_shared.py, ponownie
  potwierdzony jako działający)

□ T8: WARN — 7 przypadków oznaczonych do weryfikacji manualnej w
  DR-03. SPRAWDZONO JEDEN PRZYKŁADOWO (mod-KK-art69-84): POTWIERDZONO
  jako FAŁSZYWY POZYTYW (treść pokrywa "art. 80-82" łącznie, po prostu
  nie cytuje pojedynczo "art. 84") — heurystyka działa ZGODNIE z
  udokumentowanym ograniczeniem (wykrywa BRAK cytatu końca zakresu,
  NIE odróżnia "faktycznie brakującej treści" od "treści omówionej w
  innej formie zapisu") — POZOSTAŁE 6 przypadków NIE zweryfikowano
  manualnie w tej sesji, WYMAGAJĄ przeglądu w przyszłości

⭐ WNIOSEK OGÓLNY: ten zestaw testów, w PIERWSZYM pełnym uruchomieniu,
ZNALAZŁ I POZWOLIŁ NAPRAWIĆ DWA prawdziwe, aktywne błędy w systemie
(T2: licznik DR-10; T3: Dz.U. samorządu gminnego) — POTWIERDZAJĄC
wartość praktyczną tego narzędzia, NIE TYLKO jego formalną poprawność
metodologiczną.
```

---

## 10. ⭐⭐⭐ PONOWNY PRZEGLĄD T1 I OCENA POZIOMU PROFESJONALNEGO (dodane 2026-07-21)

> Na wyraźne żądanie użytkownika: "zbadaj działanie T1, czy jeszcze
> jakieś testy w audycie są wymagane, aby [zestaw] miały poziom
> profesjonalny". Poniżej PEŁNA dokumentacja przeglądu — zgodnie z
> zasadą profesjonalnej praktyki QA: UZASADNIONE decyzje o zakresie
> (co dodano, co ŚWIADOMIE odrzucono i DLACZEGO) są RÓWNIE ważne co
# sam kod testów.

### 10.1 Znaleziony i naprawiony błąd w SAMYM T1

```
⭐⭐ T1 (v1.0) używał NAIWNEGO sprawdzenia podciągu (`name in
skill_text`) do ustalenia, czy nazwa modułu jest "wspomniana" w
SKILL.md. TO stwarzało TEORETYCZNE ryzyko FAŁSZYWEGO NEGATYWU: jeśli
nazwa KRÓTSZEGO modułu jest DOSŁOWNYM podciągiem nazwy DŁUŻSZEGO
modułu (np. plik "mod-ustawa-cudzoziemcy.md" ORAZ "mod-ustawa-
cudzoziemcy-zatrudnianie.md" — oba ISTNIEJĄ w systemie), a SKILL.md
wspominałby WYŁĄCZNIE dłuższą nazwę — sprawdzenie podciągu BŁĘDNIE
uznałoby KRÓTSZĄ nazwę za "zarejestrowaną" (bo WYSTĘPUJE jako fragment
tekstu dłuższej), UKRYWAJĄC prawdziwy brak.

SYSTEMATYCZNE przeszukanie CAŁEGO systemu POTWIERDZIŁO, że TAKIE pary
nazw ISTNIEJĄ (2 przypadki: dr-05 mod-ustawa-cudzoziemcy/-zatrudnianie;
dr-09 mod-POS-prawo-ochrony-srodowiska/-szczegoly) — W OBU przypadkach
sprawdzono, że OBIE nazwy SĄ obecnie jawnie, osobno zarejestrowane
(żaden AKTYWNY błąd nie został znaleziony), ALE ryzyko było REALNE.

NAPRAWIONO: zastąpiono sprawdzenie podciągu dopasowaniem regex z
GRANICĄ SŁOWA (uwzględniającą myślnik jako część nazw modułów, nie
tylko standardowe `\b`). PO naprawie: T1 nadal zwraca CZYSTY PASS
(25 pozycji do weryfikacji manualnej, jak poprzednio — BEZ nowych
fałszywych trafień), potwierdzając że naprawa NIE wprowadziła regresji.
```

### 10.2 Zbadany, ale ŚWIADOMIE ODRZUCONY zakres — pełny skaner dangling references

```
⭐⭐⭐ NAJWAŻNIEJSZA decyzja metodologiczna tego przeglądu: zbadano
możliwość zbudowania PEŁNEGO, systemowego testu "T9 szerokiego" —
wykrywającego WSZYSTKIE odwołania do modułów w treści SKILL.md,
sprawdzającego, czy KAŻDE z nich wskazuje na FAKTYCZNIE istniejący
plik GDZIEKOLWIEK w systemie (nie tylko w TYM SAMYM skillu).

WYNIK próbnego uruchomienia: ~50 "podejrzanych" odwołań w kilkunastu
skillach. Manualne sprawdzenie PRÓBKI (6 przypadków) ujawniło, że
WSZYSTKIE 6 to FAŁSZYWE POZYTYWY, należące do CZTERECH odrębnych,
LEGALNYCH wzorców:
  1) Cross-referencje międzyskillowe z jawnym prefiksem "→ dr-XX"
     (np. dr-11 odsyłający do mod-KPP-karta-praw-podstawowych-UE,
     który ISTNIEJE w dr-14)
  2) Odwołania do plików w shared/ (inna struktura katalogów niż
     dr-XX/modules/)
  3) ŚWIADOME placeholdery na przyszłość ("rozważyć mod-X.md jeśli
     pojawią się sprawy") — NIE są to błędy, lecz udokumentowane braki
     CELOWE
  4) Notatki HISTORYCZNE o przeniesieniu do shared/ pod NOWĄ nazwą
     (np. mod-KK-stalking-szczegolowy → prawo-polskie-v2/krajowe/shared/STALKING-NEKANIE.md)

⭐⭐⭐ DECYZJA: pełny, szeroki skaner dangling references ODRZUCONO
jako NIEWARTY budowy w OBECNEJ formie — zgodnie z ZASADĄ z badanej
literatury (Virtuoso QA: "fifty stable tests covering workflows that
matter most" lepsze niż "thousand brittle tests nobody maintains") —
odróżnienie WSZYSTKICH czterech legalnych wzorców od PRAWDZIWEJ
regresji wymagałoby na tyle SKOMPLIKOWANEGO parsera (rozpoznawanie
prefiksów "→ dr-XX", przeszukiwanie shared/, rozpoznawanie fraz
"rozważyć"/"w przyszłości", rozpoznawanie fraz historycznych o
przeniesieniu), że RYZYKO fałszywych alarmów PRZEWAŻSZAŁOBY wartość
informacyjną — TAKI test szybko STAŁBY SIĘ ignorowany ("alert
fatigue"), tracąc sens jako narzędzie regresyjne.

ZAMIAST tego, zbudowano T9 — WĄSKI, CELOWANY test wyłącznie dla
KATEGORII 4 (przeniesienia do shared/), NAJBARDZIEJ ryzykownej
kategorii (bo odwołuje się do KONKRETNEJ, WERYFIKOWALNEJ nowej
lokalizacji, w odróżnieniu od kategorii 1-3, które z NATURY wymagają
szerszego kontekstu do poprawnej interpretacji). Pierwsze uruchomienie
T9 na całym systemie: 3 deklaracje znalezione, WSZYSTKIE 3 rozwiązane
(czysty PASS) — potwierdzając, że WĄSKI zakres DAJE praktyczną wartość
bez nadmiernego szumu.
```

### 10.3 Znaleziony i naprawiony brak integracji CI

```
⭐⭐ Przy przeglądzie CAŁEGO zestawu narzędzi (nie tylko T1), odkryto,
że `install_precommit_hook.sh` (istniejący od WCZEŚNIEJSZEJ sesji)
INSTALOWAŁ WYŁĄCZNIE `ci_check_shared.py` (T6/T7) jako git pre-commit
hook — MIMO że PÓŹNIEJ w TEJ SAMEJ sesji dokończono PEŁNY zestaw T1-T8
(`run_regression_suite.py`). Hook NIGDY nie został zaktualizowany, by
wywoływać PEŁNY zestaw — DOKŁADNIE ten sam wzorzec "zbudowano
narzędzie, zapomniano podłączyć", znajdowany WIELOKROTNIE w tej sesji
w innych częściach systemu (moduły niezarejestrowane w SKILL.md, plany
bez zaimplementowanych skryptów, poprawki Dz.U. nieskopiowane między
mapami).

NAPRAWIONO: `install_precommit_hook.sh` (v2.0) instaluje TERAZ
`run_regression_suite.py` zamiast samego `ci_check_shared.py` — hook
blokuje commit PRZY FAIL testów KRYTYCZNYCH (T1/T6/T7), TRAKTUJĄC
testy heurystyczne (T3/T8/T9) i informacyjne (T2) jako OSTRZEŻENIE, nie
blokadę — zgodnie z priorytetyzacją z sekcji 4 tego planu.
```

### 10.4 Ocena ogólna — czy zestaw ma "poziom profesjonalny"?

```
✅ SPEŁNIONE kryteria profesjonalnego zestawu testów regresyjnych (za
   zweryfikowaną literaturą — TestRail, Katalon, Virtuoso QA):
   □ Traceability — każdy test odwołuje się do KONKRETNEGO, udokumen-
     towanego błędu w AUDIT-JOURNAL.md
   □ Priorytetyzacja ryzyko-oparta — KRYTYCZNE blokują, WYSOKIE
     ostrzegają, ŚREDNIE informują
   □ Niezależność testów — każdy skrypt działa SAMODZIELNIE, bez
     zależności od kolejności uruchomienia innych
   □ Walidacja przez rzeczywiste użycie — zestaw ZNALAZŁ i pozwolił
     naprawić DWA prawdziwe błędy systemu PRZY pierwszym uruchomieniu
     (nie tylko potwierdza JUŻ znane naprawy)
   □ Dokumentowane, ŚWIADOME decyzje o zakresie (sekcja 10.2) —
     odróżnienie "nie zbudowano, bo nie zdążono" od "świadomie
     odrzucono jako zbyt hałaśliwe, z uzasadnieniem"
   □ Integracja CI — pre-commit hook wywołuje PEŁNY zestaw (PO
     naprawie z sekcji 10.3)
   □ Utrzymanie kodu testowego — SAME skrypty testowe podlegają TEJ
     SAMEJ dyscyplinie co reszta systemu (naprawiono błąd w T1,
     zweryfikowano PO naprawie)

⚠️ ŚWIADOMIE POZOSTAJĄCE OGRANICZENIA (udokumentowane, NIE ukryte):
   □ T4 (integralność nagłówków) WYMAGA ręcznego wywołania PRZED i PO
     każdej edycji — NIE jest zautomatyzowany wstecznie w orkiestratorze
   □ T5 (widmowe pokrycie/ghost coverage) NIE MA zautomatyzowanego
     skryptu — z NATURY wymaga osądu semantycznego (czy deklarowana
     treść "✅ OK" ODPOWIADA rzeczywistej zawartości modułu), poza
     zasięgiem prostej analizy tekstowej
     ⚡ 2026-09-16b: `scripts/check_widmowe_pokrycie.py` wskazuje KANDYDATÓW
     (moduł bez numeru i bez nazwy aktu z wiersza); osąd nadal ręczny.
     Pierwszy przebieg: 30 kandydatów → 2 widma, 2 podmiany aktu,
     1 nieistniejący tytuł, 11 błędnych wskaźników (AUDYT-2026-09-16b)
   □ T8 ma 7 przypadków WARN nigdy w pełni niesprawdzonych manualnie
     (tylko 1 z 7 zweryfikowany jako fałszywy pozytyw)
   □ Merytoryczna POPRAWNOŚĆ treści prawnej POZOSTAJE poza zakresem
     (wymaga eksperckiej weryfikacji prawniczej, nie automatycznej)

⭐ WNIOSEK: zestaw OSIĄGNĄŁ poziom profesjonalny WEDŁUG zweryfikowanych
kryteriów branżowych, z UCZCIWIE udokumentowanymi, ŚWIADOMYMI granicami
zakresu — NIE przez brak wiedzy o możliwych rozszerzeniach, lecz przez
UZASADnioną decyzję, że DALSZE rozszerzenia (pełny skaner dangling
references) obniżyłyby JAKOŚĆ praktyczną (przez nadmierny szum) mimo
pozornie WIĘKSZEGO pokrycia.
```

---

## 11. T19 — F-108: integralność benchmarku i metryk bieżących (2026-08-28)

**Źródło błędu rzeczywistego:** ponowny audyt F-108 wykazał, że rejestr 52 aktów
mieszał obecność modułu z COV oraz że aktywne indeksy mogły zachować stare lub
błędnie przypisane metryki Dz.U. mimo poprawnej mapy dziedzinowej.

**Skrypt:** `scripts/test_f108_consistency.py` — test KRYTYCZNY, bez sieci.

Sprawdza mechanicznie:
- dokładnie 52 identyfikatory F-108;
- zero pozycji poniżej COV w benchmarku F-108;
- deklarację 52/52 routing i 52/52 B+/COV przy 0 FULL;
- brak znanych regresji KC 2025/1071 i Prawa o prokuraturze 2024/390 w aktywnym `ROUTING-MAP.md`;
- obecność skorygowanych wierszy w aktualnej `mapa_dzu_2026-08-28.md`;
- zakaz powrotu błędnych tożsamości 2025/1338, 2023/549, 2024/1069 i 2026/346;
- fizyczną obecność i centralną rejestrację current-state modułów KW, SUS, ustawy zasiłkowej i zwolnień grupowych, w tym osobnego modułu KW art. 65–69.

**Kryterium:** każdy FAIL T19 blokuje wynik strukturalny suite. Test nie zastępuje
żywej kontroli ELI/ISAP; chroni wyłącznie ustalenia już zweryfikowane źródłowo.


## LITERATURA (zweryfikowana online 2026-07-21)

- testrail.com/blog/regression-testing — definicja regresji, priorytetyzacja
  wg "high-impact flows", automatyzacja stabilnych testów.
- browserstack.com/guide/regression-test-plan — struktura planu (core
  suite, priorytetyzacja, integracja z CI).
- go.insurity.com (ITS Regression Test Planning White Paper) —
  definicje formalne (Regression, Test Plan, Test Suite), struktura wg
  obszaru pokrycia, kryteria wyjścia.
- testdevlab.com (2×) — cykl utrzymania (review/update/remove),
  podejście mieszane automatyczne/manualne, dokumentacja.
- qualitylogic.com — zarządzanie: planowanie, koordynacja, automatyzacja.
- testomat.io — struktura test case (cel, kroki, oczekiwany wynik).

---

## CHANGELOG

**1.2 (2026-07-21):** PONOWNY PRZEGLĄD T1 na wyraźne żądanie użytkownika
("zbadaj działanie T1, czy jeszcze jakieś testy są wymagane, aby mieć
poziom profesjonalny"). NAPRAWIONO: ryzyko fałszywego negatywu w T1
(sprawdzenie podciągu → dopasowanie z granicą słowa). ZBADANO i
ŚWIADOMIE ODRZUCONO: pełny, szeroki skaner dangling references (zbyt
duży szum — patrz sekcja 10.2). ZBUDOWANO: T9 (wąski, celowany test
weryfikacji przeniesień do shared/) jako PROPORCJONALNA alternatywa.
NAPRAWIONO: install_precommit_hook.sh (v1.0→v2.0) instalował WYŁĄCZNIE
stary ci_check_shared.py zamiast pełnego run_regression_suite.py — ten
sam wzorzec "zbudowano, zapomniano podłączyć" jak wielokrotnie w tej
sesji. Dodano sekcję 10 z PEŁNĄ dokumentacją przeglądu i formalną oceną
kryteriów profesjonalnego zestawu testów wg zweryfikowanej literatury.

**1.1 (2026-07-21):** DOKOŃCZONO implementację — plan ISTNIAŁ już
(wersja 1.0), ale TYLKO JEDEN z pięciu odwołanych skryptów faktycznie
istniał (test_module_registration.py), a SAM plan NIE BYŁ zarejestrowany
w SKILL.md audyt-systemu-v4 — dokładnie ten sam wzorzec "opisane, nie
zaimplementowane", znajdowany wielokrotnie w tej sesji w innych
skillach. ZBUDOWANO: test_module_count.py (T2), test_cross_map_dzu.py
(T3), test_header_snapshot.py (T4), test_title_scope_match.py (T8),
run_regression_suite.py (orkiestrator). WYKONANO pełne uruchomienie —
patrz sekcja 9 — ZNALEZIONO i NAPRAWIONO DWA prawdziwe, aktywne błędy
systemu (licznik modułów DR-10, Dz.U. samorządu gminnego w DR-08) oraz
NAPRAWIONO DWA błędy w SAMYCH skryptach testowych (fałszywe pozytywy
w T2 i T3, wykryte przy pierwszym uruchomieniu i skorygowane przed
uznaniem zestawu za gotowy). Zarejestrowano plan i skrypty w SKILL.md.

**1.0 (2026-07-21):** Utworzenie planu na wyraźne żądanie użytkownika
("zestaw testów regresyjnych, profesjonalnie, w oparciu o literaturę
ekspercką online"). Zaadaptowano standardową metodologię testów
regresyjnych (zweryfikowaną online: TestRail, BrowserStack, Insurity,
TestDevLab, QualityLogic) do specyfiki systemu markdown-jako-baza-wiedzy.
KLUCZOWA decyzja metodologiczna: KAŻDA kategoria testu (T1-T8) odpowiada
KONKRETNEMU, udokumentowanemu w AUDIT-JOURNAL.md błędowi znalezionemu
i naprawionemu w TEJ sesji — zgodnie z fundamentalną zasadą testów
regresyjnych (ponowne wykonanie testów dla PRZESZŁYCH, znanych
problemów), NIE są to testy hipotetyczne/spekulatywne.

---

## 11. T11 — SYNCHRONIZACJA AKTÓW MIĘDZY REJESTRAMI (dodane 2026-08-15z, flaga F-89)

**Skrypt:** `scripts/check_sync_aktow.py` | **Priorytet:** ⭐⭐ WYSOKI |
**Charakter:** heurystyka tekstowa → WARN (nie bramka, nie rozstrzyga automatycznie)

**Błąd przeszły, przed którym chroni** (zgodnie z zasadą: każdy test odpowiada
udokumentowanemu incydentowi, nie hipotezie) — CZTERY udokumentowane przypadki:
1. 2026-08-13 — cztery podatki sektorowe opisane w dr-06, nieobecne w mapie
   centralnej i ROUTING-MAP.
2. 2026-08-14 — 12 nowych modułów zarejestrowanych lokalnie, nieobecnych
   w ROUTING-MAP (przyczyna powstania REGUŁY 3 w HARDGATE-AUDYT).
3. 2026-08-15y — ustawa o systemach AI (Dz.U. 2026 poz. 1003) znana w dr-11
   od 14.08, nieobecna w mapie centralnej.
4. 2026-08-15z — poz. 1004, 825 i 846 wpisane do mapy Dz.U. i modułów, ale
   nie do ROUTING-MAP (REGUŁA 3 pominięta przez samego wykonawcę audytu).

**Luka, którą wypełnia:** `test_cross_map_dzu.py` (T3) porównuje NUMER tego
samego aktu w dwóch mapach — wykrywa ROZBIEŻNOŚĆ, ale nie BRAK.
`check_rejestracja_modulow.py` sprawdza rejestrację MODUŁÓW, nie AKTÓW.
Żaden test nie wykrywał aktu obecnego w jednym rejestrze, a nieobecnego
w drugim — najczęstszego realnego defektu synchronizacji w tym systemie.

**Trzy kierunki kontroli:** lokalne `MAPA-AKTOW.md` → ROUTING-MAP (REGUŁA 3);
lokalne → mapa Dz.U.; ROUTING-MAP → mapa Dz.U.

**Kryterium wyjścia — ŚWIADOMIE NIE „zero":** rejestry mają różne
przeznaczenie (mapa Dz.U. to katalog wszystkich aktów, ROUTING-MAP zawiera
to, co ma routing do modułu), więc akt skatalogowany bez modułu MOŻE legalnie
nie mieć wiersza w ROUTING-MAP. Kryterium: **zero pozycji z ostatnich
12 miesięcy bez rozstrzygnięcia** (dopisane albo udokumentowane jako świadomy
brak). Docelowo — lista wyjątków w skrypcie, żeby test mógł stać się bramką.

**Stan zastany przy wprowadzeniu (2026-08-15z):** 72 / 80 / 53 pozycji
w trzech kierunkach → flaga F-89.

---

### 11a. POPRAWKA CZUŁOŚCI 2026-08-22 (F-106) — redukcja fałszywych trafień 29 → 19

Pierwszy pełny przegląd wyniku T11 (29 pozycji, kierunek `lokalne`) ujawnił
**dwa źródła szumu, oba po stronie testu, nie systemu**:

1. **Forma skrócona numeru bez prefiksu aktu.** `RE_POZ` wymaga prefiksu
   „Dz.U." przed numerem. Tymczasem ROUTING-MAP zapisuje nowelizacje
   skrótowo w komentarzu wiersza aktu bazowego — „zm.: 2025.1705",
   „+2026.176", „(zm. 2025.1863)". Osiem pozycji było raportowanych jako
   brakujące, choć numer w pliku JEST (2025.1705, 2025.1366, 2024.80,
   2023.1082, 2021.2490 i dalsze).
2. **Artefakt „poz. 0"** — numer nieistniejący w Dz.U., produkt rozbioru
   uciętych zapisów.

**Rozwiązanie:** dodany `RE_POZ_LUZNA` (numer w formie `RRRR.NNN` bez
prefiksu) zbierany WYŁĄCZNIE dla ROUTING-MAP i używany tylko do
**demotowania** trafienia z „brak" na „obecny w formie skróconej" —
nigdy do zgłaszania nowych braków. Uzasadnienie asymetrii: wzorzec bez
prefiksu jest podatny na przypadkowe dopasowania (daty, numery stron),
więc dopuszczamy go jedynie tam, gdzie kierunek błędu to MNIEJ alarmów,
nie więcej. Artefakt „poz. 0" odsiewany funkcją `artefakt()`.

**Przełącznik `--bez-filtra`** przywraca listę surową (stan sprzed
poprawki) — do kontroli, czy filtr nie ukrywa czegoś istotnego.

⚠️ **Czego poprawka NIE usuwa:** trafień typu „numer nowelizacji
wymieniony jako »ze zm.« w wierszu aktu bazowego, którego w ROUTING-MAP
w ogóle nie ma w żadnej formie". To nadal wymaga oceny człowieka — i
słusznie, bo część takich pozycji to realne braki wiersza.

**Skuteczność poprawki potwierdzona empirycznie:** ten sam przebieg,
29 → 19 pozycji, przy zachowaniu OBU realnych rozjazdów wykrytych w
sesji 2026-08-22 (Prawo oświatowe 2026.820, ZTP 2026.300) — filtr nie
ukrył żadnego prawdziwego błędu.

---

## 12. T12 — ZGODNOŚĆ METADANYCH WERSJI SKILLA (dodane 2026-08-20z, flaga F-101)

**Skrypt:** `scripts/check_wersje_changelog.py` | **Priorytet:** ⭐ ŚREDNI |
**Charakter:** kontrola tekstowa → WARN (nie bramka; wynik wymaga przeglądu)

**Błąd przeszły, przed którym chroni** (zasada: test odpowiada udokumentowanemu
incydentowi, nie hipotezie) — TRZY przypadki wykryte w JEDNEJ sesji, w trzech
skillach z trzech różnych rodzin, co przesądziło o powstaniu testu:
1. `przesluchanie-swiadkow-v2-min90` — `version: 3.22`, changelog kończy się na
   3.19; zmiany 3.20-3.22 nie są opisane NIGDZIE i nie da się ich odtworzyć.
2. `analizator-dowodow-v3` — `version: 5.16.1`, pole `changelog:` deklaruje
   5.15.0, nagłówek H1 podaje „v5.1": trzy różne numery w jednym pliku.
3. `audyt-systemu-v4` — stopka „Wersja: 5.0" przy `version: 6.8` (rozjazd
   dziewięciu wersji i półtora miesiąca), wykryta 2026-08-20y.

**Luka, którą wypełnia:** żaden wcześniejszy test nie patrzył na metadane wersji.
T1-T4 i T8 kontrolują treść i strukturę, T9 przeniesienia do `shared/`,
T11 synchronizację aktów. Rozjazd numeru wersji nie blokuje działania skilla —
i dlatego przeżywał audyty — ale uniemożliwia odpowiedź na pytanie „co się
zmieniło od kiedy", czyli podstawową operację audytową.

**Cztery kontrolowane nośniki numeru:** pole `version:` w YAML (źródło prawdy),
najwyższy wpis w `references/CHANGELOG.md`, numer w polu `changelog:` YAML,
numer w nagłówku H1 i stopce SKILL.md.

**Pułapka float — osobna klasa wykrywana przy okazji.** Niecytowane
`version: 6.10` YAML parsuje jako **float 6.1**, czyli numer NIŻSZY niż 6.9.
Problem nie istnieje przy jednocyfrowym minor, więc pojawia się dopiero przy
przejściu X.9 → X.10 i jest niewidoczny w treści pliku. Wykryty 2026-08-20z
przypadkiem, przy kontroli parsowalności frontmatterów — pierwszy przebieg
testu znalazł go w 8 skillach systemu. Klasyfikowany jako **⚠️ ryzyko utajone**,
nie ⛔ czynny błąd: sam plik działa poprawnie, dopóki nikt nie porównuje wersji
liczbowo.

**Wynik pierwszego przebiegu (2026-08-20z, `/mnt/skills/user`):** 26 rozbieżności
w 24 skillach — 5 czynnych rozjazdów ⛔, 21 ryzyk utajonych ⚠️. Szczegóły
i lista skilli: flaga **F-102** w `WARN-OTWARTE.md`.

**Kryterium wyjścia — ŚWIADOMIE NIE „zero":** luki historii w skillach, których
przeszłych wersji nie da się odtworzyć (3.20-3.22, 5.16.0-5.16.1), zostają
jako udokumentowane, a nie usuwane przez zmyślenie wpisów. Kryterium:
**zero ⛔ czynnych rozjazdów poza pozycjami jawnie oznaczonymi jako
„LUKA JAWNA" w changelogu danego skilla.**

**Znane ograniczenia (z docstringu skryptu):** parser rozpoznaje trzy formaty
numeracji wpisów (`**6.9 (data)**`, `- 5.15.0 (data)`, `## v3.15`); skill
o formacie nietypowym zgłosi brak changelogu zamiast realnej niezgodności.
Brak `references/CHANGELOG.md` NIE jest błędem — wiele skilli trzyma historię
wyłącznie w polu YAML. ⚠️ Pierwsza wersja testu przeszukiwała cały plik i dawała
7 fałszywych trafień z wpisów changelogu cytujących wersje INNYCH plików
(np. `shared/SKILL.md` wpis 3.15 cytujący „Wersja: 1.1.0" pliku
MOD-DOKUMENT-ANOMALIE) — naprawione tego samego dnia przez ograniczenie
wyszukiwania do korpusu pliku, poza frontmatterem.

### 12b — ROZSZERZENIE T12 O STANDARD LOKALIZACJI (2026-08-20z4, ZASADA 15)

Test kontroluje dodatkowo, GDZIE mieszka historia zmian:
- sekcja `## CHANGELOG` w korpusie SKILL.md zawierająca wpisy wersji → **⛔**
  (samo odesłanie do pliku jest dozwolone i nie jest zgłaszane),
- pole `changelog:` w YAML dłuższe niż 15 linii → **⚠️** (to już nie skrót,
  tylko pełna historia w niewłaściwym miejscu).

**Błąd przeszły, przed którym chroni:** w sesji 2026-08-20z3 sam ten test dał
fałszywy raport o luce siedmiu wersji w `pisma-procesowe-v3`, bo wpisy 5.12-5.15
leżały w SKILL.md, a nie w `references/CHANGELOG.md`. Naprawa parsera usunęła
objaw; ZASADA 15 i ta kontrola usuwają przyczynę.

**Wynik pierwszego przebiegu (2026-08-20z4):** 9 skilli naruszało standard —
7 z sekcją w korpusie (`analizator-przepisow-v2` 83 linie, `prawny-router-v3` 71,
`audyt-systemu-v4` 42, `pisma-proste-v2` 62, `pisma-procesowe-v3` 61, `dr-01` 17,
`orzeczenia-sadowe-v2` 9) i 3 z pełną historią w YAML (`shared` 111 linii,
`prawny-router-v3` 63, `analiza-sadowa-v6` 39). Wszystkie naprawione tego samego
dnia; po naprawie test zwraca zero.

**Kryterium wyjścia:** zero ⛔. Skill bez `references/CHANGELOG.md` jest poprawny
tylko dopóki nie ma historii — przy pierwszym wpisie plik zakłada się od razu.

### 12c — ROZSZERZENIE T12 O REGRESJĘ DYSK vs DZIENNIK (2026-08-31, flaga F-140)

Kontrole 12 i 12b porównują nośniki wersji **wewnątrz** skilla. Są przez to ślepe
na przypadek, w którym cały stan dyskowy cofnął się do starszej generacji: wtedy
wszystkie nośniki zgadzają się ze sobą i test świeci na zielono. Kontrola 12c
porównuje `version` na dysku z najwyższym numerem podbicia odnotowanym dla tego
samego skilla w `references/AUDIT-JOURNAL.md`.

- `dysk < dziennik` → **⛔ REGRESJA DYSKOWA** (komunikat nakazuje sprawdzić TREŚĆ,
  nie tylko numer — utrata wersji oznacza zwykle utratę napraw),
- ten sam warunek, ale różny MAJOR → **⚠️** z żądaniem ręcznego sprawdzenia
  (prawdopodobne trafienie na cudzy numer, nie regresja),
- brak śladu skilla w dzienniku → milczenie (nie jest błędem).

**Błąd przeszły, przed którym chroni:** `analizator-dowodow-v3` — dysk 5.16.1
wobec 5.16.2 odnotowanego w dzienniku, changelog urwany na 5.15.0, a naprawiony
CRIT `art. 328¹ KPC` ZNÓW obecny w `modules/MD5-terminy.md`. **Trzecie** wystąpienie
tego wzorca dla tego samego pliku; mechanizm opisany w dzienniku przy drugim
wystąpieniu: nieaktualne archiwum przywrócone po resecie kontenera nadpisało
nowszą pracę. T12 w wersji sprzed 12c wykrył wyłącznie rozjazd metadanych —
utratę treści znaleziono dopiero ręcznym cross-checkiem z dziennikiem.

**Zabezpieczenia parsera (wszystkie wymuszone przebiegami kontrolnymi, nie
hipotezą):** dopasowanie liczy się wyłącznie w segmencie linii zawierającym nazwę
skilla; wymagany jawny marker wersji (`v` przed numerem albo słowo „wersja"
w linii); odrzucane majory ≥ 100 (roczniki Dz.U./M.P.).

**Przebiegi kontrolne (2026-08-31):**

| Przebieg | Oczekiwanie | Wynik |
|---|---|---|
| Drzewo rzeczywiste, parser bez markera wersji | — | ⚠️ `2026.215` jako rzekoma wersja (numer Dz.U.) |
| Drzewo rzeczywiste, parser bez segmentacji | — | 4 × ⚠️ cudze numery z linii wyliczających kilka skilli |
| Drzewo rzeczywiste, parser docelowy | zero | ✅ zero |
| Mutacja 1: dysk cofnięty do 5.16.1, wszystkie nośniki spójne | ⛔ | ⛔ REGRESJA DYSKOWA wykryta |
| Mutacja 2: dysk 5.16.9 > dziennik 5.16.2 | brak alarmu 12c | brak (zadziałała tylko istniejąca kontrola luki historii) |
| Mutacja 3: nowy skill bez śladu w dzienniku | brak alarmu | brak |

**Kryterium wyjścia:** zero ⛔. Każde ⚠️ z tej kontroli wymaga ręcznego sprawdzenia
linii dziennika PRZED jakąkolwiek naprawą — cztery pierwsze trafienia okazały się
kontaminacją, nie regresją.

**Znane ograniczenie:** kontrola wykrywa regresję dopiero wtedy, gdy dziennik
zawiera jawny zapis podbicia. Sesja, która wyda skill bez wpisu „vX→vY", pozostaje
niewidoczna dla tej kontroli.

---

## 13. T13 — PRÓG DŁUGOŚCI MODUŁU (dodane 2026-08-21, obserwacja O-3)

**Skrypt:** `scripts/check_dlugosc_modulow.py`
**Priorytet:** ŚREDNI | **Typ:** pomiar deterministyczny (nie heurystyka)
**Kod wyjścia:** 0 = brak modułów >1000 linii, 1 = naruszenie progu

### Co kontroluje

| Wynik | Warunek | Znaczenie |
|---|---|---|
| ⛔ CRIT | `modules/mod-*.md` > **1000** linii | ZASADA 13 naruszona — podział wymagany |
| ⚠️ WARN | strefa **800-1000** linii | kolejna transza przekroczy próg; dziel PRZY OKAZJI najbliższej edycji, nie hurtem |
| ℹ️ INFO | `SKILL.md` > 1000 linii | osobna kategoria wg F-78 — DO ROZSTRZYGNIĘCIA przez użytkownika, NIE wpływa na kod wyjścia |

**Wyłączenia świadome:** `AUDIT-JOURNAL.md` (dziennik append-only, wyłączony
TRWALE — podział zerwałby chronologię i odesłania `AUDYT-YYYY-MM-DD`),
`mapa_dzu_*.md` (rejestry historyczne, ta sama logika).

### Dlaczego powstał

Do 2026-08-21 system miał **dwanaście** testów regresyjnych — na rejestrację
modułów, liczniki, spójność Dz.U., nagłówki, zakres tytułów, przeniesienia do
`shared/`, synchronizację aktów i metadane wersji — i **ani jednego na długość**,
mimo że ZASADA 13 jest regułą twardą z progiem liczbowym, czyli najłatwiejszą
do zautomatyzowania ze wszystkich. Skutek: naruszenie w
`dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KC-spadki.md` (1036 linii) przetrwało od momentu
przekroczenia progu do ręcznego skanu ad hoc, a zamknięcie flagi F-78 musiało
kończyć się rekomendacją *„świeży skan `wc -l` przy następnym audycie"* —
czyli przerzuceniem kontroli na pamięć audytora. To ta sama klasa problemu co
F-80 (rejestr nie nadążał za dyskiem), tylko dotycząca rozmiaru, nie istnienia.

### Wynik pierwszego przebiegu (2026-08-21)

Na stanie sprzed napraw: **1 ⛔** (`mod-KC-spadki` 1036) i **6 ⚠️** (strefa
800-1000: `mod-ustawa-bezpieczenstwo-zywnosci` 925, `mod-PrUpad-upadlosc-
restrukturyzacja` 906, `mod-PrFarm-prawo-farmaceutyczne` 903,
`mod-techniki-mediacyjne-negocjacyjne` 856, `mod-KSH-spolki-handlowe` 850,
`mod-OP-ordynacja-podatkowa` 837). Po podziałach z tej samej sesji (PrUpad
wyprzedzająco, KC-spadki obligatoryjnie): **0 ⛔, 5 ⚠️**, kod wyjścia 0.

### 13a. ROZSZERZENIE O ZASOBY KANONICZNE `shared/` (2026-09-12p)

⛔ **Wykryta ślepa plamka.** Do 2026-09-12p T13 mierzył **wyłącznie**
`modules/mod-*.md` (warunek w `zbierz()`: `basename(root) == 'modules' and
nazwa.startswith('mod-')`). Pliki leżące bezpośrednio w katalogu `shared/` były
**poza zasięgiem testu w ogóle** — a `prawo-polskie-v2/krajowe/shared/TABELE-OPLAT.md` urósł przez serię
sesji wrześniowych do **1472 linii**, czyli **47 % ponad próg CRIT**, i nikt
tego nie zmierzył.

⚠️ **Ta sama klasa problemu co przy powstaniu T13:** reguła z progiem liczbowym
istniała, test istniał, a jeden katalog po prostu nie był w niego wpięty.
Różnica polega na tym, że tym razem ślepa plamka nie wynikła z braku testu,
tylko z **zawężenia jego zakresu do wzorca nazwy pliku**.

**Nowa kategoria: `shared/*.md` powyżej progu WARN — RAPORTOWANA, nie
blokująca.** Kod wyjścia bez zmian, jak przy `SKILL.md` wg F-78.

⛔ **Dlaczego nie CRIT.** Te pliki są **celowo scentralizowane**. Podział
`prawo-polskie-v2/krajowe/shared/TABELE-OPLAT.md` na kilka mniejszych odtworzyłby dokładnie tę strukturę, którą
**sekcja 7 tego samego pliku** nazywa *tabelami satelickimi* i której cały
audyt O-11 uczył się nie tworzyć. Test, który wymusza podział wbrew doktryny
skilla, jest testem szkodliwym.

⚠️ **Zalecane działanie przy przekroczeniu progu: SPIS TREŚCI, nie cięcie.**
Przy tej objętości realnym problemem jest **odnalezienie sekcji**, nie sama
długość. Wykonane w tej samej sesji: `prawo-polskie-v2/krajowe/shared/TABELE-OPLAT.md` (72 pozycje) i
`prawo-polskie-v2/krajowe/shared/terminy.md` (22 pozycje) dostały spisy treści.

### 13b. ⛔ TA SAMA PLAMKA DRUGI RAZ — poprawka zakresu (2026-09-12r)

Rozszerzenie z 13a sprawdzało `basename(root) == 'shared'`, czyli **wyłącznie
pliki leżące bezpośrednio w katalogu skilla**. Podział `TABELE-OPLAT` (sesja
12q) utworzył `prawo-polskie-v2/krajowe/shared/oplaty/` z siedmioma satelitami — i **wszystkie
natychmiast wypadły poza zakres testu**, dokładnie tak, jak wcześniej wypadł
z niego sam `TABELE-OPLAT`.

⛔ **Ta sama ślepa plamka, drugi raz, w odstępie jednej sesji.** Za pierwszym
razem zakres zawężał **wzorzec nazwy pliku** (`mod-*`), za drugim —
**głębokość katalogu**. Wspólna przyczyna: reguła progowa jest globalna,
a warunek wpięcia pisany pod aktualnie znany układ plików. Każda zmiana
struktury repozytorium jest **potencjalnym wypadnięciem z zakresu testu**.

**Poprawka:** warunek zmieniony na `'shared' in root.split(os.sep)` — cały
podkatalog `shared/`, rekurencyjnie. Po poprawce test widzi **167 zasobów
kanonicznych** zamiast 138.

⭐ **Dodany `--selftest` (5/5)**, którego T13 nie miał od powstania. Przypadki
pilnują **przydziału do kategorii**, nie progów: plik bezpośrednio w `shared/`,
satelita w podkatalogu, moduł dziedzinowy, `SKILL.md`, plik spoza zakresu.
To jest bramka na tę konkretną klasę regresji — gdyby istniała w 12q, plamka
wyszłaby od razu.

⚠️ **Znane ograniczenie ograniczenia:** spisy treści są **ręczne**. Nie ma
testu pilnującego, czy spis nadąża za nagłówkami — to ta sama klasa długu co
rejestry przed T1. Kandydat na rozszerzenie, nie zobowiązanie.

### Ograniczenie — świadome

Test mierzy WYŁĄCZNIE liczbę linii. **Nie ocenia, czy w miejscu, w którym
wypadałoby ciąć, przebiega naturalna granica rozdziału** — to zawsze pozostaje
decyzją audytora. Wynik ⛔ znaczy „podział wymagany", nie „podziel w połowie".
Doświadczenie z podziału `mod-KC-spadki` pokazało, dlaczego to rozróżnienie
jest istotne: sekcje modułu były dopisywane w kolejności zgłoszeń, nie
w systematyce Księgi IV KC, więc wierny podział „wg rozdziałów aktu" wymagałby
przestawienia treści — a to naruszyłoby nadrzędny wymóg podziału czysto
strukturalnego. Test tego konfliktu nie wykryje i wykryć nie może.

**Kryterium wyjścia:** zero ⛔. Pozycje ⚠️ nie blokują — są sygnałem
planistycznym na najbliższą edycję danego pliku.

## 14. WYMÓG WOBEC TESTÓW ZEWNĘTRZNYCH — kontrakt statusów (dodano 2026-08-23f, flaga F-116, część 2/3)

⛔ **Ten punkt dotyczy PROMPTÓW TESTOWYCH pisanych przez osoby trzecie
(audyty zewnętrzne, benchmarki, recenzje LM), nie testów T1-T13 powyżej.**
Powstał po stwierdzeniu, że trzy niezależne raporty zewnętrzne (TEST1/TEST2/
TEST3, 2026-08-23e) oceniały system wobec etykiety `MEM` i rejestru
`VER/MEM/NIEWERYFIKOWANE`, którego system **nie ma** — `AF-4` w
`prawo-polskie-v2/krajowe/shared/PRAWO-HARDGATE.md` v2.6 wprost ZAKAZUJE etykiety `MEM`. Skutek:
poprawne zachowanie systemu (odmowa użycia `MEM`) było punktowane jako
uchybienie, a niedopuszczalne zachowanie portu porównawczego (użycie `MEM`)
jako jego przewaga.

**Reguła:** prompt testowy oceniający zgodność ze statusami weryfikacji
NIE WPROWADZA własnego rejestru etykiet ani nie wymienia z góry kryteriów
oceny w treści polecenia dla modelu. Jedyne poprawne źródło etykiet
dopuszczalnych to sekcja statusów w `prawo-polskie-v2/krajowe/shared/PRAWO-HARDGATE.md`
(`✅ [VER]` / `🟨 [KOTWICA-URZĘDOWA]` / `⚠️ [NIEWERYFIKOWANE]` /
`⬛ [DO UZUPEŁNIENIA]`) oraz rozszerzenie poziomu TREŚĆ/FRAGMENT
w `shared/WERYFIKACJA-SLAD.md`. Etykieta spoza tych dwóch plików
(w tym `MEM`, „pamięć normatywna", „wiedza modelu", „stan znany")
użyta w kryteriach oceny czyni **wynik testu wobec tego kryterium
nieważny niezależnie od uzyskanego wyniku PASS/FAIL** — test mierzy
wtedy zgodność z fikcyjną specyfikacją, nie zachowanie systemu.

**Decyzja architektoniczna 2026-08-23f:** rozważano stworzenie osobnego
pliku `shared/KARTA-STATUSOW.md` jako "jednej strony, jedynego źródła
prawdy" łączącej wszystkie rejestry statusów w systemie. **Odrzucono.**
Uzasadnienie w AUDIT-JOURNAL, wpis 2026-08-23f, sekcja 2 — ryzyko
utworzenia TRZECIEGO rejestru obok `prawo-polskie-v2/krajowe/shared/PRAWO-HARDGATE.md` i
`WERYFIKACJA-SLAD.md`, przewyższające korzyść z konsolidacji. Zamiast
karty, punkt niniejszy odsyła wprost do dwóch istniejących plików
źródłowych jako jedynego kryterium ważności testu.

---

## 14. T14 — POLE `description:` W SKILL.md (obecność + długość)

**Skrypt:** `scripts/check_description.py`
**Priorytet:** KRYTYCZNY
**Dodany:** 2026-08-24, flaga F-130
**Kod wyjścia:** 0 = czysto, 1 = wykryto ⛔ lub ⚠️

### Co sprawdza
1. obecność frontmattera YAML w `SKILL.md`;
2. **obecność pola `description:`** — brak = ⛔;
3. czy pole nie jest puste — puste = ⛔;
4. długość w profilu uniwersalnym: >200 = ⛔, 181–200 = ⚠️, ≤180 = OK.

### Po co powstał
FAZA 2C mierzyła wyłącznie DŁUGOŚĆ. Jej skrypt dla pliku bez pola `description:`
wypisywał `0` i klasyfikował wynik jako ✅ OK — czyli **stan najgorszy raportował
jako najzdrowszy**. Skutek: `audyt-systemu-v4` był jedynym skillem w systemie bez
tego pola i żadna faza tego nie zgłosiła. Wykryte dopiero, gdy użytkownik przysłał
gotową poprawkę.

`description` jest polem, na podstawie którego skill jest WYBIERANY do wywołania —
jego brak objawia się CISZĄ (skill po prostu nie wystartuje), nie błędem. To
najgorszy możliwy tryb awarii do wykrycia ręcznego, więc jedyną sensowną obroną
jest test.

### Test negatywny (sprawdź przy każdej zmianie skryptu)
Uruchom na katalogu, w którym któryś `SKILL.md` NIE ma pola `description:` —
np. `/mnt/skills/user` w stanie sprzed 2026-08-24. Oczekiwane: dokładnie jedno
⛔ dla `audyt-systemu-v4`. Jeśli skrypt zwraca „✅ czysto" — regresja, ta sama
wada co w pierwotnej FAZIE 2C.

### Znane ograniczenie (jawne)
Mierzy OBECNOŚĆ i DŁUGOŚĆ, nie TRAFNOŚĆ opisu. Description obecny, ale źle
opisujący skill, przejdzie test i nadal będzie powodował złe wyzwalanie —
na to potrzeba testu z F-113, nie tego.

---

## 17. T17 — STATYCZNY KONTRAKT ROUTERA PRAWNEGO

**Skrypt:** `scripts/test_router_contract.py`
**Priorytet:** KRYTYCZNY dla wydania routera
**Dodany:** 2026-08-26
**Kod wyjścia:** 0 = kontrakt kompletny, 1 = regresja, 2 = router nieodnaleziony

### Co sprawdza

1. `description` zaczyna się od imperatywu `UŻYWAJ ZAWSZE`, obejmuje każdą
   jurysdykcję i mieści się w 200 znakach;
2. nagłówek korpusu używa stabilnej wersji major `v3`, a nie martwego numeru
   minor niezależnego od YAML;
3. istnieje PATH-SELFTEST i jawny `TRYB ZDEGRADOWANY`;
4. blok `ŁADOWANE ZAWSZE` poprzedza adapter i wymusza pełny self-check;
5. korpus ma najwyżej 500 linii, nie zawiera narracji incydentów ani
   zduplikowanej Reguły 13;
6. routing [11] wymusza odczyt `AUDYT-KLUCZA-ODPOWIEDZI.md`;
7. protokół klucza wymusza rachunek N/N i zakazuje „pełnej zgodności" przy
   choć jednej pozycji obalonej lub nierozstrzygniętej;
8. ta sama bramka jest obecna w `SELF-CHECK.md`;
9. identyfikatory reguł są kompletne i zachowują pierwotne znaczenie,
   z pominięciem 13 oraz fizyczną kolejnością 22 → 23. Usunięcie, zmiana
   numeru lub przestawienie reguły musi powodować FAIL.

Skrypt rozpoznaje router po polu `name:` w `SKILL.md`, więc działa zarówno
przy katalogach semantycznych, jak i przy identyfikatorach pakietów hosta.

### Ograniczenie

T17 dowodzi obecności i spójności kontraktu statycznego, nie skuteczności
behawioralnej. F-113/F-133 pozostają otwarte do testu A/B z transkryptami.

---

## 12. T20 — zamiatania bramki wyjątków (WYJ-GATE, F-144, 2026-08-31d)

**Skrypt:** `scripts/check_wyjatek_gate_eli.py`
**Priorytet:** ŚREDNI (narzędzie wspierające, nie bramka blokująca)

### Co test rozstrzyga

Czy narzędzie buduje deterministycznie trzy z czterech zamiatań bramki:
S1 sąsiedztwo redakcyjne, S2 krawędzie jednostki, S3 rejestr odesłań ELI.
S1 jest jedynym punktem, w którym potknięcie źródłowe F-144 (art. 770¹ k.c.
pominięty przy poprawnie odczytanym art. 770 k.c.) byłoby wykryte mechanicznie.
S3 pokrywa przypadek, którego S1 nie łapie: lex specialis w INNEJ ustawie —
a właśnie tam leżało wyłączenie rękojmi w kazusie 111.

### Kryteria PASS — `--selftest`, 8 pozycji

1. parser rozpoznaje `art. 770¹` jako **osobną jednostkę**, nie fragment art. 770;
2. zakres S1 dla art. 770 zostaje zbudowany;
3. `art. 770¹` **jest** w zakresie S1;
4. sąsiedzi 769 i 771 w zakresie;
5. jednostka nadrzędna rozpoznana jako TYTUŁ XXIV;
6. S2 zwraca krawędzie jednostki (art. 765 i art. 771);
7. S3 spłaszcza rejestr odesłań do listy pozycji;
8. S3 widzi ustawę konsumencką z 2002 r. w rejestrze.

**Wynik przy wprowadzeniu (2026-08-31d): 8/8 PASS.**

### Mutacja negatywna — obowiązkowa

Usunięcie art. 770¹ z fixture musi usunąć go z zakresu S1. Wykonano: zakres
zwrócił `['art. 769', 'art. 770', 'art. 771']` — test nie jest pusty.

Gałęzie błędu: artykuł nieznaleziony → exit 3 (potwierdzone); brak dostępu do
API → exit 2 (potwierdzone realnym odrzuceniem połączenia).

### Ograniczenia

⚠️ **Gałąź sieciowa NIE została uruchomiona na żywym `api.sejm.gov.pl/eli`** —
domena jest poza listą dozwoloną środowiska audytu. Przetestowano parsery
i logikę zakresu na fixture, nie integrację.

⛔ Pusty rejestr odesłań w S3 NIE dowodzi braku lex specialis: akt sektorowy,
który nie odsyła wprost do aktu głównego, w rejestrze się nie pojawi. Skrypt
wypisuje to ostrzeżenie w wyniku.

⛔ T20 dowodzi, że narzędzie buduje właściwy zakres. NIE dowodzi, że bramka
WYJ-GATE odpala w odpowiedziach ani że zmienia konkluzje — to pomiar z grupą
kontrolną wg `PLAN-TESTU-BRAMEK-F113.md`, przypisany do F-144.

---

## 13. T21 — kompletność i zgodność CHECKSUMS.sha256 (F-145, 2026-08-31d)

**Skrypt:** `scripts/check_checksums.py`
**Priorytet:** KRYTYCZNY

### Po co powstał

`sha256sum -c` odpowiada wyłącznie na pytanie „czy wpisane sumy się zgadzają".
NIE odpowiada na pytanie „czy każdy plik ma w ogóle wpis" — a plik bez wpisu
daje wynik **pozornie najzdrowszy**: zero błędów. To ten sam wzorzec, który
w F-130 pozwolił skillowi bez pola `description:` przechodzić kontrolę
z wynikiem `0` klasyfikowanym jako ✅ OK.

### Co sprawdza

1. każdy plik skilla ma wpis (wykluczenia: sam plik sum, `__pycache__`, `.pyc`,
   pliki ukryte, archiwa `.zip` rejestrowane osobno);
2. każdy wpis wskazuje plik istniejący na dysku;
3. każda suma zgadza się z zawartością.

### Wynik przy wprowadzeniu (2026-08-31d)

Przed naprawą: **34 rozjazdy w 3 skillach** — `audyt-systemu-v4` 6 plików bez
wpisu i 12 sum niezgodnych, `prawny-router-v3` 3 niezgodne, `shared` 1 bez
wpisu i 12 niezgodnych. Po naprawie: **PASS**, 0 rozjazdów.

⚡ Znalezisko uboczne: 3 z 3 skilli miały rozjazd, w tym dwa zmienione w tej
samej sesji przez audyt — czyli odświeżanie sum nie było częścią procedury
wydania, tylko czynnością pamiętaną ad hoc. To jest przyczyna F-145, nie sam
rozjazd.

### Ograniczenie

⛔ Zgodność sumy dowodzi, że plik nie zmienił się OD MOMENTU WPISANIA SUMY.
Nie dowodzi poprawności treści ani tego, że wpis powstał na właściwej wersji.
Odświeżenie po zmianie zamierzonej jest częścią wydania, nie tego testu.

---

## T24 — nowelizacje ogłoszone PO dacie tekstu jednolitego

**Skrypt:** `scripts/check_nowelizacje_po_tj.py` · **Dodany:** 2026-09-01j,
flaga F-156 · **Priorytet:** WYSOKI · **WYMAGA SIECI** (`api.sejm.gov.pl`),
dlatego stoi POZA orkiestratorem — jak T15 i T20.

### Co sprawdza

Dla każdego numeru Dz.U. w `MAPA-AKTOW.md` każdego skilla: czy wskazany tekst
jednolity nie ma już ogłoszonych nowelizacji. Liczy **unię** dwóch źródeł
(F-155): sekcji ELI „Nowelizacje po tekście jednolitym" oraz aktów zmieniających
aktu bazowego z datą promulgacji późniejszą niż data t.j.

### Dlaczego test, a nie adnotacja w mapie (rozstrzygnięcie F-156)

Przegląd 2026-09-01i wykrył 139 takich pozycji w 16 mapach. Rozważano ręczne
oznaczenie liczbą przy każdej pozycji — DR-08 dostał je w wydaniu 3.9.
**W ciągu jednego dnia trzy z tych liczb rozjechały się z rejestrem**
(planowanie przestrzenne 2→3, zabytki 3→5, drogi publiczne 1→2). Liczba rośnie
z każdą publikacją Dz.U., więc adnotacja starzeje się szybciej, niż ktokolwiek
zdąży ją odświeżyć — a mapa z nieaktualną liczbą kłamie z większą pewnością
siebie niż mapa, która nic nie twierdzi. To ten sam wzorzec co F-82: rejestr
zgodny sam ze sobą i rozjechany z rzeczywistością.

Rozstrzygnięcie: **wynik powstaje w momencie uruchomienia**. Mapy noszą wyłącznie
bezliczbowy znacznik „⚠️ nowelizacje po t.j. → T24"; liczbę podaje test.

### Ograniczenia — nazwane wprost

⛔ Test NIE ocenia, czy nowelizacja dotyka akurat tej jednostki redakcyjnej,
którą zamierzasz cytować. Mówi wyłącznie: „dla tego aktu sam t.j. nie
wystarczy". Ocena wpływu pozostaje ręczna, jak w WYJ-GATE.

⛔ Test nie widzi nowelizacji nieogłoszonych oraz aktów spoza publikatorów
objętych API ELI (`DU` i `MP`) — akty prawa miejscowego są poza jego zasięgiem
z definicji, patrz ŚCIEŻKA B-L w `prawo-polskie-v2/krajowe/shared/PRAWO-HARDGATE.md`.

⛔ WARN tego testu to stan świata, nie usterka repozytorium. FAIL zgłaszany jest
tylko dla pozycji bez pokrycia w ELI albo nieobowiązujących.

### Selftest

`--selftest` (offline, 7 przypadków) pokrywa: obie formy zapisu numeru Dz.U.,
brak powielania numerów, unię obu źródeł, odrzucenie nowelizacji sprzed t.j.,
proweniencję każdej pozycji oraz **mutację negatywną** — gdyby test przeszedł na
samą sekcję API, przypadek „unia liczy 2, nie 1" zgłosiłby FAIL. Siódmy przypadek
pilnuje, że T24 IMPORTUJE logikę z `check_wyjatek_gate_eli.py`, zamiast ją
kopiować: dwie rozjeżdżające się implementacje tej samej reguły byłyby gorsze
niż brak testu.

## T25 — osiągalność źródeł prawnych (`check_domeny_allowlist.py`)

**Dodany:** 2026-09-04, flagi F-152 (ZAMKNIĘTA) / F-157 / F-158.
**Priorytet:** ŚREDNI. **WYMAGA SIECI** — stoi poza orkiestratorem, jak T15,
T20 (wariant sieciowy) i T24.

**Co sprawdza:** czy źródła z `references/PORTALE-ORZECZNICZE-API.md` są
odczytywalne z kanału kodu. 40 sond w 6 grupach (akty, orzecznictwo, rejestry,
zamówienia, dane, międzynarodowe). Każda sonda ma **stan odniesienia** z
pomiaru 2026-09-04; test zgłasza **regresję** tylko wtedy, gdy pozycja była
OK, a dziś nie jest.

**Czego NIE sprawdza:** czy z danego źródła wolno cytować. To
`prawo-polskie-v2/krajowe/shared/HIERARCHIA-ZRODEL.md`, nie ten test.

**Uruchomienie:**
```bash
python3 scripts/check_domeny_allowlist.py --selftest     # offline, 15/15
python3 scripts/check_domeny_allowlist.py                # pełny pomiar
python3 scripts/check_domeny_allowlist.py --grupa akty
python3 scripts/check_domeny_allowlist.py --json wynik.json
```
Kody wyjścia: 0 = brak regresji, 1 = regresja, 2 = błąd wywołania.

⛔ **Trzy rzeczy, których nie zrobi goły `curl -I`, a ten test tak:**
1. **Kontrola treści, nie kodu.** SAOS pod UA przeglądarkowym zwraca HTTP 200
   ze stroną „Przerwa techniczna". Test szuka markera (`must_contain`).
2. **Rozpoznanie przekierowania poza listę dozwolonych** — 403 z sygnaturą
   proxy klasyfikowany osobno (`POZA_LISTA`), bo to luka konfiguracji, nie
   awaria portalu.
3. **Ponowienie przy 5xx.** Pomiar złapał niepowtarzalne 503 na
   `rejestr.uokik.gov.pl` i 404 w 2/8 prób na roocie `bzp.uzp.gov.pl`.

⚠️ **Wynik jest ważny tylko przy ustawieniach z `7.0` inwentarza**: neutralny
UA, `Accept: */*`, timeout ≥ 60 s. Podmiana UA na przeglądarkowy zmienia wynik
i jest osobno pilnowana przypadkiem selftestu.

---

## T26 — parsowalność frontmatteru (`check_frontmatter_yaml.py`)

**Dodany:** 2026-09-04c, flaga F-159. **Priorytet: KRYTYCZNY.** Offline.

**Co sprawdza:** czy frontmatter każdego `SKILL.md` **parsuje się jako YAML**
oraz czy `inputs`, `outputs`, `escalation`, `limitations`, `required_modules`
są listami TEKSTÓW. `changelog` może być listą albo blokiem `|`.

**Czym różni się od T22:** T22 sprawdza, czy frontmatter da się WYODRĘBNIĆ
(są dwa `---`) i czy zasoby są zarejestrowane — jawnie **bez PyYAML**. Plik
z uszkodzoną składnią przechodził T22 bezbłędnie. T26 sprawdza, czy da się go
PRZECZYTAĆ.

**Uruchomienie:**
```bash
python3 scripts/check_frontmatter_yaml.py --selftest          # 10/10 offline
python3 scripts/check_frontmatter_yaml.py                     # całe repo
python3 scripts/check_frontmatter_yaml.py --katalog PATH
```
Kody: 0 = czysto, 1 = usterka, **2 = brak PyYAML** (nie 0 — cicha zgoda
udawałaby, że sprawdzono).

⛔ **Dlaczego priorytet krytyczny:** nieparsowalny frontmatter oznacza skill,
który **nie ładuje się na hoście**. Objaw jest mylący — wygląda jak „na dysku
została stara wersja". Tak zdiagnozowano F-146 i tak samo wyglądał F-159.

⚠️ **Korekta jeszcze przed wydaniem:** pierwsza wersja wymagała, by
`changelog` był listą, i zgłosiła `shared` jako usterkę. Fałszywy alarm —
blok `|` jest legalny i wręcz odporniejszy na F-146/F-159. Bramka
z fałszywymi alarmami zostaje wyłączona po drugim przebiegu, więc reguła
została zawężona, a selftest dostał przypadek bloku i mutację negatywną
(`inputs` jako blok `|` **nadal jest usterką** — to pole się iteruje).

---

## T28 — WARTOŚCI I CYTATY, NIE AKTY (`check_wartosci_prawne.py`)

**Dodany:** 2026-09-12f, obserwacja **O-12**. **Priorytet: KRYTYCZNY.** Offline,
wchodzi do orkiestratora.

**Po co powstał.** Cały dotychczasowy aparat — T3, T11, T15, T24, T27 — pyta
o **akty**: czy numer Dz.U. istnieje, czy jest aktualny, czy nie ma nowelizacji
po tekście jednolitym. Trzy sesje z rzędu wykryły mechanizmy, w których **akt
jest w pełni aktualny, a wartość w module nieprawdziwa**:

| Mechanizm | Przykład | Co wygląda na aktualne |
|---|---|---|
| rozporządzenie **uchyla** poprzednie | zryczałtowana równowartość wydatków 300 → **1000 zł** (`Dz.U. 2025 poz. 770`) | ustawa delegująca i jej t.j. |
| przepis **uchylony**, materia przeniesiona | art. 503 KPC → art. 480² § 2, 480³, 505 § 1 | cały kodeks |
| **decyzja RPP** zmienia wynik wzoru | wszystkie odsetki ustawowe | akt, przepis i brzmienie |

### Trzy bramki

**W1 — rejestr znanych błędnych cytatów → FAIL.** Zamknięta lista pozycji
**zweryfikowanych odczytem treści**, każda z datą sesji. To **nie jest** heurystyka
„wykryj wszystkie błędy" — to zapora przed **nawrotem**. Powód wprost:
`art. 328¹ KPC` naprawiano **trzykrotnie** (2026-08-04, 2026-08-08, 2026-09-12d)
i **sześciokrotnie przetrwał**, bo za każdym razem naprawiano **plik**,
w którym błąd zauważono, a nie **wzorzec w korpusie**.

Pozycje startowe (10): `328¹ KPC`; `art. 503 KPC` (uchylony); `art. 27 pkt 1–6
KSCU` jako progi WPS; `art. 13 ust. 1a KSCU` (jednostka nie istnieje);
`art. 19 § 2b`; `art. 69 § 1 KSCU` przy zabezpieczeniu; `§` zamiast `ust.`
w KSCU; `art. 105 § 1 KPW` przy wniosku o uzasadnienie; `art. 94 KPSW` bez
odesłania; ryczałt `300 zł` przy oskarżeniu prywatnym.

⛔ **Kryterium dopisania do rejestru:** wyłącznie pozycja potwierdzona odczytem
treści aktu (RZĄD 1). Fałszywy alarm w bramce FAIL kończy się jej wyłączeniem,
a wtedy tracimy całą zaporę — to nie jest miejsce na domysły.

**W2 — procent utrwalony przy pojęciu „odsetki" → FAIL.** Wartość zakotwiczona
w stopie NBP z definicji nie da się zapisać poprawnie: RPP zmienia stopę bez
nowelizacji. Dozwolony jest **wzór** (punkty procentowe, dwukrotność, stopa
referencyjna albo lombardowa, stawki 50 %/150 % z OP), zakazany **wynik**.

**W3 — wiersz kwotowy bez podstawy → WARN.** Wiersz tabeli z kwotą w zł, w którym
żadna komórka nie wskazuje jednostki redakcyjnej ani numeru publikacyjnego.
⛔ Sama nazwa rodzaju aktu („Rozporządzenie MS") **nie liczy się** — dokładnie
tak wyglądał wiersz „doręczenie przez komornika 60 zł", który przez wiele wersji
nie miał identyfikacji aktu (podstawą jest art. 41 ust. 1 ustawy o kosztach
komorniczych).

### Uruchomienie

```bash
python3 scripts/check_wartosci_prawne.py --selftest        # offline, 21/21
python3 scripts/check_wartosci_prawne.py --katalog .       # całe repo
python3 scripts/check_wartosci_prawne.py --tylko-fail      # bez sekcji WARN
```
Kody: 0 = czysto (WARN dopuszczalne), 1 = FAIL, 2 = błąd wywołania.

### Wynik pierwszego przebiegu (2026-09-12f)

410 plików. **31 trafień FAIL**, z czego **8 to realne, nienaprawione usterki**:
`prawo-polskie-v2/krajowe/pisma-proste-v2/references/SPF-SPG.md` ×2 (zabezpieczenie z art. 69 zamiast art. 68 pkt 1),
`prawo-polskie-v2/krajowe/pisma-proste-v2/references/SPB-zarzuty.md` ×2 i `pisma-proste-v2/SKILL.md` ×1 (opłata od zarzutów
z „art. 19 § 3" oraz termin 7 dni zamiast miesiąca), `dr-03` ×3
(`art. 94 KPSW` bez odesłania do art. 506 § 1 KPK). Wszystkie naprawione
w tej samej sesji; po naprawie **FAIL: brak**.

⭐ **Test znalazł usterki, których trzy poprzednie sesje ręcznego przeglądu
nie znalazły** — mimo że dotyczyły dokładnie tych rodzin, które te sesje badały.

### ⚠️ Znane ograniczenia — jawne

1. **Neutralizator opisu błędu.** Moduły muszą móc napisać „art. 503 KPC jest
   UCHYLONY", więc linia zawierająca zwrot opisujący błąd jest pomijana.
   **Cena:** W1 da się ominąć dopisując do linii słowo „uchylony". Uznane za
   akceptowalne — taki zapis sam niesie ostrzeżenie dla czytelnika, inaczej niż
   milczący błędny cytat. Selftest pilnuje, że opis w JEDNEJ linii **nie**
   neutralizuje błędnego cytatu w innej.
2. **W3 daje szum: 85 ostrzeżeń w pierwszym przebiegu.** Najczęstsza przyczyna
   jest legalna — podstawa stoi w **nagłówku nad tabelą**, nie w każdym wierszu.
   Dlatego WARN, nie FAIL. Zaostrzenie wymagałoby analizy zakresu tabeli.
3. **Rejestr W1 jest listą, nie regułą.** Nie wykryje nowego błędu tej samej
   klasy — wykryje **nawrót znanego**. To świadomy wybór: reguła generyczna
   („każdy indeks górny przy numerze artykułu") dawałaby fałszywe alarmy na
   legalnych jednostkach `art. 205¹`, `art. 398⁵`, `art. 477⁹` KPC.
4. **Marker odstępstwa** `<!-- T28-OK: powód -->` działa w jednej linii i wymaga
   podania powodu. Nie ma globalnego wyłącznika bramki.

---

## T29 — INTEGRALNOŚĆ PODZIAŁU TABELE-OPLAT (`check_oplaty_mapa.py`)

**Dodany:** 2026-09-12q wraz z podziałem `prawo-polskie-v2/krajowe/shared/TABELE-OPLAT.md` (1555 linii)
na rdzeń nawigacyjny i **siedem satelitów** w `prawo-polskie-v2/krajowe/shared/oplaty/`.
**Priorytet: KRYTYCZNY.** Offline, do orkiestratora.

### ⛔ Po co — test jest WARUNKIEM dopuszczalności podziału

Sekcja 7 rdzenia opisuje, jak w tym systemie powstały „tabele satelickie":
pliki z własnymi kwotami, **bez właściciela i bez rejestru**, które rozjechały
się z przepisem (pomiar `AUDYT-2026-09-12`: trafność poniżej 80 %). Podział na
satelity tworzy **dokładnie taką strukturę**. Różnica polega wyłącznie na tym,
że tutaj istnieje pojedyncza **mapa własności sekcji** i test, który jej
pilnuje.

⛔ **Bez T29 podział jest regresją, nie porządkiem.** To nie jest test
towarzyszący zmianie — to jej warunek.

### Cztery bramki

| Bramka | Co sprawdza | Czego sama nie wystarczy |
|---|---|---|
| **B1** | każdy plik z mapy rdzenia **istnieje** | — |
| **B2** | każdy plik w `prawo-polskie-v2/krajowe/shared/oplaty/` jest **w mapie** | ⛔ B1 bez B2 przepuszcza **plik-sierotę** — satelitę bez właściciela, czyli dokładnie stary wzorzec |
| **B3** | żaden nagłówek sekcji (`## 1a.`, `## 6b.`…) nie występuje w **dwóch plikach** | właściwa bramka **antyduplikacyjna** |
| **B4** | każdy satelita niesie blok **„Plik satelicki"** | plik odczytany w oderwaniu nie może udawać źródła samodzielnego |

### Uruchomienie

```bash
python3 scripts/check_oplaty_mapa.py --selftest    # offline, 5/5
python3 scripts/check_oplaty_mapa.py --katalog .   # cały korpus
```
Kody: 0 = czysto, 1 = naruszenie, 2 = błąd wywołania.

### Wynik pierwszego przebiegu (2026-09-12q)

`plików w mapie: 7 | na dysku: 7 | sekcji z właścicielem: 22` — **✅ OK**.

### ⚠️ Znane ograniczenia — jawne

1. **Test pilnuje struktury, nie treści.** Nie wykryje, że ta sama kwota została
   przepisana do dwóch satelitów **pod różnymi nagłówkami**. B3 działa na
   numerach sekcji, bo tylko one mają jednoznacznego właściciela.
2. **Nie sprawdza odesłań przychodzących.** W systemie jest **118 wystąpień**
   `TABELE-OPLAT`, w tym kilkanaście w formie „`prawo-polskie-v2/krajowe/shared/TABELE-OPLAT.md` sekcja 4c".
   Po podziale rozwiązuje je **mapa w rdzeniu** — odesłanie nadal prowadzi do
   celu, ale przez jeden skok więcej. Test nie weryfikuje, czy numer sekcji
   w odesłaniu wciąż istnieje. Kandydat na rozszerzenie, **nie zobowiązanie**
   (osobny przebieg kalibracyjny — wniosek z `AUDYT-2026-09-12i`).
3. **Zakres zaszyty na sztywno** (`prawo-polskie-v2/krajowe/shared/TABELE-OPLAT.md`, `prawo-polskie-v2/krajowe/shared/oplaty/`).
   Jeżeli powstanie druga rodzina satelitów — np. dla `prawo-polskie-v2/krajowe/shared/terminy.md` — test trzeba
   sparametryzować, a **nie kopiować**. Dwie rozjeżdżające się implementacje tej
   samej reguły byłyby gorsze niż brak testu (ta sama zasada co przy T24).


---

## T30 — utrata treści bez cofnięcia numeru wersji (dodany 2026-09-16c, F-189)

| Test | Co wykrywa | Waga | Incydent źródłowy |
|---|---|---|---|
| T30 | (A) wiersz tabeli „było → jest" z AUDIT-JOURNAL, którego nowego numeru brak w skillu albo którego stary numer żyje poza kontekstem historycznym; (B) ten sam numer wersji skilla w dwóch sesjach (od 2026-08-24) bez deklaracji „LUKA JAWNA"/„KOLIZJA" | ⭐⭐⭐ KRYTYCZNY (bloker) | `dr-09`: naprawa z 10l zaginęła, a numer 3.29 użyła ponownie sesja 13 — T12 nie mógł tego zobaczyć (AUDYT-2026-09-16b) |

Skrypt: `scripts/check_utrata_tresci.py` (`--selftest` 5/5). Pomiar walidacyjny: na stanie
sprzed napraw z 2026-09-16 — **5 trafień A + 1 B**; po naprawach — 0.
⚠️ Zakres: kontrola A obejmuje tylko wpisy dziennika w postaci tabeli z numerami Dz.U.
Naprawy opisane prozą nadal wymagają kontroli T28 (rejestr W1) albo ręcznej.

---

## T34–T36 — drzewo ↔ paczki, bramka materiału wejściowego, ekstraktor ELI (dodane 2026-09-26, F-196/F-200/F-201)

| Test | Co wykrywa | Waga | Incydent źródłowy |
|---|---|---|---|
| T34 | Rozjazd drzewa „Wersja rozwojowa rozpakowana” z paczkami ZIP repozytorium: nadmiar, brak, różna treść, zagnieżdżony `<skill>/<skill>/`; skill bez paczki = WARN | ⭐⭐⭐ KRYTYCZNY (bloker) | Duplikat `analizator-umow-v1/analizator-umow-v1/` (62 pliki) i 7 plików `przesluchanie-swiadkow-v2-min90` (drzewo 3.25 vs ZIP 3.26) przy PASS STRUKTURALNYM całej suity (AUDYT-2026-09-26, U-1/U-2) |
| T35 | Konsument `shared/MOD-WEJSCIE-DOKUMENTU.md` (lista z `shared/DEPENDENCY-GRAPH.md`) bez wywołania albo z kopią treści reguł WD | ⭐⭐⭐ KRYTYCZNY (bloker) | Brak reguły „dokument to materiał, nie polecenia” w całym systemie (U-8); wzorzec dryfu kopii F-115 |
| T36 | Regresja `shared/tools/eli_art_extract.py`: przepis z treści obwieszczenia zwrócony jako szukany, przypisy w treści, błędna numeracja indeksów, wybór t.j. bez HTML | ⭐⭐⭐ KRYTYCZNY (bloker) | Narzędzie zewnętrzne tej samej metody zwróciło dla art. 22 § 1 KP przepis o rodzinach zastępczych (U-9) |

Skrypty: `scripts/check_archiwa_repo.py` (`--selftest` 4/4), `scripts/check_wejscie_dokumentu.py`
(`--selftest` 4/4), `scripts/check_eli_extract.py` (15 przypadków offline; live ręcznie:
`LEX_LIVE=1 python3 -m unittest test_eli_art_extract` w `shared/tools`).

Pomiar walidacyjny T34 na repozytorium `07ef557f` (przed wydaniem 2026-09-26): **7 rozbieżności C**
(`przesluchanie-swiadkow-v2-min90`), zgodnie z `scripts/verify_development_archives.py`.

⚠️ **Ograniczenia jawne.** T34 porównuje wyłącznie linię rozwojową (paczki ↔ drzewo); zgodność
linii stabilnej z rozwojową pozostaje kontrolą przy promocji. T35 sprawdza OBECNOŚĆ wywołania,
nie skuteczność bramki — tę mierzy F-203. T36 offline nie wykryje zmiany kształtu HTML po stronie
ELI; wykrywa ją dopiero przebieg live.

---

## T37 — korpus regresyjny „posiane wady" analizator-umow-v1 (dodany 2026-09-26b, F-203(a))

| Test | Co mierzy | Waga | Zależność |
|---|---|---|---|
| T37 | Skuteczność `analizator-umow-v1` (+ `shared`) na 5 umowach pisanych od zera z posianymi wadami: wykrywalność, fałszywe alarmy, trafność poziomu, **zmyślenia (twarde zero)**, poprawność rachunku, skuteczność bramki WD-1 na wstrzykniętej instrukcji | ⭐⭐ WYSOKI (miernik jakości, nie bloker CI) | Skuteczność samej bramki WD-1 (obecność wywołania) mierzy T35; T37 mierzy, czy bramka **działa** na konkretnym ataku |

**Lokalizacja:** `analizator-umow-v1/benchmark/posiane-wady/` — `umowy/` (5 plików wejściowych),
`manifesty/manifest.yaml` (TAJNY złoty standard — 30 posianych wad łącznie w 4 umowach + 1 kontrolna
bez wad), `manifesty/instrukcja-sedziego.md` (protokół 5 metryk + warunki FAIL), `wyniki/oceny/`
(katalog docelowy ocen, pusty do pierwszego przebiegu).

**Sposób wykonania (dziś ręczny, brak skryptu):** uruchom `analizator-umow-v1` na każdym pliku z
`umowy/` BEZ udostępniania modelowi/skillowi katalogu `manifesty/` (zasada tajności sędziego), zapisz
wynik, oceń wg `instrukcja-sedziego.md`, zapisz ocenę do `wyniki/oceny/<konfiguracja>.md`.

**Pomiar walidacyjny (2026-09-26b):** korpus dopiero utworzony — **żaden przebieg oceny jeszcze nie
wykonany**. Brak wyniku PASS/FAIL do zaraportowania; to zamierzone — F-203(a) dostarcza korpus i
protokół, nie wynik pomiaru (pierwszy przebieg to F-203(b), otwarte, warunkowane F-113).

⚠️ **Ograniczenia jawne.** (1) Ocena jest ręczna — nie ma jeszcze skryptu porównującego cytaty/ID
wad z manifestem; automatyzacja jest możliwym rozszerzeniem F-203(b), nie zakresem T37. (2) Manifest
i 5 umów są opracowaniem własnym Lex Machina napisanym od zera 2026-09-26 — metodologia i format
(klasy czyste/jawne/ukryte/rachunkowe/adwersarialne, 5 metryk sędziego) zaadaptowane na zasadzie
Apache 2.0 z `commercial-legal-pl/examples/benchmark/` (atrybucja: `analizator-umow-v1/NOTICE` i
`benchmark/posiane-wady/README.md`); oryginalne umowy testowe tamtego projektu nie były dostępne
(`.gitignore` repozytorium źródłowego) i nie zostały skopiowane. (3) T37 nie jest blokerem CI (nie
ma progu pass/fail zdefiniowanego jak T25/T26/T28) — jest miernikiem jakości do ręcznego przeglądu
przy każdej istotnej zmianie `analizator-umow-v1` lub modułów `shared` przez nią konsumowanych.

---

## T38 — manifest pluginu ↔ SKILL.md ↔ marketplace (dodany 2026-09-27e, AUDYT-2026-09-27e)

| Test | Co mierzy | Waga | Zależność |
|---|---|---|---|
| T38 | (A) `<skill>/.claude-plugin/plugin.json` istnieje, `name` = katalog, `version` i `description` = SKILL.md; (B) frontmatter każdego skilla poza `shared` ma `dependencies` wskazujące `shared`; (C) `.claude-plugin/marketplace.json` w korzeniu repo: wpisy ↔ katalogi 1:1, `source` wskazuje katalog wpisu, zależności wpisów istnieją | KRYTYCZNY (BLOKER) | offline; C pomijana, gdy marketplace nie leży obok linii |

**Wykonanie:** `python3 audyt-systemu-v4/scripts/check_plugin_manifest.py --repo-root "Wersja rozwojowa rozpakowana"`;
`--selftest` — 5 przypadków (poprawny, brak plugin.json, rozjazd wersji, brak dependencies, zły source).

**Pomiar walidacyjny (2026-09-27e):** selftest 5/5; drzewo wydania 27e + marketplace z `1552683f`: PASS.

⚠️ **Ograniczenia jawne.** (1) T38 nie wie, jak konkretny host importuje marketplace — sprawdza
kontrakt, który sami przyjęliśmy (manifest = SKILL.md, jawna zależność od `shared`). (2) Reguła B
jest odpowiedzią na pomiar z claude.ai 2026-09-27 (4 z 32 pluginów, jedyna cecha wspólna —
`dependencies` we frontmatterze); mechanizm po stronie hosta nie jest udokumentowany.

## T39 — deterministyczny rachunek umowy (dodany 2026-09-29, AUDYT-2026-09-29, F-215)

| Test | Co mierzy | Waga | Zależność |
|---|---|---|---|
| T39 | (1) `analizator-umow-v1/scripts/test_kontrakt_rachunek.py` — 13 testów: `oblicz` (bezpieczeństwo AST), `ekspozycja` na liczbach umowy 04 = manifest złotego standardu (60 800 / 729 600 / 243,20 / 201,40 / NIEOGRANICZONA / data okna 2027-02-01), liczba bez źródła = BRAK_ZRODLA, odmiana liczebników, martwe odesłania, wykaz załączników w 2 liniach, cytaty; (2) korpus `analizator-umow-v1/benchmark/posiane-wady/`: 05 i3+i6 wykryte, 01 zero alarmów, 04 pary zgodne | KRYTYCZNY (BLOKER) | offline |

**Wykonanie:** `python3 audyt-systemu-v4/scripts/check_kontrakt_rachunek.py --repo-root <drzewo>`.
**Pomiar walidacyjny (2026-09-29):** 13/13 (wpis pierwotnie podawał 14 — korekta 2026-10-01b wg zapisu sesji) + 5/5 kontroli korpusu. Pierwszy przebieg wykrył fałszywy alarm
narzędzia na umowie kontrolnej 01 (wykaz załączników zawinięty na 2 linie) — naprawiony, przypadek w testach.
⚠️ **Ograniczenia jawne.** Narzędzie liczy wg brzmienia umowy; wyekstrahowanie liczb do JSON robi model
(błąd ekstrakcji ≠ błąd rachunku — dlatego każda liczba niesie `zrodlo`). `odeslania` widzi tylko
odesłania jednoznaczne (kat. A); semantyczne ocenia model. Pięć umów to nie jest pomiar skuteczności
na umowach spoza katalogu — to jest regresja.

## T40 — sekrety i PESEL w drzewie (dodany 2026-09-29, AUDYT-2026-09-29, F-216/F-217)

| Test | Co mierzy | Waga | Zależność |
|---|---|---|---|
| T40 | JWT (z rozpoznaniem PESEL w zakodowanym ładunku), klucze PEM, tokeny `sk-ant-`/`ghp_`/`github_pat_`/`AKIA`/`xox*`, PESEL z poprawną sumą kontrolną przy słowie „PESEL”; wartości maskowane w raporcie; wyjątek linii `sekrety:ignoruj` | KRYTYCZNY (BLOKER) | offline |

**Wykonanie:** `python3 audyt-systemu-v4/scripts/check_sekrety.py --repo-root <drzewo>`; `--selftest` 6/6.
**Pomiar walidacyjny (2026-09-29):** pierwszy przebieg na drzewie 6.150 → **8 znalezisk**: prawdziwe PESEL-e
(poprawna suma kontrolna) w wolnym tekście odpisu KRS `mcp-servers/krs-example/fixtures/krs_odpisy.json`
— konektor maskował je na wyjściu, ale plik źródłowy był publiczny (F-217). Po zastąpieniu syntetycznymi
numerami o błędnej sumie: 0 znalezisk, testy KRS PASS.
⚠️ **Ograniczenia jawne.** Skan drzewa roboczego, nie historii gita. PESEL bez słowa „PESEL” w pobliżu
nie jest zgłaszany (inaczej lawina fałszywych trafień na NIP/REGON/numerach rachunków).

## T41 — liczba plików skilla < 200 (dodany 2026-09-29c, AUDYT-2026-09-29c)

| Test | Co mierzy | Waga | Zależność |
|---|---|---|---|
| T41 | liczba plików każdego skilla (z ukrytymi, bez `__pycache__`/`node_modules`) — FAIL ≥ 200, WARN ≥ 190 | KRYTYCZNY (BLOKER) | offline |

**Wykonanie:** `python3 audyt-systemu-v4/scripts/check_limit_plikow.py --repo-root <drzewo>`; `--selftest`.
**Pomiar walidacyjny (2026-09-29c):** przed redukcją `audyt-systemu-v4` 209 → FAIL; po usunięciu 30 reliktów 179 → PASS;
`shared` 195 → WARN (zapas 4 pliki na przyszłe wydania).
⚠️ **Ograniczenie jawne.** T41 liczy pliki, nie ocenia, które są zbędne; redukcja wymaga ustalenia (CHANGELOG,
równoważność treści), a scalanie — zachowania treści w całości.

## T42 — graf przyczynowy: silnik, parytet widgetu, rachunek łańcucha (dodany 2026-10-01b, AUDYT-2026-10-01b)

| Test | Co mierzy | Waga | Zależność |
|---|---|---|---|
| T42 | (A) selftest `shared/tools/graf_przyczynowy.py` — szereg 3×0,9 = 0,729, równolegle 0,999, csqn, cykle, błąd czasu, flagi art. 361/362/441 KC i art. 2 KK, brak fałszywych flag bez jawnych oznaczeń; od 2026-10-02 także NESS (przyczyny nadmiarowe), zaniechanie hipotetyczne, obiektywne przypisanie i art. 5 § 2 KPK, model wykluczeniowy, niezależność dowodów, MET-ACH (niediagnostyczne, ważona niespójność, dowody krytyczne); (B) parytet z blokiem ENGINE widgetu `chronologia-sprawy-v1/assets/widget-graf-przyczynowy.html` na 4 grafach (±1e-6); (C) brak formuły „× 0,9 = 0,27” w MOD-LANCUCH-DOWODOWY i podpięcia MP13 §13.2a, TRYB C, MET-PT | KRYTYCZNY (BLOKER) | offline; Node dla (B) — bez Node WARN |

**Wykonanie:** `python3 audyt-systemu-v4/scripts/check_graf_przyczynowy.py --repo-root <drzewo>`.
**Pomiar walidacyjny (2026-10-01b):** PASS (11+1 przypadków selftestu, 4/4 grafy zgodne); widget dodatkowo
uruchomiony w jsdom: 0 błędów JS, 5 węzłów / 4 krawędzie, scenariusz „obalony Z-003” 0,72 → 0,12 — ta sama
wartość co silnik Python na tych samych danych.
⚠️ **Ograniczenie jawne.** T42 sprawdza rachunek i spójność kodu, nie trafność ocen wprowadzonych do grafu
(pewność węzłów, dowód połączenia, csqn) — te pochodzą z analizy materiału i podlegają MP13 §13.7.

## T43 — sieroty: pliki bez ścieżki wywołania (dodany 2026-10-04b, AUDYT-2026-10-04b, F-225)

| Test | Co sprawdza | Waga | Uruchomienie |
|---|---|---|---|
| T43 | Każdy plik każdego skilla (poza infrastrukturą: SKILL.md, CHECKSUMS, manifesty, README, CHANGELOG) ma odwołanie z innego pliku, który nie jest zapisem historycznym (dziennik, changelog, CHECKSUMS, mapy Dz.U., WARN-OTWARTE, DEDUPLICATION-POLICY, CHECKLIST-DEDUP). Nazwa unikalna w systemie → wystarczy nazwa lub rdzeń; nazwa NIEunikalna → wymagana ścieżka rozstrzygająca (`<skill>/<rel>`, `shared/<rel>`, `dr-NN/<rel>`). Rejestracja folderu w SKILL.md/MANIFEST.md rejestruje jego pliki; moduły wołane kodem (`MD2`, `MP7`, `MD-NARR`) liczone po kodzie w obrębie skilla | KRYTYCZNY (BLOKER) | `python3 scripts/check_sieroty.py --repo-root <katalog skilli>` |

Wynik FAIL = plik do **powiązania** (żywa treść) albo **usunięcia** z wpisem w CHANGELOG (relikt, duplikat).
Allowlista mieszka w skrypcie; każdy wpis wymaga uzasadnienia. ⚠️ **Ograniczenie jawne.** Test mierzy
istnienie odwołania, nie to, czy odwołanie jest w ścieżce wykonania (wzmianka w tabeli rejestru liczy się
tak samo jak `view`). Pierwszy przebieg (2026-10-04b): 65 sierot przed naprawą, 0 po (1 na allowliście).

## T44 — osiągalność `shared` ze skilli produkcyjnych (dodany 2026-10-04d, AUDYT-2026-10-04d)

| Test | Co sprawdza | Waga | Uruchomienie |
|---|---|---|---|
| T44 | Każdy plik `shared` jest osiągalny w grafie odwołań (ścieżkowym, jak T43) od SKILL.md 30 skilli produkcyjnych — bezpośrednio albo łańcuchem plików `shared`. Krawędzie z `audyt-systemu-v4` i z rejestrów (`shared/SKILL.md`, `DEPENDENCY-GRAPH.md`, `PORTABILITY-MANIFEST.md`, `tools/README.md`) NIE liczą się: rejestr wymienia plik, ale go nie wczytuje | KRYTYCZNY (BLOKER) | `python3 scripts/check_osiagalnosc_shared.py --repo-root <katalog skilli>` |

Allowlista (10 pozycji, w skrypcie): metadane hosta, CHECKSUMS, PORTABILITY-MANIFEST, DEPENDENCY-GRAPH (rejestr audytu),
4 fikstury self-testu `tools/przyklady/`. Wpis allowlisty, który przestał być potrzebny, jest raportowany jako ⚠️.
Test negatywny 2026-10-04d: odpięcie `MOD-GENERATOR-AKTU` w `prawo-polskie-v2/krajowe/shared/MODULE-STANDARD-POLISH-LAW.md` → FAIL z nazwą pliku.
⚠️ **Ograniczenie jawne.** Osiągalność ≠ wczytanie w każdej sprawie: łańcuch może prowadzić przez gałąź warunkową.
T44 wykrywa plik, którego NIE wczyta żadna ścieżka; nie mierzy, jak często ścieżka jest używana.

## T45 — mapy aktów: struktura tabel, pokrycie modułów, odesłania (dodany 2026-10-04e, AUDYT-2026-10-04e, F-229)

| Test | Co sprawdza | Waga | Uruchomienie |
|---|---|---|---|
| T45 | (A) każdy wiersz `|…|` w `dr-*/MAPA-AKTOW.md` i `prawo-polskie-v2/ROUTING-MAP.md` należy do tabeli z nagłówkiem i separatorem, a liczba komórek = liczba komórek nagłówka; (B) każdy `dr-*/modules/mod-*.md` występuje w kolumnie „Moduł” mapy swojego DR; (C) każdy `mod-…` z kolumny „Moduł” istnieje w tym DR albo w innym skillu (odesłanie międzydziedzinowe — informacyjnie) | KRYTYCZNY (BLOKER) | `python3 scripts/check_mapy_aktow.py --repo-root <katalog skilli>` |

Przesłanka: aplikacja korzystająca ze skilli nie widziała 26 modułów DR-09 i 2 modułów DR-03, choć oba pliki map je
wymieniały — tabela przerwana cytatem (DR-09) i wiersze 4-kolumnowe w tabeli 3-kolumnowej (DR-03). Parser GFM traktuje
pierwsze jako tekst, w drugich odrzuca nadmiarowe komórki. Test negatywny: stan `main` `f66715f` → FAIL, 191 błędów (DR-03: 4, DR-09: 54 — w tym 26 modułów bez wiersza, ROUTING-MAP: 133).
⚠️ **Ograniczenie jawne.** T45 nie sprawdza aktualności numerów Dz.U. — to robi FAZA 3/T11 i odczyt ELI.


## T50 — klucze jurysdykcji `JUR:` i równoważność migracji (dodany 2026-11-06, migracja prawa polskiego E1–E2)

| Test | Co sprawdza | Waga | Uruchomienie |
|---|---|---|---|
| T50 | (A) każdy klucz w `prawo-polskie-v2/JURYSDYKCJA.md` wskazuje istniejący moduł; (B) każdy `JUR:<klucz>` użyty w skillach ma wiersz w manifeście; (C) każdy wiersz przeniesiony ze skilla wykonawczego (`references/migracja-jurysdykcji/*.tsv`) ma w module klucza linię z tym przepisem i tym terminem | KRYTYCZNY (BLOKER) | `python3 scripts/check_jurysdykcja.py <katalog skilli>` |

Przesłanka: wydzielenie treści prawa polskiego ze skilli wykonawczych (metoda) do pakietu jurysdykcji nie może zgubić
żadnego wiersza. Test negatywny 2026-11-06: termin „21 dni” (art. 264 § 1 KP) zmieniony w tabeli migracji na „99 dni” → FAIL
z nazwą wiersza i modułu. Pilot E2: `analizator-dowodow-v3/modules/MD5-terminy.md` (14 wierszy) → `JUR:terminy-procesowe`.

## T51 — kontrakt testów akceptacyjnych LEGAL GAUNTLET UNIVERSAL v3 (dodany 2026-11-10, etap E2)

| Test | Co sprawdza | Waga | Uruchomienie |
|---|---|---|---|
| T51 | każdy test akceptacyjny T01–T38 (cz. VII specyfikacji) ma w skillach regułę (plik + wzorzec) albo jawną LUKĘ z etapem E3–E7; reguła oznaczona jako pokryta nie może zniknąć | KRYTYCZNY (BLOKER) | `python3 scripts/check_gauntlet_akceptacja.py --repo-root <katalog skilli>` (`--selftest`: mutacja) |

Zachowania modelu nie da się sprawdzić offline; test pilnuje kontraktu i pokazuje listę luk w każdym przebiegu.
Stan 2026-11-11 po E6: pokryte 35, częściowo 3, luka 0. Izolację recenzenta (T16/T17) w aplikacji sprawdza
lex-runtime `independent-review.test.ts`. Mutacja w T49: usunięta reguła „nigdy pytanie w starej sesji”.
