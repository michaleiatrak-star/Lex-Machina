# WARN-OTWARTE — rejestr żywy otwartych flag audytowych

**Stan:** 2026-09-01. Ten plik zawiera wyłącznie zakres pozostający do wykonania. Historia zamknięć i napraw znajduje się w `AUDIT-JOURNAL.md` / `CHANGELOG.md`.

## Tablica sterująca

| Kategoria | Liczba | Pozycje |
|---|---:|---|
| Wykonalne sesją audytową | 4 | F-135, F-141, F-148, O-4 |
| Reaktywne | 1 | F-5 |
| Zależne od środowiska/dewelopera | 9 | F-8, F-9, F-11, F-94, F-113, F-133, F-137, F-143, F-144 |
| **Razem** | **14** | — |

> **F-146 i F-149 ZAMKNIĘTE 2026-09-01b.** F-146: 202 rozjazdy sum rozliczone
> (93 wpisy uzupełnione, 4 wpisy bez pliku rozstrzygnięte jako martwe po
> udokumentowanych przeniesieniach, 105 sum odświeżonych po kontroli
> integralności 198 plików bez śladów utraty); T21 na całym repo PASS. F-149:
> trzy błędne numery Dz.U. wykryte testem T15 na żywym ELI, skorygowane
> i rozpropagowane przez 12 lokalizacji. Szczegóły: `AUDIT-JOURNAL.md`,
> wpis AUDYT-2026-09-01b. Do rejestru żywego nie wchodzą (ZASADA 10).

> **F-147 ZAMKNIĘTA 2026-09-01** w sesji, w której powstała — pięć usterek
> naprawionych i zweryfikowanych ponownym przebiegiem, przyczyna źródłowa objęta
> nowym testem T22 z mutacją negatywną. Szczegóły: `AUDIT-JOURNAL.md`,
> wpis AUDYT-2026-09-01. Do rejestru żywego nie wchodzi (ZASADA 10 — tylko otwarte).

## Wykonalne sesją audytową

| Flaga | Priorytet | Pozostały zakres | Kryterium zamknięcia |
|---|---|---|---|
| F-141 | średni | Trzecia oś T11 (lokalne/ROUTING-MAP vs centralna mapa Dz.U.) — 8 pozycji obecnych w mapach dziedzinowych, brakujących w `mapa_dzu_2026-08-28.md`. Lista robocza (klasa F-104): **2026/980** ustawa o wspieraniu rodziny i systemie pieczy zastępczej (dr-02); **2026/731** zmiana ustawy o radcach prawnych (dr-12); **2026/113** ustawa o pomocy publicznej na ratowanie/restrukturyzację (dr-02); **2024/1111** ustawa lombardowa (dr-02); **2023/845** UPNPR (dr-02); **2022/1722** ustawa o radiofonii i telewizji (dr-02); **2023/123** opłaty w sprawach karnych (dr-03); **2026/1123** prospektywna zmiana ustawy o SN od 1.01.2028 (ROUTING-MAP). ⛔ NIE domykać propagacją z map lokalnych: sekcja „Uzupełnienie mapy” wymaga wprost, by każdy tytuł, typ i status sprawdzić odrębnie w API ELI. Pierwsza próba weryfikacji (2026-08-31, poz. 2026/980) NIE potwierdziła numeru — wyszukiwanie zwróciło t.j. 2025/49 dla tej ustawy. Część numerów w mapach lokalnych może więc być błędna, a nie tylko nieprzeniesiona; przy tej fladze trzeba je rozstrzygnąć, nie przepisać. Powiązane: sześć wierszy ROUTING-MAP zsynchronizowanych 2026-08-31 nosi jawny znacznik ⚠️ NIEZWERYFIKOWANY w RZĘDZIE 1 — znacznik zdejmuje się dopiero po weryfikacji w ramach tej flagi. | Wszystkie 8 pozycji rozstrzygnięte w ELI (potwierdzone albo skorygowane), wpisane do bieżącej mapy Dz.U. z tytułem/typem/statusem; znaczniki ⚠️ NIEZWERYFIKOWANY zdjęte z ROUTING-MAP; T11 w pełnym przebiegu bez WARN. |
| F-148 | średni | Dwie luki czułości testu T15 (`audit_tj_inventory.py`), wykryte 2026-09-01b przy pierwszym przebiegu z ŻYWYM ELI. **(a) Ślepota na podmianę aktu:** test grupuje deklaracje po tytule kanonicznym pobranym z ELI, nie porównuje go z nazwą użytą w rejestrze lokalnym — więc numer, który istnieje, jest obwieszczeniem i jest najnowszy dla SWOJEGO aktu, przechodzi kontrolę nawet wtedy, gdy lokalnie opisano nim inną ustawę. Tak przeszedł błąd F-149(3): `Dz.U. 2026 poz. 884` (t.j. ustawy rehabilitacyjnej) przypisany ustawie o świadczeniu uzupełniającym. Wykrył to człowiek czytający kontekst, nie test. **(b) Dwa trwałe fałszywe trafienia:** `prawo-polskie-v2/ROUTING-MAP.md:219` (parser czyta numer aktu pierwotnego z komórki, która obok podaje poprawny t.j. 2024.1111) oraz `dr-03/modules/mod-KW-art119-131-przeciwko-mieniu.md:220` (świadome odesłanie historyczne; wiersz wyżej cytuje bieżący t.j. 2025.734). ⛔ NIE domykać przez edycję korpusu — modyfikacja treści dla uciszenia testu jest gorsza od szumu; poprawka należy do skryptu, analogicznie do poprawki czułości T11 z F-106. | (a) test porównuje tytuł z ELI z nazwą lokalną i zgłasza rozjazd jako osobną kategorię, z mutacją negatywną na przypadku F-149(3); (b) oba znane trafienia przestają się pojawiać bez zmiany treści korpusu; T15 w trybach `maps`+`operational` bez zgłoszeń nierozstrzygniętych. |
| O-4 | średni | Rejestracja skryptu w `scripts:` NIE gwarantuje, że jest on wywoływany przez `run_regression_suite.py`. Wykryte 2026-09-01: trzy skrypty żyły poza pełnym przebiegiem (`test_f108_trade.py`, `mock_eli_server_test.py` — oba ZEPSUTE od dni, awaria niewidoczna; oraz świeżo dodany T22). Wpięte ręcznie w tej sesji, ale nic nie pilnuje, żeby następny dodany test też został wpięty. Do rozstrzygnięcia: czy dodać test T23 wymagający, by każdy zarejestrowany skrypt testowy był albo wywoływany przez orkiestrator, albo miał jawnie odnotowany status RĘCZNY (jak T4/T5). ⛔ NIE domykać samym przeglądem wzrokowym listy — to dokładnie ten rodzaj kontroli, który przepuścił F-147. | Każdy skrypt `test_*`/`check_*` z rejestru `scripts:` ma przypisany status: wywoływany przez orkiestrator albo RĘCZNY z uzasadnieniem; rozbieżność wykrywana automatycznie. |
| F-135 | średni | Dokończyć cross-check wartości prawnych w pozostałych DR, elementów unikalnych oraz `shared`; każdą rozbieżność rozstrzygnąć w źródle urzędowym albo jawnie oznaczyć jako nieweryfikowalną. | Zero nieuzasadnionych rozbieżności albo jawne oznaczenie nieweryfikowalnych pozycji. |

## Reaktywne

| Flaga | Zakres | Wyzwalacz |
|---|---|---|
| F-5 | Dedykowany moduł ustawy ESAP (Dz.U. 2026 poz. 644) oraz ustalenie wpływu na KSH. | Pierwsza sprawa z rynku kapitałowego lub nadzoru finansowego. |

## Zależne od środowiska lub dewelopera

| Flaga | Pozostały zakres |
|---|---|
| F-8 | Wdrożyć realny connector MCP do ELI/ISAP i zweryfikować protokół w środowisku docelowym. |
| F-9 | Wdrożyć znacznik `AUDIT_EVENT`, parser i politykę retencji w portalu. |
| F-11 | Uruchomić `extract_api_verification_log.py` na prawdziwej odpowiedzi API zawierającej wywołania narzędzi. |
| F-94 | Rozstrzygnąć rejestrację `KONEKTORY-REKOMENDOWANE.md`, status `shared/tools/mcp-servers/` i możliwy duplikat checklisty contradiction-intelligence. |
| F-113 | Potrzebne izolowane manifesty A/B, kontrola sieci T1/T2, autorytatywne logi narzędzi i identyfikator backendu do wykonania mierzalnego testu skuteczności bramek. |
| F-133 | Brak warunków środowiskowych do pomiaru B5-e2 i wpływu reguł routera; zależne od warunków F-113. |
| F-137 | Pozostał test akceptacyjny zapisu wydzielonej sekcji w hoście z natywną pamięcią trwałą. |
| F-143 | Pomiar skuteczności OŚ-GATE (`shared/MOD-OS-CZASU-PRZESLANEK.md`) testem z grupą kontrolną wg `PLAN-TESTU-BRAMEK-F113.md`: ≥10 kazusów w dwóch ramionach, dwa kryteria — (i) czy blok OŚ-GATE faktycznie się pojawił, (ii) w ilu przebiegach zmienił konkluzję. Zakres pozostały obejmuje też dwa niewykonane wpięcia oznaczone ⬛ w §9 modułu: `analiza-sadowa-v6` (przebieg 1) i `analizator-przepisow-v2` (Moduł 3). Do zamknięcia flagi ZAKAZ opisywania modułu jako rozwiązującego problem rozjazdu czasowego. Zależne od tych samych warunków co F-113. |
| F-144 | Pomiar skuteczności WYJ-GATE (`shared/MOD-WYJATEK-GATE.md`) testem z grupą kontrolną wg `PLAN-TESTU-BRAMEK-F113.md`: ≥10 kazusów w dwóch ramionach, dwa kryteria — (i) czy blok WYJ-GATE wystąpił przy powołanym artykule i miał wszystkie cztery zamiatania S1–S4, (ii) w ilu przebiegach któreś zamiatanie zmieniło konkluzję. Drugi zakres: uruchomienie gałęzi sieciowej `scripts/check_wyjatek_gate_eli.py` (S1 `text.html`, S3 `references`) na żywym api.sejm.gov.pl/eli — w środowisku audytu domena jest poza listą dozwoloną, przetestowano wyłącznie parsery (`--selftest` 8/8 + mutacja). Trzeci zakres: dwa niewykonane wpięcia oznaczone ⬛ w §9 modułu — `analizator-przepisow-v2` (Moduł 1/1H) i `pisma-procesowe-v3` (PRE-W2). ⛔ Do zamknięcia flagi ZAKAZ opisywania WYJ-GATE jako mechanizmu, który „wyłapuje wyjątki" — dowiedziona jest wyłącznie jego obecność i poprawność zakresów na fixture. Zależne od tych samych warunków co F-113. |

## Zasada map runtime

- `MAPA-AKTOW.md` = aktualny akt → moduł;
- `MAPA-POKRYCIA.md` = aktualny faktyczny poziom pokrycia;
- mapy runtime nie przechowują baseline/delta ani historii dawnych luk;
- historia zmian trafia wyłącznie do `AUDIT-JOURNAL.md` / `CHANGELOG.md`;
- każda konkretna jednostka prawa nadal wymaga fresh gate do źródła urzędowego.
