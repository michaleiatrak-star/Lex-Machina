---
name: dr-15-compliance-iso-governance-audyt
version: "3.19"
description: "Compliance, governance i audyt: systemy zgodności, sygnaliści, AML instytucjonalny, zarządzanie ryzykiem, kontrole, ISO i audyt organizacyjno-prawny."
dependencies:
  requires:
    - shared
  # 2026-09-27e: jawna zależność (każdy skill systemu korzysta z `shared`); pole czytane przy imporcie z marketplace
---

> **Universal runtime:** przed wykonaniem zastosuj kanoniczny `shared/UNIVERSAL-RUNTIME-ADAPTER.md` z osobnego skilla `shared`. Lokalna sekcja adaptera poniżej jedynie go doprecyzowuje.


## ADAPTER RUNTIME — PORTABILITY (ChatGPT / Claude / inne hosty)

Ta sekcja zmienia wyłącznie wykonanie operacji technicznych. Merytoryka dziedzinowa, mapy aktów, hard gate’y, kolejność modułów i kryteria jakości tego DR-skilla pozostają bez zmian.

1. `view dr-15-compliance-iso-governance-audyt/<plik>` oraz `view modules/...` / `view references/...` oznaczają świeży odczyt odpowiedniego lokalnego pliku tego skilla. Literalna ścieżka `/mnt/skills/user` nie jest wymagana.
2. `view shared/<plik>` oznacza świeży odczyt z osobnego, kanonicznego skilla `shared`. NIE kopiuj `shared` do tej paczki. Brak obowiązkowego zasobu shared = fail-closed, nie substytucja pamięcią modelu.
3. `view <inny-skill>/<plik>` oznacza aktywację/odczyt wskazanego osobnego skilla. Nie vendoryzuj innych skilli do tego ZIP-a.
4. `web_search` / `web_fetch` i podobne nazwy oznaczają świeże wyszukanie/odczyt online przez równoważną funkcję hosta. Zachowaj wymagane źródła oficjalne, statusy weryfikacji i zakaz cytowania prawa z pamięci.
5. `show_widget`, `visualize:read_me`, `present_files`, `create_file`, shell/Python i podobne operacje są nazwami semantycznymi. Jeśli host nie ma literalnego narzędzia, użyj równoważnej funkcji natywnej bez omijania bramek jakości.
6. `/mnt/user-data/...` oznacza rzeczywiste załączniki użytkownika dostępne w bieżącym hoście; wymagany ponowny odczyt ma być faktycznym odczytem źródła.

**Zasada nadrzędna:** instrukcje, które są już zrozumiałe i wykonalne w bieżącym hoście, wykonuj bez konwersji. Adapter działa wyłącznie na granicy runtime.


# DR-15 — Compliance, ISO, Governance, Audyt

## ⛔ HARD GATE — ZAKAZ CYTOWANIA Z PAMIĘCI

**PRZED każdym powołaniem przepisu, artykułu, klauzuli normy, terminu lub sygnatury:**
1. Zweryfikuj brzmienie i Dz.U. w `ELI (RZĄD 1)`
2. Zweryfikuj rozporządzenia UE w `eur-lex.europa.eu`
3. Zweryfikuj status normy ISO w `iso.org` lub PKN (pkn.pl)
4. Zweryfikuj orzeczenie w `orzeczenia.ms.gov.pl` / `nsa.gov.pl` / `sn.pl`
5. **NIGDY** nie podawaj artykułu, klauzuli normy, kary ani terminu wyłącznie z pamięci modelu.

**Obszar compliance był intensywnie legislowany w 2024–2026:**
- Ustawa o sygnalistach (Dz.U. 2024 poz. 928) — stosunkowo nowa, mogły wejść nowelizacje.
- AI Act (Rozp. UE 2024/1689) stosowany etapami: zakazy 02.2025, GPAI 08.2025, pełne 08.2026.
- DORA (Rozp. UE 2022/2554) stosowane od 17.01.2025 — standardy techniczne RTS nadal publikowane.
- Ustawa AML — weryfikuj aktualny tekst jednolity przed każdym użyciem.


> ⛔ **SELF-CHECK ANTY-FASADA — obowiązkowy przed wysłaniem odpowiedzi/pisma**
> (podłączone 2026-08-24, flaga F-115 P3 — zamknięcie zakresu 16 skilli DR):
>
> ```
> view shared/SELF-CHECK-ANTY-FASADA.md
> ```
>
> Sprawdza dwie rzeczy: (1) czy w tekście stoi „zweryfikowano", data weryfikacji
> albo URL przy przepisie, dla którego NIE wywołano narzędzia W TEJ ODPOWIEDZI;
> (2) czy znacznik statusu nie został nadany treści WYGENEROWANEJ w tej odpowiedzi
> (AF-6). Treść listy jest w module, nie tutaj — celowo, żeby nie powstało kolejne
> miejsce dryfu (7 wcześniejszych kopii rozjechało się ze źródłem przy pierwszej
> zmianie brzmienia).
>
> ⛔ Wyzwalaczem jest BRAK WYWOŁANIA NARZĘDZIA dla danego twierdzenia w danej
> odpowiedzi — nie brak narzędzi w sesji. Niedostępność ELI (oba kanały) nie zwalnia z
> oznaczenia, tylko je wymusza; niedostępność ISAP to stan normalny.

---

## Zasada architektoniczna
- Jeden moduł = jeden akt prawny (tekst jednolity Dz.U.) LUB jedna norma ISO / rozporządzenie UE
- Wyjątek: wydzielone rozdziały jednej ustawy mogą mieć osobny moduł (z adnotacją)
- Ten sam akt NIE może pokrywać dwóch różnych DR-skills
- **Zakaz cytowania przepisów i klauzul norm z pamięci — każde brzmienie weryfikuj w źródle**
- **Prawo compliance i regulacje UE zmieniają się dynamicznie — weryfikuj ZAWSZE**

---

## ORKA-BAS — Definicje wspomagające (shared/ORKA-BAS-LEKSYKON.md)

Przy sprawach z tej dziedziny rozważ doładowanie (`view`) definicji:
- BAS-W19 Sygnalista — definicja ustawowa (Dz.U. 2024 poz. 928, od 25.09.2024 —
  kontekst związany z pracą, kanały zgłoszeń, odwrócony ciężar dowodu)
- BAS-W25 Uzasadniony interes administratora RODO (LIA — istotne dla compliance danych)

## DEFINICJE — shared/definicje/ (bezpośrednie, lazy loading per temat)

- `definicje/DEF-INTERES-WLASNY-WYLACZENIA.md` (sekcja 6 — RZECZYWISTY
  BENEFICJENT / UBO) — "strona ukryta" w strukturach własnościowych,
  figurant/słup, zlecenie powiernicze (art. 734 i n. KC), Centralny Rejestr
  Beneficjentów Rzeczywistych (CRBR), ustawa AML art. 2 ust. 2 pkt 1)
  — kluczowe dla due diligence AML i compliance KYC
<!-- lex:wykonuje-aplikacja: REJESTR-MODULOW -->
## Moduły (10 łącznie — ✓ 10 OK, ☐ 0 STUB)

```
PRAWO KRAJOWE — COMPLIANCE I NADZÓR:
  [✓] OK    mod-AML-nadzor-finansowy-instytucje
              (Dz.U. 2025 poz. 644 t.j. ze zm.;
               GIIF, KNF, instytucje obowiązane, beneficjent rzeczywisty,
               kary administracyjne, procedury compliance, odwołania)

  [✓] OK    mod-ustawa-sygnalisci
              (Dz.U. 2024 poz. 928 ze zm.; Dyrektywa UE 2019/1937;
               kanał wewnętrzny, zgłoszenia zewnętrzne do RPO, ujawnienie publiczne,
               ochrona przed działaniami odwetowymi, obowiązki pracodawcy ≥ 50 prac.,
               rejestr zgłoszeń, odpowiedzialność karna za odwet i ujawnienie tożsamości)

  [✓] OK    mod-ustawa-antykorupcyjna-1997-ograniczenia
              (Dz.U. 2025 poz. 499 t.j. ze zm.; ustawa z 21.08.1997 r.;
               ograniczenie prowadzenia działalności gospodarczej przez osoby
               pełniące funkcje publiczne, oświadczenia majątkowe, wygaśnięcie
               mandatu jako sankcja administracyjno-ustrojowa — NIE karna,
               z wyjątkiem wąskiego art. 15 dot. nielegalnego zatrudnienia;
               ⚠️ dodany 2026-07-16, zarejestrowany dopiero 2026-07-26 —
               naprawiono niezarejestrowanie zgodnie z Regułą 2)

  [✓] OK    mod-PZP-zamowienia-obronne-bezpieczenstwa
              (t.j. Dz.U. 2026 poz. 793 ze zm. — ✅ [VER] RZĄD 1 2026-09-16e;
               zamówienia sektorowe i obronne, wyłączenia PZP,
               tajemnica przedsiębiorstwa i informacje niejawne, odwołania KIO,
               ryzyka bezpieczeństwa infrastruktury krytycznej)

  [✓] OK    mod-ustawa-nauczyciele-uczelnie
              (Karta Nauczyciela — Dz.U. 2023 poz. 984 ze zm.;
               Prawo o szkolnictwie wyższym i nauce — Dz.U. 2024 poz. 1571 ze zm.;
               dyscyplinarka nauczyciela/akademika, ocena pracy, awans,
               odpowiedzialność dyscyplinarna uczelni, dostosowania niepełnosprawności)

REGULACJE UE — COMPLIANCE SEKTOROWY:
  [✓] OK    mod-DORA-compliance-sektor-finansowy
              (Rozp. UE 2022/2554 — stosowane od 17.01.2025;
               5 filarów: zarządzanie ryzykiem ICT, incydenty, testy TLPT,
               ryzyko dostawców ICT, wymiana informacji;
               raportowanie do KNF: 4h / 24h / 1 miesiąc;
               RTS — standardy techniczne EBA/ESMA/EIOPA — Dz.Urz. UE L 2024–2025)

NORMY ISO — ZARZĄDZANIE I CERTYFIKACJA:
  [✓] OK    mod-ISO-37301-compliance-management
              (ISO 37301:2021 — Compliance management systems;
               zastąpiła wycofaną ISO 19600:2014; certyfikowalna przez PCA;
               klauzule: kontekst org., przywództwo, planowanie, wsparcie,
               operacje, ocena wyników, doskonalenie;
               powiązana: ustawa o sygnalistach Dz.U. 2024 poz. 928; KK art. 296)

  [✓] OK    mod-ISO-37001-antykorupcja
              (ISO 37001:2016 — Anti-bribery management systems;
               polityka antykorupcyjna, ocena ryzyka łapówkarstwa,
               due diligence kontrahentów, kontrole finansowe, kanał zgłoszeń;
               certyfikacja przez PCA; powiązana: ustawa o sygnalistach)

  [✓] OK    mod-ISO-27001-bezpieczenstwo-informacji
              (ISO/IEC 27001:2022 — Information security management systems;
               ISO 22301:2019 — ciągłość działania (BCP/DRP/BIA);
               ISO 31000:2018 — zarządzanie ryzykiem (niecertyfikowalny);
               powiązana: ustawa KSC — Dz.U. 2024 poz. 1226 ze zm.;
               KSC art. 8: OUK obowiązani do systemu zarządzania bezp. informacji)

  [✓] OK    mod-ISO-42001-AI-management
              (ISO/IEC 42001:2023 — Artificial intelligence. Management system;
               AI Act — Rozp. UE 2024/1689; zakazy AI od 02.02.2025;
               systemy wysokiego ryzyka — obowiązki dostawcy art. 16, deployera art. 26;
               GPAI od 08.2025; kary: do 35 mln EUR lub 7% obrotu rocznego;
               organ krajowy ds. AI: Polska — wyznaczenie w toku [WERYFIKUJ])
```

---

## Jak wywołać

```
view dr-15-compliance-iso-governance-audyt/modules/[nazwa-modulu].md
```

## Lokalna mapa aktów prawnych

```
view dr-15-compliance-iso-governance-audyt/MAPA-AKTOW.md
```

## Mapa pokrycia treściowego (planowanie rozwoju skilla)

Rejestr informacyjny — NIE krok obowiązkowy przy obsłudze konkretnej sprawy.
Jedyne bieżące źródło statusu pokrycia tego DR (por. `prawny-router-v3/references/pokrycie-dziedzinowe.md`);
przy nowelizacji pokazuje, czy dotknięty fragment ma treść do zaktualizowania:

```
view dr-15-compliance-iso-governance-audyt/MAPA-POKRYCIA.md
```

---

## Powiązania zewnętrzne
- Wchodzi z: `prawo-polskie-v2` → `ROUTING-MAP.md` → ten skill
- AML (aspekt karny / KKS) → `dr-03` → `mod-KKS-karny-skarbowy-i-AML`
- Zamówienia publiczne (PZP ogólne) → `dr-07-zamowienia-publiczne-fundusze-ue/modules/mod-PZP-zamowienia-publiczne-KIO.md`
- Cyberbezpieczeństwo / KSC / NIS2 → `dr-11` → `mod-KSC-NIS2-cyberbezpieczenstwo-telekom`
- RODO / dane osobowe → `dr-11` → `mod-RODO-GDPR-2016-679`
- Prawo pracy (KP, PIP, zwolnienie sygnalisty) → `dr-04`
- Prawo bankowe / finanse sektorowe → `dr-06`
- Zarządzanie kryzysowe / bezpieczeństwo państwa → `dr-13`
- Wychodzi do: `pisma-procesowe-v3` / `analiza-sadowa-v6` / `orzeczenia-sadowe-v2`
- Weryfikacja: ELI (RZĄD 1) | eur-lex.europa.eu | iso.org | pkn.pl | orzeczenia.ms.gov.pl | nsa.gov.pl | sn.pl

## ⚖️ DISCLAIMER (obowiązkowy)

Po zakończeniu analizy lub przed oddaniem odpowiedzi zawierającej ocenę prawną:

```text
view shared/DISCLAIMER.md
```

Wybierz wariant odpowiedni do trybu:
- **PRAWNIK / kancelaria** → wariant techniczny (art. 4 Prawa o adwokaturze / art. 6 u.r.p.)
- **LAIK / pro se** → wariant uproszczony (informacja ≠ porada prawna)

Disclaimer musi być **ostatnim elementem** każdej odpowiedzi zawierającej analizę prawną,
ocenę szans, kwalifikację prawną lub interpretację przepisu.
