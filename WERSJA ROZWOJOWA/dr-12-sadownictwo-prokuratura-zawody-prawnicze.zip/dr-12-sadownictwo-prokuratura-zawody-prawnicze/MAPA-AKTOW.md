# DR-12 — Lokalna Mapa Aktów Prawnych

**Stan operacyjny:** 2026-08-28

Mapa zawiera wyłącznie akty i źródła używane obecnie. Historia korekt oraz przyszłe zmiany niewchodzące jeszcze w życie pozostają poza runtime.

## Sądownictwo, prokuratura, zawody prawnicze

| Akt / zakres | Aktualna podstawa operacyjna | Moduł | Status |
|---|---|---|---|
| Prawo o ustroju sądów powszechnych | aktualny tekst ELI/ISAP; kanonicznie DR-01 | → DR-01/`mod-USP-ustroj-sadow-powszechnych` | 🔗 |
| Rozporządzenie MS z 28.12.2018 r. w sprawie siedzib i obszarów właściwości sądów powszechnych oraz zakresu spraw (art. 20 pkt 1 PUSP) — sąd właściwy miejscowo, zakres spraw SR | t.j. Dz.U. 2026 poz. 492 (obejmuje 2025/1012, 2025/1607, 2026/392; brak zmian po t.j.) ✅ [VER] RZĄD 1 2026-10-17 (ELI DU/2018/2548 + text.pdf); tabela 319 SR: `references/wlasciwosc-sadow-tj-2026-492.tsv`; aplikacja: `court_for_address` | `mod-wlasciwosc-miejscowa-sadow-powszechnych` | ✅ aktywny |
| Prawo o prokuraturze | Dz.U. 2026 poz. 810 t.j. + późn. zm. (⚡ art. 11 § 1 — roczna informacja PG o kontroli operacyjnej: zm. Dz.U. 2026 poz. 1281 art. 8, w mocy 31.10.2026); fresh gate ELI | `mod-PrProkuratura-organy-ochrony-prawa` | 🟢 B+/COV |
| KPC — arbitraż i mediacja | Dz.U. 2026 poz. 468 t.j. + późn. zm. | `mod-KPC-arbitraz-mediacja-ADR` | ✅ |
| Mediacja — techniki i metodyka | bieżące standardy mediacji i wiedza fachowa; konkretne źródło wymaga fresh gate | `mod-techniki-mediacyjne-negocjacyjne` | ✅ aktywny; soft law / metodyka |
| regulatorzy UOKiK / URE / UKE / KNF | właściwe bieżące ustawy sektorowe; nie istnieje jeden zbiorczy Dz.U. | `mod-ustawa-regulatorzy-UOKiK-URE-UKE-KNF` | ✅ / fresh gate per regulator |
| sędziowie, referendarze, kuratorzy | właściwe bieżące ustawy ustrojowe i zawodowe | `mod-ustawa-sedziowie-referendarze-kuratorzy` | ✅ / fresh gate |
| odpowiedzialność dyscyplinarna zawodów | właściwa ustawa korporacyjna + kodeks etyki danego zawodu | `mod-ustawa-odpowiedzialnosc-dyscyplinarna-zawodow` | ✅ |
| koszty sądowe w sprawach cywilnych | Dz.U. 2025 poz. 1228 t.j.; zmiany po t.j.: Dz.U. 2026 poz. 473 (8.07.2026), 1003 (28.10.2026), 346 (30.09.2028) ✅ [VER] RZĄD 1 2026-10-11 (ELI `/references`, „Akty zmieniające” po ostatnim t.j.; daty — pole `date` ELI) | `mod-KSCU-koszty-sadowe-i-pomoc-prawna` | ✅ |
| KPC — biegli sądowi i opinie | Dz.U. 2026 poz. 468 t.j. + późn. zm. | `mod-KPC-biegli-sadowi-opinie` | ✅ |
| Prawo o adwokaturze | Dz.U. 2024 poz. 1564 t.j.; zmiany po t.j.: Dz.U. 2025 poz. 1172 (1.03.2026), 2026 poz. 370 (3.04.2026), 846 (1.10.2026), 1290 ✅ [VER] RZĄD 1 2026-10-11 (ELI `/references`, „Akty zmieniające” po ostatnim t.j.; daty — pole `date` ELI); w tym Dz.U. 2026 poz. 1290 — obowiązuje od 17.10.2026 (art. 1 pkt 16, 41, 42 od 1.01.2027): art. 7 ust. 3 ochrona funkcjonariusza publicznego, art. 4 ust. 1 definicja pomocy prawnej, dział VIIIa przepisy karne (art. 95o–95q) ✅ [VER] RZĄD 1 2026-10-09 (ELI DU/2026/1290 + text.pdf); ustawa o świadczeniu przez prawników zagranicznych pomocy prawnej w RP — t.j. Dz.U. 2020 poz. 823, zmiana po t.j.: Dz.U. 2026 poz. 1290 art. 2 (art. 10 ust. 5) i przejściowy art. 5, od 17.10.2026; rozp. MS z 8.09.2016 (system teleinformatyczny list NRA) Dz.U. 2016 poz. 1430 — uznane za uchylone od 17.10.2026 ✅ [VER] RZĄD 1 2026-10-19 (ELI DU/2002/1069 `/references`, DU/2026/1290 text.pdf, DU/2016/1430) | `mod-ustawa-adwokatura` | ✅ B+/COV |
| ustawa o radcach prawnych | Dz.U. 2024 poz. 499 t.j.; zmiany po t.j.: Dz.U. 2025 poz. 1172 (1.03.2026), 2026 poz. 370 (3.04.2026), 731 (18.06.2026), 846 (1.10.2026) ✅ [VER] RZĄD 1 2026-10-11 (ELI `/references`, „Akty zmieniające” po ostatnim t.j.; daty — pole `date` ELI); w tym Dz.U. 2026 poz. 731 obowiązujący od 18.06.2026 (art. 12 ust. 1 — ochrona funkcjonariusza publicznego) | `mod-ustawa-radcowie-prawni` | ✅ B+/COV |
| Prawo o notariacie | Dz.U. 2026 poz. 614 t.j. + późn. zm. | `mod-ustawa-notariat` | ✅ |
| ustawa o komornikach sądowych | Dz.U. 2026 poz. 881 t.j. + późn. zm. | `mod-ustawa-komornicy-sadowi-zawod` | ✅ |
| ustawa o rzecznikach patentowych | Dz.U. 2026 poz. 778 t.j. + późn. zm. | `mod-ustawa-rzecznicy-patentowi-zawod` | ✅ |

## Kodeksy etyki zawodowej — źródła kanoniczne

Kodeksy etyki są aktami korporacyjnymi właściwych samorządów, a nie aktami publikowanymi w Dzienniku Ustaw. Przed użyciem pobierz bieżący tekst z oficjalnej strony właściwego organu.

| Zawód | Bieżące źródło kanoniczne | Status |
|---|---|---|
| adwokat | NRA — Kodeks Etyki Adwokackiej, tekst jednolity uchwała nr 174/2026 Prezydium NRA z 23.06.2026 | ✅ B+/COV |
| radca prawny | KIRP/KRRP — KERP, tekst jednolity uchwała nr 884/XI/2023 Prezydium KRRP | ✅ B+/COV |
| notariusz | Krajowa Rada Notarialna — aktualny Kodeks Etyki Zawodowej Notariusza | fresh gate |
| komornik sądowy | Krajowa Rada Komornicza — aktualny Kodeks Etyki Zawodowej Komornika Sądowego | fresh gate |
| rzecznik patentowy | właściwy samorząd rzeczników patentowych — aktualne Zasady Etyki | fresh gate |
| lekarz / lekarz dentysta | Naczelna Izba Lekarska / Krajowy Zjazd Lekarzy | routing DR-10 |
| pielęgniarka / położna | NIPiP / Krajowy Zjazd | routing DR-10 |
| farmaceuta | Naczelna Izba Aptekarska | routing DR-10 |
| lekarz weterynarii | Krajowa Izba Lekarsko-Weterynaryjna | routing DR-10 |
| diagnosta laboratoryjny | KIDL | routing DR-10 |
| doradca podatkowy | KIDP | routing DR-06 |
| biegły rewident | PIBR/KRBR + PANA w zakresie zatwierdzeń/nadzoru | routing DR-15 |
| architekt / inżynier budownictwa | IARP / PIIB | routing DR-09/15 |

## Reguła runtime

1. Mapa wskazuje wyłącznie bieżący akt/źródło i moduł, nie historię korekt ani przyszłe zmiany.
2. `MAPA-POKRYCIA.md` wskazuje bieżącą głębokość pokrycia.
3. Każda konkretna jednostka prawa wymaga fresh gate do ELI/ISAP.
4. Kodeks etyki i soft law wymagają fresh gate do oficjalnego źródła właściwego organu.
