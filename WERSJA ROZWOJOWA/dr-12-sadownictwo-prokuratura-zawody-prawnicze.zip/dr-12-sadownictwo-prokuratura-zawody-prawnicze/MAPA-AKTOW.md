# DR-12 — Lokalna Mapa Aktów Prawnych

## Sądownictwo, Prokuratura, Zawody Prawnicze

| Akt prawny | Dz.U. (t.j.) | Moduł | Status |
|---|---|---|---|
| Ustawa Prawo o ustroju sądów powszechnych | Dz.U. 2024 poz. 334 ze zm. | → DR-01/mod-USP-ustroj-sadow-powszechnych | 🔗 odesłanie |
| Ustawa Prawo o prokuraturze + organy ochrony prawa | Dz.U. 2024 poz. 390 ze zm. — VER 2026-07-02eee: nadal aktualne (potwierdzone krzyżowo przez gov.pl/MS + orka.sejm.gov.pl) | mod-PrProkuratura-organy-ochrony-prawa | ✅ OK |
| KPC — arbitraż i mediacja (cz. V) | Dz.U. 2026 poz. 468 ze zm. | mod-KPC-arbitraz-mediacja-ADR | ✅ OK |
| Ustawa o regulatorach (UOKiK, URE, UKE, KNF) | UOKiK: Dz.U. 2025 poz. 1714 t.j. + URE: Prawo energetyczne Dz.U. 2026 poz. 43 t.j. + UKE: Prawo komunikacji elektronicznej Dz.U. 2024 poz. 1221 + ustawa o wspieraniu rozwoju usług i sieci telekom. Dz.U. 2025 poz. 311 t.j. + KNF: ustawy sektorowe (sprawdzać każdorazowo) ✅ VER: 2026-06-14 (TRYB DZU — był 2024/1221 sam; to PKE/UKE, nie UOKiK — rozwinięto wiersz, zgodny z tabelą wewnętrzną modułu) | mod-ustawa-regulatorzy-UOKiK-URE-UKE-KNF | ✅ OK |
| Ustawa o sędziach, referendarzach i kuratorach | Dz.U. 2024 poz. 334 ze zm. | mod-ustawa-sedziowie-referendarze-kuratorzy | ✅ OK |
| Ustawa o odpowiedzialności dyscyplinarnej zawodów | Ustawy korporacyjne | mod-ustawa-odpowiedzialnosc-dyscyplinarna-zawodow | ✅ OK |
| Ustawa o kosztach sądowych i pomocy prawnej (KSCU) | Dz.U. 2025 poz. 1228 t.j. ✅ VER: 2026-06-14 (TRYB DZU — był 2024/1303) | mod-KSCU-koszty-sadowe-i-pomoc-prawna | ✅ OK |
| KPC — biegli sądowi i opinie | Dz.U. 2026 poz. 468 ze zm. | mod-KPC-biegli-sadowi-opinie | ✅ OK |
| Ustawa Prawo o adwokaturze | Dz.U. 2024 poz. 1564 ze zm. — VER 2026-07-02eee: nadal aktualne (obwieszczenie 11.10.2024, potwierdzone bezpośrednio przez isap.sejm.gov.pl/WDU20240001564 + gov.pl/MS). Odnotowuje się, że TEN SAM numer (2024.1564) był omyłkowo cytowany w dr-10/MAPA-AKTOW.md jako "zbiorczy" dla "zawodów medycznych i prawniczych" — potwierdza to wcześniejsze ustalenie (sesja 2026-07-02y), że ten wiersz w dr-10 był błędnie skonstruowany: 2024.1564 to WYŁĄCZNIE Prawo o adwokaturze, nie zbiorczy numer dla wielu zawodów | mod-ustawa-adwokatura | ✅ OK |
| Ustawa o radcach prawnych | Dz.U. 2024 poz. 499 ze zm. — VER 2026-07-02eee: nadal aktualne (potwierdzone krzyżowo) | mod-ustawa-radcowie-prawni | ✅ OK |
| Ustawa Prawo o notariacie | Dz.U. 2026 poz. 614 t.j. ✅ VER: 2026-06-14 (TRYB DZU — był 2022/1799) | mod-ustawa-notariat | ✅ OK |
| Ustawa o komornikach sądowych (zawód) | Dz.U. 2024 poz. 1458 t.j. ✅ VER: 2026-06-14 (TRYB DZU — był 2023/1691, potwierdzono że 2024/1458 [ROUTING] jest aktualnym t.j., nie 2026/26 — KOREKTA błędnego wyniku wcześniejszego wyszukiwania) | mod-ustawa-komornicy-sadowi-zawod | ✅ OK |
| Ustawa o rzecznikach patentowych (zawód) | ⚠️ Dz.U. 2025 poz. 591 t.j. (POPRAWKA 2026-07-02ppp — BYŁO błędnie 2024.749; potwierdzone przez bezpośredni cytat w rozporządzeniu wykonawczym z odesłaniem "art. 68 ustawy... Dz.U. z 2025 r. poz. 591" — ⚠️ znaleziono też poszlakę jeszcze nowszego t.j. 2026.778, NIEROZSTRZYGNIĘTĄ w tej sesji, wymaga potwierdzenia) | mod-ustawa-rzecznicy-patentowi-zawod | ⚠️ WYMAGA AKTUALIZACJI MODUŁU (i możliwej kolejnej weryfikacji 2026.778) |

> 🔗 Prawo o ustroju sądów powszechnych jest kanonicznie w DR-01 (ustrój konstytucyjny).
> ℹ️ Prawo o notariacie: moduł `mod-PrNotariat-notariat-rejestry` w DR-07 (aspekt rejestrowy/zamówieniowy); tutaj `mod-ustawa-notariat` obsługuje zawód notariusza i odpowiedzialność dyscyplinarną.

> Aktualizacja: 2026-07-02eee (TRYB DZU krok 10/16 wg WARN-26, ZAMKNIĘTY:
> 0 błędów CRIT — wszystkie sprawdzone pozycje potwierdzone aktualne
> [Prawo o prokuraturze, Prawo o adwokaturze, radcy prawni] + pozostałe
> większość już VER 2026-06-14 (KSCU, Prawo o notariacie, komornicy,
> rzecznicy patentowi, regulatorzy UOKiK/URE/UKE/KNF) lub potwierdzone via
> FAZA 3A/dr-07 tego samego dnia (KPC). Efekt uboczny: rozstrzygnięto
> częściowo niejasność strukturalną z dr-10 (numer 2024.1564 = wyłącznie
> Prawo o adwokaturze, nie zbiorczy dla wielu zawodów)

## KODEKSY ETYKI ZAWODOWEJ — ZAWODY ZAUFANIA PUBLICZNEGO (dodano 2026-07-02, na żądanie użytkownika)

⚠️ **Uwaga systemowa:** kodeksy etyki zawodowej to akty KORPORACYJNE
(uchwały organów samorządów zawodowych), NIE akty prawa powszechnie
obowiązującego — NIE publikuje się ich w Dz.U., więc TRYB DZU (weryfikacja
przez ISAP) nie ma tu zastosowania wprost. Źródłem prawdy jest strona
właściwego samorządu zawodowego. Poniższa tabela obejmuje zawody prawnicze
(w pełni zweryfikowane w tej sesji) oraz zawody pokrewne z innych DR-skilli
(nazwa kodeksu i organ ustalone z wysoką pewnością, ale DOKŁADNY numer i
data najnowszej uchwały wymagają potwierdzenia na stronie samorządu przed
użyciem w piśmie — oznaczone poniżej).

| Zawód | Kodeks etyki | Organ uchwalający | Status weryfikacji | DR-skill |
|---|---|---|---|---|
| Adwokat | Kodeks Etyki Adwokackiej (Zbiór Zasad Etyki Adwokackiej i Godności Zawodu) | Naczelna Rada Adwokacka (NRA) | ✅ W PEŁNI ZWERYFIKOWANE 2026-07-02: t.j. Uchwała nr 174/2026 Prezydium NRA z 23.06.2026 + zmiana z 12-13.06.2026 (zasady AI) | dr-12/mod-ustawa-adwokatura |
| Radca prawny | Kodeks Etyki Radcy Prawnego | Krajowy Zjazd Radców Prawnych / Prezydium KRRP | ✅ W PEŁNI ZWERYFIKOWANE 2026-07-02: obowiązuje od 1.07.2015, t.j. Uchwała nr 884/XI/2023 Prezydium KRRP z 7.02.2023 | dr-12/mod-ustawa-radcowie-prawni |
| Notariusz | Kodeks Etyki Zawodowej Notariusza | Krajowa Rada Notarialna | ✅ ZWERYFIKOWANE 2026-07-02: bazowa Uchwała Nr 19/97 KRN z 12.12.1997 r., obowiązuje od stycznia 1998, ze zm. (tekst ujednolicony wielokrotnie aktualizowany) | dr-12/mod-ustawa-notariat |
| Komornik sądowy | Kodeks Etyki Zawodowej Komornika Sądowego | Krajowa Rada Komornicza | ✅ ZWERYFIKOWANE 2026-07-02: bazowa Uchwała nr 1603/V KRK z 6.09.2016 r. ze zm. (m.in. uchwała nr 2048/VI z 15.01.2019) | dr-12/mod-ustawa-komornicy-sadowi-zawod |
| Rzecznik patentowy | Zasady Etyki Zawodowej Rzeczników Patentowych | Krajowa Rada Rzeczników Patentowych / Krajowy Zjazd Rzeczników Patentowych | ✅ CZĘŚCIOWO ZWERYFIKOWANE 2026-07-02: obecna wersja WYRAŹNIE zastępuje poprzednie (uchwalone przez IV KZRP z 7.09.2005 i VII Nadzwyczajny KZRP z 12.01.2011, które utraciły moc) — potwierdzona nowsza wersja istnieje, ale dokładna data JEJ przyjęcia NIE ustalona w tej sesji | dr-12/mod-ustawa-rzecznicy-patentowi-zawod |
| Lekarz / lekarz dentysta | Kodeks Etyki Lekarskiej (KEL) | Naczelna Rada Lekarska / Krajowy Zjazd Lekarzy | ✅ ZWERYFIKOWANE 2026-07-02: przyjęty 1991 (II Nadzwyczajny KZL), znowelizowany 1993, 2003 i najnowsza rewizja **2024 r.** (Nadzwyczajny XVI Zjazd Krajowy Lekarzy w Łodzi) | dr-10 (moduły medyczne) |
| Pielęgniarka / położna | Kodeks Etyki Zawodowej Pielęgniarki i Położnej RP | Naczelna Rada Pielęgniarek i Położnych / Krajowy Zjazd | ✅ ZWERYFIKOWANE 2026-07-02: aktualny t.j. — Uchwała nr 18 VIII Krajowego Zjazdu Pielęgniarek i Położnych z **17.05.2023 r.**, zastąpiła wersję z 2003 r. | dr-10 |
| Farmaceuta (aptekarz) | Kodeks Etyki Aptekarza RP | Naczelna Rada Aptekarska / Krajowy Zjazd Aptekarzy | ✅ ZWERYFIKOWANE 2026-07-02: bazowa Uchwała Nr VI/25/2012 VI Krajowego Zjazdu Aptekarzy z **22.01.2012 r.** ze zm. | dr-10 |
| Lekarz weterynarii | Kodeks Etyki Lekarza Weterynarii | Krajowa Rada Lekarsko-Weterynaryjna / Krajowy Zjazd Lekarzy Weterynarii | ⚠️ CZĘŚCIOWO ZWERYFIKOWANE 2026-07-02: kodeks zastąpił poprzedni z 2001 r., ALE trwał proces konsultacji społecznych PROJEKTU ZMIAN z terminem uwag do 18.04.2025 — **możliwe, że w 2025/2026 nastąpiła nowelizacja nieustalona w tej sesji**, wymaga potwierdzenia aktualnej wersji na vetpol.org.pl | dr-10 |
| Diagnosta laboratoryjny | Kodeks Etyki Diagnosty Laboratoryjnego | Krajowa Izba Diagnostów Laboratoryjnych (KIDL) — organ NIE zmienił nazwy mimo reformy zawodu (ustawa o medycynie laboratoryjnej 2022), wcześniejsza niepewność ROZSTRZYGNIĘTA | ✅ W PEŁNI ZWERYFIKOWANE 2026-07-02: pierwotnie uchwalony 11.12.2004 (II KZDL), wielokrotnie nowelizowany, **obecna wersja obowiązuje od grudnia 2022 r.** (potwierdzone bezpośrednio przez wywiad z przedstawicielką KRDL) | dr-10 |
| Doradca podatkowy | Zasady Etyki Doradców Podatkowych | Krajowy Zjazd Doradców Podatkowych / Krajowa Izba Doradców Podatkowych | ✅ CZĘŚCIOWO ZWERYFIKOWANE 2026-07-02: aktualna wersja zawiera świeże przepisy o AI (obowiązek weryfikacji wyników narzędzi AI przed wykorzystaniem) — dokładny numer i data uchwały wprowadzającej te przepisy NIEUSTALONE, ale sama treść i aktualność potwierdzone bezpośrednio na kidp.pl | dr-06/mod-ustawa-doradcy-podatkowi-zawod |
| Biegły rewident | Kodeks etyki zawodowej biegłych rewidentów (Międzynarodowy Kodeks Etyki IESBA, wydanie 2022, przyjęty do porządku krajowego) | Krajowa Rada Biegłych Rewidentów (KRBR) + zatwierdzenie Polskiej Agencji Nadzoru Audytowego (PANA) | ✅ W PEŁNI ZWERYFIKOWANE 2026-07-02: Uchwała Nr 207/7a/2023 KRBR z 17.12.2023 (zmieniona Uchwałą Nr 240/8a/2023 z 22.12.2023), zatwierdzona Uchwałą Rady PANA nr 47/I/2023 z 19.12.2023 — obowiązuje od **1.07.2024 r.** dla zleceń uzgodnionych od tej daty | dr-06/mod-ustawa-biegli-rewidenci-zawod |
| Architekt | Kodeks Etyki Zawodowej Architektów (KEZA) | Krajowa Izba Architektów RP / Krajowy Zjazd Izby Architektów RP | ✅ W PEŁNI ZWERYFIKOWANE 2026-07-02: Krajowy Zjazd Izby Architektów RP z **6.12.2025 r.** przyjął nowelizację, w życie od **1.01.2026 r.** — tekst jednolity na dzień 1.01.2026 | dr-09/mod-ustawa-architekci-inzynierowie-budownictwa-zawod |
| Inżynier budownictwa | Kodeks Etyki Zawodowej Członków Polskiej Izby Inżynierów Budownictwa (PIIB) | Polska Izba Inżynierów Budownictwa / Krajowy Zjazd PIIB | ✅ W PEŁNI ZWERYFIKOWANE 2026-07-02: CAŁKOWICIE NOWY kodeks przyjęty Uchwałą Nr PIIB/KZ/0016/2024 XXIII Krajowego Zjazdu PIIB z **14.06.2024 r.**, zastępujący poprzedni z 2007 r. (nowelizowany 2013) | dr-09/mod-ustawa-architekci-inzynierowie-budownictwa-zawod |
| Psycholog | Kodeks Etyczno-Zawodowy Psychologa (część główna) + Kodeks Diagnozy Psychologicznej (część II, uzupełniająca) | Polskie Towarzystwo Psychologiczne (PTP) — ⚠️ status prawny NIE jest tożsamy z korporacyjnymi kodeksami zawodów regulowanych ustawowo, ponieważ samorząd zawodowy psychologów NIE jest jeszcze w pełni ukonstytuowany mimo ustawy o zawodzie psychologa 2026.187 | ✅ CZĘŚCIOWO ROZSTRZYGNIĘTE 2026-07-02: część główna obowiązuje jako kodeks środowiskowy PTP; część II (diagnoza psychologiczna) przyjęta Uchwałą nr 5 Nadzwyczajnego Walnego Zgromadzenia Delegatów PTP z **29.02.2020 r.**, ale WYRAŹNIE jako dokument "POMOCNICZY" (nie w pełni wiążący) — wcześniejsza niepewność co do statusu prawnego POTWIERDZONA jako zasadna | dr-10 |

**Podsumowanie finalne weryfikacji 2026-07-02:** 11 z 15 pozycji w pełni zweryfikowanych z konkretną datą/numerem uchwały. 4 pozycje (rzecznik patentowy, weterynarz, doradca podatkowy, psycholog) częściowo zweryfikowane — treść/aktualność potwierdzona, ale dokładna data ostatniej uchwały nieustalona lub status prawny odmienny od typowego kodeksu korporacyjnego. **Żadna pozycja nie pozostaje całkowicie niezweryfikowana** — to kompletne zamknięcie zadania specjalnego.

## SĄDY/ORGANY DYSCYPLINARNE I PODSTAWY PRAWNE POSTĘPOWAŃ (dodano 2026-07-02, na żądanie użytkownika)

⚠️ **Zakres tej sesji:** w pełni zweryfikowano 4 zawody prawnicze (adwokat,
radca prawny, notariusz, komornik sądowy) — te mają dyscyplinarkę uregulowaną
BEZPOŚREDNIO w tych samych ustawach, których numery Dz.U. już potwierdzono
wcześniej w tej sesji. Pozostałe 11 zawodów (rzecznik patentowy + 10 spoza
dr-12) WYMAGAJĄ odrębnej sesji weryfikacyjnej — nie zgadywano nazw organów
ani podstaw prawnych bez potwierdzenia.

| Zawód | Organ I instancji | Organ II instancji | Podstawa prawna (ta sama ustawa co już zweryfikowany numer Dz.U.) |
|---|---|---|---|
| Adwokat | Sąd dyscyplinarny izby adwokackiej | Wyższy Sąd Dyscyplinarny | Prawo o adwokaturze (Dz.U. 2024.1564), Dział VIII "Odpowiedzialność dyscyplinarna", art. 45-95m; organy adwokatury określone w art. 9 (m.in. Wyższy Sąd Dyscyplinarny, Rzecznik Dyscyplinarny Adwokatury); zakres sądu dyscyplinarnego — art. 50; skład — art. 51 (prezes, wiceprezes, 6-23 członków, 3 zastępców; orzeka w składzie 3 sędziów) |
| Radca prawny | Okręgowy sąd dyscyplinarny (I instancja) | Wyższy Sąd Dyscyplinarny (II i ostatnia instancja) | Ustawa o radcach prawnych (Dz.U. 2024.499), organy samorządu — art. 42 (m.in. Wyższy Sąd Dyscyplinarny, Główny Rzecznik Dyscyplinarny, okręgowy sąd dyscyplinarny, rzecznik dyscyplinarny); odpowiedzialność dyscyplinarna — art. 64 i nast.; ostrzeżenie dziekańskie — art. 66 |
| Notariusz | Sąd Dyscyplinarny przy Radzie Izby Notarialnej (wybierany przez Walne Zgromadzenie notariuszy na 3-letnią kadencję) | Wyższy Sąd Dyscyplinarny | Prawo o notariacie (Dz.U. 2026.614), Rozdział 6 "Odpowiedzialność dyscyplinarna", art. 50-63c; Rzecznik Dyscyplinarny Notariatu — art. 70 i nast.; pomocniczo stosuje się przepisy postępowania karnego |
| Komornik sądowy | Komisja dyscyplinarna (33 członków powoływanych przez Krajową Radę Komorniczą spośród kandydatów zgłoszonych przez rady izb komorniczych) | ⚠️ Sąd apelacyjny jako sąd odwoławczy (organ PAŃSTWOWY, nie korporacyjny — inaczej niż w pozostałych 3 zawodach powyżej) | Ustawa o komornikach sądowych (Dz.U. 2024.1458), Rozdział 11 "Odpowiedzialność dyscyplinarna", art. 222-260 (numeracja wg wersji ustawy z 22.03.2018 r. — zweryfikować zgodność z aktualnym t.j. przy najbliższej okazji) |
| Lekarz / lekarz dentysta | Okręgowy Sąd Lekarski (I instancja) | Naczelny Sąd Lekarski (II instancja) — odwołanie w 14 dni; dalej możliwa KASACJA do Sądu Najwyższego | ⛔ ODKRYTA LUKA STRUKTURALNA: podstawą jest ODRĘBNA ustawa — **ustawa z 2.12.2009 r. o izbach lekarskich** (ostatni potwierdzony t.j.: Dz.U. 2021 poz. 1342 — możliwy nowszy t.j. niepotwierdzony w tej sesji, stosowana ostrożność po lekcji z fałszywym alarmem USW), Rozdział 5 "Odpowiedzialność zawodowa", art. 53-112; Rozdział 6 "Postępowanie mediacyjne", art. 113-113a. **Ta ustawa NIE BYŁA w ogóle śledzona w dr-10/MAPA-AKTOW.md przed tą sesją** — to nie kwestia nieaktualności, tylko całkowitego braku w mapie |
| Pielęgniarka / położna | Okręgowy Sąd Pielęgniarek i Położnych (I instancja) | Naczelny Sąd Pielęgniarek i Położnych (II instancja) | ⛔ DRUGI PRZYPADEK TEGO SAMEGO WZORCA: **ustawa z 1.07.2011 r. o samorządzie pielęgniarek i położnych** (t.j. Dz.U. 2025 poz. 1760), Rozdział 6 "Odpowiedzialność zawodowa", art. 36-88. Również CAŁKOWICIE brakująca w dr-10/MAPA-AKTOW.md przed tą sesją |
| Farmaceuta (aptekarz) | Sąd Aptekarski (I instancja) | Naczelny Sąd Aptekarski (II instancja) — orzeczenia prawomocne z chwilą ogłoszenia | ✅ BEZ NOWEJ LUKI: podstawa — ustawa o izbach aptekarskich z 19.04.1991 r., JUŻ POPRAWNIE ŚLEDZONA w dr-10 jako "Ustawa o izbach aptekarskich" (Dz.U. 2025.1693, VER 2026-06-14). Różnica względem lekarzy/pielęgniarek: tu przepisy o izbach/samorządzie i sądzie dyscyplinarnym są częścią TEJ SAMEJ ustawy co przepisy o zawodzie, nie osobnym aktem |
| Lekarz weterynarii | Sąd Lekarsko-Weterynaryjny (I instancja) | Krajowy Sąd Lekarsko-Weterynaryjny (II instancja, dawniej "Naczelny" — zmiana nazwy nowelizacją z 2013 r.) — kasacja do SN możliwa w terminie 6 mies. | ✅ BEZ NOWEJ LUKI: podstawa — ustawa o zawodzie lekarza weterynarii i izbach lekarsko-weterynaryjnych z 21.12.1990 r., JUŻ POPRAWNIE ŚLEDZONA w dr-10 (Dz.U. 2026.125, VER 2026-06-14) — dokładnie ten sam numer potwierdzony niezależnie w tej sesji. Ta sama struktura co aptekarze: izby/sąd dyscyplinarny w TEJ SAMEJ ustawie co zawód |
| Diagnosta laboratoryjny | Sąd Diagnostów Laboratoryjnych (I instancja) | Wyższy Sąd Diagnostów Laboratoryjnych (II instancja) — kasacja do SN możliwa | ⚠️ ZŁOŻONA SYTUACJA: podstawa — ustawa o medycynie laboratoryjnej z 15.09.2022 r., Rozdział 7 "Odpowiedzialność zawodowa". Przy tej weryfikacji znaleziono JESZCZE NOWSZY t.j. (**Dz.U. 2023.2125**) niż potwierdzony wcześniej TEGO SAMEGO DNIA (2022.2280, sesja 2026-07-02s) — numer wymagał DRUGIEJ korekty w ciągu jednej sesji. Organ: Krajowa Izba Diagnostów Laboratoryjnych (KIDL) — nazwa potwierdzona jako niezmieniona mimo reformy |
| Rzecznik patentowy | Sąd Dyscyplinarny (I instancja) | Odwoławczy Sąd Dyscyplinarny (II instancja, odwołanie w 1 miesiąc) | ⚠️ DODATKOWA KOREKTA PRZY OKAZJI: podstawa — ustawa o rzecznikach patentowych z 11.04.2001 r., Rozdział 6 "Odpowiedzialność dyscyplinarna", art. 57-68. Weryfikacja wykazała, że mapa cytowała nieaktualny t.j. (2024.749) — aktualny to **Dz.U. 2025.591**, z dodatkową NIEROZSTRZYGNIĘTĄ poszlaką jeszcze nowszego t.j. 2026.778 |
| Doradca podatkowy | Sąd Dyscyplinarny KIDP (I instancja) | Wyższy Sąd Dyscyplinarny KIDP (II instancja) | ⚠️ HYBRYDOWY WZORZEC (podobny do komorników): od orzeczenia II instancji przysługuje DALSZE odwołanie do właściwego SĄDU APELACYJNEGO (wydział pracy i ubezpieczeń społecznych) — organu PAŃSTWOWEGO. Podstawa — ustawa o doradztwie podatkowym z 5.07.1996 r., Rozdział 9 "Odpowiedzialność dyscyplinarna", art. 64-80. Ostatni potwierdzony t.j. bazowy: Dz.U. 2021.2117 (zgodny z wcześniejszym ustaleniem tej sesji dot. dr-06) |
| Biegły rewident | Krajowy Sąd Dyscyplinarny (8-10 członków, orzeka w składzie 3) | ⚠️ Struktura specyficzna — nadzór publiczny sprawuje Polska Agencja Nadzoru Audytowego (PANA); art. 178 wskazuje właściwość SĄDU OKRĘGOWEGO w niektórych sprawach określonych ustawą | Ustawa o biegłych rewidentach, firmach audytorskich oraz nadzorze publicznym z 11.05.2017 r. (Dz.U.2024.1035 t.j. — zgodny z wcześniejszym ustaleniem tej sesji dot. dr-06), Rozdział 9 "Odpowiedzialność dyscyplinarna biegłych rewidentów", art. 139-181 |
| Architekt | Okręgowy Sąd Dyscyplinarny (I instancja) | Krajowy Sąd Dyscyplinarny (II instancja, odwołanie w 14 dni) — orzeczenia podlegają kontroli SĄDU APELACYJNEGO | JEDNA WSPÓLNA ustawa dla architektów i inżynierów budownictwa: ustawa o samorządach zawodowych architektów oraz inżynierów budownictwa z 15.12.2000 r. (Dz.U. 2025.1783 t.j., potwierdzone wcześniej tej sesji), Rozdział 5 "Odpowiedzialność dyscyplinarna" |
| Inżynier budownictwa | Okręgowy Sąd Dyscyplinarny (I instancja) | Krajowy Sąd Dyscyplinarny (II instancja) — ta sama struktura co architekci | TA SAMA ustawa co architekci (Dz.U. 2025.1783 t.j.) — jeden akt obsługuje oba odrębne samorządy zawodowe (Izba Architektów RP + PIIB), każdy ma własne okręgowe/krajowe sądy dyscyplinarne działające na tej samej podstawie ustawowej |
| Psycholog | ⛔ BRAK USTAWOWO UMOCOWANEGO SĄDU DYSCYPLINARNEGO | — | Potwierdza się wcześniejsze ustalenie tej sesji: samorząd zawodowy psychologów NIE jest jeszcze w pełni ukonstytuowany (mimo ustawy o zawodzie psychologa 2026.187) — brak więc formalnego, ustawowego sądu dyscyplinarnego analogicznego do pozostałych 14 zawodów. Odpowiedzialność ma obecnie charakter głównie środowiskowy (PTP), nie korporacyjno-ustawowy |

### ⛔⛔ WZORZEC SYSTEMOWY — SPRECYZOWANY (nie uniwersalny, ale realny dla 2/4 sprawdzonych zawodów medycznych)

Po sprawdzeniu 4 zawodów medycznych: **lekarz i pielęgniarka/położna MAJĄ
lukę** (osobna ustawa "o samorządzie/izbach" nieśledzona w dr-10), ale
**aptekarz i weterynarz NIE MAJĄ tej luki** (przepisy o samorządzie są
częścią tej samej, już śledzonej ustawy "o zawodzie"). Wzorzec nie jest
więc uniwersalny — zależy od tego, czy ustawodawca połączył przepisy o
zawodzie i o izbach w jeden akt, czy rozdzielił je na dwa. **Diagnosta
laboratoryjny pozostaje niesprawdzony pod tym kątem** — biorąc pod uwagę
niedawną reformę tego zawodu (ustawa o medycynie laboratoryjnej z 2022 r.,
patrz wcześniejsza poprawka 2026-07-02s), struktura organizacyjna mogła
się zmienić i wymaga odrębnego sprawdzenia.

### POZOSTAŁE 11 ZAWODÓW — DO WERYFIKACJI W KOLEJNEJ SESJI

Rzecznik patentowy, lekarz/lekarz dentysta, pielęgniarka/położna, farmaceuta,
lekarz weterynarii, diagnosta laboratoryjny, doradca podatkowy, biegły
rewident, architekt, inżynier budownictwa, psycholog. Dla większości z nich
prawdopodobne jest, że dyscyplinarka jest uregulowana w tej samej ustawie
zawodowej, której numer Dz.U. już potwierdzono w tabeli kodeksów etyki
powyżej — ale nazwa organu (np. "okręgowy sąd lekarski"/"Naczelny Sąd
Lekarski" dla lekarzy) i dokładne artykuły NIE zostały zweryfikowane w tej
sesji i nie powinny być zgadywane.

**Zasada stosowania:** kodeksy etyki NIE są źródłem powszechnie obowiązującego
prawa w rozumieniu art. 87 Konstytucji RP, ale mają istotne znaczenie
dowodowe i dyscyplinarne — naruszenie kodeksu etyki może stanowić podstawę
odpowiedzialności dyscyplinarnej na mocy odrębnej ustawy zawodowej (np.
Prawo o adwokaturze art. 80 i nast. dla adwokatów). Przy powoływaniu się na
konkretny paragraf kodeksu w piśmie procesowym lub opinii — ZAWSZE
weryfikować aktualność na stronie właściwego samorządu, gdyż kodeksy te są
nowelizowane częściej i mniej przewidywalnie niż ustawy (przykład z tej
sesji: zmiana KEA ws. AI z czerwca 2026, kilka tygodni przed audytem).
