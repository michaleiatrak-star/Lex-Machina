# Ustawa o radcach prawnych — moduł bieżący

**Akt:** PrAdw (Prawo o adwokaturze) — t.j. Dz.U. 2024 poz. 1564 (zm. po t.j.: 2025/1172 od 2026-03-01 — art. 4, 37d; 2026/370 od 2026-04-03 — art. 66, 78a; 2026/846 od 2026-10-01 — art. 6; 2026/1290 od 2026-10-17 — art. 1, 1a, 3, 4, 4b, 4c, 4ca, 7, 8a, 10, 11, 12, 16a, 16b, 16c, 16d, 16e, 37a, 40, 42).
**Akt:** URP (ustawa o radcach prawnych) — t.j. Dz.U. 2024 poz. 499 (zm. po t.j.: 2025/1172 od 2026-03-01 — art. 6, 2211; 2026/370 od 2026-04-03 — art. 25, 362; 2026/846 od 2026-10-01 — art. 3).
**Akt:** KPC (Kodeks postępowania cywilnego) — t.j. Dz.U. 2026 poz. 468 (zm. po t.j.: 2026/473 od 2026-07-08 — art. 460, 461, 465, 476, 631, 632, 3982, 4771b, 4771c, 4771d, 4777a, 7555, 7556; 2026/830 od 2026-07-08 — art. 4; 2026/1003 od 2026-10-28 — zakres: tekst nowelizacji w ELI; 2026/1046 od 2026-11-05 — art. 1, 2, 47, 94, 461, 477; 2026/1296 od 2026-11-06 — art. 17).
**Akt:** KPK (Kodeks postępowania karnego) — t.j. Dz.U. 2026 poz. 490 (zm. po t.j.: 2026/421 od 2026-04-14 — art. 21h, 74, 213, 332, 336; 2026/638 od 2026-05-28 — art. 25; 2026/760 od 2026-06-12 — art. 21h, 74, 213, 332; 2026/882 od 2026-07-16 — art. 607k, 607m, 607t, 607y, 607ya, 607zb; 2026/901 od 2026-07-21 — art. 87).
**Akt:** PPSA (Prawo o postępowaniu przed sądami administracyjnymi) — t.j. Dz.U. 2026 poz. 143 (zm. po t.j.: 2026/846 od 2026-06-26 — art. 53, 264).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

**Stan weryfikacji:** 2026-08-28  
**Tekst jednolity bazowy:** Dz.U. 2024 poz. 499  
**Stan obowiązujący:** tekst bazowy + późniejsze zmiany, w tym **Dz.U. 2026 poz. 731**, obowiązujący od 18.06.2026.  
**Źródła kanoniczne:** ELI/ISAP + Krajowa Izba Radców Prawnych dla aktów korporacyjnych.

## 1. Bramka źródłowa

- ELI — tekst jednolity: `https://eli.gov.pl/eli/DU/2024/499/ogl`
- ELI — nowelizacja z 15.05.2026 r.: `https://eli.gov.pl/eli/DU/2026/731/ogl`
- KIRP — aktualny Kodeks Etyki Radcy Prawnego: oficjalna strona `kirp.pl`; tekst jednolity ogłoszony uchwałą nr 884/XI/2023 Prezydium KRRP z 7.02.2023, uwzględniający zmiany obowiązujące od 1.01.2023.

Przed cytowaniem konkretnego przepisu otwórz aktualny tekst po zmianach. Sam Dz.U. 2024 poz. 499 nie wystarcza do stanu 2026.

## 2. Mapa ustawy

| Rozdział / zakres | Materia | Status modułu |
|---|---|---|
| 1 | przepisy ogólne, zawód, tajemnica | 🟢 B+ |
| 1a | przetwarzanie danych osobowych | 🟢/🟡 B+ — istotnie zmienione w 2026 |
| 2 | wykonywanie zawodu, formy wykonywania, OC | 🟢 B+ — istotnie zmienione w 2026 |
| 3 | uprawnienia do wykonywania zawodu / lista | 🟢/🟡 B+ |
| 4 | aplikacja i egzamin radcowski | 🟡 B |
| 5 | samorząd radców prawnych | 🟢/🟡 B+ — istotnie zmienione w 2026 |
| 6 | odpowiedzialność dyscyplinarna | 🟢 B+ — istotnie zmienione w 2026 |
| 6a | przepis karny | 🟢 B+ — dodany Dz.U. 2026 poz. 731 |
| 7 | szczególne, przejściowe i końcowe | 🟡 B |

## 3. Wykonywanie zawodu i tajemnica — art. 3 i nast.

Radca prawny świadczy pomoc prawną w formach dopuszczonych ustawą. Przy analizie rozdziel:
- formę wykonywania zawodu, w tym zatrudnienie;
- niezależność i obowiązki zawodowe;
- tajemnicę zawodową;
- konflikt interesów i normy etyczne;
- obowiązkowe ubezpieczenie OC;
- szczególne reguły procesowe właściwe dla rodzaju sprawy.

**Nie wpisuj ogólnego twierdzenia o „pełnej zdolności postulacyjnej bez wyjątków”.** Uprawnienie do występowania w konkretnej sprawie i ewentualne ograniczenia wynikają także z KPC/KPK i ustaw szczególnych.

## 4. Nowelizacja obowiązująca — Dz.U. 2026 poz. 731

Ustawa z 15.05.2026 r. o zmianie ustawy o radcach prawnych (ogł. 3.06.2026) weszła w życie **18.06.2026** i jest częścią bieżącego stanu prawnego.

Nowelizacja obejmuje m.in.:
- reguły przetwarzania i retencji danych osobowych przez organy samorządu;
- model obowiązkowego ubezpieczenia OC i zadania Krajowej Izby Radców Prawnych;
- zadania i kompetencje organów samorządu;
- uprawnienia KIRP w postępowaniach cywilnych, karnych, administracyjnych i sądowoadministracyjnych przez nowy art. 60a;
- zmianę katalogu podmiotów uprawnionych do kasacji od prawomocnego orzeczenia Wyższego Sądu Dyscyplinarnego;
- odpowiedzialność dyscyplinarną związaną z obowiązkiem ubezpieczeniowym;
- nowy rozdział 6a i art. 74² penalizujący nieuprawnione posługiwanie się tytułem „radca prawny” lub oznaczeniem kancelarii.
- **art. 12 ust. 1** (ust. 2 uchylony): „Radca prawny podczas wykonywania czynności zawodowych lub w związku z ich wykonywaniem korzysta z ochrony przysługującej funkcjonariuszowi publicznemu na zasadach określonych w ustawie z dnia 6 czerwca 1997 r. – Kodeks karny” ✅ [VER] RZĄD 1 2026-10-09 (ELI DU/2026/731 text.pdf). Ustawa nie zmienia KK (art. 115 § 13): radca korzysta z ochrony, nie jest funkcjonariuszem publicznym. Kwalifikacja czynu przeciwko radcy → DR-03 `mod-KK-art222-226-ochrona-funkcjonariusza`. Analogiczna ochrona adwokata od 17.10.2026 (Dz.U. 2026 poz. 1290) → `mod-ustawa-adwokatura.md` sekcja 8a;
- **art. 12a** — strój urzędowy radcy prawnego (toga z żabotem i wypustką koloru ciemnoniebieskiego; rozporządzenie MS);
- **art. 8a** — ochrona oznaczeń „kancelaria radcy prawnego” i „kancelaria radców prawnych”.

**HARD GATE:** gdy sprawa dotyczy zdarzenia sprzed 18.06.2026, sprawdź przepisy przejściowe nowelizacji; w szczególności ustawa zawiera osobne reguły dla części spraw dyscyplinarnych i danych.

## 5. Odpowiedzialność dyscyplinarna

Przy sprawie dyscyplinarnej ustal:
1. datę czynu;
2. właściwą normę ustawową i etyczną;
3. organ I i II instancji;
4. dopuszczalny środek odwoławczy;
5. możliwość kasacji do SN według aktualnego art. 62²;
6. przepisy przejściowe Dz.U. 2026 poz. 731, jeżeli orzeczenie lub kasacja wiążą się z okresem przejściowym.

Kasacja do Sądu Najwyższego jest nadzwyczajnym środkiem kontroli, nie „trzecią instancją”.

## 6. Etyka zawodowa — źródło KIRP

Oficjalna KIRP publikuje Kodeks Etyki Radcy Prawnego w tekście jednolitym ogłoszonym uchwałą nr 884/XI/2023 Prezydium KRRP z 7.02.2023. Tekst uwzględnia zmiany uchwalone w 2022 r. i obowiązujące od 1.01.2023.

Przy sprawie etycznej pobierz aktualny dokument z KIRP i ustal konkretną normę dotyczącą m.in.:
- niezależności;
- tajemnicy zawodowej;
- konfliktu interesów i zajęć niedopuszczalnych;
- relacji z klientem;
- informowania o wykonywaniu zawodu i pozyskiwania klientów;
- stosunków między radcami prawnymi;
- zabezpieczenia informacji i wykonywania zawodu przy użyciu technologii.

Nie zastępuj KERP stanowiskiem komisji etyki ani opracowaniem prasowym. Stanowiska KIRP mogą być materiałem pomocniczym dopiero po ustaleniu normy z KERP.

## 7. OC i opłaty

Po nowelizacji 2026 szczególnie uważnie sprawdzaj aktualny model OC w ustawie i aktach wykonawczych. Kwot, sum gwarancyjnych i stawek nie utrwalaj w module.

Aktualne rozporządzenie o opłatach za czynności radców prawnych ma tekst jednolity ogłoszony w **Dz.U. 2026 poz. 118**. Koszty pomocy prawnej z urzędu mają odrębny obowiązujący akt — weryfikuj go osobno w ELI.

## 8. Zmiana przyszła — Dz.U. 2026 poz. 846

Ustawa z 29.05.2026 r. zmienia m.in. art. 3 ustawy o radcach prawnych w obszarze relacji tajemnicy do obowiązków raportowych. Zasadnicza data wejścia w życie ustawy to **1.10.2026**.

**Na dzień 2026-08-28 nie stosuj przyszłego brzmienia jako obowiązującego.** Po 1.10.2026 wykonaj nowy fresh gate.

## 9. Routing

- KPC / cywilne → DR-02;
- KPK / obrona karna → DR-03;
- postępowanie administracyjne / PPSA → DR-05;
- dyscyplinarne i ustrój zawodu → DR-12;
- RODO / cyber → DR-11;
- AML / MDR → DR-06 i DR-15;
- prawo UE → DR-14.

## 10. Quality gate

- [ ] uwzględniono Dz.U. 2026 poz. 731 jako obowiązujące od 18.06.2026;
- [ ] ustalono, czy sprawa podlega przepisom przejściowym tej nowelizacji;
- [ ] etyka pochodzi z oficjalnego KIRP;
- [ ] tajemnicę ustawową odróżniono od procesowych zakazów dowodowych;
- [ ] kasację do SN odróżniono od zwykłej instancji;
- [ ] aktualny model OC i stawki pobrano z urzędowego aktu;
- [ ] przyszłej zmiany z 1.10.2026 nie zastosowano przed jej wejściem w życie.

## 11. Źródła urzędowe

- ELI — ustawa o radcach prawnych, Dz.U. 2024 poz. 499: `https://eli.gov.pl/eli/DU/2024/499/ogl`
- ELI — nowelizacja, Dz.U. 2026 poz. 731: `https://eli.gov.pl/eli/DU/2026/731/ogl`
- ELI — przyszła zmiana, Dz.U. 2026 poz. 846: `https://eli.gov.pl/eli/DU/2026/846/ogl`
- KIRP — Kodeks Etyki Radcy Prawnego i Regulamin wykonywania zawodu: oficjalna strona `kirp.pl`.
