# Moduł [AZ] — Postępowania dyscyplinarne zawodów zaufania publicznego

**Akt:** USP (Prawo o ustroju sądów powszechnych) — t.j. Dz.U. 2024 poz. 334 (zm. po t.j.: 2024/1907 od 2025-01-01 — art. 49; 2025/526 od 2025-05-07 — art. 77; 2025/820 od 2025-07-25 — art. 16; 2025/1609 od 2025-12-09 — art. 1, 2, 22a; 2025/1172 od 2026-03-01 — art. 20, 53e, 157b; 2025/1178 od 2026-03-01 — art. 41, 53e; 2026/370 od 2026-04-03 — art. 147, 149, 155, 155a, 155ca, 155cb, 155d, 155e; 2026/26 [OD 2027-01-01: 2026/26] — art. 70, 94, 94b, 94d; 2026/1123 [OD 2028-01-01: 2026/1123] — art. 94).
**Akt:** PrAdw (Prawo o adwokaturze) — t.j. Dz.U. 2024 poz. 1564 (zm. po t.j.: 2025/1172 od 2026-03-01 — art. 4, 37d; 2026/370 od 2026-04-03 — art. 66, 78a; 2026/846 od 2026-10-01 — art. 6; 2026/1290 od 2026-10-17 — art. 1, 1a, 3, 4, 4b, 4c, 4ca, 7, 8a, 10, 11, 12, 16a, 16b, 16c, 16d, 16e, 37a, 40, 42).
**Akt:** URP (ustawa o radcach prawnych) — t.j. Dz.U. 2024 poz. 499 (zm. po t.j.: 2025/1172 od 2026-03-01 — art. 6, 2211; 2026/370 od 2026-04-03 — art. 25, 362; 2026/731 od 2026-06-18 — art. 1, 5a, 5b, 5c, 5d, 8, 8a, 12, 12a, 22, 28, 35, 37, 45, 52, 52a, 60, 60a, 62, 64; 2026/846 od 2026-10-01 — art. 3).
**Akt:** PrNot (Prawo o notariacie) — t.j. Dz.U. 2026 poz. 614 (zm. po t.j.: 2026/1099 [OD 2026-11-19: 2026/1099] — art. 2, 92a).
**Akt:** UKS (ustawa o komornikach sądowych) — t.j. Dz.U. 2026 poz. 881.
**Akt:** URzP (ustawa o rzecznikach patentowych) — t.j. Dz.U. 2026 poz. 778 (zm. po t.j.: 2026/846 od 2026-10-01 — art. 14).
**Akt:** PPSA (Prawo o postępowaniu przed sądami administracyjnymi) — t.j. Dz.U. 2026 poz. 143 (zm. po t.j.: 2026/846 od 2026-06-26 — art. 53, 264).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

**Standard jakości:** stosuj `prawo-polskie-v2/krajowe/shared/MODULE-STANDARD-POLISH-LAW.md` oraz `prawo-polskie-v2/krajowe/shared/POLISH-LAW-COMPLETENESS-MATRIX.md`.
---
WSPÓLNE ZASADY DLA MODUŁU:
- przed cytowaniem przepisu zastosuj `shared/ISAP-AUDIT-PROTOCOL.md`;
- metryki aktów sprawdzaj w `prawo-polskie-v2/krajowe/shared/ISAP-METRYKI-AKTOW.md`;
- jeżeli sprawa jest procesowa, uruchom `prawo-polskie-v2/krajowe/shared/FORMAL-CHECK.md`, `shared/WARUNKI-SKUTECZNOSCI.md`, `prawo-polskie-v2/krajowe/shared/TERM-CALC.md`, `shared/RISK-ASSESSMENT.md`;
- nie mieszaj trybów: KPA, Ordynacja podatkowa, KAS, PPSA i egzekucja administracyjna mają odrębne rygory.
---

**Zakres:** adwokaci, radcowie prawni, lekarze, notariusze, komornicy, sędziowie i asesorzy sądowi, biegli, rzecznicy dyscyplinarni, sądy dyscyplinarne, skargi, zawiadomienia, odpowiedzialność zawodowa.

## ZASADY ABSOLUTNE

1. Każdy samorząd zawodowy ma własną ustawę i regulamin. Nie przenoś automatycznie trybu z jednej korporacji na drugą.
2. Oddziel odpowiedzialność dyscyplinarną od cywilnej, karnej i administracyjnej.
3. W zawiadomieniu kluczowe są: konkretny czyn, data, dowód, norma etyczna, skutek.
4. Sprawdź przedawnienie dyscyplinarne i status pokrzywdzonego/pokrzywdzonej.

## KLUCZOWE AKTY PRAWNE — ISAP

| Zawód | Akty startowe |
|---|---|
| Adwokat | Prawo o adwokaturze + Zbiór Zasad Etyki Adwokackiej — sprawdzić aktualne źródła |
| Radca prawny | ustawa o radcach prawnych + Kodeks Etyki Radcy Prawnego — sprawdzić aktualne źródła |
| Lekarz | ustawa o izbach lekarskich + KEL — sprawdzić aktualne źródła |
| Notariusz | Prawo o notariacie — sprawdzić ISAP |
| Komornik | ustawa o komornikach sądowych — sprawdzić ISAP |

## WALIDACJA

```text
□ osoba i zawód
□ organ dyscyplinarny
□ czyn, data, miejsce, dowody
□ norma prawna i etyczna
□ przedawnienie
□ interes zawiadamiającego / status pokrzywdzonego
□ równoległe postępowanie cywilne/karne
```

---

# STANDARDOWE UZUPEŁNIENIE MODUŁU — poziom prawa pracy / prawa karnego

> Ten blok jest częścią obowiązkową modułu. Ma pierwszeństwo przed opisowym użyciem modułu. Nie zastępuje kontroli ISAP; wymusza praktyczny workflow kancelaryjny.

## 1. Intake szczególny

Przed odpowiedzią ustal co najmniej:
- zawód i samorząd;
- organ dyscyplinarny;
- czyn zarzucany;
- termin przedawnienia;
- status pokrzywdzonego/obwinionego;
- ścieżka odwoławcza;

## 2. Mapa proceduralna

```text
Identyfikacja trybu i organu/sądu
  ↓
Kontrola terminu, doręczenia, właściwości i legitymacji
  ↓
Ustalenie faktów materialnych i proceduralnych
  ↓
Matryca dowodowa: fakt → dowód → ciężar dowodu → luka
  ↓
Dobór pisma/środka: wniosek / odwołanie / zażalenie / skarga / pozew / zawiadomienie
  ↓
Walidacja formalna: prawo-polskie-v2/krajowe/shared/FORMAL-CHECK.md + shared/WARUNKI-SKUTECZNOSCI.md
  ↓
Ocena ryzyka: shared/RISK-ASSESSMENT.md + shared/QUALITY-CHECK.md
  ↓
Strategia: minimum, optimum, wariant eskalacyjny
```

## 3. Warunki skuteczności

```text
□ prawidłowy tryb
□ właściwy organ albo sąd
□ termin liczony od prawidłowego zdarzenia
□ legitymacja strony
□ żądanie możliwe prawnie
□ fakty powiązane z podstawą prawną
□ dowody przypisane do każdej tezy
□ kontrola opłat, odpisów, pełnomocnictw i podpisu
□ kontrola ISAP na dzień sporządzenia pisma
□ kontrola stanu prawnego na dzień zdarzenia oraz na dzień orzekania
```

## 4. Matryca dowodowa

Dowody typowe dla tego modułu:
- zawiadomienie;
- akta dyscyplinarne;
- korespondencja z rzecznikiem;
- dowody naruszenia etyki;
- orzeczenia organów;
- pełnomocnictwa;

Każdy dowód oceniaj według schematu:

```text
Dowód → fakt, który ma wykazać → bezpośredni/pośredni → wiarygodność → ryzyko podważenia → brakujący dowód wzmacniający
```

## 5. Typowe zarzuty i kontrzarzuty

W każdej sprawie przygotuj dwie wersje:

1. argumentację strony inicjującej sprawę,
2. argumentację organu/przeciwnika procesowego.

Typowe ryzyka i kontrargumenty:
- niewłaściwy organ;
- mylenie odpowiedzialności cywilnej i dyscyplinarnej;
- brak interesu/legitymacji;
- przedawnienie dyscyplinarne;

## 6. Strategia procesowa

Zastosuj trzy warianty:

### Wariant ostrożny
Minimalizuje ryzyko formalne. Priorytet: termin, kompletność, zabezpieczenie dowodów.

### Wariant ofensywny
Eksponuje naruszenia proceduralne, wadliwość ustaleń, niewłaściwą wykładnię, naruszenie zasady proporcjonalności albo praw strony.

### Wariant eskalacyjny
Zakłada przejście do organu II instancji, WSA/NSA, sądu powszechnego, SN, TSUE, ETPC albo organu sektorowego — tylko gdy wynika to z trybu.

## 7. Quality gate

Przed końcową odpowiedzią sprawdź:

```text
□ Czy moduł działa praktycznie, a nie opisowo?
□ Czy wskazano decydujący element prawny?
□ Czy oddzielono fakty od interpretacji?
□ Czy podano ryzyka przeciwnika/organu?
□ Czy wskazano słabe punkty klienta?
□ Czy każdy przepis i Dz.U. ma kontrolę ISAP albo oznaczenie braku weryfikacji?
□ Czy użyto prawo-polskie-v2/krajowe/shared/MODULE-STANDARD-POLISH-LAW.md?
```

## Orzecznictwo dyscyplinarne — instancje i bazy (⚙️ spięte z prawo-polskie-v2/krajowe/shared/PRAWO-HARDGATE.md)

**Stan zweryfikowany online (nie z pamięci) — 2026-07-06, zaktualizowany po
dodatkowej weryfikacji miast/instancji zwykłych (I instancja izbowa):**

| Zawód | I instancja | II instancja / kasacja | Publiczna baza (zweryfikowany adres) |
|---|---|---|---|
| Adwokat | Sąd Dyscyplinarny Izby Adwokackiej — patrz podtabela per-izba niżej | Wyższy Sąd Dyscyplinarny Adwokatury → kasacja SN | **`wsd.adwokatura.pl`** — ✅ ZWERYFIKOWANE DOKŁADNIE 2026-07-16: portal jest w pełni FUNKCJONALNY, zawiera pełne teksty uzasadnień (nie tylko tezy), z systemem tagów tematycznych (np. "konflikt interesów", "tajemnica adwokacka") i wzajemnymi odnośnikami do innych orzeczeń WSD/SN — przykład zweryfikowany bezpośrednim fetchem: orzeczenie WSD 55/19 z pełnym, wieloakapitowym uzasadnieniem. To istotnie lepszy stan niż `wsd.kirp.pl` radców (który dziś przekierowuje na stronę główną) |

**Podtabela ORA (Okręgowe Rady Adwokackie) — status publikacji I INSTANCJI (Sąd Dyscyplinarny Izby), zweryfikowany 2026-07-16; uzupełniony 2026-10-03 (Łódź — dopisana, wcześniej BRAK w podtabeli mimo 24 izb na liście NRA; Kielce — rewalidacja + 👁 OBSERWACJA):**

⛔ **WAŻNE ZASTRZEŻENIE STRUKTURALNE:** `wsd.adwokatura.pl` obejmuje WYŁĄCZNIE II instancję (WSD) i kasacje SN — **NIE obejmuje 24 sądów dyscyplinarnych I instancji poszczególnych izb adwokackich**. To dokładnie ta sama luka strukturalna, którą znaleziono u radców (`wsd.kirp.pl` też nigdy nie objął w pełni 19 OSD) — różnica jest tylko w jakości wykonania szczebla centralnego, nie w architekturze problemu.

| Izba (ORA) | Status archiwum orzeczeń I instancji |
|---|---|
| Kraków, Wrocław, Gdańsk, Katowice, Warszawa, Lublin, Szczecin, Rzeszów, Bydgoszcz, Zielona Góra, Białystok, Bielsko-Biała, Koszalin | ❌ SPRAWDZONE BEZPOŚREDNIO (13 z 24 izb; Kielce i Łódź — osobne wiersze niżej) — każda z tych stron ma WYŁĄCZNIE skład osobowy sądu dyscyplinarnego, **zero archiwów treści orzeczeń** |
| Kielce (Świętokrzyska Izba Adwokacka) — 👁 OBSERWACJA | ❌ POTWIERDZONE PONOWNIE 2026-10-03 (rewalidacja tury IX z 2026-07-16), bezpośredni fetch: strona główna, mapa strony, „Władze ORA”, „Uchwały ORA w Kielcach” oraz pełna paginacja „Komunikaty” (13 str.), „Aktualności” (15 str.), „Informacje”, „Z życia Izby” — szukano też wg lekcji Poznania (wzorzec „SD nr/rok”, „wydalenie”, „ukarany”, „orzeczenie”). Wynik: brak sekcji orzeczeń i brak pojedynczych ogłoszeń o orzeczeniach; „Władze ORA” zawiera wyłącznie skład Sądu Dyscyplinarnego i Rzecznika Dyscyplinarnego; „sprawy dyscyplinarne” tylko jako rozdział opracowania historycznego. 👁 Rewalidować przy każdym audycie podtabeli i po zmianie kadencji organów izby | `ora.kielce.pl` (lista NRA: `www.ora.kielce.pl` → przekierowanie); skład: `ora.kielce.pl/s,19,Wladze_ORA.html` |
| Łódź | ❌ POTWIERDZONE BEZPOŚREDNIO 2026-10-03 (NOWY WIERSZ — izba nr 11 na liście NRA, w poprzednich wersjach podtabeli pominięta) — fetch strony głównej, pełnej mapy strony WordPress (106 stron + wpisy) i strony „Samorząd”: wyłącznie skład Sądu Dyscyplinarnego, rzecznik prasowy SD i skład Rzecznika Dyscyplinarnego; zero archiwum orzeczeń. ⚑ Jedyny materiał dyscyplinarny: „Informacja Rzecznika Dyscyplinarnego” z 9.12.2016 o WSZCZĘCIU postępowań (sygn. RD 84/16) — komunikat o wszczęciu, NIE orzeczenie (ten sam typ co komunikaty rzecznika sędziów, nie format Poznania) | `lodz.adwokatura.pl/samorzad/`; komunikat: `lodz.adwokatura.pl/informacja-rzecznika-dyscyplinarnego-izby-adwokackiej-w-lodzi/` |
| Poznań | ⚠️→✅ KOREKTA (2026-07-16, zgłoszona przez użytkownika, zweryfikowana) — WCZEŚNIEJSZA OCENA BYŁA BŁĘDNA. Poznań PUBLIKUJE orzeczenia — nie w dedykowanym archiwum, lecz jako pojedyncze wpisy w kategorii "Ogłoszenia" na stronie głównej ORA. Potwierdzony przykład: orzeczenie SD 18/24 z 14.05.2024 (wydalenie z adwokatury), opisane też niezależnie w prasie lokalnej (Głos Wielkopolski, Nasze Miasto Leszno). WAŻNA HIPOTEZA DO DALSZEJ WERYFIKACJI: publikacja może dotyczyć wyłącznie kar WYDALENIA Z ADWOKATURY (gdzie prawdopodobnie istnieje odrębny obowiązek podania do publicznej wiadomości dla ochrony klientów), a NIE rutynowej publikacji wszystkich orzeczeń — to inny mechanizm niż zbiorcze archiwum Gdańska/Wrocławia u radców. LEKCJA METODOLOGICZNA: format "pojedyncze ogłoszenia" (jak wcześniej Rzeszów u radców) jest systematycznie niedoszacowywany przez wyszukiwanie po frazach typu "archiwum orzeczeń" — trzeba też szukać po konkretnych sygnaturach lub kategorii "ogłoszenia" | `ora.poznan.pl/2024/11/07/orzeczenie-sadu-dyscyplinarnego-izby-adwokackiej-w-poznaniu-o-sygn-akt-sd-18-24-z-dnia-14-05-2024-r/` |
| Częstochowa, Olsztyn, Opole, Płock, Radom, Siedlce, Toruń, Wałbrzych | ⚠️ ŻADNEGO ŚLADU ARCHIWUM w żadnym wyniku wyszukiwania (8 z 24 — KOREKTA 2026-10-03: poprzednio „9 z 24” przy 8 wymienionych izbach; brakującą 24. izbą była Łódź, dopisana wyżej), ale bez bezpośredniego fetchu pełnego menu każdej strony — status "prawdopodobnie negatywny, formalnie niepotwierdzony", analogicznie do metodyki radcowskiej |

**Cytat potwierdzający systemowo ten wzorzec (a nie przypadek):** prezes Wyższego Sądu Dyscyplinarnego adwokatury, zapytany wprost, czy klient ma prawo wiedzieć o karze nałożonej na adwokata, odpowiedział: "Znajduję uzasadnienie praktyczne, iż klient chciałby mieć informacje (?), jednak nie znajduję podstawy prawnej (?). Żaden przepis nie zobowiązuje nas do prowadzenia takiego publicznego rejestru." — czyli sam szef sądownictwa dyscyplinarnego adwokatury potwierdza brak prawnego obowiązku, nie tylko brak praktyki.

**Wniosek roboczy (zaktualizowany po korekcie Poznania):** 15 z 16 sprawdzonych bezpośrednio izb (stan 2026-10-03, po dopisaniu Łodzi) — zero archiwum; 1 (Poznań) publikuje wybiórczo, w formie pojedynczych ogłoszeń, prawdopodobnie tylko dla kar wydalenia. To NIE obala głównego wniosku (adwokatura ma niższą transparentność I instancji niż radcowie: ~1/16 vs 8/19), ale pokazuje, że "zero" nigdy nie powinno być traktowane jako pewnik bez próby wyszukania też po konkretnej sygnaturze/kategorii "ogłoszenia", nie tylko po frazie "archiwum orzeczeń" — dokładnie ta sama lekcja, co przy Rzeszowie u radców.
| Radca prawny | Okręgowy Sąd Dyscyplinarny (OSD) — lokalne strony per izba, patrz podtabela niżej | Wyższy Sąd Dyscyplinarny KRRP (WSD) → kasacja SN | ⚠️ **DEZAKTUALIZACJA WYKRYTA 2026-07-16:** `wsd.kirp.pl` — opisywany od 2018 r. jako "portal centralny orzecznictwa" — dziś (web_fetch 2026-07-16) **przekierowuje na stronę główną kirp.pl**; sekcja-następczyni "Biuro Orzecznictwa Dyscyplinarnego" (`kirp.pl/biuro-orzecznictwa/`) zawiera obecnie WYŁĄCZNIE pojedynczy PDF przeglądu orzecznictwa Izby Odpowiedzialności Zawodowej SN (styczeń-luty 2025), NIE przeszukiwalną bazę orzeczeń OSD/WSD. Status dawnego portalu: **NIEPOTWIERDZONY jako aktywna baza — traktować jako zdezaktualizowany, dopóki nie zostanie zweryfikowany ponownie**. Aktualnie właściwym źródłem per sprawę jest wyłącznie strona danej OIRP — patrz podtabela. |

**Podtabela OIRP — status zweryfikowany online 2026-07-16 (19 izb okręgowych):**

| OIRP | Status publikacji orzeczeń OSD | Zweryfikowany adres / źródło |
|---|---|---|
| Gdańsk | ✅ VER — własna, dedykowana podstrona z archiwum 2014–2025, orzeczenia pojedynczo w PDF (sygn., np. „D 9/22") | `oirp.gda.pl/izba/orzeczenia-okregowego-sadu-dyscyplinarnego/` |
| Wrocław | ✅ VER — własna podstrona, repertorium od 2012 r. do chwili obecnej, z uzasadnieniami | `oirp.wroclaw.pl/akty-prawne/orzeczenia-postanowienia-osd` |
| Lublin | ✅ VER 2026-11-14 — archiwum na stronie izby: pojedyncze PDF (ok. 320, zanonimizowane; data orzeczenia często zastąpiona „(…)”), sygnatury „OS n/rr” (postanowienia) i „D n/rr”; dawny adres w BIP (`bip.oirp.lublin.pl`) nie jest już miejscem publikacji | `oirp.lu/o-izbie/okregowy-sad-dyscyplinarny/orzeczenia-okregowego-sadu-dyscyplinarnego/` |
| Warszawa | ✅ VER 2026-11-14 — publikowane na stronie izby jako artykuły „Temidium” (lista z podziałem na strony, ok. 67 stron), np. orzeczenie z 2.06.2020, sygn. D 210/19; dawny adres `temidium.pl/orzeczenia_dyscyplinarne-10` nieaktualny | `oirpwarszawa.pl/dla-radcow-prawnych/odpowiedzialnosc-dyscyplinarna/okregowy-sad-dyscyplinarny-oirp-w-warszawie-2/orzeczenia-dyscyplinarne/` (pozycje: `oirpwarszawa.pl/temidium/artykul/...`) |
| Szczecin | ✅ VER — własna dedykowana podstrona, zanonimizowane orzeczenia i postanowienia OSD | `oirp.szczecin.pl/izba/orzeczenia-postanowienia-sadu-dyscyplinarnego/` |
| Katowice | ✅ VER 2026-11-14 — strony lat z PDF orzeczeń (`/add/vrecord/...pdf`), ale **tylko 2017–2018**; nowszych orzeczeń izba nie publikuje (badanie z 2019 r. wskazywało izbę jako nieodpowiadającą na wnioski) | `oirp.katowice.pl/orzeczenia-sadu-dyscyplinarnego/orzeczenia-sadu-dyscyplinarnego.html` (lata: `.../2017-orzeczenia-sadu-dyscyplinarnego.html`) |
| Kraków | 🔴 POTWIERDZONE DEFINITYWNIE (bezpośredni fetch treści, nie tylko strony menu) — BIP izby publikuje WYŁĄCZNIE zbiorcze statystyki liczbowe postępowań (liczba spraw, rodzaje rozstrzygnięć) w blokach wieloletnich: 2005-2009, 2010-2014, 2015-2017, 2018-2020. Zero treści orzeczeń, zero sygnatur, zero uzasadnień. Dodatkowo: **ostatnia aktualizacja statystyk to 2021 r. (dane do 2020)** — same statystyki są już nieaktualne o ok. 5 lat | `oirp.krakow.bip-e.pl/rpk/odpowiedzialnosc-dyscyp/zestawienie-postepowan` — potwierdzone: TYLKO statystyki, BRAK treści orzeczeń, dane nieaktualne od 2021 |
| Białystok | ⚠️ KOREKTA (2026-07-16, po dokładniejszym sprawdzeniu) — poprzednia kategoria 🟡 była ZA MOCNA: opis anonimizacji z badania 2019 r. dotyczy prawdopodobnie SKANÓW przesłanych badaczowi prywatnie w odpowiedzi na wniosek o informację publiczną ("czternaście OSD przesłało żądane skany LUB wskazało miejsce publikacji" — z kontekstu nie wynika które z dwóch dotyczyło Białegostoku), NIE potwierdzonej publicznej strony z archiwum. BIP izby (`oirp.bialystok.pl/izba/bip/`) zawiera dane organizacyjne, ale BRAK znalezionego archiwum treści orzeczeń. Dodatkowo: niezależne źródło dziennikarskie (Stowarzyszenie Polskich Mediów, 2021) opisuje krytycznie funkcjonowanie nadzoru dyscyplinarnego w tej izbie, w tym konkretny przypadek — wyrok OSD Białystok z czerwca 2016 r. uchylony przez SN w maju 2017 r. za rażące naruszenie procedury (brak przeprowadzenia jakichkolwiek dowodów na rozprawie) — wartościowy precedens merytoryczny, niezależnie od kwestii publikacji | `oirp.bialystok.pl/izba/bip/` (dane organizacyjne, BRAK potwierdzonego archiwum orzeczeń) |
| Olsztyn | ⚠️ KOREKTA (2026-07-16) — jak wyżej dla Białegostoku: opis anonimizacji z 2019 r. NIE jest pewnym dowodem publicznej strony internetowej z archiwum, mogły to być skany przesłane prywatnie. Brak potwierdzonego adresu w tej sesji | do ustalenia dokładny URL w kolejnym audycie |
| Zielona Góra | ⚠️ NIEPOTWIERDZONE — stara strona (`zielonagora.oirp.pl/page/...`) zwraca dziś 404, izba przeniosła się na nowy adres z działającą stroną składu OSD, ale bez znalezionego archiwum treści orzeczeń | `zielonagora.oirp.pl/organy-izby/` (skład potwierdzony, archiwum orzeczeń niepotwierdzone; stara ścieżka nieaktualna) |
| Kielce | ✅ VER — pełne archiwum od 2007 do 2025, z uczciwą adnotacją "OSD nie wydała żadnego orzeczenia" dla lat 2008 i 2009 zamiast milczenia | `oirpkielce.pl/o-izbie/odpowiedzialnosc-dyscyplinarna/orzeczenia-osd` |
| Rzeszów | ✅ VER 2026-11-14 — strony lat (`/radcowie/odpowiedzialnosc-dyscyplinarna/RRRR`, od 2016) z plikami `item.php?id=N` (PDF-skany, sygn. „OSD n rr”) | `oirp.rzeszow.pl/radcowie/odpowiedzialnosc-dyscyplinarna` |
| Łódź, Poznań | ❌ POTWIERDZONE NEGATYWNIE (pełny fetch całej struktury menu, nie tylko snippetu) — obie strony mają wyłącznie stronę składu OSD/BIP, bez jakiegokolwiek linku do archiwum orzeczeń w całym drzewie menu | Łódź: `oirplodz.pl/o-nas/struktura-oirp/`; Poznań: `poznan.oirp.pl/o-izbie/organy/` + BIP — sprawdzone kompletnie, brak archiwum |
| Bydgoszcz, Wałbrzych | ❌/🟠 ZWERYFIKOWANE DOKŁADNIEJ (2026-07-16, siódma tura) — Wałbrzych: pełne menu główne sprawdzone, BRAK linku do archiwum orzeczeń na stronie głównej; JEST jednak osobny BIP (`oirpwalbrzych.ibip.wroc.pl`), który mógłby zawierać archiwum, ale **ten BIP blokuje automatyczny dostęp (ROBOTS_DISALLOWED)** — TRZECI już w tej sesji, realny przypadek treści potencjalnie istniejącej, ale niedostępnej dla narzędzi web_fetch (po Toruniu i wcześniejszych sądach powszechnych z CAPTCHA). Bydgoszcz: sprawdzona strona główna i "Organy Izby" — tylko skład OSD, brak archiwum, brak zmiany względem 2019 r. | Wałbrzych: `oirpwalbrzych.ibip.wroc.pl` — 🟠 zablokowane dla automatycznego dostępu, wymaga ręcznego sprawdzenia przez człowieka w przeglądarce; Bydgoszcz: `oirp.bydgoszcz.pl/o-izbie/organy-izby/` — ❌ brak archiwum |
| Toruń | 🟠 ZNALEZIONE, ALE TECHNICZNIE NIEDOSTĘPNE (rzeczywisty przypadek analogiczny do problemu "zablokowane dla crawlerów" omawianego wcześniej w tej sesji) — na stronie widoczny jest wprost link "Orzeczenia OSD", ale strona korzysta z WordPress Download Manager (JS), więc zwykły fetch nie dociera do listy plików — wymaga renderowania przeglądarki, nie samego pobrania HTML. To dowód, że orzeczenia PRAWDOPODOBNIE istnieją, ale nie da się tego potwierdzić narzędziami web_search/web_fetch | `torun.oirp.pl/o-izbie/organy/okregowy-sad-dyscyplinarny/` — sekcja "Orzeczenia OSD" istnieje, treść niedostępna przez prosty fetch |
| Koszalin, Opole | ⚠️ NIE ZNALEZIONE mimo wielokrotnych prób — tylko dane teleadresowe rzecznika/OSD | do sprawdzenia bezpośrednim fetchem stron głównych w kolejnym audycie |

**Precedens prawny istotny dla całej kategorii:** 11 kwietnia 2019 r. Wyższy Sąd Dyscyplinarny KIRP, rozpatrując odwołanie wniesione przez Sieć Obywatelską Watchdog Polska, uchylił decyzję OSD OIRP Warszawa odmawiającą udostępnienia orzeczeń dyscyplinarnych jako informacji publicznej — co potwierdza, że orzeczenia dyscyplinarne radców prawnych **są informacją publiczną i podlegają udostępnieniu na wniosek**, nawet gdy dana izba nie publikuje ich z własnej inicjatywy online. Źródło: informacjapubliczna.org (praca magisterska UZ 2019, nagrodzona, oparta na wnioskach o informację publiczną do 19 OIRP).
| Lekarz | Okręgowy Sąd Lekarski (OSL) | Naczelny Sąd Lekarski (NSL) → kasacja SN | `nil.org.pl/orzeczenia` — portal NIL uruchomiony 2024 (OSL+NSL, zanonimizowane); kasacje SN skompilowane pod `nil.org.pl/izba/naczelny-rzecznik-odpowiedzialnosci-zawodowej/dokumenty/orzeczenia-sadu-najwyzszego` (sygn. SDI / II ZK) |
| **Sędzia / asesor sądowy** *(NOWA POZYCJA — dot. też dr-01, USP)* | **Sąd Dyscyplinarny przy Sądzie Apelacyjnym** (art. 110 USP) — osobny w każdej apelacji: Lublin (`lublin.sa.gov.pl`), Poznań, Warszawa, Gdańsk, Rzeszów, Katowice i in. | Sąd Najwyższy, Izba Odpowiedzialności Zawodowej (dawniej Izba Dyscyplinarna) | Strony poszczególnych SA opisują skład/kompetencję sądu dyscyplinarnego, ale BEZ potwierdzonego archiwum treści orzeczeń; jawne są za to KOMUNIKATY o wszczętych postępowaniach na `rzecznik.gov.pl` (Rzecznik Dyscyplinarny Sędziów Sądów Powszechnych) — to NIE są pełne orzeczenia, tylko zawiadomienia o wszczęciu/zarzutach; kasacja → **sn.pl** |
| Notariusz | Sąd Dyscyplinarny Izby Notarialnej | Wyższy Sąd Dyscyplinarny przy Krajowej Radzie Notarialnej (korporacyjny, NIE sąd apelacyjny) → kasacja SN | Brak potwierdzonego scentralizowanego publicznego portalu; orzeczenia uznane za informację publiczną na żądanie (WSA, sygn. II SA/Wa 1455/13), ale bez stałej bazy online; kasacja → **sn.pl** (sygn. SDI, np. "SDI 74/17") |
| Komornik sądowy | Komisja Dyscyplinarna przy KRK | Sąd apelacyjny (JEDYNY zawód z tej listy, gdzie II instancja to sąd powszechny) | Brak potwierdzonego portalu KRK; pojedyncze orzeczenia bywają zaindeksowane w **saos.org.pl** (potwierdzony przykład); II instancja → **orzeczenia.ms.gov.pl** |
| Rzecznik patentowy | Sąd Dyscyplinarny PIRP | Odwoławczy Sąd Dyscyplinarny PIRP (korporacyjny) → kasacja SN | Brak potwierdzonego portalu PIRP; kasacja → **sn.pl** |

**Uwaga krytyczna (zaktualizowana):** jawność I/II instancji korporacyjnej jest
**nierówna między zawodami I między poszczególnymi izbami tego samego zawodu**
(np. wśród OIRP niektóre publikują, inne nie odpowiadają nawet na wnioski o
informację publiczną). Adwokatura ma obecnie największy zweryfikowany portal
(1151+ pozycji), ale to NIE oznacza kompletności — traktuj każdy wynik zerowy
jako możliwą lukę bazy, nie jako dowód zmyślenia sygnatury: oznacz
⚠️ [NIEWERYFIKOWALNE — baza korporacyjna niekompletna/nieaktualna/lokalna],
nigdy ✅ [VER] bez faktycznego odnalezienia treści. Dopiero kasacja do SN (lub
— wyłącznie dla komornika — odwołanie do sądu apelacyjnego) podlega pełnej,
niezawodnej procedurze weryfikacji sygnatury wg PRAWO-HARDGATE KROK 0–5.

## 8. Łącz obowiązkowo z


| Potrzeba | Moduł współdzielony / skill |
|---|---|
| aktualność prawa | `shared/ISAP-AUDIT-PROTOCOL.md` + `prawo-polskie-v2/krajowe/shared/ISAP-METRYKI-AKTOW.md` |
| stan prawny w czasie | `shared/TEMPORAL-LAW-CHECK.md` |
| braki formalne | `prawo-polskie-v2/krajowe/shared/BRAKI-FORMALNE.md` |
| warunki skuteczności | `shared/WARUNKI-SKUTECZNOSCI.md` |
| dowody | `shared/DOWODY-METODOLOGIA.md` + `analizator-dowodow-v3` |
| ryzyka | `shared/RISK-ASSESSMENT.md` |
| **weryfikacja orzeczeń dyscyplinarnych** | `prawo-polskie-v2/krajowe/shared/PRAWO-HARDGATE.md` (sekcja "zawody zaufania publicznego — odpowiedzialność dyscyplinarna") + `orzeczenia-sadowe-v2` |
| pisma | `pisma-procesowe-v3` albo `pisma-proste-v2` |
| analiza sądowa | `analiza-sadowa-v6` |

---

**Dokumenty samorządu zawodowego** (uchwały, kodeks etyki, regulaminy, rejestr członków): `view prawo-polskie-v2/krajowe/shared/SAMORZADY-ZAWODOWE-DOKUMENTY.md` — sekcja 2 (zawody prawnicze), 3–4 (pozostałe); RZĄD 1 tylko z oficjalnego portalu samorządu.

## STATUS KANCELARSKI

**Status:** moduł klasy kancelaryjnej — poziom DR-03
**Data weryfikacji:** 2026-07-06 (dodano sekcję 4a — orzecznictwo dyscyplinarne + spięcie z PRAWO-HARDGATE)
**Zasada:** Każde brzmienie przepisu przed powołaniem → isap.sejm.gov.pl
