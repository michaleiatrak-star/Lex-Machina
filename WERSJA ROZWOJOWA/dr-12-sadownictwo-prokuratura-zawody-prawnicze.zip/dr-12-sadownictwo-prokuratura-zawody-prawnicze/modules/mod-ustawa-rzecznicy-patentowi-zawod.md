# mod-ustawa-rzecznicy-patentowi-zawod — Rzecznik patentowy jako zawód zaufania publicznego

**Akt:** USP (Prawo o ustroju sądów powszechnych) — t.j. Dz.U. 2024 poz. 334 (zm. po t.j.: 2024/1907 od 2025-01-01 — art. 49; 2025/526 od 2025-05-07 — art. 77; 2025/820 od 2025-07-25 — art. 16; 2025/1609 od 2025-12-09 — art. 1, 2, 22a; 2025/1172 od 2026-03-01 — art. 20, 53e, 157b; 2025/1178 od 2026-03-01 — art. 41, 53e; 2026/370 od 2026-04-03 — art. 147, 149, 155, 155a, 155ca, 155cb, 155d, 155e; 2026/26 [OD 2027-01-01: 2026/26] — art. 70, 94, 94b, 94d; 2026/1123 [OD 2028-01-01: 2026/1123] — art. 94).
**Akt:** PrAdw (Prawo o adwokaturze) — t.j. Dz.U. 2024 poz. 1564 (zm. po t.j.: 2025/1172 od 2026-03-01 — art. 4, 37d; 2026/370 od 2026-04-03 — art. 66, 78a; 2026/846 od 2026-10-01 — art. 6; 2026/1290 od 2026-10-17 — art. 1, 1a, 3, 4, 4b, 4c, 4ca, 7, 8a, 10, 11, 12, 16a, 16b, 16c, 16d, 16e, 37a, 40, 42).
**Akt:** URP (ustawa o radcach prawnych) — t.j. Dz.U. 2024 poz. 499 (zm. po t.j.: 2025/1172 od 2026-03-01 — art. 6, 2211; 2026/370 od 2026-04-03 — art. 25, 362; 2026/731 od 2026-06-18 — art. 1, 5a, 5b, 5c, 5d, 8, 8a, 12, 12a, 22, 28, 35, 37, 45, 52, 52a, 60, 60a, 62, 64; 2026/846 od 2026-10-01 — art. 3).
**Akt:** URzP (ustawa o rzecznikach patentowych) — t.j. Dz.U. 2026 poz. 778 (zm. po t.j.: 2026/846 od 2026-10-01 — art. 14).
**Akt:** KPK (Kodeks postępowania karnego) — t.j. Dz.U. 2026 poz. 490 (zm. po t.j.: 2026/421 od 2026-04-14 — art. 21h, 74, 213, 332, 336; 2026/638 od 2026-05-28 — art. 25; 2026/760 od 2026-06-12 — art. 21h, 74, 213, 332; 2026/882 od 2026-07-16 — art. 607k, 607m, 607t, 607y, 607ya, 607zb; 2026/901 od 2026-07-21 — art. 87).
**Akt:** PPSA (Prawo o postępowaniu przed sądami administracyjnymi) — t.j. Dz.U. 2026 poz. 143 (zm. po t.j.: 2026/846 od 2026-06-26 — art. 53, 264).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

**Standard jakości:** stosuj `prawo-polskie-v2/krajowe/shared/MODULE-STANDARD-POLISH-LAW.md` oraz `prawo-polskie-v2/krajowe/shared/POLISH-LAW-COMPLETENESS-MATRIX.md`.
**Status:** moduł NOWY — utworzony 2026-06-14 (audyt: pokrycie "zawodów zaufania
publicznego" — grupa (c) zawody powstałe w wyniku rozwoju gospodarki rynkowej,
analiza Senatu OT-625).
---
WSPÓLNE ZASADY DLA MODUŁU:
- przed cytowaniem przepisu zastosuj `shared/ISAP-AUDIT-PROTOCOL.md`;
- metryki aktów sprawdzaj w `prawo-polskie-v2/krajowe/shared/ISAP-METRYKI-AKTOW.md`;
- jeżeli sprawa jest procesowa, uruchom `prawo-polskie-v2/krajowe/shared/FORMAL-CHECK.md`, `shared/WARUNKI-SKUTECZNOSCI.md`, `prawo-polskie-v2/krajowe/shared/TERM-CALC.md`, `shared/RISK-ASSESSMENT.md`;
- ⛔ ZAKAZ podawania artykułów, terminów, sygnatur z pamięci — weryfikuj w ELI (RZĄD 1).
---

## KLUCZOWE AKTY PRAWNE — ZWERYFIKOWANE 2026-06-14

```
Ustawa o rzecznikach patentowych (z 11.04.2001):
  t.j. Dz.U. 2026 poz. 778 ✅ VER: isap.sejm.gov.pl 2026-06-14
  → https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20240000749

Nowelizacja: ustawa z 17.10.2025 o zmianie ustawy o rzecznikach patentowych
  Dz.U. 2025 poz. 1679 ✅ VER: 2026-06-14
  → weszła w życie 3.02.2026 (potwierdzone: projekt rozp. PRM, gov.pl/web/premier)
  → zakres: rozszerzenie listy rzeczników patentowych i aplikantów o numer PESEL
    (niezbędne dla pełnego korzystania z portalu informacyjnego sądów —
    art. 53e § 1 Prawa o ustroju sądów powszechnych, Dz.U. 2024 poz. 334)

⚠️ PROJEKT (status: weryfikuj online przed powołaniem) — odrębna inicjatywa:
  zwolnienie adwokatów i radców prawnych z części egzaminu na rzecznika
  patentowego (część dot. prawa oraz kazus) — argumentacja projektu odwołuje się
  wprost do "innych zawodów zaufania publicznego" (adwokat, radca prawny) jako
  punktu odniesienia. web_search: "projekt ustawy rzecznicy patentowi zwolnienie
  adwokatów egzamin 2026 status"
```

---

## ZASADY ABSOLUTNE

```
1. Zawód rzecznika patentowego jest USTAWOWO zawodem zaufania publicznego
   (art. 1 ustawy o rzecznikach patentowych — wprost w tekście ustawy).
   Tytuł zawodowy "rzecznik patentowy" jest prawnie chroniony.

2. Samorząd: Polska Izba Rzeczników Patentowych — Krajowa Rada Rzeczników
   Patentowych (KRRP) + okręgowe zgromadzenia. Lista rzeczników i aplikantów
   prowadzona przez Urząd Patentowy RP na podstawie informacji z KRRP.

3. Zakres działania (art. 4 i n. ustawy — weryfikuj aktualne brzmienie):
   → pomoc prawna: porady, opinie prawne, badanie stanu prawnego przedmiotów
     własności przemysłowej, zastępstwo prawne i procesowe
   → pomoc techniczna: opisy techniczne zgłoszeń, badanie zakresu ochrony,
     poszukiwania stanu techniki
   → zastępstwo: przed Urzędem Patentowym, sądami i organami orzekającymi
     w sprawach własności przemysłowej — Z WYJĄTKIEM postępowania karnego
     i karnego skarbowego (weryfikuj aktualny zakres wyłączeń)

4. ⚠️ ROZSZERZENIE KOMPETENCJI ADWOKATÓW/RADCÓW (2019-2020):
   Adwokaci i radcowie prawni mogą reprezentować strony przed UP RP w zakresie
   znaków towarowych, wzorów przemysłowych i oznaczeń geograficznych — to NIE
   jest wyłączny monopol rzeczników patentowych. Rzecznicy patentowi z kolei
   mogą występować we wszystkich sprawach własności intelektualnej (nie tylko
   przemysłowej) od 2020 r. — weryfikuj aktualny zakres w ELI (RZĄD 1).

5. Odpowiedzialność dyscyplinarna: sądy dyscyplinarne samorządu (Polska Izba
   Rzeczników Patentowych) — weryfikuj aktualną procedurę w ustawie.

6. Zawieszenie/utrata prawa wykonywania zawodu (art. 23-24 ustawy):
   → obowiązek zawiadomienia KRRP w terminie 1 miesiąca o okolicznościach
     skutkujących zawieszeniem
   → KRRP podejmuje uchwałę w terminie 3 miesięcy
   → na uchwałę KRRP — skarga do sądu administracyjnego w terminie 30 dni
     (✅ VER: isap.sejm.gov.pl/isap.nsf/download.xsp/WDU20240000749, 2026-06-14)
```

---

## INTAKE

```
□ rola: rzecznik patentowy / klient / Urząd Patentowy / samorząd (KRRP)
□ przedmiot sprawy: zgłoszenie patentowe/znaku/wzoru, spór o zastępstwo,
  odpowiedzialność dyscyplinarna, zawieszenie/skreślenie z listy
□ czy sprawa wymaga rozróżnienia kompetencji rzecznik patentowy vs adwokat/
  radca prawny (znaki towarowe/wzory/oznaczenia geograficzne — kompetencja
  dzielona)?
□ data doręczenia decyzji UP RP / uchwały KRRP i termin na środek
□ czy sprawa dotyczy PESEL w rejestrze (nowelizacja 2025/1679, wejście
  w życie 3.02.2026) — termin 30 dni od wejścia w życie na zgłoszenie?
```

---

## MAPA PROCEDURALNA

```
Zgłoszenie / decyzja UP RP / uchwała KRRP (zawieszenie, skreślenie)
  ↓
Kwalifikacja: postępowanie przed UP RP / skarga do WSA / postępowanie
  dyscyplinarne / spór cywilny (wynagrodzenie, odpowiedzialność rzecznika)
  ↓
Właściwy organ: UP RP / WSA w Warszawie (z zasady dla decyzji UP RP) /
  sąd dyscyplinarny PIRP / sąd cywilny
  ↓
Środek: odwołanie / skarga do WSA (30 dni od uchwały KRRP wg art. 24) /
  pozew / odwołanie dyscyplinarne
  ↓
Walidacja formalna: prawo-polskie-v2/krajowe/shared/FORMAL-CHECK.md + shared/WARUNKI-SKUTECZNOSCI.md
  ↓
Ocena ryzyka: shared/RISK-ASSESSMENT.md
```

---

## WARUNKI SKUTECZNOŚCI

```
□ prawidłowy organ (UP RP / WSA / sąd dyscyplinarny / sąd cywilny)
□ termin: 30 dni do WSA na uchwałę KRRP (art. 24 — weryfikuj aktualne brzmienie)
□ legitymacja: rzecznik patentowy / klient / KRRP
□ kontrola ISAP na dzień zdarzenia i na dzień orzekania
□ czy sprawa dotyczy znaków/wzorów/oznaczeń geograficznych — sprawdź czy
  pełnomocnik (adwokat/radca) ma kompetencję, czy wymagany rzecznik patentowy
```

---

## ORZECZNICTWO

```
Nie twórz fikcyjnych sygnatur. Szukaj w:
- orzeczenia.nsa.gov.pl (sprawy własności przemysłowej, skargi na UP RP)
- sn.pl
- LEX/Legalis pomocniczo

web_search: "rzecznik patentowy zawieszenie prawa wykonywania zawodu skarga WSA orzecznictwo"
web_search: "kompetencje rzecznika patentowego adwokat radca prawny znaki towarowe orzecznictwo"
```

---

## QUALITY GATE

```
□ Czy zawód rzecznika patentowego potraktowany jako zawód zaufania publicznego
  (art. 1 ustawy — fakt ustawowy, nie interpretacja)?
□ Czy rozróżniono kompetencje rzecznik patentowy vs adwokat/radca prawny
  (znaki/wzory/oznaczenia — dzielone; pozostałe IP — rzecznik patentowy)?
□ Czy sprawdzono nowelizację Dz.U. 2025 poz. 1679 (PESEL w rejestrze,
  w życie 3.02.2026) jeśli sprawa dotyczy wpisu na listę?
□ Czy termin na skargę do WSA (art. 24) zweryfikowany w ISAP?
□ Czy każde brzmienie przepisu zweryfikowane online — żadnych cytatów z pamięci?
```

---

## POWIĄZANIA

| Sytuacja | Skill / Moduł |
|---|---|
| Postępowanie przed UP RP w sprawach IP (materialne) | DR-11 → moduły IP/własność przemysłowa |
| Kompetencje adwokata/radcy w sprawach IP | DR-12/`mod-ustawa-adwokatura`, `mod-ustawa-radcowie-prawni` |
| Skarga do WSA na decyzję UP RP / uchwałę KRRP | `dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-PPSA-terminy-kasacja-prawo-pomocy.md` |
| Pismo: skarga / odwołanie | `pisma-procesowe-v3` albo `pisma-proste-v2` |

---

## ZMIANA OD 1.10.2026 — TAJEMNICA A MDR

Art. 9 ustawy z 29.05.2026 r. (Dz.U. 2026 poz. 846) nadaje art. 14 ust. 2
ustawy o rzecznikach patentowych analogiczne, zawężone odesłanie wyłącznie
do informacji udostępnianych na podstawie przepisów AML, w zakresie przez
nie określonym. Usunięto równoległe odesłanie do rozdziału 11a Ordynacji
podatkowej; wejście w życie 1.10.2026 r.

## ŹRÓDŁA WERYFIKACJI

| Źródło | URL | Zakres |
|---|---|---|
| ISAP — tekst jednolity | isap.sejm.gov.pl | t.j. Dz.U. 2026 poz. 778 (✅ [VER] RZĄD 1 2026-09-16e; `2024/749` — poprzedni t.j., wygasły; `2025/1679` — nowelizacja objęta t.j.) |
| Urząd Patentowy RP | uprp.gov.pl | Lista rzeczników, postępowania, decyzje |
| Polska Izba Rzeczników Patentowych | rzecznikpatentowy.org.pl | Samorząd, KRRP, sądy dyscyplinarne |
| Orzecznictwo NSA | orzeczenia.nsa.gov.pl | Skargi na decyzje UP RP |

---

## ⚖️ DISCLAIMER

Po zakończeniu analizy: `view shared/DISCLAIMER.md` — wariant wg trybu (PRAWNIK/LAIK).

---
*mod-ustawa-rzecznicy-patentowi-zawod.md · dr-12 · utworzony 2026-06-14*
