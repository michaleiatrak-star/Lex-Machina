# mod-DG-prawo-wojskowe-obrona-mobilizacja — Prawo wojskowe, obrona Ojczyzny i mobilizacja

Status modułu: pełny moduł prawa polskiego klasy wzorcowej — analogiczny funkcjonalnie do modułów prawa pracy i prawa karnego.
Data wdrożenia: 2026-05-28
Źródło prawa: ISAP jako źródło podstawowe; LEX/Legalis pomocniczo wyłącznie przy braku bezpośredniego dostępu do aktu lub komentarza.

## 1. CORE

### Zakres
Moduł obejmuje obowiązek obrony, służbę wojskową, kwalifikację wojskową, mobilizację, WCR, świadczenia na rzecz obrony, postępowania służbowe i dyscyplinarne żołnierzy oraz relacje z prawem karnym wojskowym.

### Akty i źródła kontrolne
- Ustawa o obronie Ojczyzny — Dz.U. 2025 poz. 825 t.j. (obwieszczenie Marszałka
  Sejmu z 11.06.2025) — poprzedni t.j./pierwotna publikacja Dz.U. 2022 poz. 655
  NIEAKTUALNA, zastąpiona przez t.j. 2025.825; ⏳ Po t.j. (ELI 2026-10-12): Dz.U.
  2025 poz. 1014, 1080; Dz.U. 2026 poz. 26, 426, 635, 815 (od 4.07.2026), 1123. ⚠️ [F-57, 2026-08-14] wcześniejsza wersja tego modułu błędnie podawała
  2022.655 jako podstawę mimo że mapa DR-13 od 2026-07-02 wskazywała już 2025.825
  jako aktualny t.j. — naprawione.
- Kodeks karny — część wojskowa i przepisy szczególne, kontrola ISAP.
- Akty wykonawcze MON dotyczące kwalifikacji, służby, uposażeń i orzecznictwa — kontrola ISAP.

### Zasada aktualności
Przed użyciem przepisu, podstawy prawnej, Dz.U., terminu lub cytatu należy wykonać kontrolę według:

- `shared/ISAP-AUDIT-PROTOCOL.md`,
- `shared/TEMPORAL-LAW-CHECK.md`,
- `shared/LEGAL-LIFECYCLE-MANAGEMENT.md`,
- `shared/LEGAL-QUALITY-GATE.md`.

Nie wolno rekonstruować literalnego brzmienia przepisu z pamięci modelu.

## 2. INTAKE

Ustal obowiązkowo:

1. kto jest klientem i jaki ma status procesowy lub administracyjny;
2. jaki akt, czynność, decyzja, uchwała, zaniechanie albo orzeczenie jest kwestionowane;
3. datę doręczenia, publikacji, ogłoszenia, wejścia w życie albo dokonania czynności;
4. organ właściwy i tryb kontroli;
5. czy sprawa jest materialna, proceduralna, dyscyplinarna, kontrolna, nadzorcza, konstytucyjna, europejska albo egzekucyjna;
6. czy istnieje termin zawity, prekluzja, środek zaskarżenia, skarga albo wniosek o zabezpieczenie;
7. jakie dowody istnieją, jaką mają moc i czy są kompletne;
8. jaki jest realny cel: uchylenie, zmiana, stwierdzenie naruszenia, odszkodowanie, zabezpieczenie, dostęp do akt, wstrzymanie wykonania, unieważnienie albo sankcja.

## 3. PROCEDURA

### Mapa proceduralna
- wezwanie do kwalifikacji wojskowej lub WCR
- decyzje i rozkazy personalne
- odwołania w sprawach służbowych i uposażeniowych
- postępowania dyscyplinarne wojskowe
- świadczenia rzeczowe i osobiste na rzecz obrony
- kontrola orzeczeń komisji lekarskich
- skargi administracyjne i sądowoadministracyjne, jeżeli dopuszczalne

### Warunki skuteczności
Sprawdź: właściwość organu/sądu, legitymację, termin, formę, opłatę, podpis, załączniki, pełnomocnictwo, odpisy, tryb doręczenia, żądanie, podstawę faktyczną, podstawę prawną, dowody i właściwy środek zaskarżenia.

## 4. DOWODY

### Matryca dowodowa
- wezwania, decyzje, rozkazy, dokumentacja WCR
- orzeczenia lekarskie i psychologiczne
- dokumenty służbowe, opinie, karty przebiegu służby
- dowody rodzinne, zdrowotne, zawodowe i edukacyjne
- dowody doręczeń i terminów
- akta dyscyplinarne

### Ocena dowodów
Każdy dowód przypisz do konkretnej tezy. Oddziel fakty od ocen. Oznacz dowody bezpośrednie, pośrednie, urzędowe, prywatne, elektroniczne, eksperckie i osobowe. Wskaż luki dowodowe i sposób ich usunięcia.

## 5. STRATEGIA

### Strategia procesowa i kancelaryjna
- ustalić czy czynność ma charakter decyzji administracyjnej, rozkazu, aktu wewnętrznego czy czynności materialno-technicznej
- w sprawach zdrowotnych budować argumentację funkcjonalną i medyczną
- w dyscyplinarkach kontrolować kompetencję przełożonego i gwarancje obrony
- w mobilizacji i świadczeniach badać proporcjonalność, podstawę i tryb
- oddzielić odpowiedzialność służbową od karnej

### Kontrargumenty przeciwnika/organu
Dla każdej tezy przewidź: zarzut braku legitymacji, przekroczenia terminu, niewłaściwego trybu, braku interesu prawnego, nieudowodnienia szkody, braku związku przyczynowego, braku kompetencji organu, związania organu przepisem albo niedopuszczalności środka.

## 6. ORZECZNICTWO

Orzecznictwo dobieraj wyłącznie z realnych źródeł. Preferuj: TK, SN, NSA, TSUE, ETPC, sądy apelacyjne i WSA/SO zgodnie z właściwością dziedziny. Nie wolno tworzyć fikcyjnych sygnatur. Cytat z orzeczenia wymaga pobrania z publicznego źródła albo zweryfikowanej bazy.

## 7. RYZYKA

- ryzyko ograniczonej kognicji sądu administracyjnego
- ryzyko krótkich terminów służbowych
- ryzyko niejawności lub ograniczonego dostępu do akt
- ryzyko podporządkowania służbowego i trudności dowodowych
- ryzyko równoległości dyscyplinarnej i karnej

## 8. CHECKLISTA WYJŚCIOWA

Przed wygenerowaniem pisma lub analizy odpowiedz:

- Jaki jest tryb i organ?
- Jaki jest termin?
- Jaki przepis został zweryfikowany w ISAP?
- Czy brzmienie przepisu jest aktualne na dzień czynności?
- Jakie fakty są udowodnione?
- Jakie fakty są tylko twierdzeniem?
- Jakie dowody są decydujące?
- Jakie są trzy najsilniejsze argumenty przeciwnika?
- Jakie jest największe ryzyko oddalenia, odrzucenia albo zwrotu?
- Jaka jest rekomendowana czynność procesowa?

## 9. POWIĄZANIA

- `dr-13-sluzby-bezpieczenstwo-informacje-niejawne/modules/mod-ustawa-zandarmeria-wojskowa.md`
- `dr-13-sluzby-bezpieczenstwo-informacje-niejawne/SKILL.md` → dobierz właściwy moduł ustawy danej służby (Policja/SG/PSP/ABW-AW-CBA/SKW-SWW/ŻW)
- `dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-KPK-framework-karne.md`
- `dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-medyczne-szczegolowy.md`

## 10. OUTPUT

Wynik pracy modułu powinien mieć strukturę: stan faktyczny → kwalifikacja prawna → tryb → terminy → dowody → zarzuty → kontrargumenty → ryzyka → strategia → wnioski → lista czynności.

---

## KLUCZOWE AKTY — ZWERYFIKOWANE 2026-08-14 (F-57)

```
Ustawa o obronie Ojczyzny:
  Dz.U. 2025 poz. 825 t.j. (obwieszczenie Marszałka Sejmu z 11.06.2025)
  — pierwotna publikacja Dz.U. 2022 poz. 655 NIEAKTUALNA jako podstawa cytowania
  → Dz.U. 2025 poz. 1014 — nowelizacja po t.j. 2025.825, weryfikuj czy uwzględniona
    w kolejnym t.j.
  ⏳ Po t.j. (ELI 2026-10-12) także: Dz.U. 2025 poz. 1080; Dz.U. 2026 poz. 26, 426,
    635, 815, 1123
  → Dz.U. 2026 poz. 815 (od 4.07.2026), art. 23 — zmienia WYŁĄCZNIE art. 650:
    pkt 1: wyrazy „w jednolitym wykazie obiektów, instalacji, urządzeń i usług
    wchodzących w skład infrastruktury krytycznej” zastąpiono wyrazami „w wykazie,
    o którym mowa w art. 6r ust. 1 ustawy z dnia 26 kwietnia 2007 r. o zarządzaniu
    kryzysowym”; pkt 2: „2) przepisach rozdziału 7 ustawy z dnia 26 kwietnia 2007 r.
    o zarządzaniu kryzysowym.” (zm. Dz.U. 2026 poz. 815, od 4.07.2026)
  ✅ VER: isap.sejm.gov.pl (WDU20250000825) 2026-08-14 (F-57) — koryguje poprzedni
    błędny zapis tego modułu, który mimo poprawki mapy z 2026-07-02 nadal podawał
    2022.655 jako podstawę
  ⚠️ weryfikuj każdą kolejną zmianę w ELI (RZĄD 1) przed powołaniem

Kluczowe procedury:
  Kwalifikacja wojskowa i rekrutacja — WCR (Wojskowe Centrum Rekrutacji):
    ⚠️ [F-57, korekta 2026-08-14] WKU (Wojskowa Komenda Uzupełnień) NIE jest
    odrębną instytucją równoległą do WCR — to HISTORYCZNA NAZWA TEGO SAMEGO
    organu, zniesiona z dniem 23.04.2022 r. wraz z wejściem w życie ustawy
    o obronie Ojczyzny. Od tej daty WKU → WCR (Wojskowe Centrum Rekrutacji),
    a Wojewódzkie Sztaby Wojskowe → Centralne Wojskowe Centrum Rekrutacji.
    "WKU" można używać wyłącznie przy odniesieniu do stanu prawnego/faktycznego
    SPRZED 23.04.2022 — w pismach dot. spraw bieżących używać wyłącznie WCR.
    ✅ VER: rdn.pl, informatorbrzeski.pl, suwalki.info (8 zgodnych źródeł) 2026-08-14
    → Wezwanie przez WCR
    → Orzeczenie Wojskowej Komisji Lekarskiej (WKL)
    → Odwołanie od orzeczenia WKL: do Centralnej Wojskowej Komisji Lekarskiej
    → Zaskarżenie do WSA (w zakresie decyzji administracyjnych)
    → Rejestracja żołnierzy zawodowych i ochotniczej służby
    → Dobrowolna zasadnicza służba wojskowa (DZSW)

  Świadczenia na rzecz obrony (rekwizycja):
    → Decyzja wójta / starosty / Wojewody
    → Odszkodowanie za rekwizycję — weryfikuj przepisy w ELI (RZĄD 1)
    → Zaskarżenie: odwołanie → WSA

  Wydatki na obronę: docelowo 5% PKB — aktualizuj ze źródeł

web_search: "ustawa obrona ojczyzny 2025 nowelizacja Dz.U. poz. 825 1014 WCR kwalifikacja"
```
