# mod-CA-sluzby-specjalne-abw-aw-cba-sop.md — Służby specjalne i SOP — procedury, kontrola, odpowiedzialność

Status: moduł prawa polskiego klasy wzorcowej. Stan metodyczny: 2026-05-28. Źródła prawa muszą być każdorazowo weryfikowane w ELI (RZĄD 1) / Dzienniku Ustaw; LEX/Legalis dopuszczalne pomocniczo przy braku praktycznego dostępu do aktu albo dla komentarza.

## 1. Akty i źródła do weryfikacji
- Ustawa o ABW oraz AW
- ustawa o CBA
- ustawa o SOP
- ustawa o działaniach antyterrorystycznych
- ustawa o ochronie informacji niejawnych

Nie cytuj literalnego brzmienia przepisu bez aktualnego sprawdzenia źródła. Przed użyciem artykułu ustal:

- akt i Dz.U.,
- status obowiązywania,
- wersję temporalną na dzień zdarzenia,
- wersję na dzień sporządzania pisma,
- przepisy przejściowe,
- właściwy organ i tryb zaskarżenia.

## 2. Zakres spraw
- czynności operacyjno-rozpoznawcze
- kontrola operacyjna
- dostęp do informacji niejawnych
- skargi i odpowiedzialność
- postępowania dyscyplinarne
- granice jawności

## 3. Intake
Ustal obowiązkowo:

1. kto jest stroną / uczestnikiem / funkcjonariuszem / organem,
2. jaki akt, czynność albo zaniechanie jest kwestionowane,
3. data czynności, doręczenia, powzięcia wiadomości i termin do reakcji,
4. organ pierwszej instancji i organ odwoławczy,
5. czy sprawa jest administracyjna, cywilna, karna, dyscyplinarna, służbowa albo mieszana,
6. czy istnieje dokument urzędowy: decyzja, postanowienie, zarządzenie, protokół, notatka, polecenie, uchwała,
7. czy zachodzi ryzyko prekluzji, przedawnienia, bezczynności albo bezskuteczności środka.

## 4. Mapa proceduralna
Stosuj ścieżkę:

`zdarzenie/czynność → kwalifikacja prawna → właściwość organu → środek zwykły → środek nadzwyczajny → kontrola sądowa → wykonanie rozstrzygnięcia → odpowiedzialność odszkodowawcza/dyscyplinarna`

W sprawach publicznoprawnych zawsze rozważ równolegle:

- środek w toku sprawy,
- skargę na bezczynność/przewlekłość,
- wniosek o wstrzymanie wykonania,
- zabezpieczenie dowodów,
- odpowiedzialność funkcjonariusza/organu,
- dostęp do akt i informacji publicznej,
- ochronę danych osobowych i informacji niejawnych.

## 5. Warunki skuteczności
Sprawdź:

- termin,
- właściwość organu/sądu,
- legitymację,
- interes prawny albo faktyczny,
- podpis,
- pełnomocnictwo,
- opłatę,
- odpisy,
- załączniki,
- dowód doręczenia,
- wskazanie żądania,
- wskazanie zarzutów,
- relację dowód → fakt → norma.

## 6. Matryca dowodowa
Dla każdego faktu zbuduj tabelę:

| Fakt | Dowód | Źródło | Siła | Luka | Ryzyko |
|---|---|---|---|---|---|

Typowe dowody:

- decyzje, postanowienia, protokoły, notatki, zarządzenia,
- korespondencja z organem,
- nagrania, zdjęcia, logi, metadane,
- zeznania świadków,
- dokumentacja medyczna/techniczna/księgowa,
- opinie biegłych,
- akty prawa miejscowego,
- wydruki z BIP, rejestrów, systemów publicznych.

## 7. Zarzuty typowe
Rozważ co najmniej:

- naruszenie właściwości,
- naruszenie prawa do udziału w sprawie,
- brak podstawy prawnej,
- błędna wykładnia przepisu,
- dowolna ocena dowodów,
- brak uzasadnienia,
- nieproporcjonalność,
- nierówne traktowanie,
- naruszenie zaufania do organu,
- naruszenie terminów,
- brak rozpoznania istoty sprawy,
- pominięcie dowodu,
- wadliwe pouczenie.

## 8. Kontrargumenty organu / strony przeciwnej
Przewiduj:

- formalny brak legitymacji,
- spóźnienie środka,
- brak interesu prawnego,
- domniemanie prawidłowości dokumentu urzędowego,
- uznaniowość organu,
- tajemnicę ustawowo chronioną,
- bezpieczeństwo publiczne,
- brak szkody albo związku przyczynowego,
- nieadekwatność środka.

## 9. Strategia
Priorytety:

1. zabezpiecz termin i dowód doręczenia,
2. uzyskaj akta i pełną podstawę rozstrzygnięcia,
3. oddziel zarzuty formalne od materialnych,
4. wskaż fakty decydujące, nie wszystkie fakty,
5. buduj żądanie główne i ewentualne,
6. przygotuj wariant: organ → sąd administracyjny/cywilny/karny/dyscyplinarny,
7. oceń, czy korzystniejsze jest uchylenie, zmiana, stwierdzenie nieważności, wznowienie, odszkodowanie lub skarga.

## 10. Orzecznictwo
Nie wpisuj fikcyjnych sygnatur. Szukaj tylko realnych orzeczeń w:

- SN / NSA / TK,
- CBOSA,
- Portalu Orzeczeń Sądów Powszechnych,
- orzeczeniach sądów dyscyplinarnych, jeżeli publicznie dostępne,
- LEX/Legalis pomocniczo.

Każde orzeczenie oceniaj według: aktualność, hierarchia sądu, analogiczność stanu faktycznego, linia dominująca/odmienna.

## 11. Ryzyka
Oceń:

- ryzyko zwrotu/odrzucenia,
- ryzyko spóźnienia,
- ryzyko braku legitymacji,
- ryzyko niewykazania faktu,
- ryzyko niedopuszczalności dowodu,
- ryzyko uznania organu,
- ryzyko kosztowe,
- ryzyko retorsji służbowej/dyscyplinarnej,
- ryzyko równoległych postępowań.

## 12. Quality gate
Przed odpowiedzią lub pismem zastosuj:

- `shared/POLISH-LAW-FINAL-COMPLETENESS-GATE.md`,
- `shared/ISAP-AUDIT-PROTOCOL.md`,
- `shared/TEMPORAL-LAW-CHECK.md`,
- `shared/LEGAL-QUALITY-GATE.md`,
- `shared/RISK-ASSESSMENT.md`, jeżeli istnieje,
- `shared/FORMAL-CHECK.md`, jeżeli powstaje pismo.

---

## KLUCZOWE AKTY — ZWERYFIKOWANE 2026-06-05

```
Ustawa o ABW oraz AW: Dz.U. 2026 poz. 937 t.j. (VER 2026-07-02 — WARN-28 zamknięty; to nowy t.j. tej samej ustawy z 24.05.2002 r., NIE nowa ustawa — art. 1 "Tworzy się ABW" to oryginalny tekst ustawy z 2002 r. powtórzony w konsolidacji, nie dowód reformy) — weryfikuj dalsze zm. w ISAP
Ustawa o CBA: Dz.U. 2025 poz. 712 t.j. (obwieszczenie Marszałka Sejmu z 10.04.2025)
  — poprzedni t.j. Dz.U. 2024 poz. 184 NIEAKTUALNY, zastąpiony przez t.j. 2025.712 (⛔ KOREKTA 2026-10-09: było „2024 poz. 1392” — w ELI to rozporządzenie RM o stanie klęski żywiołowej)
  ✅ VER: isap.sejm.gov.pl (WDU20250000712), infor.pl, lexlege.pl 2026-08-14 (F-57)
Ustawa o SOP: Dz.U. 2025 poz. 34 t.j. ze zm.
  → Dz.U. 2025 poz. 1366 — zakwaterowanie funkcjonariuszy SOP
  ⏳ Po t.j.: Dz.U. 2025 poz. 179, 718, 1366, 1823; 2026 poz. 646, 815 (od 4.07.2026 — art. 19: nowe brzmienie art. 37 ust. 1–2 [katalog ŚPB i broni palnej] i art. 39 ust. 1 [urządzenia uniemożliwiające telekomunikację]), 821, 1123, 1281
Ustawa o działaniach antyterrorystycznych: **Dz.U. 2025 poz. 194 t.j.** ✅ [VER] RZĄD 1 2026-09-10c (F-148a; poprzednio błędnie 2024/1474 — obwieszczenie MS o t.j. ROZPORZĄDZENIA, inny akt; ⛔ KROK 2C: nowelizacja po tekście jednolitym, Dz.U. 2026 poz. 815 (od 4.07.2026 — art. 17: uchylony art. 2 pkt 3; nowe brzmienie art. 4, art. 12 ust. 1 pkt 1–2 i ust. 2, dodane art. 12 ust. 3–4; zm. art. 5 ust. 1, 15 ust. 9, 16 ust. 1 pkt 4, 17) — akt zmieniający) t.j. — weryfikuj
  ✅ VER: isap.sejm.gov.pl 2026-06-05 (poz. ABW/AW/SOP/antyterrorystyczna nie objęte
    weryfikacją F-57 — dotyczyła wyłącznie CBA)

Kontrola operacyjna — postanowienie sądu:
  → Wymagana zgoda sądu okręgowego (na wniosek szefa służby + PG lub MS)
  → Termin: 3 miesiące (przedłużalny)
  → Materiały z kontroli niezgodnej z prawem: niedopuszczalne jako dowód
  → Zniszczenie zebranych materiałów gdy nie użyto w postępowaniu
  → Od 31.10.2026 (Dz.U. 2026 poz. 1281): nadzór sądu i prokuratora nad kontrolą operacyjną — informacja w toku, zakończenie kontroli z urzędu, uzasadnienie postanowień, terminy niszczenia materiałów; tabela przepisów i art. 11 (kontrola zarządzona przed 31.10.2026) → `mod-ustawa-sluzby-operacyjne-retencja-danych`, sekcja „KONTROLA OPERACYJNA — NADZÓR SĄDU I PROKURATORA”.
    ABW art. 27, CBA art. 17, SOP art. 42–54 (w tym nowy art. 49a).

Skargi na działania służb:
  → Skargi do Kolegium ds. Służb Specjalnych (przy Prezesie RM)
  → Sejmowa Komisja ds. Służb Specjalnych — kontrola parlamentarna
  → RPO — skargi na naruszenia praw obywatelskich
  → Sąd cywilny — odszkodowanie za bezprawne działania (art. 417 KC)
  → Skarga do ETPC — po wyczerpaniu krajowych środków
  ⚠️ Ograniczona jawność postępowania → buduj argumentację na procedurze i skutku
```
