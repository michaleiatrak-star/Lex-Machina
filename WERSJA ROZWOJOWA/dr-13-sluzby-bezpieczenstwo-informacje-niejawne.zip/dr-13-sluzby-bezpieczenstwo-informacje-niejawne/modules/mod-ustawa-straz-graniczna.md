# mod-BY-straz-graniczna-procedury.md — Straż Graniczna — czynności, cudzoziemcy, granica i dyscyplinarki

Status: moduł prawa polskiego klasy wzorcowej. Stan metodyczny: 2026-05-28. Źródła prawa muszą być każdorazowo weryfikowane w ELI (RZĄD 1) / Dzienniku Ustaw; LEX/Legalis dopuszczalne pomocniczo przy braku praktycznego dostępu do aktu albo dla komentarza.

## 1. Akty i źródła do weryfikacji
- Ustawa o Straży Granicznej
- ustawa o cudzoziemcach
- ustawa o udzielaniu cudzoziemcom ochrony
- KPA/PPSA
- akty wykonawcze MSWiA
- ⚠️ Kontrola przekraczania granicy w ramach małego ruchu granicznego (MRG) —
  rama prawna, umowy dwustronne i aktualny status obowiązywania/zawieszenia
  → `dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/mod-maly-ruch-graniczny.md` (utworzony 2026-07-15, temat zmienny
  politycznie — zawsze weryfikuj aktualny status przed sprawą)

Nie cytuj literalnego brzmienia przepisu bez aktualnego sprawdzenia źródła. Przed użyciem artykułu ustal:

- akt i Dz.U.,
- status obowiązywania,
- wersję temporalną na dzień zdarzenia,
- wersję na dzień sporządzania pisma,
- przepisy przejściowe,
- właściwy organ i tryb zaskarżenia.

- ⚡ **Kontrola operacyjna od 31.10.2026** — Straż Graniczna: art. 9e (zmiany: art. 2 ustawy 2026/1281; nowy ust. 21 — roczna informacja MSWiA dla Sejmu i Senatu, pierwsza do 30.06.2027): sąd i prokurator mogą żądać informacji w toku i zakończyć kontrolę z urzędu, sąd uzasadnia postanowienia, materiały niszczy się w 3 miesiące; kontrola zarządzona przed 31.10.2026 → art. 11 ustawy 2026/1281. Szczegóły: `mod-ustawa-sluzby-operacyjne-retencja-danych`. ✅ [VER: ELI DU/2026/1281, RZĄD 1, 2026-11-04]

## 2. Zakres spraw
- kontrola graniczna
- zobowiązanie do powrotu
- detencja cudzoziemca
- odmowa wjazdu
- czynności operacyjne
- skargi i odwołania
- dyscyplinarka funkcjonariusza

## 3. Intake
Ustal obowiązkowo:

1. kto jest stroną / uczestnikiem / funkcjonariuszem / organem,
2. jaki akt, czynność albo zaniechanie jest kwestionowane,
3. data czynności, doręczenia, powzięcia wiadomości i termin do reakcji,
4. organ pierwszej instancji i organ odwoławczy,
5. czy sprawa jest administracyjna, cywilna, karna, dyscyplinarna, służbowa albo mieszana,
6. czy istnieje dokument urzędowy: decyzja, postanowienie, zarządzenie, protokół, notatka, polecenie, uchwała,
7. czy zachodzi ryzyko prekluzji, przedawnienia, bezczynności albo bezskuteczności środka.

## 4. Mapa proceduralna
Stosuj ścieżkę:

`zdarzenie/czynność → kwalifikacja prawna → właściwość organu → środek zwykły → środek nadzwyczajny → kontrola sądowa → wykonanie rozstrzygnięcia → odpowiedzialność odszkodowawcza/dyscyplinarna`

W sprawach publicznoprawnych zawsze rozważ równolegle:

- środek w toku sprawy,
- skargę na bezczynność/przewlekłość,
- wniosek o wstrzymanie wykonania,
- zabezpieczenie dowodów,
- odpowiedzialność funkcjonariusza/organu,
- dostęp do akt i informacji publicznej,
- ochronę danych osobowych i informacji niejawnych.

## 5. Warunki skuteczności
Sprawdź:

- termin,
- właściwość organu/sądu,
- legitymację,
- interes prawny albo faktyczny,
- podpis,
- pełnomocnictwo,
- opłatę,
- odpisy,
- załączniki,
- dowód doręczenia,
- wskazanie żądania,
- wskazanie zarzutów,
- relację dowód → fakt → norma.

## 6. Matryca dowodowa
Dla każdego faktu zbuduj tabelę:

| Fakt | Dowód | Źródło | Siła | Luka | Ryzyko |
|---|---|---|---|---|---|

Typowe dowody:

- decyzje, postanowienia, protokoły, notatki, zarządzenia,
- korespondencja z organem,
- nagrania, zdjęcia, logi, metadane,
- zeznania świadków,
- dokumentacja medyczna/techniczna/księgowa,
- opinie biegłych,
- akty prawa miejscowego,
- wydruki z BIP, rejestrów, systemów publicznych.

## 7. Zarzuty typowe
Rozważ co najmniej:

- naruszenie właściwości,
- naruszenie prawa do udziału w sprawie,
- brak podstawy prawnej,
- błędna wykładnia przepisu,
- dowolna ocena dowodów,
- brak uzasadnienia,
- nieproporcjonalność,
- nierówne traktowanie,
- naruszenie zaufania do organu,
- naruszenie terminów,
- brak rozpoznania istoty sprawy,
- pominięcie dowodu,
- wadliwe pouczenie.

## 8. Kontrargumenty organu / strony przeciwnej
Przewiduj:

- formalny brak legitymacji,
- spóźnienie środka,
- brak interesu prawnego,
- domniemanie prawidłowości dokumentu urzędowego,
- uznaniowość organu,
- tajemnicę ustawowo chronioną,
- bezpieczeństwo publiczne,
- brak szkody albo związku przyczynowego,
- nieadekwatność środka.

## 9. Strategia
Priorytety:

1. zabezpiecz termin i dowód doręczenia,
2. uzyskaj akta i pełną podstawę rozstrzygnięcia,
3. oddziel zarzuty formalne od materialnych,
4. wskaż fakty decydujące, nie wszystkie fakty,
5. buduj żądanie główne i ewentualne,
6. przygotuj wariant: organ → sąd administracyjny/cywilny/karny/dyscyplinarny,
7. oceń, czy korzystniejsze jest uchylenie, zmiana, stwierdzenie nieważności, wznowienie, odszkodowanie lub skarga.

## 10. Orzecznictwo
Nie wpisuj fikcyjnych sygnatur. Szukaj tylko realnych orzeczeń w:

- SN / NSA / TK,
- CBOSA,
- Portalu Orzeczeń Sądów Powszechnych,
- orzeczeniach sądów dyscyplinarnych, jeżeli publicznie dostępne,
- LEX/Legalis pomocniczo.

Każde orzeczenie oceniaj według: aktualność, hierarchia sądu, analogiczność stanu faktycznego, linia dominująca/odmienna.

## 11. Ryzyka
Oceń:

- ryzyko zwrotu/odrzucenia,
- ryzyko spóźnienia,
- ryzyko braku legitymacji,
- ryzyko niewykazania faktu,
- ryzyko niedopuszczalności dowodu,
- ryzyko uznania organu,
- ryzyko kosztowe,
- ryzyko retorsji służbowej/dyscyplinarnej,
- ryzyko równoległych postępowań.

## 12. Quality gate
Przed odpowiedzią lub pismem zastosuj:

- `prawo-polskie-v2/krajowe/shared/POLISH-LAW-FINAL-COMPLETENESS-GATE.md`,
- `shared/ISAP-AUDIT-PROTOCOL.md`,
- `shared/TEMPORAL-LAW-CHECK.md`,
- `shared/LEGAL-QUALITY-GATE.md`,
- `shared/RISK-ASSESSMENT.md`, jeżeli istnieje,
- `prawo-polskie-v2/krajowe/shared/FORMAL-CHECK.md`, jeżeli powstaje pismo.

---

## KLUCZOWE AKTY — ZWERYFIKOWANE 2026-06-05

```
Ustawa o Straży Granicznej:
  Dz.U. 2026 poz. 367 t.j. (obwieszczenie 27.02.2026, POTWIERDZONE na
    ISAP: WDU20260000367) — ✅ NAPRAWIONE 2026-07-21: poprzednio
    cytowany numer "2024 poz. 1552" był NIEAKTUALNY (istniał POŚREDNI
    t.j. 2025 poz. 914 z 26.06.2025, POMINIĘTY przez wcześniejszy
    audyt, po czym KOLEJNY, aktualny t.j. 2026 poz. 367) — poprawka ta
    BYŁA już odnotowana w lokalnej mapie DR-13 (audyt 2026-07-02iii),
    ale NIGDY nie trafiła do TEGO pliku — TERAZ zsynchronizowane
  → Dz.U. 2025 poz. 1366 — ⚡ zakwaterowanie funkcjonariuszy SG
  ⏳ Po t.j.: Dz.U. 2026 poz. 646, 815 (od 4.07.2026 — art. 4: nowe brzmienie art. 10e ust. 1
    [urządzenia uniemożliwiające telekomunikację] i art. 23 ust. 1 [ŚPB: „art. 12 ust. 1
    pkt 1–13 i 16–23"]), 821, 864, 1123, 1281
  ✅ VER: isap.sejm.gov.pl 2026-07-21 (poprzednia weryfikacja 2026-06-05
    była NIEAKTUALNA co do numeru t.j.)

Ustawa o cudzoziemcach — Dz.U. 2025 poz. 1079 t.j. — weryfikuj w ELI (RZĄD 1)
Ustawa o udzielaniu cudzoziemcom ochrony na terytorium RP — Dz.U. 2026 poz. 862 t.j. ✅ [VER] RZĄD 1 2026-10-09 (ELI). ⛔ BŁĄD SKORYGOWANY: było `Dz.U. 2024 poz. 1546` — to t.j. rozporządzenia RM w sprawie zaświadczeń o pomocy de minimis (inny akt)

Kluczowe sprawy SG:
  Detencja cudzoziemca:
    → ⚠️ POPRAWKA 2026-07-27 (FAZA 3E/ZASADA 14) — poprzednia wersja
      miała BŁĘDNĄ instancję sądową, błędny okres i błędny termin
      zażalenia. Potwierdzone w 6+ źródłach (Kwartalnik IUSTITIA,
      publikacja akademicka KIPK vol. XXVI, gofin.pl, panstwoprawa.org,
      Amnesty International, interwencjaprawna.pl):
    → Zatrzymanie wstępne przez SG/Policję: MAX 48 GODZIN — w tym
      czasie SG składa do SĄDU (rejonowego, NIE WSA — to sąd
      POWSZECHNY, nie administracyjny) wniosek o umieszczenie w
      strzeżonym ośrodku lub zastosowanie aresztu dla cudzoziemców
    → Sąd w postanowieniu wskazuje okres pobytu: NIE DŁUŻSZY niż
      3 MIESIĄCE (nie "14 dni" jak błędnie wcześniej), z możliwością
      przedłużania do 6 miesięcy, a w uzasadnionych przypadkach
      maksymalnie do 12 miesięcy łącznie
    → Prawo do adwokata z urzędu
    → ZAŻALENIE na postanowienie sądu: 7 DNI od doręczenia postanowienia
      (nie "skarga do WSA w 14 dni" — to ZAŻALENIE do SĄDU REJONOWEGO
      za pośrednictwem Straży Granicznej, ŚCIEŻKA SĄDÓW POWSZECHNYCH,
      analogiczna do KPK, NIE ścieżka sądowoadministracyjna jak przy
      zobowiązaniu do powrotu/odmowie wjazdu poniżej). Sąd rozpoznaje
      zażalenie również w terminie 7 dni.
    → Odszkodowanie/zadośćuczynienie od Skarbu Państwa możliwe, jeśli
      zatrzymanie/umieszczenie okazało się nieuzasadnione
  Zobowiązanie do powrotu:
    → Decyzja SG → odwołanie do Komendanta Głównego SG (14 dni)
    → Skarga do WSA → NSA
  Odmowa wjazdu:
    → Decyzja przy granicy (pilna) → prawo do tłumacza i pełnomocnika
    → Zaskarżenie do komendanta nadrzędnego → WSA
  Push-back (zawracanie na granicy):
    → ETPC: wyrok pilot Hudorovič + inne → weryfikuj aktualną linię ETPC
```

---

## ⭐⭐ KONTROLA LEGALNOŚCI ZATRUDNIENIA I POBYTU CUDZOZIEMCÓW — ZGŁOSZENIA ZWIĄZANE Z SG (dodane 2026-07-21)

> Odpowiedź na pytanie użytkownika o "wszystkie typy zgłoszeń do
> Straży Granicznej" — sekcje wyżej dotyczą SPRAW CUDZOZIEMCA
> (detencja/powrót/odmowa wjazdu); TA sekcja dotyczy PERSPEKTYWY
> PRACODAWCY i mechanizmów zgłoszeniowo-kontrolnych.

### 1. Dwa uprawnione organy — SG działa RÓWNOLEGLE z PIP

```
□ Kontrolę LEGALNOŚCI ZATRUDNIENIA cudzoziemców, prowadzenia przez
  nich działalności gospodarczej ORAZ powierzania im pracy przez
  pracodawcę MOGĄ przeprowadzać DWA organy: PAŃSTWOWA INSPEKCJA PRACY
  i STRAŻ GRANICZNA — WSPÓŁPRACUJĄCE ze sobą (⭐ ta sama kontrola MOŻE
  być prowadzona przez OBA organy RÓWNOLEGLE lub JEDEN z nich)
□ SG dodatkowo prowadzi KONTROLĘ LEGALNOŚCI POBYTU (sprawdzenie
  ważności paszportu/wizy/karty pobytu) — kompetencja, KTÓREJ PIP NIE
  MA (PIP koncentruje się na aspekcie PRACOWNICZYM, SG na aspekcie
  POBYTOWYM)
```

### 2. Tryb kontroli — ZA ZAWIADOMIENIEM lub BEZ (analogia do Prawa przedsiębiorców)

```
□ NA PODSTAWIE ZAWIADOMIENIA: funkcjonariusze INFORMUJĄ pracodawcę o
  ZAMIARZE kontroli — PO DORĘCZENIU zawiadomienia, kontrola MOŻE
  rozpocząć się NIE WCZEŚNIEJ niż po 7 DNIACH i NIE PÓŹNIEJ niż w
  CIĄGU 30 DNI (⭐ MECHANIZM IDENTYCZNY jak ogólne zasady kontroli
  przedsiębiorcy z Rozdziału 5 Prawa przedsiębiorców, patrz
  `mod-wekslowe-kontrola-przedsiebiorcy-koncesje.md` (DR-02) cz. B — PO upływie 30 dni
  zawiadomienie WYGASA, wymaga PONOWNEGO doręczenia)
□ BEZ zawiadomienia — w określonych, WYJĄTKOWYCH okolicznościach
  (⚠️ dokładny katalog wyjątków analogiczny do ogólnych zasad Prawa
  przedsiębiorców, NIE potwierdzony w pełni w tej sesji dla SG
  konkretnie)
□ Kontrolę PRZEPROWADZA WYŁĄCZNIE osoba posiadająca stosowne
  UPOWAŻNIENIE wydane przez KOMENDANTA właściwej placówki SG
```

### 3. Przebieg kontroli i PROTOKÓŁ

```
□ Z kontroli SPORZĄDZA SIĘ PROTOKÓŁ zawierający USTALENIA
□ ⭐ KONTROLOWANY MA PRAWO zgłosić PRZED podpisaniem protokołu
  ZASTRZEŻENIA do ustaleń — w TERMINIE 7 DNI od dnia OTRZYMANIA KOPII
  protokołu
□ Organ kontrolujący MA OBOWIĄZEK NIEZWŁOCZNEGO ustosunkowania się do
  zastrzeżeń oraz PRZEKAZANIA kontrolowanemu NA PIŚMIE informacji o
  sposobie ich ROZPATRZENIA
```

### 4. ⭐ SPRZECIW wobec czynności kontrolnych (art. 59 Prawa przedsiębiorców)

```
□ Kontrolowany MOŻE złożyć SPRZECIW wobec podjęcia i wykonywania przez
  organy kontroli (W TYM inspektorów pracy I funkcjonariuszy SG)
  czynności NARUSZAJĄCYCH przepisy ustawy — analogicznie do
  MECHANIZMU już opisanego w `mod-wekslowe-kontrola-przedsiebiorcy-koncesje.md` (DR-02) cz. B
  (DR-02) dla kontroli WIOŚ/innych organów — TEN SAM instrument
  proceduralny, TERAZ potwierdzony jako STOSOWANY RÓWNIEŻ wobec SG
□ PRZYKŁADOWE podstawy sprzeciwu: BRAK zawiadomienia kontrolowanego o
  ZAMIARZE wszczęcia kontroli; podjęcie kontroli BEZ okazania
  LEGITYMACJI służbowej i UPOWAŻNIENIA
```

### 5. ⭐⭐ OBOWIĄZKI ZGŁOSZENIOWE PRACODAWCY — CO SPRAWDZA SG

```
□ PRZED rozpoczęciem pracy — pracodawca MUSI ZAŻĄDAĆ od cudzoziemca
  przedstawienia WAŻNEGO dokumentu uprawniającego do POBYTU w Polsce
  (art. 4 ust. 2 ustawy o warunkach dopuszczalności powierzania pracy
  cudzoziemcom) — I PRZECHOWYWAĆ KOPIĘ tych dokumentów przez CAŁY
  okres zatrudnienia
□ ⭐ "BEZPIECZNA PRZYSTAŃ": pracodawca, KTÓRY wypełnił ten obowiązek
  (zażądał i przechowuje kopię), NIE PODLEGA karze za wykroczenie
  powierzenia pracy cudzoziemcowi BEZ ważnej wizy/dokumentu — CHYBA że
  WIEDZIAŁ, że dokument był SFAŁSZOWANY
□ OBOWIĄZEK INFORMACYJNY o PODJĘCIU LUB NIEPODJĘCIU pracy przez
  cudzoziemca NA PODSTAWIE OŚWIADCZENIA o powierzeniu wykonywania
  pracy — ⭐ TEN konkretny obowiązek KIERUJE SIĘ do URZĘDU PRACY
  (starosty), NIE bezpośrednio do SG — ALE SG WERYFIKUJE PRZY KONTROLI,
  czy pracodawca TEGO dopełnił — BRAK dopełnienia = RYZYKO przy
  kontroli SG, mimo że adresatem zgłoszenia jest inny organ
□ PRZY BRAKU wymaganych dokumentów w chwili kontroli — pracodawca
  ZOSTANIE WEZWANY do sporządzenia NA PIŚMIE wyjaśnień; NIEDOSTARCZENIE
  dokumentów w terminie MOŻE być UZNANE za ICH BRAK
```

### 6. ⭐ ZGŁOSZENIE SIĘ CUDZOZIEMCA DO SG — z WŁASNEJ inicjatywy

```
□ Cudzoziemiec MAJĄCY WĄTPLIWOŚCI co do POSIADANYCH dokumentów (w tym
  wpisu-podstawy wjazdu w systemach granicznych SG) lub DALSZEJ
  legalności POBYTU/możliwości PODRÓŻOWANIA — POWINIEN zgłosić się z
  dokumentem PODRÓŻY oraz DOKUMENTACJĄ uzupełniającą do NAJBLIŻSZEJ
  OPERACYJNEJ jednostki SG, celem PODDANIA SIĘ kontroli legalności
  pobytu i WYJAŚNIENIA swojej sytuacji prawnej/faktycznej
□ SKUTEK kontroli legalności pobytu: PROTOKÓŁ ze STWIERDZENIEM wyników
  — STANOWIĄCY PODSTAWĘ do wszczęcia postępowania administracyjnego o
  ZOBOWIĄZANIU do POWROTU, LUB udzielenia ZGODY na pobyt ze WZGLĘDÓW
  HUMANITARNYCH, ALBO zgody na pobyt TOLEROWANY
□ ⭐ BRAK WAŻNEGO paszportu przy kontroli — MOŻLIWY mandat karny DO
  500 ZŁ (⚠️ zweryfikuj aktualną kwotę), JEŚLI cudzoziemiec NIE
  PRZEDSTAWI CHOĆBY zaświadczenia o ZŁOŻENIU wniosku o wydanie/
  przedłużenie dokumentu podróży w placówce DYPLOMATYCZNEJ kraju
  pochodzenia
```

### 7. CHECKLIST PRAKTYCZNY

```
□ Czy KLIENT jest PRACODAWCĄ zatrudniającym cudzoziemca — sprawdź, czy
  ZAŻĄDAŁ i PRZECHOWUJE kopię dokumentu pobytowego
□ Czy DOPEŁNIONO obowiązku informacyjnego wobec URZĘDU PRACY
  (podjęcie/niepodjęcie pracy z oświadczenia) — SG to WERYFIKUJE, mimo
  że adresatem jest inny organ
□ Czy KONTROLA SG odbyła się ZA ZAWIADOMIENIEM (sprawdź termin 7-30
  dni) czy BEZ NIEGO — jeśli za zawiadomieniem, sprawdź czy ZACHOWANO
  wymogi formalne
□ Czy warto złożyć SPRZECIW wobec czynności kontrolnych (art. 59 Prawa
  przedsiębiorców) — sprawdź, czy zaszła KTÓRAKOLWIEK z przesłanek
  (brak zawiadomienia, brak legitymacji/upoważnienia)
□ Czy KLIENT (cudzoziemiec) ma WĄTPLIWOŚCI co do WŁASNYCH dokumentów —
  rozważ DOBROWOLNE zgłoszenie się do najbliższej jednostki SG,
  ZAMIAST czekania na przypadkową kontrolę
```

### 8. Literatura i źródła (zweryfikowane online 2026-07-21)

- poradnikprzedsiebiorcy.pl — tryb kontroli, sprzeciw z art. 59 Prawa
  przedsiębiorców, termin 7 dni na zastrzeżenia do protokołu.
- centrumverte.pl, hrappka.pl — dwa uprawnione organy (PIP+SG),
  obowiązek informacyjny do urzędu pracy weryfikowany przez SG, termin
  zawiadomienia 7-30 dni.
- paluckiszkutnik.pl — "bezpieczna przystań" pracodawcy (art. 4 ust. 2,
  art. 85 ustawy o warunkach dopuszczalności powierzania pracy).
- strazgraniczna.pl, nadwislanski.strazgraniczna.pl — dobrowolne
  zgłoszenie się cudzoziemca do jednostki SG, skutek protokołu kontroli
  legalności pobytu.
- zielonalinia.gov.pl — mandat do 500 zł za brak ważnego paszportu bez
  zaświadczenia o złożeniu wniosku.
