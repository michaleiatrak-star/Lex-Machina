# mod-BX-policja-procedury-wewnetrzne.md — Policja — procedury wewnętrzne, czynności służbowe i kontrola

Status: moduł prawa polskiego klasy wzorcowej. Stan metodyczny: 2026-05-28. Źródła prawa muszą być każdorazowo weryfikowane w ELI (RZĄD 1) / Dzienniku Ustaw; LEX/Legalis dopuszczalne pomocniczo przy braku praktycznego dostępu do aktu albo dla komentarza.

## 1. Akty i źródła do weryfikacji
- Ustawa o Policji
- akty wykonawcze MSWiA dotyczące służby, dyscyplinarki, dokumentacji i użycia środków przymusu
- ustawa o środkach przymusu bezpośredniego i broni palnej
- KPK/KW/KPA w zakresie czynności i skarg

Nie cytuj literalnego brzmienia przepisu bez aktualnego sprawdzenia źródła. Przed użyciem artykułu ustal:

- akt i Dz.U.,
- status obowiązywania,
- wersję temporalną na dzień zdarzenia,
- wersję na dzień sporządzania pisma,
- przepisy przejściowe,
- właściwy organ i tryb zaskarżenia.

## 2. Zakres spraw
- legitymowanie
- zatrzymanie
- przeszukanie
- notatki urzędowe
- skargi na funkcjonariuszy
- postępowania dyscyplinarne
- użycie środków przymusu
- odpowiedzialność odszkodowawcza Skarbu Państwa

## 3. Intake
Ustal obowiązkowo:

1. kto jest stroną / uczestnikiem / funkcjonariuszem / organem,
2. jaki akt, czynność albo zaniechanie jest kwestionowane,
3. data czynności, doręczenia, powzięcia wiadomości i termin do reakcji,
4. organ pierwszej instancji i organ odwoławczy,
5. czy sprawa jest administracyjna, cywilna, karna, dyscyplinarna, służbowa albo mieszana,
6. czy istnieje dokument urzędowy: decyzja, postanowienie, zarządzenie, protokół, notatka, polecenie, uchwała,
7. czy zachodzi ryzyko prekluzji, przedawnienia, bezczynności albo bezskuteczności środka.

## 4. Mapa proceduralna
Stosuj ścieżkę:

`zdarzenie/czynność → kwalifikacja prawna → właściwość organu → środek zwykły → środek nadzwyczajny → kontrola sądowa → wykonanie rozstrzygnięcia → odpowiedzialność odszkodowawcza/dyscyplinarna`

W sprawach publicznoprawnych zawsze rozważ równolegle:

- środek w toku sprawy,
- skargę na bezczynność/przewlekłość,
- wniosek o wstrzymanie wykonania,
- zabezpieczenie dowodów,
- odpowiedzialność funkcjonariusza/organu,
- dostęp do akt i informacji publicznej,
- ochronę danych osobowych i informacji niejawnych.

## 5. Warunki skuteczności
Sprawdź:

- termin,
- właściwość organu/sądu,
- legitymację,
- interes prawny albo faktyczny,
- podpis,
- pełnomocnictwo,
- opłatę,
- odpisy,
- załączniki,
- dowód doręczenia,
- wskazanie żądania,
- wskazanie zarzutów,
- relację dowód → fakt → norma.

## 6. Matryca dowodowa
Dla każdego faktu zbuduj tabelę:

| Fakt | Dowód | Źródło | Siła | Luka | Ryzyko |
|---|---|---|---|---|---|

Typowe dowody:

- decyzje, postanowienia, protokoły, notatki, zarządzenia,
- korespondencja z organem,
- nagrania, zdjęcia, logi, metadane,
- zeznania świadków,
- dokumentacja medyczna/techniczna/księgowa,
- opinie biegłych,
- akty prawa miejscowego,
- wydruki z BIP, rejestrów, systemów publicznych.

## 7. Zarzuty typowe
Rozważ co najmniej:

- naruszenie właściwości,
- naruszenie prawa do udziału w sprawie,
- brak podstawy prawnej,
- błędna wykładnia przepisu,
- dowolna ocena dowodów,
- brak uzasadnienia,
- nieproporcjonalność,
- nierówne traktowanie,
- naruszenie zaufania do organu,
- naruszenie terminów,
- brak rozpoznania istoty sprawy,
- pominięcie dowodu,
- wadliwe pouczenie.

## 8. Kontrargumenty organu / strony przeciwnej
Przewiduj:

- formalny brak legitymacji,
- spóźnienie środka,
- brak interesu prawnego,
- domniemanie prawidłowości dokumentu urzędowego,
- uznaniowość organu,
- tajemnicę ustawowo chronioną,
- bezpieczeństwo publiczne,
- brak szkody albo związku przyczynowego,
- nieadekwatność środka.

## 9. Strategia
Priorytety:

1. zabezpiecz termin i dowód doręczenia,
2. uzyskaj akta i pełną podstawę rozstrzygnięcia,
3. oddziel zarzuty formalne od materialnych,
4. wskaż fakty decydujące, nie wszystkie fakty,
5. buduj żądanie główne i ewentualne,
6. przygotuj wariant: organ → sąd administracyjny/cywilny/karny/dyscyplinarny,
7. oceń, czy korzystniejsze jest uchylenie, zmiana, stwierdzenie nieważności, wznowienie, odszkodowanie lub skarga.

## 10. Orzecznictwo
Nie wpisuj fikcyjnych sygnatur. Szukaj tylko realnych orzeczeń w:

- SN / NSA / TK,
- CBOSA,
- Portalu Orzeczeń Sądów Powszechnych,
- orzeczeniach sądów dyscyplinarnych, jeżeli publicznie dostępne,
- LEX/Legalis pomocniczo.

Każde orzeczenie oceniaj według: aktualność, hierarchia sądu, analogiczność stanu faktycznego, linia dominująca/odmienna.

## 11. Ryzyka
Oceń:

- ryzyko zwrotu/odrzucenia,
- ryzyko spóźnienia,
- ryzyko braku legitymacji,
- ryzyko niewykazania faktu,
- ryzyko niedopuszczalności dowodu,
- ryzyko uznania organu,
- ryzyko kosztowe,
- ryzyko retorsji służbowej/dyscyplinarnej,
- ryzyko równoległych postępowań.

## 12. Quality gate
Przed odpowiedzią lub pismem zastosuj:

- `shared/POLISH-LAW-FINAL-COMPLETENESS-GATE.md`,
- `shared/ISAP-AUDIT-PROTOCOL.md`,
- `shared/TEMPORAL-LAW-CHECK.md`,
- `shared/LEGAL-QUALITY-GATE.md`,
- `shared/RISK-ASSESSMENT.md`, jeżeli istnieje,
- `shared/FORMAL-CHECK.md`, jeżeli powstaje pismo.

---

## KLUCZOWE AKTY — ZWERYFIKOWANE 2026-08-14 (F-57)

```
Ustawa o Policji:
  Dz.U. 2025 poz. 636 t.j. (obwieszczenie Marszałka Sejmu z 10.04.2025)
  — poprzedni t.j. Dz.U. 2024 poz. 1589 NIEAKTUALNY, zastąpiony przez t.j. 2025.636
  → nowelizacje uwzględnione w tekście jednolitym 2025.636 m.in.:
    Dz.U. poz. 1248/2024 (zagrożenie bezpieczeństwa państwa), poz. 1562/2024
    (oddziały o profilu mundurowym), poz. 1688/2024, poz. 1717/2024, poz. 1871/2024,
    poz. 179/2025 (Prawo lotnicze)
  → Dz.U. 2025 poz. 1366 — ⚡ zakwaterowanie funkcjonariuszy (zm. Policji, SG, PSP,
    ABW, AW, SKW, SWW, SOP jednocześnie) — NOWELIZACJA PO t.j. 2025.636, weryfikuj
    czy uwzględniona w kolejnym t.j.
  ⏳ Po t.j.: Dz.U. 2025 poz. 718, 1366; 2026 poz. 187, 421, 646, 760, 815 (od 4.07.2026 —
    art. 3: nowe brzmienie art. 16 ust. 1 [ŚPB: „art. 12 ust. 1 pkt 1–13 i 17–23"] i art. 18c
    ust. 1 [urządzenia uniemożliwiające telekomunikację, m.in. po wprowadzeniu trzeciego lub
    czwartego stopnia alarmowego]), 821, 864, 1004, 1123, 1281
  ✅ VER: isap.sejm.gov.pl, api.sejm.gov.pl 2026-08-14 (F-57)

Ustawa o środkach przymusu bezpośredniego i broni palnej:
  Dz.U. 2026 poz. 244 t.j. (obwieszczenie Marszałka Sejmu z 20.02.2026)
  — poprzednie t.j. Dz.U. 2023 poz. 202 i Dz.U. 2025 poz. 555 NIEAKTUALNE,
    zastąpione przez t.j. 2026.244
  ✅ VER: isap.sejm.gov.pl, inforlex.pl (Dz.U. 2026 poz. 244) 2026-08-14 (F-57)
  ⏳ Po t.j.: Dz.U. 2026 poz. 737, 815 (od 4.07.2026 — art. 15: zm. art. 4 pkt 8 lit. b
    i pkt 9, dodane art. 11 pkt 16–17 i art. 12 ust. 1 pkt 22–23 [bezzałogowe obiekty
    pływające i lądowe], nowe brzmienie art. 23, art. 33a ust. 3, dodane art. 33b–33c,
    art. 47 pkt 8)
  ⚠️ weryfikuj dalsze zm. w ELI (RZĄD 1) przed każdym powołaniem

Odpowiedzialność odszkodowawcza Skarbu Państwa za działania Policji:
  → Art. 417 KC (delikt władzy publicznej)
  → Art. 15e ustawy o Policji — odszkodowanie za bezprawne zatrzymanie
  → Właściwy: sąd cywilny (nie WSA)
  → Przedawnienie: 3 lata od dowiedzenia się o szkodzie (art. 4421 KC — weryfikuj)

Skargi na funkcjonariuszy Policji:
  □ Skarga do przełożonego (art. 227 KPA + przepisy wewn.)
  □ Skarga do prokuratury (zawiadomienie o przestępstwie)
  □ Pozew cywilny o odszkodowanie (SO lub SR wg WPS)
  □ Skarga do RPO
  □ Skarga do Sejmowej Komisji ds. Służb Specjalnych (dla ABW/AW/CBA)
```
