# CHANGELOG — prawny-router-v3

- 3.81 (2026-11-24): Oznaczenia lex:wykonuje-aplikacja: bramka anonimizera (ANONIMIZER), detekcja trybu (TRYB), renderowanie widgetow (WIDGET-HOST); tresc bez zmian dla czatu
- 3.80 (2026-11-19): F-240: podważenie świadka — SW-DETECT-HARD, inwentarz zeznań ze wszystkich protokołów (tools/inwentarz_zeznan.py), SW-P6/SW-A9 niepamięć wobec wiedzy, checkpoint SW-INW, PEER-APPLY PA-1–PA-5, kroki W1-SW-INW i W3-PEER-APPLY
- 3.79 (2026-11-13): UP-5: kanał prawa UE = eurlex_tekst / Cellar REST (Accept xhtml, pol); eur-lex.europa.eu w kanale kodu daje HTTP 202 i 0 B (pomiar 2026-11-13) — usunięto sprzeczne zdanie „curl działa dla eur-lex”.
- 3.78 (2026-11-09): UP-5 — rodzina prawa nordyckiego: shared/RODZINA-PRAWA-NORDYCKIE.md (NR-1…NR-6), wpis w PROFIL-LEKKI (wyzwalacz: jurysdykcja DK, FI, IS, NO, SE, FO).
- 3.77 (2026-11-08, rodzina prawa jako kategoria jurysdykcji): UP-5 — sprawa w systemie common law albo w dziedzinie systemu mieszanego opartej na common law wczytuje shared/RODZINA-PRAWA-COMMON-LAW.md (CL-1…CL-7). CN-GATE i REM-GATE bez zmian; odwołanie dopisane w istniejącej linii UP-5 i w eskalacji (korpus bez nowych linii, T17).
- 3.76 (2026-11-06): migracja prawa polskiego E3: moduły prawa krajowego tego skilla i shared przeniesione do prawo-polskie-v2/krajowe/; odwołania jako klucze `JUR:` (manifest jurysdykcji prawo-polskie-v2/JURYSDYKCJA.md); korpus SKILL.md 506 → 500 linii (T17: trzy zbędne separatory `---` przed nagłówkami, blok `view` w jednej linii; reguły bez zmian)
- 3.75 (2026-11-06, zgłoszenie użytkownika — porozumienie rozwiązujące jako załącznik do wezwania): routing [1] — dostarczony dokument z kategorii [1] przy innym PRIMARY uruchamia `analizator-umow-v1` jako SECONDARY obowiązkowo, co najmniej w zakresie CAL-GATE (analizator 1.52).
- 3.74 (2026-10-31, BENCHMARK-02): KONKLUZJA-GATE (benchmark 02: P04, P13, P09/P10): pierwsze zdanie odpowiada wprost — pytanie zamknięte → „Tak”/„Nie”/„Tak, ale…”; „zależy” tylko z wariantem typowym; konkluzja warunkowa nazwana, gdy rozstrzyga wykładnia; skutek prawny tylko w brzmieniu przepisu. Blok KROK 3A i opis bramek po treści, przed zastrzeżeniem (P01, A8). SKILL.md + references/SELF-CHECK.md; reguły dopisane, żadna nie usunięta.
- 3.73 (2026-10-20, LEXAGENTO-P1): PROFIL-LEKKI: pełna ścieżka modułu kwalifikatora karnomaterialnego (skrót dr-03/.../ nie działał poza lex-runtime)
- 3.72 (2026-10-20, AUDYT-2026-10-20a): „KROK 2 — ROUTING [1]–[11]” i „POKRYCIE DZIEDZINOWE” oznaczone `<!-- lex:wykonuje-aplikacja: ROUTING -->`. Aplikacja zastępuje je odnośnikiem tylko w trybie mechanicznym (skill wykonawczy wybrał użytkownik, dziedzinę wskazała aplikacja); w trybie automatycznym model dostaje je w całości. Rdzeń R-1…R-5, bramki KROK 5–6, reguły nadrzędne i SELF-CHECK bez zmian. Treść bez zmian.

- 3.71 (2026-10-10b, AUDYT-2026-10-10b): Opis: router przy sprawach prawnych, nie przy wzmiankach prawnych w pracy nad kodem; preferencje użytkownika w zakresie sprawy prawnej; PROFIL-LEKKI 1.3 z kosztami zmierzonymi (rdzeń ≈103 kB ≈28 tys. tokenów, typowa sprawa ≈221 kB ≈55-60 tys.); HARD-GATES-ORZECZNICTWO i ZRODLA-AKTOW-FALLBACK bez obchodzenia WAF.

- 3.70 (2026-10-09f, AUDYT-2026-10-09f): KANCELARIA-WORKFLOW, SOCIAL-SECURITY-LAW-STANDARD, DISCIPLINARY-PROCEEDINGS-STANDARD, JUDICIARY-LEGAL-STANDARD przeniesione z `shared/` do `references/` (jedyny konsument).

- 3.69 (2026-10-09e, AUDYT-2026-10-09e): KROK 2 [5] ORZECZNICTWO: „wyszukaj/znajdź/podaj wyrok”, „orzeczenie Sądu Najwyższego”, „zweryfikowany wyrok”, „orzecznictwo” (wcześniej „wyszukaj wyroku … SN” trafiało do [2] analiza-sadowa-v6 przez samo słowo „wyrok”); [2]: „przeanalizuj/oceń wyrok, orzeczenie, postanowienie”, „analiza wyroku/postanowienia” — wyrok sądu apelacyjnego to nie apelacja [3]. Nazwa sądu wskazuje źródło, nie dziedzinę.

- 3.68 (2026-10-09): KROK 2: [1] tylko gdy umowa jest przedmiotem pracy (analiza, napisanie, negocjacje, podpisanie, klauzule); umowa jako tło sporu → [10]. [6] faktury jako dowód, nie opowieść o niezapłaconej fakturze. [8] przy przygotowaniu przesłuchania świadka lub biegłego; biegły w opowieści i biegły rewident → [10].

- 3.67 (2026-10-06): HARD-GATES-ORZECZNICTWO: karta SN; SAOS RZĄD 3 tylko zastępczo

- 3.66 (2026-10-05m, AUDYT-2026-10-05m): KROK 2: [3] odwołanie do KIO, skarga do WSA; [6] jako dowód / czy to dowód / moc dowodowa.

- 3.65 (2026-10-05l, AUDYT-2026-10-05l): KROK 2: [3] odwołanie od wypowiedzenia / od decyzji / do sądu; [6] policz termin, termin na wniesienie; [1] „na umowie zlecenie / o pracę” to podstawa zatrudnienia → [10]; [6] maile/SMS/nagrania tylko przy pytaniu o dowód.

- 3.64 (2026-10-05k, AUDYT-2026-10-05k): KROK 2 [2]: frazy „oceń szanse”, „szanse wygrania”, analiza akt (spójnie z macierzą aktywacji).

- 3.63 (2026-10-05i, AUDYT-2026-10-05i): PROFIL-LEKKI: „PO CO ISTNIEJE” jako HISTORIA, „DEKLARACJA PROFILU” i „KIEDY PROFIL LEKKI JEST ZAKAZANY” jako PROFIL — aplikacja wybiera profil, pisze KROK 3A i przy niewczytanym zasobie ogłasza TRYB ZDEGRADOWANY. Treść reguł bez zmian.

- 3.62 (2026-10-04n, AUDYT-2026-10-04n): Historia zmian SKILL.md i modułów przeniesiona z plików roboczych do `references/HISTORIA-ZMIAN-PLIKOW.md` (plik historyczny, niewczytywany przez model). Treść robocza bez zmian.

- 3.61 (2026-10-04m, AUDYT-2026-10-04m): KROK0A-anonimizer.md oznaczony `<!-- lex:wykonuje-aplikacja: ANONIMIZACJA -->`, „PATH-SELFTEST — RESOLVER” oznaczony RESOLVER (aplikacja rozwiązuje adresy korpusu sama) — w aplikacji Lex Machina pseudonimizacja działa zawsze lokalnie przed wysłaniem do modelu. Treść bez zmian; poza aplikacją znacznik jest niewidocznym komentarzem. Pełny opis: `audyt-systemu-v4/references/AUDIT-JOURNAL.md`, AUDYT-2026-10-04m.

- 3.60 (2026-10-04c, AUDYT-2026-10-04c): **F-226 (zamknięta) — usunięte archiwum `references/legacy-material-router/` (8 plików, 1 722 linie).** Porównanie z modułami wskazanymi przez mosty: zgodność linii 87–100% (cyberprzestępstwa, przemoc domowa, przesłuchanie, stalking, tryby ścigania); kwalifikator — archiwum v1.0 (589 l.) wobec v3.0 w DR-03 (indeks + 8 części); mobbing i wykroczenia — DR przebudowane. Kotwice prawne bez odpowiednika w całym DR: 4 (art. 287 § 4 KK, art. 43a § 1 KK, art. 92a § 1 KW, art. 8a ustawy Prawo o miarach) — NIE przeniesione (treść archiwum była wyłączona z T28, niezweryfikowana), przekazane do FAZY 3E jako F-228. `stalking-nekanie.md` był bajtowo równy `shared/STALKING-NEKANIE.md`. Odesłanie w SKILL.md i rejestr mostów w `pokrycie-dziedzinowe.md` zaktualizowane. Historia: git `main` do `f66715f`. Pełny opis: `audyt-systemu-v4/references/AUDIT-JOURNAL.md`, AUDYT-2026-10-04c.

- 3.59 (2026-10-04b, AUDYT-2026-10-04b): **Sieroty (F-225).** (1) Reguła 15 wczytuje `references/HARD-GATES-ORZECZNICTWO.md` — standard istnienia orzeczenia (3.54) żył dotąd wyłącznie w pliku bez ścieżki wywołania. (2) Reguła 17 wczytuje `ROUTING-OPPONENT-ANALYSIS-V9.md` i `ROUTING-CONTRADICTION-INTELLIGENCE-V10.md`; listy silników z pełnymi ścieżkami, `final-pleading-audit-v8` → `shared/AUDYT-KONCOWY.md`, `core-burden-of-proof-v9` oznaczony jako nieistniejący, dodany `contradictory-evidence-engine-v10`. (3) Rejestr MOSTY DZIEDZINOWE I ARCHIWUM w `references/pokrycie-dziedzinowe.md` (odesłanie z SKILL.md; korpus ≤500 — T17) — 8 mostów; zerwane cele w mostach `przesluchanie-swiadkow` i `stalking-nekanie` (moduły scalone do shared 2026-07-12) poprawione; `legacy-material-router/` = archiwum (F-226). (4) Usunięte stuby `references/MOD-WALIDACJA.md`, `HYBRID-VALIDATION.md`, `ISAP-AUDIT-PROTOCOL.md` (deklarowane jako usunięte 2026-07-12) i pusty `references/modules/ROUTING-TO-DOMAIN-SKILLS.md`. Pełny opis: `audyt-systemu-v4/references/AUDIT-JOURNAL.md`, AUDYT-2026-10-04b.

- 3.58 (2026-09-27e, AUDYT-2026-09-27e): claude.ai po dodaniu marketplace instalował wyłącznie 4 z 32 pluginów (shared, prawny-router-v3, analizator-dowodow-v3, przesluchanie-swiadkow-v2-min90); jedyna cecha wspólna tych 4, nieobecna w żadnym z 28 pozostałych, to klucz `dependencies` we frontmatterze SKILL.md. Ten skill już go miał; oraz jawny manifest pluginu (name, description = description z SKILL.md, author, repository, license) — host nie musi niczego wnioskować z SKILL.md. `version` w manifeście = `version:` z SKILL.md (pilnuje T38 w audyt-systemu-v4) — host rozpoznaje aktualizację po podbiciu wersji. Treść skilla bez zmian.
- 3.57 (2026-09-27c, AUDYT-2026-09-27c): **RESOLVER przy instalacji z marketplace.** PATH-SELFTEST przepisany: bootstrap `shared` (lista kopii z `version:`, najwyższa wygrywa), potem `shared/UNIVERSAL-RUNTIME-ADAPTER.md` §1A R-1…R-5 dla każdego skilla; ostrzeżenie `⚠️ DUPLIKAT SKILLA`. KROK 3A: nowe pole `RESOLVER`. `dependencies.requires` uzupełnione z 19 do 31 skilli (= `dependencies` wpisu routera w `.claude-plugin/marketplace.json`; dotąd brakowało dr-01, dr-02, dr-04–dr-07, dr-13–dr-15, audyt-systemu-v4, raport-sytuacyjny-v2, raport-klienta-v1, a reguła PATH-SELFTEST wymaga obecności nazwy na tej liście). **Odtworzone** wywołanie `shared/MOD-WEJSCIE-DOKUMENTU.md` w ŁADOWANE ZAWSZE (F-200) — jedyna zmiana routera z wydania 3.56, które nie dotarło do repozytorium (F-207). T35 dla routera: PASS.
- 3.56 — WYDANIE NIEDOSTARCZONE (F-207): odnotowane w AUDIT-JOURNAL, AUDYT-2026-09-26 §7 (wywołanie `shared/MOD-WEJSCIE-DOKUMENTU.md`, F-200), w historii git `michaleiatrak-star/Lex-Machina` nieobecne na żadnej gałęzi (`git log --all -S`; na `main` router 3.55 od `9c4088f2` do `56a7eefc`). Zakres odtworzony w 3.57; numer 3.56 nie jest używany ponownie.
- 3.55 (2026-09-23, AUDYT-2026-09-23c): Korekty użytkownika do 3.54: UP-2 i ZRODLA-AKTOW-FALLBACK — E-3/E-4 uruchamia BRAK-AKTU (akt niepobieralny z RZĘDU 1: awaria serwera, timeout, blokada) i wtedy jest obowiązkowe; przy awarii ELI próba odczytu z ISAP. „Zakaz obchodzenia blokad” zastąpiony ZASADĄ INNEJ DROGI (robots.txt nie przesądza; granice: logowanie, licencja, CAPTCHA, zabezpieczenia). HARD-GATES-ORZECZNICTWO analogicznie. SELF-CHECK: OC-1 — skala 0–10 dozwolona; E-3/E-3b wg BRAKU-AKTU.
- 3.54 (2026-09-23, AUDYT-2026-09-23b): UP-2 = kanon E-1…E-5 (ELI pierwszy; ISAP adres dla człowieka; LEX/Legalis → ArsLege po porażce ELI w obu kanałach). ZRODLA-AKTOW-FALLBACK przepisany na E-1…E-5 + zakaz obchodzenia blokad. KROK 3: R-3.54-a (DR-xx przed weryfikacją), R-3.54-b (wezwanie czytane przed routingiem). HARD-GATES-ORZECZNICTWO: standard potwierdzenia istnienia (jeden rekord; zakaz „prawdopodobnie istnieje”). KROK0A: ścieżka FOLDER/DYSK (anonimizacja skryptem przed odczytem), forma bezosobowa. SELF-CHECK: blok OC (zakaz ocen liczbowych) i blok E (kolejność źródeł). Instrukcje „weryfikuj w ISAP” w legacy → ELI.
- 3.53 (2026-09-22, F-195): references/ISAP-METRYKI-AKTOW.md — osierocona kopia (stan 2026-06-07; 49 linii rozbieżnych z kanonem shared; PrBud t.j. 2025/418 zamiast 2026/524) zastąpiona odesłaniem do `shared/ISAP-METRYKI-AKTOW.md`. Żaden plik jej nie wczytywał (KROK1-detekcja odsyła do shared). Treść routera bez zmian.
- 3.52 (2026-09-16, F-189): references/legacy-material-router/cyberprzestepstwa.md — „art. 117 § 1 KC — 6 lat” → art. 118 KC (F-135). Treść routera bez zmian.
- 3.51 (2026-09-16, F-189): references/legacy-material-router/cyberprzestepstwa.md — „Prawo telekomunikacyjne, Dz.U. 2024 poz. 1221 t.j.” skorygowane: 2024/1221 to akt pierwotny Prawa komunikacji elektronicznej (RZĄD 1; T31). Treść routera bez zmian.
- 3.50 (2026-09-16, F-189): T12: pole YAML `changelog:` skrócone do odesłania; wersja 3.49 bez opisu oznaczona jako LUKA JAWNA. Treść bez zmian.
- 3.49 — LUKA JAWNA: numer obecny na dysku 2026-09-16, brak wpisu w changelogu i w AUDIT-JOURNAL; zakresu zmian nie da się odtworzyć — wpis celowo niezmyślony
- 3.48 (2026-09-10x, O-11): **KWOTA-GATE — kontrola przy każdej podawanej kwocie.**

  Nowa pozycja w `references/SELF-CHECK.md`. Wyzwalacz: odpowiedź podaje kwotę
  opłaty sądowej, taksy, kosztów zastępstwa albo wyliczenia alimentacyjnego.
  Trzy pytania, wszystkie muszą mieć odpowiedź TAK:

  1. czy sprawdzono, że strona **nie jest zwolniona** (art. 94–103 KSCU — trzy
     warstwy: podmiotowe art. 96 ust. 1, przedmiotowe art. 95, na wniosek
     art. 100–103),
  2. czy kwota pochodzi z **tabeli ustanawiającej**, nie z bazy katalogującej
     ani z pamięci,
  3. czy sprawdzono **przypisy** przy jednostce redakcyjnej.

  ⛔ Punkt 3 istnieje dlatego, że art. 13 ust. 2 KSCU niesie **dwa brzmienia obok
  siebie** rozróżnione wyłącznie odnośnikami — cap opłaty stosunkowej to
  100 000 zł od 23.09.2025, nie powszechnie powtarzane 200 000 zł.

  `shared/TABELE-OPLAT.md` dopisany do `required_modules` oraz do warstwy
  odroczonej w `references/PROFIL-LEKKI.md`, z wyzwalaczem mechanicznym
  „zamierzasz podać kwotę" i najpóźniejszym momentem odczytu „przed pierwszą
  liczbą".

- 3.47 (2026-09-10o, F-181): **przemoc domowa — przeterminowana podstawa
  i przemianowany akt.**

  `references/legacy-material-router/przemoc-domowa.md` podawał ustawę
  o przeciwdziałaniu przemocy jako `Dz.U. 2021 poz. 1249` — status
  **wygaśnięcie aktu**. Aktualny tekst jednolity: **Dz.U. 2024 poz. 1673**
  ✅ [VER] RZĄD 1, ⛔ KROK 2C: jedna nowelizacja po nim.

  ⛔ **Akt został PRZEMIANOWANY.** Tytuł „ustawa o przeciwdziałaniu przemocy
  **w rodzinie**" jest historyczny; obowiązujący to „ustawa o przeciwdziałaniu
  przemocy **domowej**". Wpisane wprost, bo sama podmiana numeru zostawiłaby
  nieaktualną nazwę — a to jest dokładnie sygnał, który w tej serii dwukrotnie
  okazał się wierzchołkiem podmiany aktu (F-148a, 10j).

  Ta sama poprawka w bliźniaczym module `dr-03`.

- 3.46 (2026-09-10l, F-181): legacy-material-router/tryby-scigania: KPK 2024/37 (wygaśnięcie aktu) → 2026/490 + lista 5 nowelizacji po tekście jednolitym
- 3.45 (2026-09-10b, O-6 / F-180): **zakaz orzekania o systemie z jednego
  nośnika; rdzeń mniejszy po wydzieleniu gałęzi HARD GATE.**

  **O-6.** Nowa pozycja `[STAN-ZAŁADOWANY]` w `references/SELF-CHECK.md`:
  jeśli odpowiedź twierdzi, że w systemie jest luka, błąd, brak pliku lub
  niedomknięta flaga, wolno to orzec dopiero po zestawieniu wersji **załadowanej
  przez hosta** z wersją w repozytorium. Alternatywa dopuszczalna: oznaczyć
  wniosek jako ⚠️ WARUNKOWY z podaniem wersji roboczej.

  Podstawa: 2026-09-09/10 ocena prowadzona na kopii sesyjnej z routerem 3.41
  zgłosiła jako usterkę systemu lukę historii, która w repozytorium (3.42) nie
  istniała. ⛔ Klasa błędu jak F-151 — wniosek z jednego nośnika bez sprawdzenia
  drugiego, tym razem po stronie oceniającego, nie źródła.

  **F-180 (skutek dla routera).** Wydzielenie 236 linii gałęzi warunkowych
  z `shared/PRAWO-HARDGATE.md` zmniejszyło rdzeń R-1…R-5 z ≈100 kB do ≈88 kB.
  `references/PROFIL-LEKKI.md` 1.1 → 1.2: skorygowana tabela rdzenia, dwa nowe
  wpisy w warstwie odroczonej (`PRAWO-HARDGATE-BLOKADA.md`,
  `PRAWO-HARDGATE-AKT-MIEJSCOWY.md`) z wyzwalaczami mechanicznymi.

- 3.44 (2026-09-10, F-179): **korekta przesłanki profilu LEKKIEGO — pomiar
  z 3.43 był fałszywy w przesłance.**

  Wpis 3.43 uzasadniał profil liczbą „≈219 kB ≈ 54 tys. tokenów ścieżki
  obowiązkowej przed wczytaniem PRIMARY". Liczba sumowała `MOD-CN-GATE`,
  `MOD-REM-GATE`, `MOD-WYJATEK-GATE`, `MOD-OS-CZASU-PRZESLANEK`,
  `HIERARCHIA-ZRODEL`, `MOD-STEP-TRACKER` i `DISCLAIMER` jako koszt
  bezwarunkowy — a wszystkie mają wyzwalacze warunkowe zapisane u siebie
  i podlegają **leniwemu ładowaniu**. Host wczytuje treść zasobu przy `view`,
  nie z góry, więc warstwa warunkowa była leniwa, zanim profil powstał.

  ⛔ Klasa błędu identyczna z **F-164** (REM-0): reguła zbudowana na tezie
  o świecie, której nikt nie zmierzył. Czwarte wystąpienie w tym systemie
  (F-151, F-162, F-164, F-179).

  Zmierzone poprawnie 2026-09-10:

  | Warstwa | Kiedy | Rozmiar |
  |---|---|---:|
  | `name` + `description` 32 skilli | zawsze | ≈5,9 kB ≈ 1,5 tys. tokenów |
  | rdzeń R-1…R-5 | po wyzwoleniu routera, bezwarunkowo | ≈100 kB ≈ 25 tys. tokenów |
  | zasoby warunkowe | po padnięciu wyzwalacza | 0–113 kB |

  Skutek dla profilu: **korzyść jest audytowa, nie wydajnościowa.** Profil nie
  zmniejsza rdzenia ani o bajt. Zamyka natomiast tryb awarii, który leniwe
  ładowanie tworzy: **odroczenie cicho stające się pominięciem**, dotąd
  nieweryfikowalne z zewnątrz. Trzy mechanizmy zamknięcia bez zmian —
  deklaracja w KROKU 3A, kontrola `[PROFIL-ODROCZENIA]`, zamknięta lista
  wyzwalaczy w jednym miejscu.

  ⚠️ Realna redukcja kosztu wymagałaby skrócenia rdzenia — `PRAWO-HARDGATE.md`
  to 41 kB, czyli 41% rdzenia. Osobna decyzja projektowa, inny profil ryzyka,
  nieobjęta tym wydaniem.

  `references/PROFIL-LEKKI.md` 1.0 → 1.1, sekcja „PO CO ISTNIEJE" przepisana.

- 3.43 (2026-09-10, F-175): **PROFIL LEKKI — kolejność odczytu zasobów
  obowiązkowych.** `references/PROFIL-LEKKI.md`.

  Zmierzona ścieżka obowiązkowa routera 3.42 (2026-09-10): **≈219 kB ≈ 54 tys.
  tokenów PRZED** wczytaniem PRIMARY, jego modułów i materiału sprawy. Rdzeń
  R-1…R-5 (SKILL, KROK 0A, KROK 1, PRAWO-HARDGATE, SELF-CHECK) to ≈106 kB;
  reszta — HIERARCHIA-ZRODEL, CN, REM, WYJ, OŚ, STEP-TRACKER, DISCLAIMER —
  ≈113 kB, i cała ta reszta ma już dziś wyzwalacze warunkowe zapisane u siebie.

  ⛔ Kwalifikacja: to jest kwestia bezpieczeństwa, nie wygody. Bramka, której nie
  da się załadować, nie chroni przed niczym, a presja kontekstowa jest
  strukturalną przyczyną trybu fasadowego — przeciwko któremu SELF-CHECK ma trzy
  osobne kontrole. Trzy kontrole na jeden tryb awarii są objawem, nie
  rozwiązaniem.

  ⚡ **Zbieżność z benchmarkiem 2026-09-08.** Pomiar 2×2 wykazał, że skille mają
  znak ZALEŻNY od poziomu rozumowania: przy wysokim +3,6 pkt, przy średnim
  −7,5 pkt. Ujemny znak przy średnim poziomie jest dokładnie tym, czego należy
  oczekiwać, gdy koszt kontekstu wypiera uwagę z merytoryki. Profil LEKKI
  atakuje ten mechanizm, nie objaw.

  Plik rozdziela RDZEŃ NIEREDUKOWALNY od warstwy ODROCZONEJ, każdą pozycję
  z wyzwalaczem MECHANICZNYM i najpóźniejszym momentem odczytu.
  ⛔ Nie znosi żadnej bramki — zmienia moment `view`, nigdy zakres kontroli.
  UP-6 (CN-GATE i REM-GATE w każdej sprawie) bez zmian. Cztery przypadki
  zakazu profilu LEKKIEGO: karne materialne, tura generująca pismo, kategoria
  [11], błąd odczytu zasobu rdzenia.

  Egzekwowanie: nowa pozycja `[PROFIL-ODROCZENIA]` w `references/SELF-CHECK.md`
  (kontrola na wyjściu — wyzwalacz padł, a `view` nie ma = bramka niewykonana)
  oraz dwie linie w bloku KROKU 3A: `PROFIL` i `ODROCZONE`. Deklaracja
  `PROFIL: LEKKI` bez wypisanej listy odroczeń jest nieweryfikowalna, czyli
  fasadowa.

- 3.42 (2026-09-09, F-169/F-170/F-171): **trzy łatki po audycie czterech
  arkuszy odpowiedzi na bank 14 kazusów wieloaspektowych.**
  Układ pomiaru 2×2 — poziom rozumowania (średni / wysoki) × obecność skilli,
  ten sam klucz autorski jako rdzeń odniesienia, ta sama pula kazusów.
  Wynik: bez skilli 84,5 (śr.) i 88,4 (wys.); ze skillami 77,0 (śr.) i 92,0
  (wys.). Skille nie mają stałego znaku — przy wysokim rozumowaniu +3,6 pkt,
  przy średnim −7,5 pkt; premia za poziom rozumowania rośnie ze skillami
  z +3,9 do +15,0. To INTERAKCJA, nie efekt główny.
  Trzy jednostki obalone, wszystkie w arkuszu skillowanym o średnim
  rozumowaniu, wszystkie noszące znacznik „✅ [VER]".

  **F-169 — AF-7, forma znacznika ✅ [VER]** (`shared/PRAWO-HARDGATE.md`).
  Luka źródłowa: rygor nieważności formy istniał WYŁĄCZNIE dla 🎯 [CEL]
  w AF-2 („brak któregokolwiek z pięciu pól = znacznik NIEWAŻNY"). Znacznik
  najsilniejszy — ✅ [VER] — był jedynym bez sankcji za niekompletność, mimo
  że linia 630 pliku od 2026-08-27 przewidywała formę `✅ [VER: źródło, data]`.
  Asymetria odwrotna do ryzyka. Zmierzone: 24 wystąpienia gołego „✅ [VER]"
  w jednym arkuszu; z pięciu sprawdzonych dwa fałszywe (data stosowania
  obowiązków AI Act podana w brzmieniu sprzed rozporządzenia zmieniającego,
  mimo że akt zmieniający wszedł w życie przed datą weryfikacji arkusza).
  Wdrożono rygor trzech pól: kanał odczytu, identyfikator aktu lub orzeczenia,
  data odczytu W TEJ turze. Brak pola = znacznik nieważny, czytany jak
  ⚠️ [NIEWERYFIKOWANE]. Reguła jest składniowa i sprawdzalna z zewnątrz bez
  dostępu do logów.
  ⚠️ Skutek uboczny wdrożenia: dotychczasowe odpowiedzi z gołym „✅ [VER]"
  stają się formalnie nieoznaczone. Wzrost liczby ⚠️ w pierwszej sesji po
  wdrożeniu jest dowodem działania reguły, nie nową flagą.

  **F-170 — S3(b2), oś działalności regulowanej**
  (`shared/MOD-WYJATEK-GATE.md` 2.0→2.1). Luka źródłowa: pytanie zamknięte
  S3(b) brzmiało „czy obowiązywał akt SEKTOROWY regulujący ten sam stosunek
  dla tej kategorii strony?", a katalog kategorii obejmował wyłącznie role
  chronionej strony stosunku prywatnoprawnego (konsument, pacjent, pracownik,
  rolnik, najemca, inwestor). Akt sektorowy przywiązany do ROLI REGULOWANEJ —
  sponsora, dostawcy usługi, instytucji obowiązanej, zamawiającego — był poza
  zasięgiem tego pytania. Zamiatanie wykonane literalnie i poprawnie NIE MOGŁO
  takiego aktu wskazać. To nie było zaniedbanie wykonawcy, tylko zły zakrój
  warunku. Wdrożono dwie osie: b1 strona chroniona, b2 działalność regulowana;
  oba katalogi otwarte, każda oś zamykana osobnym wpisem, „brak" jest wynikiem
  w każdej z nich. Pozycja S3 w bloku wyjściowym zamyka się dopiero po zapisie
  obu osi.

  **F-171 — S4(b), akt o etapowym stosowaniu** (tamże). Luka źródłowa: S4
  obejmowało nowelizacje ujawnione w S1–S3, a S1–S3 patrzą na akt główny.
  Akt, który przesuwa wyłącznie DATĘ STOSOWANIA aktu głównego, nie zmienia
  treści żadnej normy, więc nie ujawnia się przy odczycie normy i S1–S3 go nie
  wskażą. Wdrożono obowiązek odczytu przepisu o rozpoczęciu stosowania
  (typowo ostatni artykuł, „stosuje się od…", z wyjątkami rozdziałami lub
  załącznikami) w brzmieniu AKTUALNYM, nie pierwotnym, wraz z zapisem aktu
  zmieniającego harmonogram. Zapis „akt X stosuje się zasadniczo od DATY" bez
  ustalenia, czy DATA pochodzi z brzmienia pierwotnego czy aktualnego, jest
  wykonaniem FASADOWYM: pole wypełnione, kontrola niewykonana.

  **Zmiany w routerze:** wersja 3.41→3.42; Reguła 12a rozszerzona o obie osie
  S3 i o zakres S4; nowa Reguła 14a (forma znacznika ✅ wg AF-7); SELF-CHECK
  uzupełniony o bramkę blokującą „każdy znacznik ✅ [VER] niesie kanał,
  identyfikator i datę odczytu".

  **Wniosek ogólny.** Pomiar potwierdza Regułę 26 („skill nie jest źródłem")
  i pokazuje jej warunek brzegowy: bramka wymusza POSTAWIENIE znacznika, nie
  wymusza ODCZYTU. Model o słabszym rozumowaniu wypełnia pole bramki z pamięci
  i wystawia sobie certyfikat; model o mocniejszym rozumowaniu idzie do źródła,
  zanim postawi znacznik. Przy identycznym aparacie proceduralnym daje to trzy
  jednostki obalone w jednym arkuszu i zero w drugim. Rekomendacja doboru:
  skille uruchamiać RAZEM z najwyższym dostępnym poziomem rozumowania, nie
  zamiast niego.
  Zaktualizowane sumy w `shared/CHECKSUMS.sha256`.

- 3.37 (2026-09-01, hotfix F-146): **naprawa CRIT — nieparsowalny frontmatter.**
  We wpisie 3.36 pola `changelog:` fragment `„≥1 powołany artykuł"` łączył
  otwarcie typograficzne `„` z zamknięciem prostym `"`. Ponieważ cały wpis jest
  skalarem w cudzysłowach prostych, ten znak kończył skalar w połowie zdania i
  parser przerywał odczyt (`expected <block end>, but found '<scalar>'`).
  Skutek praktyczny: wersja 3.36 nie ładowała się w ogóle — na dysku hosta
  pozostawała 3.34, a system cicho pracował na starszej generacji bramek
  (brak WYJ-GATE z 3.36 i brak OŚ-GATE w wariancie 3.35+).
  Naprawa: zamknięcie zmienione na `”` (poprawna para `„…”`). Zmiana obejmuje
  JEDEN znak w metadanych; treść proceduralna, routing [1]–[11], bramki i
  pipeline pism bez zmian. Zaktualizowane sumy w `CHECKSUMS.sha256`.
  Wniosek profilaktyczny: w YAML cytuj wpisy apostrofami albo pilnuj pary
  `„…”` — ten sam wzorzec mieszanych cudzysłowów występuje w kilkunastu
  miejscach `references/` (tam nieszkodliwie, bo poza frontmatterem).

- 3.36 (2026-08-31d, flaga F-144): BRAMKA SĄSIEDZTWA z 3.35 przemianowana na
  **BRAMKĘ WYJĄTKÓW (WYJ-GATE)** i rozszerzona z jednego zamiatania na cztery:
  S1 sąsiedztwo redakcyjne, S2 krawędzie jednostki (klauzule zakresowe),
  S3 akty powiązane z rejestru ELI (lex specialis leżący poza aktem),
  S4 przepisy przejściowe. Wyzwalacz bez zmian — mechaniczny, „≥1 powołany
  artykuł". Powód: reguła 3.35 pokrywała tylko jedno z czterech miejsc,
  w których mieszkają wyjątki, a jej nazwa opisywała czynność zamiast celu;
  w kazusie 111 wyłączenie rękojmi leżało w INNEJ ustawie, czego S1 nie widzi.
  Moduł: `shared/MOD-WYJATEK-GATE.md`. Reguła 12a i SELF-CHECK przepisane —
  pozycja blokująca wymaga teraz wszystkich czterech zamiatań w bloku, także
  przy wyniku pustym. Bez zmian w routingu [1]–[11] i w pipeline pism.
  ⛔ Skuteczność NIEZMIERZONA — F-144. Pełny opis:
  `audyt-systemu-v4/references/AUDIT-JOURNAL.md`, wpis AUDYT-2026-08-31d.

- 3.35 (2026-08-31c, flaga F-144): nowa **BRAMKA SĄSIEDZTWA (US-GATE)** przed KROK 4, wyzwalacz MECHANICZNY „≥1 powołany artykuł" → `shared/MOD-UNIT-SWEEP.md`. Powód: hard gate potwierdza, że cytowany przepis brzmi tak, jak model twierdzi, a kontrola temporalna — że to właściwa wersja; żadna nie pyta, CO LEŻY OBOK. Luka źródłowa (kazus 111): art. 770 k.c. odczytany ze źródła i we właściwym brzmieniu na 20.02.2011, pominięty art. 770¹ k.c. — jednostka pod następnym numerem, odsyłająca kupującego-konsumenta do przepisów o sprzedaży konsumenckiej. Zakres minimalny US-2 obejmuje obowiązkowo artykuły z indeksem górnym, bo to typowe miejsce lex specialis dodanego nowelizacją. Zaktualizowane: `required_modules`, Reguła 12a, SELF-CHECK (pozycja blokująca). Bez zmian w routingu [1]–[11] i w pipeline pism. ⛔ Skuteczność NIEZMIERZONA — pomiar przypisany do F-144. Pełny opis: `audyt-systemu-v4/references/AUDIT-JOURNAL.md`, wpis AUDYT-2026-08-31c.

- 3.34 (2026-08-31, flaga F-142): BRAMKA CHRONOLOGICZNA rozdzielona na dwa niezależne tory. TOR A — OŚ-GATE, wyzwalacz MECHANICZNY „≥2 daty w opisie stanu faktycznego" → `shared/MOD-OS-CZASU-PRZESLANEK.md`. TOR B — dotychczasowy, „≥2 dokumenty wieloetapowe lub słowa kluczowe" → `chronologia-sprawy-v1`. Powód rozdzielenia: dotychczasowy wyzwalacz nie odpalał na materiale jednodokumentowym — kazus zapisany w pięciu zdaniach zawiera cztery daty i pełny problem temporalny, a bramka go nie widziała. Warunek TORU A jest liczbowy celowo; warunek ocenny („gdy sprawa wydaje się temporalna") to ten sam tryb awarii, który mierzy F-113. Zaktualizowane: `required_modules`, Reguła 12, SELF-CHECK (blok OŚ-GATE jako pozycja blokująca przed konkluzją). Bez zmian w routingu [1]–[11] i bez zmian w pipeline pism. Pełny opis: `audyt-systemu-v4/references/AUDIT-JOURNAL.md`, wpis AUDYT-2026-08-31b.

- 3.33 (2026-08-28): przywrócono jawne wskazanie orzeczenia.ms.gov.pl / sn.pl / nsa.gov.pl w sekcji escalation pliku SKILL.md. Niedostępność uruchamia właściwą weryfikację orzecznictwa; brak potwierdzenia po dostępnych alternatywach wymaga oznaczenia NIEWERYFIKOWANE. Zachowano wszystkie pozostałe instrukcje 3.32, w tym kontroler BI i fallback ISAP.

- 3.32 (2026-08-28): przeniesiono poprawkę BI i fallbacku ISAP z osobistej instalacji, zachowując zmiany rozwojowe 3.30–3.31. Dodano zależność DR-16 i poprawny adres kontrolera; nieudane pobranie aktu/tekstu z ISAP uruchamia LEX/Legalis/ArsLege z kontrolą licencji, wersji i kategorii dowodu.

- 3.31 (2026-08-28): zsynchronizowano router z modelem runtime current-state-only po zamknięciu F-108. Lokalne `MAPA-AKTOW.md` przechowują wyłącznie bieżący akt/zakres → moduł oraz fresh/temporal gate; historia napraw pozostaje w dziennikach i changelogach. Routing korzysta z aktualnych indeksów COV, a `COV` nie jest utożsamiane z `FULL`.

- 3.30 (2026-08-27): zsynchronizowano `pokrycie-dziedzinowe.md` ze stanem faktycznym repozytorium: REACH/CLP → DR-10, akcyza/cło → istniejące moduły DR-06, cudzoziemcy → kanoniczny DR-05; dodano wejścia F-108 P1/41, P1/8 i P1/52.

- 3.29 (2026-08-27): przywrócono stałe identyfikatory reguł po skróceniu,
  bez Reguły 13, z kolejnością 22 → 23. Odwołania w SELF-CHECK i modułach
  zachowują znaczenie. Usunięto pozostałe notatki historyczne z korpusu i YAML.
  Końcowy SKILL.md: 391 linii wobec 924 przed przebudową.

- 3.28 (2026-08-26): korpus routera skrócono z 924 do około 400 linii.
  Na początku dodano siedmiopunktowy blok `ŁADOWANE ZAWSZE`. Szczegóły
  warunkowe pozostawiono w kanonicznych modułach, a z korpusu usunięto
  narracje incydentów, przykłady spraw, zduplikowane źródła, Regułę 13,
  tabelę kombinacji i lokalne warianty disclaimera. `SELF-CHECK.md` zachowuje
  pełne bramki wykonawcze bez opisów historycznych.

- 3.27 (2026-08-26): porównanie z kluczem dostało osobny, obowiązkowy protokół
  `AUDYT-KLUCZA-ODPOWIEDZI.md`: inwentarz wszystkich twierdzeń prawnych,
  atomizacja wg VER-GRAIN, HARD GATE per jednostka oraz jawny licznik pokrycia.
  Werdykt „pełna zgodność" jest teraz dozwolony wyłącznie przy wyniku N/N,
  bez pozycji obalonych i nierozstrzygniętych. Kategoria [11], REGUŁA 27 i oba
  self-checki wskazują tę samą kanoniczną procedurę. Imperatyw `description`
  skrócono z 336 do 170 znaków (profil uniwersalny ≤200), a nagłówek korpusu
  zmieniono z martwego „v3.13" na stabilne „v3", aby nie dublował wersji YAML.

- 3.26 (2026-08-25b, flaga **F-134**): naprawa czterech wad wskazanych w
  zewnętrznej opinii porównawczej — po **audycie samej opinii**, nie po
  przyjęciu jej na wiarę (REGUŁA 25 zastosowana do materiału, który tę regułę
  chwalił).

  **(1) description — przywrócony imperatyw.** Pole było jedynym miejscem
  decydującym o załadowaniu skilla, a w 3.24 wymieniono w nim imperatyw
  („UŻYWAJ ZAWSZE i AUTOMATYCZNIE. Nigdy nie analizuj bez wczytania tego
  pliku") na neutralny opis funkcji. Zysk dla walidatora, strata dla
  wyzwalania. Przywrócono imperatyw i rozszerzono go o przypadek ujawniony
  w F-132 („nie oceniaj cudzej analizy bez wczytania"), zachowując opis
  funkcjonalny dla czytelności.

  **(2) compatibility — realne nazwy.** `live_web_lookup, file_read` nie
  odpowiadały żadnej faktycznej funkcji, co rozluźniało wiązanie HARD GATE
  z konkretnym wywołaniem. Przywrócono nazwy realne z jawnym dopiskiem
  „lub równoważne funkcje hosta wg `shared/UNIVERSAL-RUNTIME-ADAPTER.md`" —
  to zachowuje uniwersalność bez utraty wiązania.

  **(3) PATH-SELFTEST — wykrywanie fail zamiast deklaracji fail-closed.**
  Ścieżki semantyczne (bez prefiksu hosta) są warstwą deklaratywną: jeśli
  host wymaga ścieżki bezwzględnej, odczyt zwróci błąd, a domyślnym
  zachowaniem modelu jest wtedy cicha odpowiedź z pamięci. „Fail-closed
  wymaga, by ktoś wykrył fail". Rozwiązanie NIE polega na powrocie do
  ścieżek jednego hosta (to zabiłoby uniwersalność) ani na dwóch wariantach
  plików (koszt utrzymania), tylko na uczynieniu PIERWSZEGO odczytu w sesji
  testem: forma względna → jeśli błąd, ustal prefiks hosta i powtórz →
  jeśli nadal błąd, jawny `⛔ TRYB ZDEGRADOWANY` z nazwą zasobu i błędu.

  **(4) REGUŁA 26 — skill nie jest źródłem prawa.** Przyczyna zmierzona
  w F-134: wartość „do 2 lat" dla art. 178a §1 KK, którą model podał
  użytkownikowi, pochodziła z modułu `dr-03`, nie z pamięci. Moduł nie był
  drugim źródłem — był jedynym i był w błędzie. Reguła rozdziela role:
  moduł odpowiada „KTÓRY przepis", źródło odpowiada „CO on dziś stanowi";
  znacznik ✅ [VER: data] w module dokumentuje stan na tę datę, nie dziś.

  **Czego z opinii NIE wprowadzono i dlaczego — art. 87 §1 KW.** Opinia
  zgłaszała wartość „30 000 zł" w modułach jako błąd wymagający zamiany na
  „2 500 zł". Weryfikacja: **obie wartości są prawdziwe i opisują różne
  granice tej samej sankcji** — 2 500 zł to dolna granica grzywny z art. 87
  §1 KW, a 30 000 zł to górna granica, bo art. 87 §1 jest wymieniony
  w katalogu art. 24 §1a KW ✅ [VER: lexlege.pl/kw/art-24, odczyt
  2026-08-25]. Zamiana jednej liczby na drugą przeniosłaby błąd, nie
  usunęła. Moduły uzupełniono o OBIE granice z zakazem podawania samej
  górnej. To zastosowanie reguły 25 do samej opinii — trafna diagnoza
  („ta liczba jest niepełna") z błędną korektą.

- 3.25 (2026-08-25, flaga **F-132**): kategoria routingu **[11] WERYFIKACJA
  CUDZEGO MATERIAŁU PRAWNEGO** (→ PRIMARY `analizator-przepisow-v2`) oraz
  **REGUŁA 24 (VER-GRAIN)** i **REGUŁA 25 (ADVERSARIAL-SOURCE)**.

  **Incydent (ta sama rozmowa co F-131, tura następna).** Po naprawie 3.24
  model w turze „porównaj z kluczem" wykonał już weryfikację online — ale
  TYLKO dla części powołań. Zweryfikował definicje stanu po użyciu alkoholu
  (art. 46 ust. 2 ustawy o wychowaniu w trzeźwości), a NIE zweryfikował
  ponownie górnej granicy kary z art. 178a §1 KK i przepisał z pamięci
  wartość „do lat 2", nieaktualną od 1.10.2023 (obowiązuje „do lat 3").
  Wartość ta była BŁĘDNA także w ocenianym kluczu — czyli błąd nie został
  wychwycony, tylko POWIELONY, mimo że jedno ze źródeł w wynikach
  wyszukiwania podawało wartość poprawną. Rozbieżność między źródłami
  została nierozpoznana jako ślad nowelizacji.

  **Dwie odrębne przyczyny, dwie odrębne reguły:**

  (1) *Ziarnistość i kompletność* — reguła 23 wymagała „osobnego wyszukiwania
  dla KAŻDEGO powołania", ale nie definiowała, CO jest powołaniem (teza czy
  liczba?), ani nie ustanawiała kontroli kompletności na wyjściu. Reguła
  spełnialna wybiórczo: model weryfikuje to, co samo wyda mu się wątpliwe,
  a przeoczenie z definicji nie zgłasza się samo. Naprawa: REGUŁA 24 —
  jednostka weryfikacji zdefiniowana wprost (artykuł + §/ust./pkt, każda
  liczba, data, sygnatura, granice kary), INWENTARZ POWOŁAŃ jako czynność
  na wyjściu (lista powołań zestawiona 1:1 z wywołaniami), zakaz znacznika
  ✅ [VER] „hurtem" dla akapitu, oraz reguła 24(c): rozbieżność między
  źródłami = sygnał nowelizacji, nie szum do przegłosowania.

  (2) *Postawa wobec cudzego materiału* — zadanie „porównaj z kluczem"
  weszło do routingu przez skill dziedzinowy (`dr-XX`), bo tabela [1]–[10]
  nie miała pozycji dla weryfikacji cudzego opracowania. `dr-XX` odpowiada
  na pytanie „czy argumentacja jest trafna", nie „czy każda dana w tym
  tekście jest prawdziwa". Skutek: ocena toku rozumowania klucza wypadła
  poprawnie, a ani jedna jednostka redakcyjna klucza nie została sprawdzona
  (niezależna analiza zewnętrzna tego samego materiału wykazała m.in. art.
  250 §2 zamiast §2a, art. 243 zamiast art. 246 §1, grzywnę 100 zł zamiast
  2500 zł, przepadek pojazdu przypisany art. 178a zamiast art. 44b KK,
  oraz zarzut niezgodny ze stanem faktycznym kazusu). Naprawa: kategoria
  [11] z PRIMARY `analizator-przepisow-v2` + REGUŁA 25 — cudzy materiał jako
  hipoteza do obalenia, zgodność ≠ potwierdzenie (dwa teksty mogą powielać
  ten sam błąd), test spójności wewnętrznej jako ustalenie samodzielne,
  zakaz milczącej adopcji cudzej danej bez znacznika.

  **Zakres uniwersalny (portability):** obie reguły i kategoria [11] są
  sformułowane w kategoriach OPERACJI SEMANTYCZNYCH (wyszukanie/odczyt
  źródła, wczytanie skilla), bez nazw narzędzi konkretnego hosta i bez
  ścieżek bezwzględnych — zgodnie z sekcją ADAPTER RUNTIME i
  `shared/UNIVERSAL-RUNTIME-ADAPTER.md`. Działają identycznie na hoście
  bez `web_search`/`view`, o ile host ma funkcje równoważne; brak takich
  funkcji = fail-closed (⚠️ [NIEWERYFIKOWANE]), nie substytucja pamięcią.

  ⚠️ **Skuteczność NIEZMIERZONA** — jak przy F-131 i całej sesji 2026-08-23,
  potwierdzona jest wyłącznie OBECNOŚĆ bramek w plikach, nie ich wpływ na
  zachowanie. Bramka „inwentarz powołań" jest samo-raportująca (klasa e2 wg
  `PLAN-TESTU-BRAMEK-F113.md`) — model, który pominął weryfikację, może z
  tego samego powodu błędnie zaliczyć inwentarz. Pomiar objęty flagą F-133
  (otwarta, `WARN-OTWARTE.md`).

- 3.24 (2026-08-25, flaga **F-131**): REGUŁA 23 — twardy trigger re-check
  HARD GATE/PRIMARY na KAŻDEJ turze rozmowy prawnej, nie tylko pierwszej.
  Incydent: router wczytany raz na starcie rozmowy o kazusach KPK (TA),
  HARD GATE zastosowany poprawnie w pierwszej turze (6 web_search), ale w
  kolejnej turze tej samej rozmowy ("porównaj z kluczem użytkownika") model
  wykonał zero web_search i nigdy nie wczytał PRIMARY dr-03, mimo że treść
  dotyczyła tych samych przepisów KPK/KK/KW. Root cause: reguła 9 (HARD GATE
  TRWAŁY) i formuła SELF-CHECK "przed każdą odpowiedzią" były sformułowane
  jako stan trwały w pliku już przeczytanym, nie jako mechaniczny trigger
  niezależny od klasyfikacji charakteru kolejnej wiadomości ("to tylko
  porównanie, nie nowa analiza" — dokładnie ta klasyfikacja była punktem
  awarii, analogicznie do F-8/F-8b dla świadka). Naprawa: REGUŁA 23 (wzorzec
  reguły 22) + pozycja w bloku SELF-CHECK, niezależna od oceny czy tura jest
  "nowym pytaniem" czy "recenzją/oceną/pytaniem meta" — trigger zależy
  wyłącznie od obecności treści prawnej w odpowiedzi, nie od gatunku tury.
  Dodatkowo odnotowana (nie naprawiona w tej sesji, ⬛ NIEPOTWIERDZONA —
  wymaga testu kontrolowanego) hipoteza uboczna: sekcja ADAPTER RUNTIME
  (ścieżki semantyczne zamiast bezwzględnych `/mnt/skills/user/...`) mogła
  dołożyć koszt pośredniości zwiększający ryzyko pominięcia wykonania —
  patrz `audyt-systemu-v4/references/AUDIT-JOURNAL.md`, wpis AUDYT-2026-08-25,
  sekcja 3-4 dla pełnej analizy i zastrzeżenia metodologicznego.

- 3.23 (2026-08-24, sesja audytowa audyt-systemu-v4, flaga **F-126**): historia wersji sprowadzona do JEDNEJ lokalizacji kanonicznej (ZASADA 15). Usunięte dwa równoległe nośniki: (1) sekcja `## CHANGELOG (prawny-router-v3)` w korpusie `SKILL.md` — wpisy 3.13…3.9, w korpusie zostało odesłanie; (2) pole `changelog:` w YAML liczące 63 linie, czyli pełną historię zamiast skrótu — T12 zgłaszał je jako ⚠️, teraz ma 7 linii i odsyła tutaj. Oba bloki przeniesione 1:1, bez przeredagowania i bez odtwarzania czegokolwiek z pamięci. Pełny opis: `audyt-systemu-v4/references/AUDIT-JOURNAL.md`, wpis AUDYT-2026-08-24.

- 3.22 (2026-08-23i, sesja audytowa audyt-systemu-v4, flaga F-115): self-check ANTY-FASADA podłączony jako WYWOŁANIE modułu kanonicznego `shared/SELF-CHECK-ANTY-FASADA.md`, kopia treści zastąpiona wywołaniem. Powód modułu zamiast kopii: gdy F-117 dodała regułę AF-6 i drugą pozycję listy do `shared/PRAWO-HARDGATE.md`, żadna z 7 istniejących kopii nie została zaktualizowana — źródło miało 2 pozycje, kopie 1. Pełny opis: `audyt-systemu-v4/references/AUDIT-JOURNAL.md`, wpis AUDYT-2026-08-23i.

> Lokalizacja kanoniczna historii wersji (ZASADA 15). Plik założony 2026-08-23i;
> wersje wcześniejsze nieodtworzone — ślad w audyt-systemu-v4/references/AUDIT-JOURNAL.md.

---

## Wpisy przeniesione z korpusu SKILL.md (F-126, 2026-08-24)

> Tekst poniżej przeniesiony 1:1 z sekcji `## CHANGELOG (prawny-router-v3)` w `SKILL.md`.
> Nic nie przeredagowano ani nie odtworzono z pamięci — przeniesienie
> istniejącego tekstu, zgodnie z zakazem z wiersza flagi F-126.

**3.13 (2026-07-12) — Reguła 22: TWARDY trigger słowny dla pytań do świadka
(naprawa F-8b, kontynuacja F-8):**
- Incydent: mimo poprawnie wdrożonej reguły 21 (dekompozycja żądań złożonych),
  model w KOLEJNEJ odpowiedzi w tej samej sesji otrzymał proste, samodzielne
  doprecyzowanie ("czy użyłeś skila przesłuchania świadków... router zawsze
  powinien odpalać ten skill") i — zamiast tego — wcześniej dostarczył pytania
  do świadka wprost z pamięci prawniczej, bez żadnego `view` pliku
  przesluchanie-swiadkow-v2-min90/SKILL.md, mimo że fraza "pytania do świadka"
  padła explicite w poleceniu użytkownika.
- Root cause: reguła 21 wiąże obowiązek wczytania skilla świadka z oceną
  "czy zlecenie jest złożone" (≥2 komponenty z różnych PRIMARY). To dobra
  reguła dla dekompozycji, ale nie jest ona TRIGGEREM SAMYM W SOBIE — model
  może (błędnie) ocenić, że dany fragment prośby "nie wymaga" pełnego
  pipeline'u i odpowiedzieć skrótowo.
- Naprawa: dodano REGUŁĘ 22 — bezwarunkowy, słowny trigger niezależny od
  oceny złożoności: obecność fraz "pytania do świadka"/"przesłuchanie
  świadka"/"kontrprzesłuchanie"/"impeachment świadka" wymusza `view`
  przesluchanie-swiadkow-v2-min90/SKILL.md PRZED napisaniem jakiejkolwiek
  odpowiedzi zawierającej takie pytania — niezależnie od tego, czy reszta
  zlecenia jest prosta czy złożona. Dodano też pozycję w SELF-CHECK.
- Pełny opis incydentu: AUDIT-JOURNAL.md, wpis AUDYT-2026-07-12 (F-8 → F-8b).

**3.12 (2026-07-12) — Reguła 21: CHECKPOINT w żądaniach złożonych (naprawa F-8):**
- Incydent: zlecenie łączące tezy/chronologię/sprzeczności + "pytania do świadka"
  zostało obsłużone przez chronologia-sprawy-v1 w całości; przesluchanie-swiadkow-v2-min90
  nigdy nie zostało wczytane mimo poprawnego wiersza [8] w tabeli routingu — pytania
  W3 powstały bez CHECKPOINT-W2 (bez akceptacji tez przez użytkownika).
- Dodano REGUŁĘ 21 (sekcja reguł nadrzędnych, po regule 20/20a): żądania złożone
  dekomponować na komponenty, każdy z własnym PRIMARY skillem i checkpointami;
  obecność checkpointu w jednym komponencie (np. świadek → CHECKPOINT-W2) blokuje
  wyłącznie ten komponent, nie całą odpowiedź — ale MUSI zablokować.
- Pełny opis incydentu i naprawy równoległej w chronologia-sprawy-v1 (v1.3→v1.4,
  KATEGORIA A0 fałszywe sprzeczności): AUDIT-JOURNAL.md, wpis AUDYT-2026-07-12.
- Flaga F-8 w WARN-OTWARTE.md → zamknięta tym wpisem.

**3.11 (2026-07-05) — scalenie standaryzacji metadanych z pełną logiką 3.10:**
- Kontekst: równolegle do rozwoju 3.9→3.10 (logika weryfikacji podmiotów) powstała
  osobna gałąź robocza, oznaczona "3.9" z dnia 2026-07-04, wprowadzająca ustrukturyzowany
  frontmatter (dependencies, inputs, outputs, confidence, escalation, limitations,
  required_modules) — ale bez KROK 0D i bez POV-D-TRIGGER.
- Scalenie: przyjęto ustrukturyzowany frontmatter, zachowując w całości treść
  KROK 0D, [POV-D-TRIGGER], ZASADĘ FUNDAMENTALNĄ ("dane z akt ≠ zweryfikowane")
  oraz pełny blok SELF-CHECK z POV-B/C/D.
- Dodano: required_modules → shared/PRE-W2-VERIFICATION-GATE.md; escalation →
  przypadek podmiotu ⬛ bez dostępu do rejestru.
- Dodano do frontmatter adnotację ZNALEZISKO 2026-07-04 o potencjalnym duplikacie
  kwalifikator-karnomaterialny.md (zgłoszone do CHECKLIST-DEDUP, nie rozwiązane
  w tym scaleniu).
- Wersja: 3.10 → 3.11. Żadna funkcja bezpieczeństwa nie została usunięta.

**3.10 (2026-06-26) — KROK 0D: oznaczanie podmiotów ⬛ [DO WERYFIKACJI]:**
- Nowy krok 0D w sekwencji głównej: obowiązkowe oznaczanie każdego podmiotu
  (spółki, sądy, organy) statusem ⬛ [DO WERYFIKACJI] od chwili napotkania.
- Status ⬛ utrzymuje się do faktycznego web_search/web_fetch — nie do zamiaru.
- SELF-CHECK: nowy blok "STATUS PODMIOTÓW" z checklistą przed każdą odpowiedzią.
- MOD-STEP-TRACKER: dodano R0D do REJESTRU.
- Wyjątki: dane osoby fizycznej (imię/nazwisko/adres/PESEL) — nie oznaczaj ⬛.
- Powiązane: PRE-W2-VERIFICATION-GATE.md v1.2.0 (nowy krok PRE-W2.0).

**3.9 (2026-06-26) — naprawa [POV-D-TRIGGER] i zasady "dane z akt ≠ zweryfikowane":**
- Root cause: model traktował KRS/NIP z umów/akt jako zweryfikowane online.
  Skutek: KRS [KRS-A] ([SPÓŁKA-A] sp. z o.o.) wpisany przy [SPÓŁKA-B] sp. z o.o.
  (która ma KRS [KRS-B]) w piśmie procesowym [SYGN-SPRAWY] (sesja 2026-06-26).
- SELF-CHECK: blok POV-B/C/D rozbudowany o:
  (a) zasadę explicite "dane z akt ≠ zweryfikowane"
  (b) [POV-D] jako osobny krok z triggerem przy ≥2 różnych numerach KRS/NIP
  (c) wymóg wyświetlenia raportu PRE-W2 przed W2
- Reguła nadrzędna 18: dodano [POV-D-TRIGGER] i zasadę fundamentalną.
- Wersja: 3.8 → 3.9

---

## Wpisy przeniesione z pola `changelog:` YAML (F-126, 2026-08-24)

> T12 zgłaszał to pole jako ⚠️ — 63 linie to pełna historia, nie skrót
> (ZASADA 15 dopuszcza w YAML skrót do ~15 linii). Tekst poniżej przeniesiony
> 1:1, w oryginalnej składni listy YAML, bez przeredagowania i bez
> odtwarzania czegokolwiek z pamięci.

```yaml
changelog:
  - "3.21 (2026-08-18): NOWY KROK 0-RPK — router jest teraz jedynym miejscem
    decydującym, KIEDY inicjować shared/MOD-REJESTR-POKRYCIA-JEDNOSTEK.md
    (RPK), zamiast zostawiać tę decyzję wyłącznie w opisie biblioteki
    shared/SKILL.md, która sama w sobie nie jest samodzielnym skillem i nie
    ma własnej sekwencji wywołania. Powód: użytkownik trafnie zauważył, że
    dodanie modułu RPK do shared (2026-08-18, AUDYT-2026-08-18, flaga F-93)
    nie wystarcza — biblioteka nie decyduje SAMA o swoim wywołaniu, potrzebny
    jest punkt orkiestracji. Krok umieszczony zaraz po KROK 0-ST (analogicznie
    do MOD-STEP-TRACKER), z jawnymi sygnałami wyzwalającymi (zbiór ≥10
    ponumerowanych jednostek, plik źródłowy z numeracją ciągłą, zapowiedź
    pracy partiami). required_modules i SELF-CHECK rozszerzone. Nie zamyka
    F-93 w całości — propagacja do pozostałych 5 skilli-konsumentów
    (analizator-przepisow-v2, analizator-dowodow-v3,
    przesluchanie-swiadkow-v2-min90, chronologia-sprawy-v1, audyt-systemu-v4)
    pozostaje otwarta, patrz WARN-OTWARTE.md."
  - "3.17 (2026-07-21): NAPRAWIONO — shared/HIERARCHIA-ZRODEL.md (istniał
    od dawna) i shared/PORTALE-BRANZOWE-RZAD-2B.md (zbudowany w tej sesji,
    16 dziedzin z weryfikacją site:) NIE BYŁY ładowane przez ŻADEN DR-skill
    ani przez sam router — DOKŁADNIE ten sam wzorzec 'zbudowano, zapomniano
    podłączyć' co wielokrotnie w tej sesji (moduły niezarejestrowane w
    SKILL.md, plany bez skryptów, poprawki niezsynchronizowane między
    mapami). Dodano OBA do required_modules — TERAZ każde wywołanie routera
    (a więc każdy DR-skill uruchamiany PRZEZ router) ma dostęp do
    kategoryzacji wiarygodności źródeł i rejestru portali branżowych.
    Odkryte przy pytaniu użytkownika 'czy wszystkie DR wiedzą o tej bazie
    portali?' — odpowiedź brzmiała: ŻADEN, naprawiono."
  - "3.16 (2026-07-13f): KONSOLIDACJA — usunięto zależność od osobnych skilli
    mcp-zrodla-prawa-v1/audit-trail-portal-v1/sync-dzu-automatyczny-v1 (utworzonych
    2026-07-13). Ich treść przeniesiono do shared/MCP-INTEGRACJA.md,
    shared/AUDIT-TRAIL-SPEC.md i audyt-systemu-v4/references/SYNC-DZU-AUTOMATYCZNY.md
    — bo żaden z nich nie był samodzielnym skillem wywoływanym intencją użytkownika,
    tylko protokołem/narzędziem ładowanym przez router lub audyt-systemu-v4,
    dokładnie jak PRAWO-HARDGATE.md czy HYBRID-VALIDATION.md. Powód: uniknięcie
    duplikowania wzorca 'protokół + narzędzia w shared/tools', na wniosek
    użytkownika po pytaniu 'czy nie lepiej wdrożyć to jako elementy obecnych
    skili, a nie tworzyć coś nowego, co duplikuje już istniejące skille?'.
    Skille w systemie: 36 → 33 (powrót do liczby sprzed 2026-07-13)."
  - "3.15 (2026-07-13): INTEGRACJA — dodano shared/MCP-INTEGRACJA.md jako opcjonalną
    warstwę deterministyczną PRZED HARD GATE (nie zamiast). Gdy connector MCP
    (ISAP/SAOS/CBOSA/KRS/EUR-Lex) jest podłączony i dostępny w rozmowie, router
    używa go w pierwszej kolejności do weryfikacji powołań; HARD GATE
    (web_search/web_fetch) pozostaje aktywny bez zmian jako fallback i jako
    jedyna ścieżka gdy MCP niedostępne. Część realizacji rekomendacji #2 z
    audytu komercyjnego silnika 2026-07-13 (pełny opis: audyt-systemu-v4/
    references/AUDIT-JOURNAL.md, wpis AUDYT-2026-07-13)."
  - "3.14 (2026-07-12): DEDUP — usunięty duplikat
    references/kwalifikator-karnomaterialny.md (identyczny z kanonicznym
    dr-03/modules/mod-KK-kwalifikator-karnomaterialny.md, MD5 zgodny),
    zgłoszony jako ZNALEZISKO 2026-07-04. 2 miejsca wywołania w dr-03
    przekierowane na ścieżkę kanoniczną. Zamyka pozycję w limitations —
    pełny opis tam. Część audytu komercyjnego silnika (punkt 4)."
  - "3.9 (2026-06-26): naprawa [POV-D-TRIGGER] i zasady 'dane z akt ≠ zweryfikowane
    online' — pełny opis w sekcji CHANGELOG na końcu pliku."
  - "3.10 (2026-06-26): KROK 0D — obowiązkowe oznaczanie podmiotów ⬛ [DO WERYFIKACJI]
    — pełny opis w sekcji CHANGELOG na końcu pliku."
  - "3.11 (2026-07-05): SCALENIE dwóch równoległych gałęzi rozwoju — (a) standaryzacja
    metadanych frontmatter (dependencies/inputs/outputs/confidence/escalation/
    limitations/required_modules), wprowadzona w wersji roboczej oznaczonej 3.9
    z dnia 2026-07-04, z (b) pełną logiką weryfikacji podmiotów KROK 0D +
    POV-D-TRIGGER z wersji 3.10 (2026-06-26). Żadna funkcja bezpieczeństwa nie
    została usunięta w procesie scalenia — required_modules rozszerzone o
    shared/PRE-W2-VERIFICATION-GATE.md, escalation rozszerzone o przypadek
    podmiotu ⬛ bez dostępu do rejestru."
```

## 3.38 (2026-09-04c) — naprawa YAML + podpięcie instrukcji dostępu do API

### Błąd naprawiony (F-159)

`escalation:` zawierał wielolinijkowy element z `weryfikacji: view shared/...`
w linii kontynuacji. YAML czyta `": "` jako początek mapy → `ScannerError:
mapping values are not allowed here` w linii 50 → **cały frontmatter
nieparsowalny**, czyli skill nie ładował się na hoście.

⛔ **To NAWRÓT.** Wpis 3.37 opisuje dokładnie tę samą klasę usterki: „naprawa
niesparowanego cudzysłowu w polu changelog — otwarcie typograficzne domknięte
znakiem prostym kończyło skalar YAML w połowie zdania i czyniło CAŁY
frontmatter nieparsowalnym". Dwa razy pod rząd ta sama awaria, bo **nic w tym
skillu nie sprawdza, czy własny frontmatter się parsuje**. Naprawa punktowa
nie usuwa przyczyny — zgłoszone jako F-159, do bramki.

Naprawiono także ciche zniekształcenie typu: `- opcjonalnie: pliki/dowody`
w `inputs`/`outputs` parsowało się BEZ BŁĘDU jako mapa `{opcjonalnie: "..."}`,
nie jako tekst. Konsument czytający listę łańcuchów dostawał słownik.

### Zmiana architektoniczna

Instrukcje „jak wywołać API" mieszkały wyłącznie w
`audyt-systemu-v4/references/PORTALE-ORZECZNICZE-API.md`. Sprawdzone:
`audyt-systemu-v4` **nie występuje w `dependencies.requires` żadnego skilla
produkcyjnego** — ani routera, ani `analiza-sadowa-v6`, `prawo-polskie-v2`,
`pisma-procesowe-v3`, `orzeczenia-sadowe-v2`. Wszystkie wzmianki o tym skillu
to narracyjne cytaty flag. Instrukcje były więc **niewidoczne z produkcji**.

- Utworzony `shared/DOSTEP-MASZYNOWY-API.md` — wyciąg operacyjny (nagłówki,
  ścieżki robocze, limity tempa, endpointy ELI/SAOS/KRS/UODO/HUDOC/eZamówienia,
  token CEIDG, anonimizacja odpisu KRS).
- Dopisany do `required_modules` routera.
- `escalation` rozszerzone o trzy pozycje: bramkę „sprawdź kształt żądania,
  zanim orzekniesz o niedostępności źródła", status ISAP jako **stanu
  normalnego** (kanał maszynowy martwy — weryfikacja przez ELI, ISAP jako
  adres dla człowieka) oraz białą listę VAT jako nieosiągalną maszynowo.

⛔ Bez duplikacji: pomiar i jego dowód zostają w `audyt-systemu-v4` (T25),
w `shared` stoi wyłącznie wyciąg operacyjny.
