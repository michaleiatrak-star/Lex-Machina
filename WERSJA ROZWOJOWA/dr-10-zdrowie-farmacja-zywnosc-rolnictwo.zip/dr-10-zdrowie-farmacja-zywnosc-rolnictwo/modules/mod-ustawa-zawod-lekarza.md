# Modul - Zawood lekarza i lekarza dentysty

**Akt:** UPP (ustawa o prawach pacjenta i Rzeczniku Praw Pacjenta) — t.j. Dz.U. 2024 poz. 581 (zm. po t.j.: 2026/791 od 2026-07-01 — art. 7, 10, 14, 26, 30a, 30b, 35; 2026/26 [OD 2027-01-01: 2026/26] — art. 28).
**Akt:** UZL (ustawa o zawodach lekarza i lekarza dentysty) — t.j. Dz.U. 2026 poz. 37 (zm. po t.j.: 2026/203 od 2026-03-05 — art. 7; 2026/791 od 2026-07-01 — art. 3, 15b, 15d, 15f, 15g, 15h, 41a).
**Akt:** UIL (ustawa o izbach lekarskich) — t.j. Dz.U. 2021 poz. 1342 (zm. po t.j.: 2023/1234 od 2023-07-14 — art. 49).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

## Akt prawny
**Ustawa z 05.12.1996 r. o zawodach lekarza i lekarza dentysty**
- Tekst jednolity: **Dz.U. 2026 poz. 37** (t.j. z 13.01.2026)
  VER: isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20240001287 [2026-05-31]

**Weryfikacja w ELI (RZĄD 1) przed kazdy cytowaniem.**

## Zakres
Reguluje: prawo wykonywania zawodu lekarza (PWZ), kwalifikacje, rejestracja,
ksztalcenie, obowiazki i prawa lekarza, tajemnica lekarska, odpowiedzialnosc.

## Prawo wykonywania zawodu (PWZ)
```
Wymagania: dyplom lekarza + staaz podyplomowy 13 miesiecy + zdanie LEK/LEP (egzamin)
Organ:     Okregowa Izba Lekarska lub Naczelna Izba Lekarska
Ograniczone PWZ: Dla cudzoziemcow i absolwentow spoza UE - ograniczone miejsce pracy
Zawieszenie:     Przez sad (art. 19) lub Izbe Lekarska (postep. dyscypl.)
```

## Kluczowe obowiazki lekarza
```
Udzielenie pomocy: Obowiazek nawet bez skierowania (nagly przypadek)
Tajemnica lekarska: Art. 40 - bezwzgledna (wyj.: sad, prokuratura, pacjent)
Zgoda pacjenta:     Obowiazkowa (art. 32) - swiadoma, bez przymusu
Badanie: Tylko za zgoda z wyjatkiem stanow naglych (art. 33)
Dokumentacja medyczna: ⚠️ POPRAWKA 2026-07-27 (FAZA 3E/ZASADA 14) —
  było błędnie "Art. 41" (ustawy o zawodach lekarza). Ten przepis
  (dawny art. 41 ust. 7 ustawy o zawodach lekarza) został UCHYLONY —
  obowiązek przechowywania przez 20 LAT jest teraz uregulowany w
  **art. 29 ustawy o prawach pacjenta i Rzeczniku Praw Pacjenta**
  (INNA ustawa), licząc od końca roku kalendarzowego ostatniego wpisu.
  Sama liczba (20 lat) była poprawna, podstawa prawna nieaktualna.
  Wyjątki: zgon wskutek uszkodzenia ciała/zatrucia oraz dane o krwi —
  30 lat; zdjęcia RTG — 10 lat; skierowania — 5 lat (2 lata, jeśli
  świadczenie niezrealizowane); dokumentacja dzieci do 2. r.ż. — 22
  lata. Potwierdzone w 8+ źródłach (prawo.pl, lexlege.pl, arslege.pl,
  archiwum RPP, NIL, termedia.pl).
```

## Odpowiedzialnosc dyscyplinarna
```
Akt: Ustawa z dnia 2 grudnia 2009 r. o izbach lekarskich — Dz.U. 2021 poz. 1342
  t.j. (obwieszczenie 25.06.2021), nadal aktualny [VER: 2026-07-15]. Rozdział 5
  "Odpowiedzialność zawodowa" — art. 53-112 — to źródłowa podstawa całej
  poniższej procedury (organy, kary, przedawnienie, postępowanie mediacyjne).
  ⚠️ Weryfikuj w ELI (RZĄD 1) przed każdym cytowaniem konkretnego artykułu.

Organ: Okregowy Sad Lekarski -> Naczelny Sad Lekarski -> SN (kasacja)
Kary: Upomnienie, nagana, zawieszenie PWZ (max 5 lat), pozbawienie PWZ
Przedawnienie: 5 lat od popelnienia czynu lub 3 lata od dowiedzenia sie przez Izbe

Baza orzeczen (⚙️ spięte z prawo-polskie-v2/krajowe/shared/PRAWO-HARDGATE.md, sekcja "zawody zaufania
publicznego — odpowiedzialność dyscyplinarna"; zweryfikowane online 2026-07-06):
  I i II instancja (Okregowy Sad Lekarski, Naczelny Sad Lekarski) ->
    nil.org.pl/orzeczenia (portal NIL prawomocnych orzeczen sadow lekarskich,
    uruchomiony 2024, tresci zanonimizowane) -> mimo istnienia portalu, brak
    trafienia NIE jest dowodem zmyslenia sygnatury (portal moze byc
    niekompletny/opozniony) -> oznacz ⚠️ [NIEWERYFIKOWALNE], nigdy ✅ [VER]
    bez faktycznego odnalezienia tresci
  Kasacja -> sn.pl (Izba Odpowiedzialnosci Zawodowej SN), rowniez skompilowana
    osobno przez NIL pod nil.org.pl/izba/naczelny-rzecznik-odpowiedzialnosci-
    zawodowej/dokumenty/orzeczenia-sadu-najwyzszego (sygnatury SDI / II ZK)
    -> pelna procedura weryfikacji sygnatury wg PRAWO-HARDGATE KROK 0-5
Pelny opis trybu, tabela zawodow i uzasadnienie: dr-12 ->
  mod-ustawa-odpowiedzialnosc-dyscyplinarna-zawodow.md, sekcja
  "Orzecznictwo dyscyplinarne — instancje i bazy"
```

**Dokumenty samorządu zawodowego** (uchwały, kodeks etyki, regulaminy, rejestr członków): `view prawo-polskie-v2/krajowe/shared/SAMORZADY-ZAWODOWE-DOKUMENTY.md` — sekcja 3 (NIL, w tym lekarze dentyści); RZĄD 1 tylko z oficjalnego portalu samorządu.

## Weryfikacja online
```
web_search: "ustawa zawod lekarza Dz.U. 2026 poz. 37 isap t.j."
web_fetch: https://www.sn.pl/pl/wyszukiwarka-orzeczen (kasacja od orzeczen NSL)
```
