# mod-rzadkie-choroby-genetyczne-plan-leki-sieroce

**Wersja:** 1.0 | **Dodano:** 2026-07-20
**Rola w systemie:** odpowiedź na pytanie użytkownika o rzadkie choroby
genetyczne i wsparcie państwa — dotąd CAŁKOWITA LUKA w całym systemie.

> ⛔ HARDGATE — zweryfikuj aktualny stan wdrożenia Planu dla Chorób
> Rzadkich i listy refundacyjnej na ISAP/gov.pl przed użyciem — to
> obszar w CIĄGŁEJ rozbudowie (kolejne edycje planu, kolejne listy
> refundacyjne co 2 miesiące).

---

## 1. DEFINICJA I SKALA ZJAWISKA

```
□ CHOROBA RZADKA — występowanie NIE WIĘCEJ niż 5 przypadków na 10 000
  mieszkańców (definicja UE)
□ CHOROBA ULTRARZADKA — 1 przypadek na 50 000-100 000 mieszkańców
□ LICZBA znanych chorób rzadkich: szacowana na 8000-10 000
□ POCHODZENIE: ok. 80% chorób rzadkich ma podłoże GENETYCZNE,
  pozostałe 20% — infekcyjne/alergiczne/środowiskowe
□ WIEK UJAWNIENIA: ok. 50% chorób rzadkich ujawnia się w wieku
  DZIECIĘCYM (z czego ok. 30% dzieci umiera przed ukończeniem 5. roku
  życia), pozostałe dotyczą osób dorosłych
□ SKALA W POLSCE: szacunkowo NAWET 2-3 MLN Polaków może żyć z rzadką
  chorobą (⚠️ różne źródła podają różne szacunki, zweryfikuj aktualne)
```

---

## 2. PLAN DLA CHORÓB RZADKICH — RAMY INSTYTUCJONALNE

### Geneza i status wdrożenia

```
□ PODSTAWA UNIJNA: zalecenie Rady UE z 8.06.2009 r. w sprawie działań
  w dziedzinie rzadkich chorób — zobowiązanie państw członkowskich do
  opracowania KRAJOWYCH planów/strategii
□ HISTORIA W POLSCE: pierwsze założenia opracowane w 2011 r. (Krajowe
  Forum na rzecz Terapii Chorób Rzadkich → Zespół ds. Chorób Rzadkich
  przy Ministrze Zdrowia)
□ ⚠️ PIERWOTNIE zapowiadany na sierpień 2023 r. — MIMO wypracowanych
  rozwiązań i przyjęcia projektu, NIGDY nie wszedł do kalendarza prac
  legislacyjnych w TEJ formie
□ REALIZACJA: obecny "Plan dla Chorób Rzadkich" realizowany jest OD
  2020 r., w KOLEJNYCH edycjach — ✅ **ZWERYFIKOWANE 2026-08-19 (F-47),
  status na dzień weryfikacji:**
  - Uchwała RM nr 88/2024 z 13.08.2024 — Plan na lata **2024-2025**.
  - Uchwała RM nr 179/2025 — **Plan dla Chorób Rzadkich na 2026 r.**
    (edycja roczna, nie dwuletnia jak poprzednia), kontynuacja
    niedokończonych zadań z 2024-2025: dokończenie sieci Ośrodków
    Eksperckich Chorób Rzadkich (OECR), uruchomienie Systemu dla
    Chorób Rzadkich (Rejestr Chorób Rzadkich + Karta Pacjenta +
    Platforma Informacyjna).
  - ⭐⭐ **PRZEDŁUŻONY do końca 2026 r.** (potwierdzone: ptchnm.org.pl,
    środowisko pacjenckie) — pytanie o edycję "po 2026" pozostaje
    otwarte, MZ rozważa kolejne edycje, ale bez konkretnego zobowiązania.
  - ⚠️ **"MARTWY PUNKT" (mzdrowie.pl, czerwiec 2026):** ostateczne
    wdrożenie Systemu dla Chorób Rzadkich UZALEŻNIONE od wejścia w
    życie odrębnej ustawy o systemie informacji w ochronie zdrowia
    (SIOZ) — prace informatyczne ZAKOŃCZONE, ale system czeka na
    podstawę prawną do uruchomienia. To realne, aktualne wąskie
    gardło — nie samo istnienie Planu, tylko brak ustawowej podstawy
    dla jego kluczowego elementu informatycznego.
  ⭐ **Wniosek praktyczny:** przy sprawie dot. dostępu pacjenta do
  OECR/rejestru — Plan formalnie ISTNIEJE i jest aktywny (do końca
  2026), ale System dla Chorób Rzadkich (rejestr + karta pacjenta) NIE
  jest jeszcze operacyjny z powodu braku ustawy SIOZ — to rozróżnienie
  ma znaczenie przy ocenie realnych praw pacjenta "na papierze" vs "w
  praktyce".
```

### Sześć głównych obszarów Planu

```
A) Poprawa DIAGNOSTYKI (w tym GENETYCZNEJ) — nowoczesne badania
   wysokoprzepustowe/genomowe (sekwencjonowanie nowej generacji),
   nowe badania NIEGENETYCZNE laboratoryjne
B) Ośrodki Eksperckie Chorób Rzadkich (OECR) — patrz sekcja 3
C) Poprawa DOSTĘPU do LEKÓW i środków specjalnego przeznaczenia
   żywieniowego — patrz sekcja 4 (leki sieroce)
D) ZINTEGROWANA POMOC SOCJALNA dla pacjentów z chorobami rzadkimi
   I ICH RODZIN — kluczowy element dla opiekunów, patrz Integracja
   z systemem
E) INFORMACJA, NAUKA i EDUKACJA w zakresie chorób rzadkich — Platforma
   Chorób Rzadkich (materiały dla pacjentów I medyków niemających
   pogłębionej wiedzy o tych chorobach)
F) MONITOROWANIE realizacji planu
```

### 3. Ośrodki Eksperckie Chorób Rzadkich (OECR)

```
□ FUNKCJA: wyspecjalizowane ośrodki koncentrujące wiedzę i doświadczenie
  w diagnostyce/leczeniu konkretnych grup chorób rzadkich
□ FINANSOWANIE: NFZ wspólnie z Ministerstwem Zdrowia wypracowały
  rozwiązania dot. FINANSOWANIA ośrodków eksperckich (⚠️ dokładny
  mechanizm finansowy niepotwierdzony w pełni w tej sesji)
□ Dodatkowe narzędzia: Polski Rejestr Chorób Rzadkich (rejestr
  epidemiologiczny), Paszport Pacjenta z Chorobą Rzadką (dokument
  ułatwiający komunikację między różnymi placówkami medycznymi —
  szczególnie istotny przy CHOROBACH RZADKICH, gdzie personel medyczny
  spoza specjalizacji często NIE MA wiedzy o konkretnej jednostce
  chorobowej), Platforma Informacyjna "Choroby Rzadkie"
```

---

## 4. ⭐⭐ LEKI SIEROCE — MECHANIZM REFUNDACJI

```
□ DEFINICJA (prawo UE): "sierocy produkt leczniczy" — lek przeznaczony
  do diagnozowania/zapobiegania/leczenia chorób RZADKICH, wobec
  którego NIE OPŁACAŁOBY SIĘ producentowi ponosić normalnych kosztów
  opracowania BEZ zachęt regulacyjnych — podstawa: Rozporządzenie (WE)
  nr 141/2000 Parlamentu Europejskiego i Rady z 16.12.1999 r.

⭐ PROBLEM SYSTEMOWY (odnotowany przez ekspertów): leki sieroce
  stosowane w chorobach rzadkich HISTORYCZNIE KONKUROWAŁY o refundację
  NA TAKICH SAMYCH zasadach jak leki na choroby POWSZECHNE — co jest
  problematyczne, bo analiza farmakoekonomiczna (koszt/efekt) leku
  sierocego dla MAŁEJ populacji pacjentów WYPADA GORZEJ niż leku dla
  choroby powszechnej, mimo że dla POJEDYNCZEGO pacjenta z rzadką
  chorobą może to być JEDYNA dostępna terapia

POSTĘP (stan na 2024-2025):
  □ W 2024 r. Ministerstwo Zdrowia OBJĘŁO REFUNDACJĄ 36 NOWYCH terapii
    dla chorób rzadkich i ultrarzadkich
  □ Od 1.01.2025 r. lista refundacyjna ROZSZERZONA o KOLEJNE 12 terapii
    dla tej grupy pacjentów
  □ AOTMiT (Agencja Oceny Technologii Medycznych i Taryfikacji) —
    w samym 2024 r. rozpoczęła ocenę SZEŚCIU leków na choroby rzadkie

⭐ PROPONOWANA NOWELIZACJA ustawy refundacyjnej (⚠️ STATUS: projekt
  rządowy w toku prac, NIE uchwalony na dzień weryfikacji, sprawdź
  aktualny postęp) — GŁÓWNY CEL: SKRÓCENIE czasu oczekiwania na
  refundację leków sierocych, poprzez uwzględnianie w analizach
  FARMAKOEKONOMICZNYCH DODATKOWYCH kryteriów, takich jak WPŁYW CHOROBY
  NA CAŁĄ RODZINĘ (nie tylko na samego pacjenta) — to POTENCJALNIE
  istotna zmiana metodologiczna, gdyby weszła w życie

Checklist praktyczny (refundacja):
□ Sprawdź, czy KONKRETNY lek dla danej choroby rzadkiej figuruje na
  AKTUALNEJ liście refundacyjnej (aktualizowanej co 2 miesiące) —
  gov.pl/web/zdrowie → wykazy refundacyjne
□ Jeśli lek NIE jest refundowany — rozważ ścieżkę WNIOSKU o objęcie
  refundacją (procedura AOTMiT) lub RATUNKOWY DOSTĘP DO TECHNOLOGII
  LEKOWEJ (RDTL, ⚠️ mechanizm istniejący w polskim systemie ochrony
  zdrowia dla sytuacji wyjątkowych — NIE opracowany w pełni w tym
  module, punkt startowy, sprawdź odrębnie)
```

---

## 5. CHECKLIST PRAKTYCZNY ZBIORCZY

```
□ Czy pacjent ma DOSTĘP do OECR właściwego dla jego jednostki
  chorobowej — sprawdź AKTUALNĄ listę ośrodków na Platformie Chorób
  Rzadkich (chorobyrzadkie.gov.pl)
□ Czy warto wystąpić o wpisanie danych pacjenta do Polskiego Rejestru
  Chorób Rzadkich (korzyści: lepsza koordynacja opieki, dane dla
  badań epidemiologicznych)
□ Czy pacjent POSIADA Paszport Pacjenta z Chorobą Rzadką — przydatny
  przy KAŻDYM kontakcie z placówką medyczną SPOZA specjalizacji
□ Czy lek potrzebny pacjentowi jest już REFUNDOWANY — sprawdź
  AKTUALNĄ listę, a jeśli nie — rozważ ścieżkę wnioskową
□ Czy sprawa dotyczy DZIECKA urodzonego z ciężką/nieuleczalną chorobą —
  sprawdź ŚWIADCZENIE "ZA ŻYCIEM" (4000 zł jednorazowo) i pozostałe
  świadczenia opiekuńcze — patrz `mod-ustawa-swiadczenia-rodzinne.md`
  (DR-04, rozbudowany 2026-07-20) dla PEŁNEGO opracowania wsparcia dla
  RODZIN i OPIEKUNÓW
```

---

## 6. INTEGRACJA Z SYSTEMEM

- **`mod-ustawa-swiadczenia-rodzinne.md`** (DR-04, rozbudowany
  2026-07-20) — PEŁNE wsparcie FINANSOWE dla rodzin/opiekunów osób
  z chorobą rzadką (świadczenie "za życiem", świadczenie pielęgnacyjne
  po reformie 2024, opieka wytchnieniowa) — TEN moduł dostarcza
  WYŁĄCZNIE stronę MEDYCZNĄ/systemową (diagnostyka, ośrodki, leki),
  bez duplikacji świadczeń pieniężnych.
- **`mod-ustawa-swiadczenie-wspierajace-WZON.md`** (DR-04) — świadczenie
  wspierające dla DOROSŁYCH osób z niepełnosprawnością (w tym z rzadką
  chorobą genetyczną) — system punktowy niezależny od konkretnej
  jednostki chorobowej.
- **`mod-ustawa-rehabilitacja-PFRON.md`** (DR-04) — dofinansowania
  sprzętu rehabilitacyjnego, ANEKS o wypożyczalni PFRON.
- **DR-02** — `mod-KRO-przysposobienie-adopcja-miedzynarodowa.md`,
  `mod-piecza-zastepcza-rodzina-zastepcza.md` — pośrednio, przy
  dzieciach z chorobami rzadkimi wymagającymi opieki zastępczej.

---

## 7. LITERATURA I ŹRÓDŁA (zweryfikowane online 2026-07-20)

- archiwum.mz.gov.pl, chorobyrzadkie.gov.pl (2×) — Narodowy Plan dla
  Chorób Rzadkich, geneza, sześć obszarów planu, definicje UE.
- bip.brpo.gov.pl — rekomendacje RPO, status wdrożenia poszczególnych
  elementów planu (OECR, rejestr, paszport pacjenta).
- rynekzdrowia.pl — historia opóźnień legislacyjnych planu (zapowiedź
  sierpień 2023, brak wejścia w kalendarz prac).
- wnp.pl, oddechzycia.pl — mechanizm refundacji leków sierocych,
  konkretne liczby (36 terapii 2024, +12 terapii 2025), proponowana
  nowelizacja ustawy refundacyjnej (kryterium wpływu na rodzinę).
- gov.pl (dokument PDF Planu dla Chorób Rzadkich 2024-2025) — pełne
  dane epidemiologiczne (5/10000, 1/50000-100000, 80% podłoże
  genetyczne, 50% ujawnienie w dzieciństwie).
