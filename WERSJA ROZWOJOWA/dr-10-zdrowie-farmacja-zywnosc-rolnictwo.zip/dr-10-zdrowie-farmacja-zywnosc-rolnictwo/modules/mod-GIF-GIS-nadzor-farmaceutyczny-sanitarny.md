# mod-CT-farmaceutyczne-sanitarne-gif-gis.md — Prawo farmaceutyczne, sanitarne, GIF/GIS

**Akt:** PrFarm (Prawo farmaceutyczne) — t.j. Dz.U. 2026 poz. 612 (zm. po t.j.: 2026/791 od 2026-07-01 — art. 75, 83; 2026/1004 od 2026-08-27 — art. 72; 2026/1079 od 2026-09-10 — art. 37av, 37ava, 42, 70, 96, 103).
**Akt:** URef (ustawa o refundacji leków, środków spożywczych specjalnego przeznaczenia żywieniowego oraz wyrobów medycznych) — t.j. Dz.U. 2026 poz. 253 (zm. po t.j.: 2026/791 od 2026-07-01 — art. 38d, 38e).
**Akt:** UIA (ustawa o izbach aptekarskich) — t.j. Dz.U. 2025 poz. 1693.
**Akt:** UDL (ustawa o działalności leczniczej) — t.j. Dz.U. 2026 poz. 156 (zm. po t.j.: 2026/972 od 2026-08-05 — art. 27a).
**Akt:** UPP (ustawa o prawach pacjenta i Rzeczniku Praw Pacjenta) — t.j. Dz.U. 2024 poz. 581 (zm. po t.j.: 2026/791 od 2026-07-01 — art. 7, 10, 14, 26, 30a, 30b, 35; 2026/26 [OD 2027-01-01: 2026/26] — art. 28).
**Akt:** UWM (ustawa o wyrobach medycznych) — t.j. Dz.U. 2024 poz. 1620.
**Akt:** UPIS (ustawa o Państwowej Inspekcji Sanitarnej) — t.j. Dz.U. 2024 poz. 416 (zm. po t.j.: 2026/605 od 2026-05-21 — art. 2, 2b, 3, 4, 4c, 4d, 4e, 4g, 4j, 4k, 4m, 4n, 4p, 8, 11, 13, 13a, 13d, 13e, 20).
**Akt:** UZZw (ustawa o zdrowiu zwierząt) — akt pierwotny, bez t.j.: Dz.U. 2025 poz. 1795.
**Akt:** UPB (ustawa o produktach biobójczych) — t.j. Dz.U. 2021 poz. 24 (zm. po t.j.: 2025/1716 od 2026-02-06 — art. 3, 7, 8, 11, 12, 13, 17, 19, 20, 21, 23, 24, 26, 27, 28, 29, 30; 2025/1709 od 2026-03-06 — art. 6, 6a, 45, 45a).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

Status: moduł prawa polskiego klasy wzorcowej. **RZĄD 1 VER 2026-08-28:** Prawo farmaceutyczne — Dz.U. 2026 poz. 612 t.j.; Państwowa Inspekcja Sanitarna — **Dz.U. 2024 poz. 416 t.j. ze zm.** (ELI nadal wskazuje ten t.j.; po t.j. istnieje nowelizacja, dlatego przed cytatem używaj tekstu ujednoliconego).

## 1. Akty i źródła do weryfikacji
- Prawo farmaceutyczne
- ustawa o Państwowej Inspekcji Sanitarnej
- ustawy refundacyjne i medyczne
- KPA/PPSA

Nie cytuj literalnego brzmienia przepisu bez aktualnego sprawdzenia źródła. Przed użyciem artykułu ustal:

- akt i Dz.U.,
- status obowiązywania,
- wersję temporalną na dzień zdarzenia,
- wersję na dzień sporządzania pisma,
- przepisy przejściowe,
- właściwy organ i tryb zaskarżenia.

## 2. Zakres spraw
- GIF/WIF
- GIS/Sanepid
- zezwolenia apteczne
- kontrole sanitarne
- kary administracyjne
- reklama produktów
- odwołania

## 3. Intake
Ustal obowiązkowo:

1. kto jest stroną / uczestnikiem / funkcjonariuszem / organem,
2. jaki akt, czynność albo zaniechanie jest kwestionowane,
3. data czynności, doręczenia, powzięcia wiadomości i termin do reakcji,
4. organ pierwszej instancji i organ odwoławczy,
5. czy sprawa jest administracyjna, cywilna, karna, dyscyplinarna, służbowa albo mieszana,
6. czy istnieje dokument urzędowy: decyzja, postanowienie, zarządzenie, protokół, notatka, polecenie, uchwała,
7. czy zachodzi ryzyko prekluzji, przedawnienia, bezczynności albo bezskuteczności środka.

## 4. Mapa proceduralna
Stosuj ścieżkę:

`zdarzenie/czynność → kwalifikacja prawna → właściwość organu → środek zwykły → środek nadzwyczajny → kontrola sądowa → wykonanie rozstrzygnięcia → odpowiedzialność odszkodowawcza/dyscyplinarna`

W sprawach publicznoprawnych zawsze rozważ równolegle:

- środek w toku sprawy,
- skargę na bezczynność/przewlekłość,
- wniosek o wstrzymanie wykonania,
- zabezpieczenie dowodów,
- odpowiedzialność funkcjonariusza/organu,
- dostęp do akt i informacji publicznej,
- ochronę danych osobowych i informacji niejawnych.

## 5. Warunki skuteczności
Sprawdź:

- termin,
- właściwość organu/sądu,
- legitymację,
- interes prawny albo faktyczny,
- podpis,
- pełnomocnictwo,
- opłatę,
- odpisy,
- załączniki,
- dowód doręczenia,
- wskazanie żądania,
- wskazanie zarzutów,
- relację dowód → fakt → norma.

## 6. Matryca dowodowa
Dla każdego faktu zbuduj tabelę:

| Fakt | Dowód | Źródło | Siła | Luka | Ryzyko |
|---|---|---|---|---|---|

Typowe dowody:

- decyzje, postanowienia, protokoły, notatki, zarządzenia,
- korespondencja z organem,
- nagrania, zdjęcia, logi, metadane,
- zeznania świadków,
- dokumentacja medyczna/techniczna/księgowa,
- opinie biegłych,
- akty prawa miejscowego,
- wydruki z BIP, rejestrów, systemów publicznych.

## 7. Zarzuty typowe
Rozważ co najmniej:

- naruszenie właściwości,
- naruszenie prawa do udziału w sprawie,
- brak podstawy prawnej,
- błędna wykładnia przepisu,
- dowolna ocena dowodów,
- brak uzasadnienia,
- nieproporcjonalność,
- nierówne traktowanie,
- naruszenie zaufania do organu,
- naruszenie terminów,
- brak rozpoznania istoty sprawy,
- pominięcie dowodu,
- wadliwe pouczenie.

## 8. Kontrargumenty organu / strony przeciwnej
Przewiduj:

- formalny brak legitymacji,
- spóźnienie środka,
- brak interesu prawnego,
- domniemanie prawidłowości dokumentu urzędowego,
- uznaniowość organu,
- tajemnicę ustawowo chronioną,
- bezpieczeństwo publiczne,
- brak szkody albo związku przyczynowego,
- nieadekwatność środka.

## 9. Strategia
Priorytety:

1. zabezpiecz termin i dowód doręczenia,
2. uzyskaj akta i pełną podstawę rozstrzygnięcia,
3. oddziel zarzuty formalne od materialnych,
4. wskaż fakty decydujące, nie wszystkie fakty,
5. buduj żądanie główne i ewentualne,
6. przygotuj wariant: organ → sąd administracyjny/cywilny/karny/dyscyplinarny,
7. oceń, czy korzystniejsze jest uchylenie, zmiana, stwierdzenie nieważności, wznowienie, odszkodowanie lub skarga.

## 10. Orzecznictwo
Nie wpisuj fikcyjnych sygnatur. Szukaj tylko realnych orzeczeń w:

- SN / NSA / TK,
- CBOSA,
- Portalu Orzeczeń Sądów Powszechnych,
- orzeczeniach sądów dyscyplinarnych, jeżeli publicznie dostępne,
- LEX/Legalis pomocniczo.

Każde orzeczenie oceniaj według: aktualność, hierarchia sądu, analogiczność stanu faktycznego, linia dominująca/odmienna.

## 11. Ryzyka
Oceń:

- ryzyko zwrotu/odrzucenia,
- ryzyko spóźnienia,
- ryzyko braku legitymacji,
- ryzyko niewykazania faktu,
- ryzyko niedopuszczalności dowodu,
- ryzyko uznania organu,
- ryzyko kosztowe,
- ryzyko retorsji służbowej/dyscyplinarnej,
- ryzyko równoległych postępowań.

## 12. Quality gate
Przed odpowiedzią lub pismem zastosuj:

- `prawo-polskie-v2/krajowe/shared/POLISH-LAW-FINAL-COMPLETENESS-GATE.md`,
- `shared/ISAP-AUDIT-PROTOCOL.md`,
- `shared/TEMPORAL-LAW-CHECK.md`,
- `shared/LEGAL-QUALITY-GATE.md`,
- `shared/RISK-ASSESSMENT.md`, jeżeli istnieje,
- `prawo-polskie-v2/krajowe/shared/FORMAL-CHECK.md`, jeżeli powstaje pismo.

---

## SEKCJA GIS / PAŃSTWOWA INSPEKCJA SANITARNA — RZĄD 1

**Akt:** ustawa z 14.03.1985 r. o Państwowej Inspekcji Sanitarnej,
Dz.U. 2024 poz. 416 t.j. ze zm. — VER ELI 2026-08-28.

### Zadania i właściwość

- **art. 1-2:** PIS realizuje zadania zdrowia publicznego przez nadzór m.in.
  nad higieną środowiska i pracy, higieną nauczania, warunkami żywności,
  kosmetyków i podmiotów leczniczych; wykonuje nadzór zapobiegawczy,
  bieżący, przeciwepidemiczny i działalność oświatowo-zdrowotną.
- **art. 3-4:** zakres zapobiegawczego i bieżącego nadzoru obejmuje m.in.
  planowanie przestrzenne, obiekty budowlane, wodę, żywność, zakłady pracy,
  obiekty użyteczności publicznej, transport i warunki udzielania świadczeń.
- **art. 12:** co do zasady organem właściwym w KPA jest państwowy
  powiatowy albo graniczny inspektor sanitarny; organem wyższego stopnia
  wobec nich jest państwowy wojewódzki inspektor sanitarny, a wobec
  wojewódzkiego — **Główny Inspektor Sanitarny**. Art. 12 ust. 1a przewiduje
  kompetencje wojewódzkiego inspektora m.in. w higienie radiacyjnej i
  określonych sprawach inżynierii genetycznej.

### Kontrola i decyzje

- **art. 25:** inspektor/GIS ma w związku z kontrolą prawo wejścia m.in. do
  zakładów pracy, obiektów użyteczności publicznej, nieruchomości, środków
  transportu i obiektów w budowie; może żądać informacji i dokumentów,
  przesłuchiwać osoby oraz pobierać próbki.
- **art. 26:** wejście do mieszkania jest dopuszczalne tylko w ustawowo
  wskazanych sytuacjach; mieszkania osób objętych immunitetem dyplomatycznym
  wymagają porozumienia z właściwym przedstawicielem dyplomatycznym.
- **art. 27 ust. 1:** przy naruszeniu wymagań higienicznych/zdrowotnych
  inspektor nakazuje decyzją usunięcie uchybień w terminie.
- **art. 27 ust. 2:** przy bezpośrednim zagrożeniu życia lub zdrowia może
  nakazać m.in. unieruchomienie zakładu/części, zamknięcie obiektu,
  wyłączenie środka transportu albo wycofanie produktu z obrotu; przy
  konkretnej decyzji sprawdź aktualny pełny katalog i rygor wykonalności.
- **art. 28:** sprzeciw wobec uruchomienia obiektu / technologii może
  wstrzymać dalsze działania do rozstrzygnięcia przez organ wyższego stopnia.
- **art. 29:** zabezpieczenie pomieszczeń, urządzeń, produktów i substancji;
  w nieuregulowanym zakresie odwołanie do egzekucji administracyjnej.
- **art. 29a:** informacje objęte prawnie chronioną tajemnicą kontrolowanego
  podlegają ograniczeniom ujawnienia, z wyjątkami ustawowymi.
- **art. 30-31a:** zawiadomienia o istotnych uchybieniach, książka kontroli
  oraz kompetencje interwencyjne GIS — stosuj aktualny tekst ujednolicony.

⛔ **Rozgraniczenie:** „Sanepid” nie oznacza automatycznie GIS jako organu
I instancji. Najpierw ustal rzeczową i miejscową właściwość konkretnego
państwowego inspektora oraz przepis szczególny (żywność, choroby zakaźne,
chemikalia, kosmetyki, działalność lecznicza itd.).

---

## SEKCJA SCALONA: Prawo Farmaceutyczne — Framework GIF/WIF (kancelarski)

> Scalone z: mod-PrFarm-GIF-WIF-framework.md

## TERMINY — SPRAWDŹ JAKO PIERWSZE
```
Odwołanie od decyzji GIF / WIF:                    14 dni (art. 129 §2 KPA)
Skarga do WSA:                                     30 dni od decyzji II inst.
Cofnięcie zezwolenia na prowadzenie apteki:        postępowanie KPA — 14 dni na odwołanie
Sprzeciw WIF wobec uruchomienia apteki:            30 dni od zgłoszenia
Pozwolenie na dopuszczenie do obrotu (rejestracja): URPL — weryfikuj aktualny termin
Termin na uzupełnienie braków formalnych:          wyznaczony przez organ
Odpowiedzialność zawodowa farmaceuty:              brak terminu zawitego na skargę
```

## FAZA 0 — INTAKE
```
□ Kto jest stroną?
  → apteka / hurtownia / wytwórca / importer / podmiot odpowiedzialny
  → farmaceuta / technik farmaceutyczny (sprawa dyscyplinarna)
  → pacjent (prawa pacjenta w aptece)
□ Jaki problem?
  → cofnięcie / odmowa zezwolenia na aptekę ogólnodostępną / szpitalną
  → kara administracyjna (GIF / WIF)
  → naruszenia przepisów aptecznych (reklama / substancje psychoaktywne)
  → dopuszczenie produktu leczniczego do obrotu
  → kwestia refundacji / cenowa
  → sprawa dyscyplinarna farmaceuty
□ Jaka data decyzji / zdarzenia? (termin odwołania)
□ Czy sprawa dotyczy obrotu produktami z art. 37j–37n PF (hurtownie)?
```

## MAPA ORGANÓW I KOMPETENCJI
```
GIF (Główny Inspektor Farmaceutyczny):
  → Organ II inst. od decyzji WIF
  → Nadzór nad hurtowniami ogólnopolskimi i wytwórcami
  → Rejestr aptek szpitalnych / zakładowych
  → Postępowanie w sprawie wycofania produktu z obrotu

WIF (Wojewódzki Inspektor Farmaceutyczny):
  → Organ I inst. dla aptek ogólnodostępnych
  → Kontrola aptek (KPA — wszczyna z urzędu lub na wniosek)
  → Decyzje o cofnięciu / zawieszeniu zezwolenia

URPL (Urząd Rejestracji Produktów Leczniczych, Wyrobów Medycznych i Produktów Biobójczych):
  → Dopuszczenie produktów leczniczych do obrotu
  → Rejestracja / zmiana / odnowienie / cofnięcie pozwolenia

MZ (Ministerstwo Zdrowia):
  → Wykaz leków refundowanych (obwieszczenie co 3 miesiące — weryfikuj: gov.pl)
  → Decyzje refundacyjne i cenowe
  → Nadzór nad GIF i URPL

NIA (Naczelna Izba Aptekarska):
  → Odpowiedzialność zawodowa farmaceutów
  → Sąd Aptekarski: OIA (I inst.) → NIA (II inst.)
```

## APTEKA OGÓLNODOSTĘPNA — ZEZWOLENIA

### Warunki uzyskania (art. 99 PF)
```
□ Podmiot: wyłącznie farmaceuta (osoba fizyczna) lub spółka jawna/partnerska
  → Zakaz: sieci apteczne (>1% aptek w woj.), hurtownie, producenci, sklepy ogólne
  → "Apteka dla aptekarza": zasada z nowelizacji 2017 r. — weryfikuj aktualne wyjątki
□ Lokal: spełnia wymagania architektoniczne i sanitarne (rozporządzenie MZ)
□ Kierownik apteki (art. 88 ust. 2 PF): 5 lat stażu w aptece ogólnodostępnej albo specjalizacja + 2 lata stażu
□ Godziny otwarcia: min. 8h/dobę, w woj. i powiatach wg rozporządzenia
□ Przynależność do izby aptekarskiej
□ Brak przesłanek odmowy z art. 99 ust. 3 i 3a PF (niżej)

PRZESŁANKI ODMOWY I KRYTERIA (art. 99 PF — t.j. Dz.U. 2026 poz. 612):
  → ust. 3 pkt 1: hurtownia / pośrednictwo w obrocie lekami — odmowa
  → ust. 3 pkt 2–3: więcej niż 1% aptek ogólnodostępnych w województwie (sam, podmioty kontrolowane, grupa kapitałowa)
  → ust. 3a: wnioskodawca/wspólnik prowadzi (sam lub przez spółki/podmioty kontrolowane/grupę) co najmniej 4 apteki
  → ust. 3b: DEMOGRAFIA I ODLEGŁOŚĆ — co najmniej 3000 mieszkańców gminy na 1 aptekę ORAZ co najmniej 500 m
    (w linii prostej, między wejściami do izb ekspedycyjnych) od najbliższej apteki; liczba mieszkańców wg GUS (ust. 3c)
  → ust. 3d: wyłączenie ograniczeń z ust. 3b m.in. przy odległości co najmniej 1000 m (pkt 1) — pozostałe wyjątki odczytaj
  ✅ [VER: ELI DU/2026/612 art. 88, 99, RZĄD 1, 2026-11-14] (poprzednio błędnie: „art. 104”, „art. 99 ust. 3a pkt 3b”,
     „brak ustawowego kryterium odległości”)
```

### Cofnięcie zezwolenia (art. 103 PF)
```
OBLIGATORYJNE COFNIĘCIE gdy:
  → Apteka rażąco narusza przepisy PF (po wcześniejszym wezwaniu do usunięcia)
  → Przestała spełniać warunki wymagane przy udzieleniu zezwolenia
  → Farmaceuta-właściciel utracił prawo wykonywania zawodu

TRYB:
  Kontrola WIF → protokół → decyzja WIF
  ↓ [14 dni] odwołanie do GIF
  GIF → decyzja ostateczna
  ↓ [30 dni] skarga do WSA → NSA
```

## REKLAMA APTEK — STAN NA DZIEŃ WERYFIKACJI (22.05.2026)
```
OBECNY STAN: art. 94a PF (zakaz) NADAL OBOWIĄZUJE

WYROK TSUE C-200/2024 (19.06.2025):
  → TSUE uznał, że całkowity zakaz reklamy aptek narusza:
    - Dyrektywę 2000/31/WE (handel elektroniczny)
    - Swobodę przedsiębiorczości (art. 49 TFUE)
  → Polska ma obowiązek dostosowania prawa

PROJEKT NOWELIZACJI:
  → Planowane uchylenie art. 94a i zastąpienie ograniczonym systemem reklamy
    neutralnej / obiektywnej
  → Status: projekt rządowy; planowane przyjęcie przez RM III kw. 2026
  → ⚠️ Do czasu wejścia w życie — zakaz reklamy OBOWIĄZUJE
  → Weryfikuj: legislacja.rcl.gov.pl / gov.pl (projekt UDER114)

RYZYKO: postępowania GIF/WIF za naruszenie art. 94a PF mimo wyroku TSUE —
  rozważ powołanie się na wyrok TSUE i bezpośrednią skuteczność dyrektywy
  (weryfikuj aktualną linię NSA przed powołaniem: orzeczenia-sadowe-v2)
```

## REFUNDACJA I CENY

### Wykaz leków refundowanych
```
OBWIESZCZENIE MZ: aktualizacja co 3 miesiące (1 styczeń, kwiecień, lipiec, październik)
  → Weryfikuj aktualny wykaz: gov.pl/web/zdrowie → refundacja

DECYZJA REFUNDACYJNA:
  → Podmiot odpowiedzialny składa wniosek refundacyjny do MZ
  → Negocjacje z Komisją Ekonomiczną MZ
  → Decyzja MZ → odwołanie do MZ (III KPA) → skarga do WSA

CENY LEKÓW REFUNDOWANYCH:
  → Urzędowe ceny zbytu dla refundowanych — ustalane decyzją MZ
  → Marże hurtowe i apteczne: ustawowe, stałe
  → Apteka nie może udzielać rabatów na leki refundowane (naruszenie → kara WIF)
```

## PRODUKTY LECZNICZE — DOPUSZCZENIE DO OBROTU (URPL)
```
TRYBY:
  A. Procedura narodowa (art. 10–21 PF) — wyłącznie Polska
  B. Procedura zdecentralizowana (DCP) — kilka krajów UE jednocześnie
  C. Procedura wzajemnego uznania (MRP) — rozszerzenie istniejącego pozwolenia
  D. Procedura centralna (EMA) — pozwolenie EU-wide (lek innowacyjny, biologiczny)

POZWOLENIE NA PRODUKTY LECZNICZE: 5 lat → odnowienie (art. 28 PF)
(Zezwolenie na aptekę: bezterminowe — do cofnięcia przez organ; patrz art. 103 PF)
ZMIANA WARUNKÓW: CharPL, SPC — decyzja URPL; duże/małe zmiany (wg rozporządzeń)
COFNIĘCIE POZWOLENIA: gdy lek nieskuteczny, szkodliwy lub fałszywych danych

⚠️ Weryfikuj aktualne regulacje URPL: urpl.gov.pl — przepisy zmieniają się często
```

## ODPOWIEDZIALNOŚĆ ZAWODOWA FARMACEUTY
```
ORGANY:
  OIA (Okręgowa Izba Aptekarska) → Okręgowy Sąd Aptekarski (I inst.)
  NIA → Naczelny Sąd Aptekarski (II inst.)

KARY: upomnienie / nagana / zawieszenie prawa wykonywania (do 3 lat) / pozbawienie

PODSTAWY:
  → Naruszenie zasad etyki farmaceutycznej
  → Naruszenie przepisów o wykonywaniu zawodu
  → Rażące błędy zawodowe

TRYB: skarga do OIA → postępowanie wyjaśniające → rozprawa → orzeczenie
  Niezależne od postępowania karnego (możliwe równoległe)
```

## PREDYKCJA WYNIKU — SZABLON
```
Szanse: [0–100%]
IN PLUS: uchybienie proceduralne WIF, brak spełnienia przesłanek cofnięcia (art. 103),
         upływ terminu na wydanie decyzji (bezczynność), kryterium demograficzne
         niezastosowane prawidłowo, wyrok TSUE jako argument przy reklamie
IN MINUS: udokumentowane naruszenie art. 94a / warunków PF, utrata prawa wyk. zawodu,
          wielokrotne wezwania do usunięcia naruszeń zignorowane

BENCHMARKING:
  → Wywołaj orzeczenia-sadowe-v2 z frazą:
    "apteka cofnięcie zezwolenia WIF GIF NSA WSA"
    "art. 99 PF kryterium demograficzne"
  → Portal NSA: nsa.gov.pl | TSUE: curia.europa.eu
  ⚠️ NIEZWERYFIKOWANE — wyszukaj URL przed powołaniem

REKOMENDACJA: □ Odwołanie do GIF  □ Skarga do WSA  □ Wniosek o wstrzymanie decyzji
              □ Argumentacja z wyroku TSUE  □ Skarga do sądu aptekarskiego
```

## ŁĄCZ Z
| Sytuacja | Skill |
|---|---|
| Odwołanie od decyzji WIF/GIF | `dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-KPA-postepowanie-administracyjne.md` + `pisma-procesowe-v3` |
| Skarga do WSA | `pisma-procesowe-v3` + `kpa-admin.md` |
| Błąd medyczny / prawa pacjenta | `dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-prawa-pacjenta-framework.md` + `dr-10-zdrowie-farmacja-zywnosc-rolnictwo/modules/mod-ustawa-medyczne-szczegolowy.md` |
| Naruszenie przepisów — odpow. karna | `dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-KPK-framework-karne.md` + `dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-kwalifikator-karnomaterialny.md` |
| Umowa z hurtownią / dystrybucja | `analizator-umow-v1` |
| Analiza szans odwołania | `analiza-sadowa-v6` |
| Orzecznictwo NSA / WSA / TSUE | `orzeczenia-sadowe-v2` |

*PF: Dz.U. 2026 poz. 612 t.j. (obwieszczenie 17.04.2026) + nowelizacje Dz.U. 2025 poz. 924, 1416, 1537*
✅ FAZA 3E ZAMKNIĘTA 2026-08-21 (F-45): numer t.j. i lista nowelizacji
POTWIERDZONE jako aktualne i kompletne — zweryfikowane bezpośrednim
cytatem obwieszczenia (api.sejm.gov.pl/eli, Rząd 1) + infor.pl, oia.koszalin.pl:
oficjalny footnote obwieszczenia z 17.04.2026 wymienia dokładnie te same
4 nowelizacje (poz. 905, 924, 1416, [świadczenia] 1537) plus poz. 1795
(ustawa o zdrowiu zwierząt — poza zakresem treści tego modułu, dotyczy
weterynarii). Brak rozbieżności, treść modułu aktualna.
*URPL: urpl.gov.pl | GIF: gif.gov.pl | NIA: nia.org.pl*
*Projekt UDER114: legislacja.rcl.gov.pl | TSUE C-200/2024: curia.europa.eu*
*Weryfikacja: 22.05.2026 — zakaz cytowania przepisów z pamięci*