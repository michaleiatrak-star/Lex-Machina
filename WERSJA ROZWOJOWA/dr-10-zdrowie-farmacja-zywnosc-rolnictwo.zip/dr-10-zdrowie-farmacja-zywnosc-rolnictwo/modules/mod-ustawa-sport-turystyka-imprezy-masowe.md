---
name: mod-AQ-sport-turystyka-imprezy

**Standard jakości:** stosuj `prawo-polskie-v2/krajowe/shared/MODULE-STANDARD-POLISH-LAW.md` oraz `prawo-polskie-v2/krajowe/shared/POLISH-LAW-COMPLETENESS-MATRIX.md`.
description: |
  Moduł sportu, turystyki i imprez masowych. Stosuj przy organizatorach turystyki,
  reklamacjach turystycznych, odpowiedzialności biur podróży, imprezach masowych,
  klubach sportowych, licencjach, bezpieczeństwie imprez.
compatibility:
  tools: [web_search, web_fetch]
---

# mod-AQ — Turystyka / Sport / Imprezy Masowe

**Akt:** UPIS (ustawa o Państwowej Inspekcji Sanitarnej) — t.j. Dz.U. 2024 poz. 416 (zm. po t.j.: 2026/605 od 2026-05-21 — art. 2, 2b, 3, 4, 4c, 4d, 4e, 4g, 4j, 4k, 4m, 4n, 4p, 8, 11, 13, 13a, 13d, 13e, 20).
**Akt:** USport (ustawa o sporcie) — t.j. Dz.U. 2026 poz. 95 (zm. po t.j.: 2026/615 od 2026-05-22 — art. 7, 9, 11, 12, 29, 31, 32, 32a, 32b, 38, 38a).
**Akt:** UBIM (ustawa o bezpieczeństwie imprez masowych) — t.j. Dz.U. 2023 poz. 616 (zm. po t.j.: 2026/875 [OD 2027-01-01: 2026/875] — art. 25, 25a, 26, 29, 29a, 31, 32, 58).
**Akt:** UIT (ustawa o imprezach turystycznych i powiązanych usługach turystycznych) — t.j. Dz.U. 2026 poz. 925 (zm. po t.j.: 2026/1006 od 2026-08-11 — art. 47, 47a, 47b).
**Akt:** KC (Kodeks cywilny) — t.j. Dz.U. 2026 poz. 795.
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

## AKTY PRAWNE

| Akt | Zakres |
|---|---|
| Ustawa o imprezach turystycznych | biura podróży, reklamacje, TFG |
| Ustawa o bezpieczeństwie imprez masowych | zezwolenia, organizator, policja/PSP |
| Ustawa o sporcie | kluby, związki, licencje |
| KC | odpowiedzialność odszkodowawcza |

## IMPREZA TURYSTYCZNA — ANALIZA

Sprawdź: umowę, program, zmianę świadczeń, reklamację, termin, dowody zdjęciowe, tabelę frankfurcką jako pomocniczą praktykę, nie jako źródło prawa.

## IMPREZA MASOWA — CHECKLISTA

- kwalifikacja imprezy,
- zezwolenie,
- opinie policji/PSP/sanepidu,
- regulamin,
- zabezpieczenie medyczne,
- odpowiedzialność organizatora.

---

# STANDARDOWE UZUPEŁNIENIE MODUŁU — poziom prawa pracy / prawa karnego

> Ten blok jest częścią obowiązkową modułu. Ma pierwszeństwo przed opisowym użyciem modułu. Nie zastępuje kontroli ISAP; wymusza praktyczny workflow kancelaryjny.

## 1. Intake szczególny

Przed odpowiedzią ustal co najmniej:
- organizator;
- uczestnik/konsument;
- umowa/regulamin;
- zdarzenie/szkoda;
- organ/związek;
- ubezpieczenie;

## 2. Mapa proceduralna

```text
Identyfikacja trybu i organu/sądu
  ↓
Kontrola terminu, doręczenia, właściwości i legitymacji
  ↓
Ustalenie faktów materialnych i proceduralnych
  ↓
Matryca dowodowa: fakt → dowód → ciężar dowodu → luka
  ↓
Dobór pisma/środka: wniosek / odwołanie / zażalenie / skarga / pozew / zawiadomienie
  ↓
Walidacja formalna: prawo-polskie-v2/krajowe/shared/FORMAL-CHECK.md + shared/WARUNKI-SKUTECZNOSCI.md
  ↓
Ocena ryzyka: shared/RISK-ASSESSMENT.md + shared/QUALITY-CHECK.md
  ↓
Strategia: minimum, optimum, wariant eskalacyjny
```

## 3. Warunki skuteczności

```text
□ prawidłowy tryb
□ właściwy organ albo sąd
□ termin liczony od prawidłowego zdarzenia
□ legitymacja strony
□ żądanie możliwe prawnie
□ fakty powiązane z podstawą prawną
□ dowody przypisane do każdej tezy
□ kontrola opłat, odpisów, pełnomocnictw i podpisu
□ kontrola ISAP na dzień sporządzenia pisma
□ kontrola stanu prawnego na dzień zdarzenia oraz na dzień orzekania
```

## 4. Matryca dowodowa

Dowody typowe dla tego modułu:
- regulaminy;
- umowy;
- bilety;
- protokoły zdarzeń;
- polisy;
- korespondencja reklamacyjna;

Każdy dowód oceniaj według schematu:

```text
Dowód → fakt, który ma wykazać → bezpośredni/pośredni → wiarygodność → ryzyko podważenia → brakujący dowód wzmacniający
```

## 5. Typowe zarzuty i kontrzarzuty

W każdej sprawie przygotuj dwie wersje:

1. argumentację strony inicjującej sprawę,
2. argumentację organu/przeciwnika procesowego.

Typowe ryzyka i kontrargumenty:
- krótkie terminy reklamacyjne;
- wyłączenia odpowiedzialności;
- brak protokołu szkody;
- jurysdykcja regulaminowa;

## 6. Strategia procesowa

Zastosuj trzy warianty:

### Wariant ostrożny
Minimalizuje ryzyko formalne. Priorytet: termin, kompletność, zabezpieczenie dowodów.

### Wariant ofensywny
Eksponuje naruszenia proceduralne, wadliwość ustaleń, niewłaściwą wykładnię, naruszenie zasady proporcjonalności albo praw strony.

### Wariant eskalacyjny
Zakłada przejście do organu II instancji, WSA/NSA, sądu powszechnego, SN, TSUE, ETPC albo organu sektorowego — tylko gdy wynika to z trybu.

## 7. Quality gate

Przed końcową odpowiedzią sprawdź:

```text
□ Czy moduł działa praktycznie, a nie opisowo?
□ Czy wskazano decydujący element prawny?
□ Czy oddzielono fakty od interpretacji?
□ Czy podano ryzyka przeciwnika/organu?
□ Czy wskazano słabe punkty klienta?
□ Czy każdy przepis i Dz.U. ma kontrolę ISAP albo oznaczenie braku weryfikacji?
□ Czy użyto prawo-polskie-v2/krajowe/shared/MODULE-STANDARD-POLISH-LAW.md?
```

## 8. Łącz obowiązkowo z

| Potrzeba | Moduł współdzielony / skill |
|---|---|
| aktualność prawa | `shared/ISAP-AUDIT-PROTOCOL.md` + `prawo-polskie-v2/krajowe/shared/ISAP-METRYKI-AKTOW.md` |
| stan prawny w czasie | `shared/TEMPORAL-LAW-CHECK.md` |
| braki formalne | `prawo-polskie-v2/krajowe/shared/BRAKI-FORMALNE.md` |
| warunki skuteczności | `shared/WARUNKI-SKUTECZNOSCI.md` |
| dowody | `shared/DOWODY-METODOLOGIA.md` + `analizator-dowodow-v3` |
| ryzyka | `shared/RISK-ASSESSMENT.md` |
| pisma | `pisma-procesowe-v3` albo `pisma-proste-v2` |
| analiza sądowa | `analiza-sadowa-v6` |
