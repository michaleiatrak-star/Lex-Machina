# Prawo Medyczne — Szczegółowy Framework

**Akt:** UDL (ustawa o działalności leczniczej) — t.j. Dz.U. 2026 poz. 156 (zm. po t.j.: 2026/972 od 2026-08-05 — art. 27a).
**Akt:** UPP (ustawa o prawach pacjenta i Rzeczniku Praw Pacjenta) — t.j. Dz.U. 2024 poz. 581 (zm. po t.j.: 2026/791 od 2026-07-01 — art. 7, 10, 14, 26, 30a, 30b, 35; 2026/26 [OD 2027-01-01: 2026/26] — art. 28).
**Akt:** USOZ (ustawa o świadczeniach opieki zdrowotnej finansowanych ze środków publicznych) — t.j. Dz.U. 2025 poz. 1461 (zm. po t.j.: 2025/1537 od 2026-01-01 — art. 2, 4, 7, 7a, 19a, 20, 22, 23, 23b, 23c, 23e, 23h, 30, 31d, 40, 42d, 42f, 42i, 42j, 47c; 2025/1739 od 2026-01-01 — art. 97, 116, 132c, 132d; 2026/203 od 2026-03-05 — art. 12, 50, 87; 2026/791 od 2026-07-01 — art. 49, 50, 51, 188e, 240; 2026/972 od 2026-08-05 — art. 31lc, 31n, 31o; 2026/986 od 2026-08-07 — art. 42b, 159a, 189a, 189b; 2026/1007 od 2026-08-11 — art. 23e, 97, 102; 2026/26 [OD 2027-01-01: 2026/26] — art. 87a).
**Akt:** UZL (ustawa o zawodach lekarza i lekarza dentysty) — t.j. Dz.U. 2026 poz. 37 (zm. po t.j.: 2026/203 od 2026-03-05 — art. 7; 2026/791 od 2026-07-01 — art. 3, 15b, 15d, 15f, 15g, 15h, 41a).
**Akt:** UIL (ustawa o izbach lekarskich) — t.j. Dz.U. 2021 poz. 1342 (zm. po t.j.: 2023/1234 od 2023-07-14 — art. 49).
**Akt:** KC (Kodeks cywilny) — t.j. Dz.U. 2026 poz. 795.
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

## TERMINY — SPRAWDŹ JAKO PIERWSZE
```
Przedawnienie roszczenia o błąd medyczny (art. 442¹ KC) — ✅ [VER] RZĄD 1 2026-09-16f (KC `Dz.U. 2026 poz. 795`):
  → 3 lata od dowiedzenia się (albo możliwości dowiedzenia się) o szkodzie i osobie
    zobowiązanej (§ 1 zd. 1)
  → ⛔ SZKODA NA OSOBIE (§ 3): przedawnienie nie może skończyć się wcześniej niż
    3 lata od dowiedzenia się — granica 10 lat z § 1 zd. 2 NIE OBOWIĄZUJE
    (błąd medyczny to z reguły szkoda na osobie — nie odrzucaj sprawy za „ponad 10 lat")
  → 20 lat od popełnienia przestępstwa, gdy szkoda wynikła ze zbrodni lub występku (§ 2)
  → Małoletni — szkoda na osobie: nie wcześniej niż 2 LATA od pełnoletności (§ 4)
  (⛔ poprzednio: „max 20 lat dla szkód na osobie — § 3" i „małoletni: 3 lata" — błędne)
Wniosek do FKZM (Fundusz Kompensacyjny Zdarzeń Medycznych) — art. 67t ust. 3 u.p.p.
(t.j. `Dz.U. 2024 poz. 581`, ✅ RZĄD 1 2026-09-16f; poprzednio błędnie „ust. 8"):
  → rok od dowiedzenia się o zakażeniu, uszkodzeniu ciała, rozstroju zdrowia albo śmierci
  → nie dłużej niż 3 lata od zdarzenia; opłata od wniosku — art. 67t ust. 4–6 (waloryzowana)
Odwołanie od decyzji NFZ (odmowa świadczenia):
  → 14 dni (KPA) lub 30 dni (PPSA) — zależnie od trybu
Skarga do RPP:                   brak terminu zawitego
Skarga do sądu lekarskiego:      brak terminu zawitego (ale wpływa na dowody)
```

## FAZA 0 — INTAKE
```
□ Co konkretnie nastąpiło?
  → błąd diagnostyczny / terapeutyczny / operacyjny / pielęgnacyjny / anestezjologiczny
  → zakażenie szpitalne / upadek / pominięcie leku / złe dawkowanie
  → brak zgody na zabieg / naruszenie praw pacjenta
  → odmowa leczenia / odmowa wydania dokumentacji
□ Gdzie nastąpiło zdarzenie?
  → szpital publiczny (NFZ) / prywatna klinika / NZOZ / lekarz indywidualnie
□ Kiedy nastąpiło zdarzenie? (ocena terminów)
□ Jaka jest dokumentacja medyczna?
  → historia choroby / wyniki badań / epikryzy / karty zleceń
□ Jaka jest szkoda?
  → trwały uszczerbek na zdrowiu / śmierć / dodatkowe leczenie / ból i cierpienie
□ Jaki efekt oczekuje klient?
  → odszkodowanie / zadośćuczynienie / stwierdzenie błędu / skargi na lekarza
□ Czy złożono już jakiekolwiek pisma lub skargi?
```

## ŚCIEŻKI DOCHODZENIA ROSZCZEŃ

### A. FUNDUSZ KOMPENSACYJNY ZDARZEŃ MEDYCZNYCH (FKZM)
```
ZAKRES: Zdarzenia medyczne w szpitalach (hospitalizations) od 06.09.2023
  → Zakażenie pacjenta biologicznym czynnikiem chorobotwórczym
  → Uszkodzenie ciała lub rozstrój zdrowia pacjenta
  → Śmierć pacjenta — roszczenia bliskich

PROGI KWOTOWE — ✅ ZAKTUALIZOWANE 2026-07-30 (FAZA 3E/ZASADA 14):
  poprzednie kwoty (200 000/100 000 zł) to BAZOWE wartości SPRZED
  waloryzacji — AKTUALNE, obowiązujące od 06.09.2025 (potwierdzone
  niezależnie w mod-ustawa-prawa-pacjenta-framework.md, transza
  27z105 tej sesji, zgodność potwierdzona):
  → Uszkodzenie ciała / rozstrój zdrowia: do **230 821 zł**
  → Śmierć: do **115 411 zł** (na rzecz każdego uprawnionego)
  ⚠️ Kolejna coroczna waloryzacja: 06.09.2026 — sprawdź nową kwotę,
  jeśli data użycia przypada PO tym dniu

PROCEDURA:
  Wniosek do Prezesa RPP → Komisja RPP (90 dni) → propozycja świadczenia
  → AKCEPTACJA: wypłata (zrzeczenie się dalszych roszczeń!)
  → ODMOWA lub ODRZUCENIE: wniosek o ponowne rozpatrzenie (30 dni) → WSA

⚠️ PRZYJĘCIE ŚWIADCZENIA Z FKZM = ZAMKNIĘCIE ŚCIEŻKI SĄDOWEJ
  Rozważ dokładnie przed akceptacją — nie łącz z pozwem cywilnym
```

### B. POZEW CYWILNY
```
PODSTAWY PRAWNE:
  → Art. 415 KC (czyn niedozwolony — odpow. lekarza/personelu)
  → Art. 430 KC (odpow. szpitala za pracownika — zwierzchnik)
  → Art. 444 KC (odszkodowanie za szkodę na osobie)
  → Art. 445 KC (zadośćuczynienie za doznaną krzywdę)
  → Art. 446 KC (roszczenia po śmierci pacjenta — bliscy)
  → Art. 471 KC (nienależyte wykonanie umowy — odpow. kontraktowa)

CIĘŻAR DOWODU:
  → Poszkodowany: szkoda + zdarzenie + związek przyczynowy
  → Domniemanie winy w organizacji (szpital): można zastosować w pewnych przypadkach
  → KLUCZOWY DOWÓD: opinia biegłego sądowego (obligatoryjny w sprawach med.)

SĄD WŁAŚCIWY:
  → SR: do 100 000 zł (próg od 01.07.2023 na mocy ustawy z 9.03.2023, Dz.U. 2023 poz. 614, art. 1 pkt 1 — KPC art. 17 pkt 4; ELI 2026-10-09)
     → SO: powyżej 100 000 zł — weryfikuj aktualnie art. 17 KPC
  → SO: powyżej + sprawy o zadośćuczynienie dot. naruszenia dóbr osobistych
  → Właściwość: siedziba pozwanego LUB miejsce zdarzenia (wybór powoda)
```

### C. SKARGA DO RZECZNIKA PRAW PACJENTA (RPP)
```
ZAKRES RPP:
  → Naruszenie prawa do świadczeń zdrowotnych
  → Naruszenie prawa do informacji (art. 9 u.p.p.)
  → Naruszenie prawa do dokumentacji medycznej (art. 23 u.p.p.)
  → Naruszenie prawa do poszanowania intymności i godności
  → Naruszenie tajemnicy lekarskiej

PROCEDURA: bezpłatna; pisemna skarga → RPP bada → wystąpienie do kierownika placówki
  → RPP może wydać stanowisko; nie przyznaje odszkodowania
  → Kara finansowa (art. 108 u.p.p.) do 500 000 zł dla placówki przy ciężkim naruszeniu
```

### D. SĄD LEKARSKI (odpowiedzialność zawodowa)
```
IZBY LEKARSKIE: Okręgowy Sąd Lekarski → Naczelny Sąd Lekarski
KARY: upomnienie / nagana / zawieszenie prawa wykonywania zawodu / pozbawienie
PODSTAWA: naruszenie zasad etyki lekarskiej lub przepisów o wykonywaniu zawodu
NIE: nie przyznaje odszkodowania; niezależne od postępowania cywilnego/karnego
```

> Ustawa o działalności leczniczej — t.j. `Dz.U. 2026 poz. 156` (✅ [VER] RZĄD 1 2026-09-16, status obowiązujący; F-190).

## PRAWA PACJENTA — KATALOG (u.p.p. Dz.U. 2024 poz. 581 t.j.)
| Prawo | Podstawa | Jak egzekwować |
|---|---|---|
| Do świadczeń zdrowotnych | art. 6–8 u.p.p. | NFZ / RPP / skarga do NFZ |
| Do informacji o stanie zdrowia | art. 9 u.p.p. | Żądanie pisemne; jeśli odmowa → RPP |
| Do dokumentacji medycznej | art. 23–29 u.p.p. | 7 dni na wydanie kopii; brak → RPP |
| Do tajemnicy lekarskiej | art. 13 u.p.p. | Skarga do RPP / sąd cywilny |
| Do poszanowania godności i intymności | art. 20 u.p.p. | Skarga do RPP |
| Do wyrażenia zgody na zabieg | art. 15–19 u.p.p. | Brak zgody = bezprawność zabiegu |
| Do leczenia bólu | art. 20a u.p.p. | Odmowa → skarga RPP |

## UZYSKANIE DOKUMENTACJI MEDYCZNEJ
```
PRAWO DO KOPII (art. 27 u.p.p.):
  → Szpital/klinika: obowiązek wydania w ciągu 7 dni od wniosku
  → Forma: kopia papierowa (opłata do 0,002% MWPS) / elektroniczna (bezpłatna)
  → Odmowa lub opóźnienie → skarga do RPP

PRAWO DO WGLĄDU (art. 23 u.p.p.):
  → Na miejscu, bez kopiowania — obowiązek niezwłoczny
  → Reprezentacja przez pełnomocnika (pisemne pełnomocnictwo)
```

## OPINIA BIEGŁEGO — STRATEGIA
```
BIEGŁY SĄDOWY (art. 278–291 KPC):
  → Obowiązkowy w sprawach błędów medycznych
  → Sąd powołuje — ale strona może wnosić o konkretnego eksperta
  → Biegły z listy: sądy okręgowe (biegły-lekarz.pl — nieoficjalne, weryfikuj)

PRYWATNA OPINIA MEDYCZNA:
  → Dokument prywatny (art. 245 KPC) — nie zastępuje biegłego sądowego
  → Wartość: jako podstawa oceny szans przed złożeniem pozwu
  → Koszt: 2 000–10 000 zł zależnie od specjalizacji

INSTYTUT EKSPERTYZ SĄDOWYCH (Kraków):
  → Opinie na zlecenie sądu i stron — wyspecjalizowany
```

## PREDYKCJA WYNIKU — SZABLON
```
Szanse: [0–100%]
IN PLUS: udokumentowana przyczyna szkody w dokumentacji (adnotacje operacyjne),
         pozytywna opinia prywatna, zakażenie szpitalne (domniemanie winy placówki),
         brak zgody na zabieg (bezprawność → odpow. niezależna od błędu),
         trwały uszczerbek > 20%, śmierć pacjenta
IN MINUS: wieloczynnikowa etiologia (trudny związek przyczynowy), brak dokumentacji
          operacyjnej, upływ 3 lat od dowiedzenia się o szkodzie, sprzeczne opinie

BENCHMARKING:
  → Wywołaj orzeczenia-sadowe-v2 z frazą:
    "błąd medyczny art. 445 KC zadośćuczynienie SN"
    "zgoda na zabieg art. 19 ustawa o prawach pacjenta SN"
  ⚠️ NIEZWERYFIKOWANE — wyszukaj URL: sn.pl / orzeczenia.ms.gov.pl

REKOMENDACJA: □ FKZM (do 200 000 zł, szybciej)  □ Pozew cywilny (bez limitu)
              □ Oba — UWAGA: FKZM zamyka ścieżkę sądową
```

## ŁĄCZ Z
| Sytuacja | Skill |
|---|---|
| Pozew o odszkodowanie / zadośćuczynienie | `pisma-procesowe-v3` |
| Wezwanie przedsądowe do szpitala | `pisma-proste-v2` |
| Wniosek o dokumentację medyczną | `pisma-proste-v2` |
| Analiza szans — błąd medyczny | `analiza-sadowa-v6` |
| Analiza umowy z kliniką / OWU ubezpieczyciela | `analizator-umow-v1` |
| Orzecznictwo SN / SA (błędy medyczne) | `orzeczenia-sadowe-v2` |
| Odmowa świadczenia przez NFZ | `dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-KPA-postepowanie-administracyjne.md` |
| Śmierć pacjenta — roszczenia rodziny | `dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KC-cywilne-zobowiazania-odpowiedzialnosc.md` (art. 446 KC) |

*Ustawa o pr. pacjenta (u.p.p.): Dz.U. 2024 poz. 581 t.j. | KC: Dz.U. 2026 poz. 795 t.j.*
*KOZM ZLIKWIDOWANE 01.07.2024 | FKZM działa od 06.09.2023*
*Kwoty FKZM: coroczna waloryzacja — weryfikuj aktualną wysokość: gov.pl/web/rpp*
*Ustawa o zawodzie lekarza: weryfikuj aktualny t.j. w ELI (RZĄD 1)*
*Weryfikacja: 22.05.2026 — zakaz cytowania przepisów z pamięci*
