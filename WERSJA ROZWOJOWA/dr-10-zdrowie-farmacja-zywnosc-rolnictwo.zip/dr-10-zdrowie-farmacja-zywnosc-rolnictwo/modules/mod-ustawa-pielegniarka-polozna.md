# Modul - Zawody pielegniarki i poloznej

**Akt:** UDL (ustawa o działalności leczniczej) — t.j. Dz.U. 2026 poz. 15 (zm. po t.j.: 2026/203 od 2026-03-05 — art. 35a; 2026/26 od 2026-04-13 — art. 4; 2026/986 od 2026-08-07 — art. 5a; 2026/1123 [OD 2027-01-01: 2026/1123] — art. 4, 5).
**Akt:** UZPP (ustawa o zawodach pielęgniarki i położnej) — t.j. Dz.U. 2026 poz. 15.
**Akt:** USPP (ustawa o samorządzie pielęgniarek i położnych) — t.j. Dz.U. 2025 poz. 1760.
**Akt:** o działalności leczniczej — t.j. Dz.U. 2026 poz. 156 (zm. po t.j.: 2026/972 od 2026-08-05 — art. 27a).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

## Akt prawny
**Ustawa z 15.07.2011 r. o zawodach pielegniarki i poloznej**
- Tekst jednolity: **Dz.U. 2026 poz. 15** (obwieszczenie z 4.12.2025 r.)
  ✅ VER: ELI/ISAP WDU20260000015 [2026-08-25]
- Poprzednie t.j.: Dz.U. 2025 poz. 450 i Dz.U. 2024 poz. 814

**Weryfikacja w ELI (RZĄD 1) przed kazdy cytowaniem.**

## Zakres
Warunki i zasady wykonywania zawodow pielegniarki i poloznej.
Prawa i obowiazki, ksztalcenie (studia I i II stopnia), odpowiedzialnosc.

## Prawo wykonywania zawodu (PWZ)
```
Pielegniarnia: Tytu mag. pielegniarstwa lub lic. (przejsciowo) + IPPWZ (egzamin)
Polozna:       Tytu mag. poloznictwa
Organ:         Okregowa Izba Pielegniarek i Poloznych (OIPiP)
Przerwa w zawodzie: Max 5 lat w 6 ostatnich - po powrocie kurs doskonalacy
```

## Uprawnienia pielegniarki i poloznej
```
Wystawianie recept:  Tak, w zakresie swojej dziedziny (art. 15a) - np. cewniki, leki
Zlecenia:           Moze realizowac zlecenia lekarskie + samodzielne dzialania (art. 6)
Polozna:            Prowadzenie porodow fizjologicznych samodzielnie
```

## Odpowiedzialnosc dyscyplinarna

✅ UZUPEŁNIONE 2026-08-13 (F-53) — podstawa prawna dotąd nieprzywołana:
odpowiedzialność zawodowa (dyscyplinarna) pielęgniarek/położnych wynika
z ODRĘBNEJ ustawy, nie z ustawy o zawodach powyżej:

**Ustawa z 1.07.2011 r. o samorządzie pielęgniarek i położnych**
Tekst jednolity: **Dz.U. 2025 poz. 1760** (obwieszczenie 24.11.2025)
Rozdział 6 „Odpowiedzialność zawodowa" — ⚠️ zweryfikuj dokładny zakres
numerów artykułów w ISAP przed cytowaniem w piśmie.

```
Organ I inst.:  Okręgowy Sąd Pielęgniarek i Położnych (przy okręgowej
                izbie właściwej dla członkostwa obwinionej osoby)
Organ II inst.: Naczelny Sąd Pielęgniarek i Położnych (NSPiP)
Dalej:          kasacja do Sądu Najwyższego
Kary:           upomnienie, nagana, zawieszenie PWZ (max 5 lat),
                pozbawienie prawa wykonywania zawodu
Postępowanie:   wszczyna Rzecznik Odpowiedzialności Zawodowej (analogia
                do prokuratora) na wniosek/z urzędu; świadek/biegły
                zamieszkały poza obszarem działania organu prowadzącego
                może być przesłuchany przez sąd właściwy dla miejsca
                zamieszkania (odpowiednie stosowanie KPK)
```

⚠️ POZOSTAJE DO POGŁĘBIENIA: dokładne numery artykułów Rozdziału 6
(zakres art. wg gofin.pl: Rozdział 6 następuje po Rozdziale 5 "Organy
okręgowej izby", art. 27-35) — nie zweryfikowane wprost w tej sesji,
sprawdź przed powołaniem konkretnego przepisu w piśmie.

## Weryfikacja online
```
**Dz.U. 2026 poz. 15 t.j.** ✅ [VER] RZĄD 1 2026-09-10o — ustawa o zawodach pielęgniarki i położnej, ⛔ KROK 2C: 3 nowelizacje po nim (Dz.U. 2026 poz. 26, 203, 986).
⛔ **BŁĄD SKORYGOWANY:** wiersz kierował do `Dz.U. 2025 poz. 450`, a to tekst jednolity **ustawy o działalności leczniczej** — inny akt (klasa F-149/3)
```
