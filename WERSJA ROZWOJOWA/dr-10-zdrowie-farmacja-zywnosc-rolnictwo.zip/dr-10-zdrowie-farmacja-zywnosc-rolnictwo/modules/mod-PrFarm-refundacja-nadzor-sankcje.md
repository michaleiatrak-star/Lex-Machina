# mod-PrFarm-refundacja-nadzor-sankcje

**Akt:** PrFarm (Prawo farmaceutyczne) — t.j. Dz.U. 2026 poz. 612 (zm. po t.j.: 2026/1004 od 2026-08-27 — art. 72; 2026/1079 od 2026-09-10 — art. 37av, 37ava, 42, 70, 96, 103).
**Akt:** URef (ustawa o refundacji leków, środków spożywczych specjalnego przeznaczenia żywieniowego oraz wyrobów medycznych) — t.j. Dz.U. 2026 poz. 253.
**Akt:** UPP (ustawa o prawach pacjenta i Rzeczniku Praw Pacjenta) — t.j. Dz.U. 2024 poz. 581 (zm. po t.j.: 2026/26 [OD 2027-01-01: 2026/26] — art. 28).
**Akt:** USOZ (ustawa o świadczeniach opieki zdrowotnej finansowanych ze środków publicznych) — t.j. Dz.U. 2025 poz. 1461 (zm. po t.j.: 2025/1537 od 2026-01-01 — art. 2, 4, 7, 7a, 19a, 20, 22, 23, 23b, 23c, 23e, 23h, 30, 31d, 40, 42d, 42f, 42i, 42j, 47c; 2025/1739 od 2026-01-01 — art. 97, 116, 132c, 132d; 2026/203 od 2026-03-05 — art. 12, 50, 87; 2026/972 od 2026-08-05 — art. 31lc, 31n, 31o; 2026/986 od 2026-08-07 — art. 42b, 159a, 189a, 189b; 2026/1007 od 2026-08-11 — art. 23e, 97, 102; 2026/26 [OD 2027-01-01: 2026/26] — art. 87a).
**Akt:** UWM (ustawa o wyrobach medycznych) — t.j. Dz.U. 2024 poz. 1620.
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

**Status:** moduł uzupełniający do `mod-PrFarm-szczegolowy.md`
**Wydzielony:** 2026-06-14 (audyt — moduł nadrzędny >400 linii, podział tematyczny)

> **Zasada absolutna:** Każdy artykuł weryfikować w isap.sejm.gov.pl.
> Prawo farmaceutyczne zmieniane jest kilka razy rocznie — NIGDY nie cytuj z pamięci.
> Aktualne t.j. ✅ [VER] RZĄD 1 2026-09-10h (`api.sejm.gov.pl/eli`):
> Prawo farmaceutyczne **Dz.U. 2026 poz. 612** — ⛔ KROK 2C: trzy nowelizacje po
> tekście jednolitym (Dz.U. 2026 poz. 791, 1004, 1079);
> Ustawa refundacyjna **Dz.U. 2026 poz. 253** — ⛔ KROK 2C: jedna nowelizacja po
> tekście jednolitym (Dz.U. 2026 poz. 791, ustawa z 15.05.2026 o rozwoju usług e-zdrowia).
>
> ⛔ **BŁĄD SKORYGOWANY 2026-09-10h:** nagłówek podawał ustawę refundacyjną jako
> `Dz.U. 2025 poz. 907` — to tekst jednolity o statusie **wygaśnięcie aktu**,
> zastąpiony przez 2026/253. Sekcja 1 tego samego modułu podawała już numer
> właściwy, więc moduł **sam sobie przeczył**: nagłówek mówił co innego niż treść.

---

## Zakres modułu

Moduł główny (`mod-PrFarm-szczegolowy.md`) pokrywa: dopuszczanie produktów
leczniczych, wytwarzanie/GMP, reklamę, apteki, hurtownie.

Ten moduł pokrywa **stronę regulacyjno-egzekucyjną** Prawa farmaceutycznego
i ustawy refundacyjnej:

1. Refundacja leków (ustawa z 12.05.2011, Dz.U. 2026 poz. 253 t.j.)
2. Państwowa Inspekcja Farmaceutyczna (GIF/WIF) — struktura, tryb odwoławczy
3. Sankcje karne i kary pieniężne (rozdział 9 PF, art. 124–129, 127)

---

## 1. REFUNDACJA LEKÓW

### Ustawa refundacyjna z 12.05.2011 (Dz.U. 2026 poz. 253 t.j.)

```
LISTA LEKÓW REFUNDOWANYCH:
  → ogłaszana obwieszczeniem Ministra Zdrowia co 2 miesiące
  → weryfikuj aktualną listę na stronie MZ: mz.gov.pl → refundacja
  → trzy grupy limitowe: lek podstawowy, lek uzupełniający, lek o wskazaniu do stosowania

POZIOMY ODPŁATNOŚCI PACJENTA:
  → bezpłatny (0 zł) — seniorzy 75+, ciężarne, dzieci do 18. roku życia (weryfikuj warunki)
  → ryczałtowy (✅ POTWIERDZONE 2026-07-30: 3,20 zł — STAŁA kwota
    ustawowa, art. 6 ust. 2 pkt 2 ustawy o refundacji leków, NIE
    zmienia się z waloryzacją minimalnego wynagrodzenia jak niektóre
    inne opłaty farmaceutyczne — potwierdzone w 8+ zgodnych źródłach,
    w tym lexlege.pl [21.05.2026] i NFZ Poznań. ⚠️ NIE MYLIĆ z
    OSOBNYM ryczałtem za lek RECEPTUROWY, który JEST procentowy
    (0,50% płacy minimalnej) i ROŚNIE co roku — od 1.01.2026 to 24,00
    zł, inna kategoria niż zwykły ryczałt "R" na recepcie)
  → 50% limitu finansowania
  → 30% limitu finansowania
  → pełna odpłatność poza limitem

RECEPTA NA LEK REFUNDOWANY:
  → wystawiana przez lekarza posiadającego umowę z NFZ
  → oznaczenie: "Rp" + poziom refundacji + PESEL pacjenta
  → recepta wystawiona niezgodnie z przepisami → apteka odmawia realizacji po refundowanej cenie

ZMIANY USTAWĄ Z 25.07.2025 (Dz.U. 2025 poz. 1192):
  → weryfikuj zakres zmian przed podaniem szczegółów — nowelizacja weszła w życie
    w II połowie 2025 r. / 2026 r. (sprawdź datę wejścia w życie online)
```

### Decyzja refundacyjna — tryb administracyjny

```
Podmiot odpowiedzialny (wytwórca/MAH) składa wniosek do MZ o:
  → objęcie refundacją → Minister Zdrowia wydaje decyzję administracyjną
  → podwyższenie ceny / rozszerzenie wskazań refundowanych

Odwołanie od decyzji MZ:
  → do Ministra Zdrowia (ponowne rozpatrzenie)
  → skarga do Wojewódzkiego Sądu Administracyjnego w Warszawie
  → skarga kasacyjna do NSA

Skargi pacjentów (brak dostępu do refundowanego leku):
  → Narodowy Fundusz Zdrowia (NFZ) — właściwy oddział
  → Rzecznik Praw Pacjenta (gov.pl/web/rpp)
  → Skarga do WIF gdy apteka odmówiła realizacji recepty refundowanej
```

---

## 2. PAŃSTWOWA INSPEKCJA FARMACEUTYCZNA

### Struktura i kompetencje (art. 108–123b PF)

```
GIF (Główny Inspektor Farmaceutyczny):
  → nadzór nad wytwarzaniem, importem, dystrybucją hurtową
  → zezwolenia na wytwarzanie i prowadzenie hurtowni
  → inspekcje GMP i GDP
  → środki tymczasowe przy bezpośrednim zagrożeniu dla zdrowia
  → wycofanie serii produktu leczniczego z obrotu (recall)
  → nadzór nad reklamą (art. 62 PF)
  → organ odwoławczy od decyzji WIF

WIF (Wojewódzki Inspektor Farmaceutyczny):
  → zezwolenia na prowadzenie aptek i punktów aptecznych
  → nadzór nad obrotem detalicznym i aptecznym
  → inspekcje aptek i punktów aptecznych
  → I instancja w sprawach aptecznych

Uprawnienia kontrolne (art. 119 PF — weryfikuj):
  → prawo wstępu do pomieszczeń
  → żądanie dokumentów i próbek
  → nakazy natychmiastowego zaprzestania działalności (rygor natychmiastowej wykonalności)
  → zawiadomienie organów ścigania o przestępstwach farmaceutycznych
```

### Tryb odwoławczy od decyzji organów farmaceutycznych

```
WIF (I instancja) → odwołanie do GIF (II instancja)
  → termin: 14 dni od doręczenia decyzji WIF

GIF (II instancja) → skarga do WSA w Warszawie
  → termin: 30 dni od doręczenia decyzji GIF

WSA → skarga kasacyjna do NSA
  → termin: 30 dni od doręczenia wyroku WSA

Wniosek o zawieszenie wykonania decyzji (art. 135 KPA):
  → ważne przy cofnięciu zezwolenia — apteka może działać do rozstrzygnięcia
  → organ rozpatruje niezwłocznie; w razie odmowy — wniosek do WSA
```

> Cofnięcie zezwolenia na prowadzenie apteki (art. 103 PF) — przesłanki:
> `mod-PrFarm-szczegolowy.md` CZĘŚĆ IV.

---

## 3. SANKCJE KARNE I KARY PIENIĘŻNE

### Odpowiedzialność karna (rozdział 9 PF — weryfikuj Dz.U. 2026 poz. 612)

```
Art. 124 PF — WPROWADZANIE DO OBROTU BEZ POZWOLENIA:
  Kto wprowadza do obrotu lub przechowuje w celu wprowadzenia do obrotu
  produkt leczniczy, nie posiadając pozwolenia na dopuszczenie do obrotu
  → grzywna, ograniczenie wolności albo pozbawienie wolności do lat 2
  → w razie skazania: przepadek przedmiotu przestępstwa obowiązkowy

Art. 126 PF — PRZETERMINOWANY PRODUKT LECZNICZY:
  Wprowadzanie do obrotu produktu po upływie terminu ważności
  → grzywna, ograniczenie wolności albo pozbawienie wolności do lat 2

Art. 126b PF — NARUSZENIE ZAKAZU ZBYCIA:
  Sprzedaż lub zbycie wbrew zakazowi zbycia wydanemu przez GIF
  → grzywna lub ograniczenie wolności

Art. 126c PF — WYWÓZ / ZBYWANIE BEZ ZGŁOSZENIA:
  → kara pieniężna: 10 000 zł (weryfikuj aktualne stawki po nowelizacji 2025)

Art. 129 PF — PROWADZENIE APTEKI BEZ ZEZWOLENIA:
  → grzywna, ograniczenie wolności albo pozbawienie wolności do lat 2

KUMULACJA: odpowiedzialność karna + administracyjne cofnięcie zezwolenia są niezależne
```

### Kary pieniężne administracyjne (art. 127 PF — weryfikuj aktualne stawki)

```
UWAGA: art. 127 PF był wielokrotnie nowelizowany — SPRAWDŹ ONLINE przed podaniem kwot.
Nowelizacja z 24.06.2025 zmieniła górne limity kar (max 100 000 zł dla badań jakościowych).

Przykładowe podstawy kar (weryfikuj aktualne stawki):
  → prowadzenie apteki wbrew warunkom zezwolenia → kara pieniężna
  → prowadzenie hurtowni wbrew warunkom zezwolenia → kara pieniężna
  → wywóz produktu bez zgłoszenia → 10 000 zł
  → odmowa wykonania obowiązku zbycia produktu → 50 000–100 000 zł
  → nieprzekazanie dokumentów na żądanie GIF → 10 000–50 000 zł

Organ nakładający: GIF lub WIF (zależnie od rodzaju naruszenia)
Odwołanie: do GIF / wniosek o uchylenie → skarga do WSA
```

---

## ŹRÓDŁO WYKAZU: KTÓRY LEK, JAKA ODPŁATNOŚĆ, DLA KOGO

⛔ **Ustalone 2026-09-10h. Pomiar dwukanałowy wykonany (Reguła 12d/REM-0).**

Pytanie „czy ten lek jest refundowany, na jakim poziomie i dla kogo" ma **jedno
źródło rozstrzygające**: obwieszczenie Ministra Zdrowia wydawane na podstawie
**art. 37 ust. 1 ustawy o refundacji**. Wykaz jest **załącznikiem** do
obwieszczenia — nie stroną internetową, nie wyszukiwarką.

| Kanał | Co daje | Rząd | Pomiar 2026-09-10h |
|---|---|---|---|
| **Dziennik Urzędowy Ministra Zdrowia** `dziennikmz.mz.gov.pl` | miejsce **urzędowego ogłoszenia** obwieszczenia — źródło rozstrzygające | **RZĄD 1** | HTTP 200, ⛔ **aplikacja jednostronicowa** — treść nie wychodzi prostym pobraniem, wymaga przeglądarki |
| `gov.pl/web/zdrowie/obwieszczenia-ministra-zdrowia-lista-lekow-refundowanych` | hub z **załącznikami XLSX i PDF** każdego obwieszczenia + zestawienia zmian cen i dopłat | RZĄD 2A | HTTP 200, HTML ~33 kB; **XLSX ≈1 MB to jedyny praktycznie przetwarzalny wariant wykazu** (PDF ≈97 MB) |
| `ezdrowie.gov.pl` — dane refundacyjne | dane dla systemów gabinetowych + komunikaty o korektach wskazań między obwieszczeniami | RZĄD 2A | HTTP 200 |
| `nfz.gov.pl`, `pacjent.gov.pl` | wyjaśnienie poziomów odpłatności i uprawnień dodatkowych | RZĄD 2A | HTTP 200 |
| `api.nfz.gov.pl/app-stat-api-ra/` | ⚠️ **statystyka wykonanej refundacji**, nie wykaz | RZĄD 2A | HTTP 200 |

⛔ **`api.nfz.gov.pl` NIE odpowiada na pytanie o refundację leku.** Zwraca dane
o zrealizowanych receptach i kosztach — czyli co refundowano, nie co podlega
refundacji. Użycie go jako podstawy odpowiedzi jest błędem kategorii źródła.

⛔ **Komercyjne wyszukiwarki leków refundowanych są RZĘDU 3.** Bywają wygodne
i bywają aktualne, ale ich zgodność z obwieszczeniem nie jest niczym gwarantowana.
Nie stanowią podstawy odpowiedzi — najwyżej trop do sprawdzenia w załączniku.

### Trzy elementy odpowiedzi — gdzie który stoi

```
1. CZY refundowany       → załącznik do obwieszczenia (XLSX), pozycja wykazu
2. NA JAKIM POZIOMIE     → kolumna poziomu odpłatności przy tej pozycji
                           (bezpłatny / ryczałt / 30% / 50%) + LIMIT FINANSOWANIA
3. DLA KOGO              → kolumna wskazań refundacyjnych przy tej pozycji
                           + oznaczenie uprawnienia dodatkowego (np. 65+, ciąża,
                             do 18. r.ż.) ⚠️ oznaczenia i progi wiekowe
                             WERYFIKUJ w załączniku — zmieniały się
```

⛔ **Poziom odpłatności NIE wystarcza do podania kwoty.** Dopłata pacjenta zależy
od relacji ceny detalicznej do **limitu finansowania** grupy limitowej: przy cenie
powyżej limitu pacjent dopłaca nadwyżkę ponad limit. Odpowiedź „lek jest na 50%,
więc zapłaci połowę" jest fałszywa w typowym przypadku.

⛔ **Wykaz zmienia się cyklicznie**, a między obwieszczeniami wychodzą sprostowania
i obwieszczenia zmieniające. Data obwieszczenia i data, na którą wykaz ustalono,
to **dwie różne daty** — w powołaniu podawać obie.

⚠️ Struktura załączników (podział na listy apteczne, programy lekowe, chemioterapię
i listy dla grup uprawnionych) **nie jest tu odtwarzana z pamięci** — odczytać
z konkretnego obwieszczenia, bo bywa zmieniana.

---

## POWIĄZANIA

| Sytuacja | Skill / Moduł |
|---|---|
| Dopuszczanie / wytwarzanie / reklama / apteki / hurtownie | `mod-PrFarm-szczegolowy.md` |
| Wyroby medyczne (MDR/IVDR) | `mod-wyroby-medyczne.md` |
| Skarga do WSA na decyzję GIF/MZ | `dr-05` → `mod-KPA-postepowanie-administracyjne` |
| Odpowiedzialność karna — projekt pisma | `pisma-procesowe-v3` |

---

## ŹRÓDŁA WERYFIKACJI

| Źródło | URL | Zakres |
|---|---|---|
| ISAP — teksty jednolite | isap.sejm.gov.pl | PF, ustawa refundacyjna |
| GIF | gif.gov.pl | Decyzje, kontrole, wycofania, wytyczne |
| **Wykaz leków refundowanych — ogłoszenie urzędowe** | `dziennikmz.mz.gov.pl` | **RZĄD 1**; ⛔ SPA — treść wymaga przeglądarki |
| **Wykaz leków refundowanych — załączniki XLSX/PDF** | `gov.pl/web/zdrowie/obwieszczenia-ministra-zdrowia-lista-lekow-refundowanych` | RZĄD 2A; XLSX ≈1 MB — jedyny przetwarzalny wariant |
| Dane refundacyjne dla systemów | `ezdrowie.gov.pl` | RZĄD 2A; korekty wskazań między obwieszczeniami |
| Poziomy odpłatności i uprawnienia | `nfz.gov.pl`, `pacjent.gov.pl` | RZĄD 2A; wyjaśnienia, nie wykaz |
| NFZ — refundacja | nfz.gov.pl | Umowy, realizacja recept |
| RPP | gov.pl/web/rpp | Skargi pacjentów |
| Orzeczenia NSA farm. | orzeczenia.nsa.gov.pl | Wyroki w sprawach farmaceutycznych |

---

## ⚖️ DISCLAIMER

Po zakończeniu analizy: `view shared/DISCLAIMER.md` — wariant wg trybu (PRAWNIK/LAIK).
