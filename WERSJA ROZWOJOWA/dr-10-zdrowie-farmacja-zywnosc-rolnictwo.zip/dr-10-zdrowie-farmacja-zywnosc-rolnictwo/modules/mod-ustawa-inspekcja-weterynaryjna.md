# Moduł — Inspekcja Weterynaryjna

**Akt:** UZChZ (ustawa o zapobieganiu oraz zwalczaniu zakażeń i chorób zakaźnych u ludzi) — t.j. Dz.U. 2025 poz. 1675 (zm. po t.j.: 2026/92 od 2026-02-12 — zakres: tekst nowelizacji w ELI; 2026/791 od 2026-07-01 — art. 21d; 2026/26 [OD 2027-01-01: 2026/26] — art. 47).
**Akt:** UPPZ (ustawa o produktach pochodzenia zwierzęcego) — t.j. Dz.U. 2026 poz. 981.
**Akt:** UIW (ustawa o Inspekcji Weterynaryjnej) — t.j. Dz.U. 2024 poz. 12.
**Akt:** UZZw (ustawa o zdrowiu zwierząt) — akt pierwotny, bez t.j.: Dz.U. 2025 poz. 1795.
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

## Akt prawny / źródło
- Ustawa o Inspekcji Weterynaryjnej — Dz.U. 2024 poz. 12 (t.j.)
  ✅ [VER: isap.sejm.gov.pl, 2026-05-31]
- ⛔ **ZASTĄPIONA 2026-08-21 (F-105/FAZA 3E):** Ustawa o zdrowiu zwierząt z 21.11.2025 —
  Dz.U. 2025 poz. 1795, weszła w życie **18.03.2026**, w przeważającej części
  **uchyliła** poprzednią ustawę o ochronie zdrowia zwierząt oraz zwalczaniu chorób
  zakaźnych zwierząt (ostatni t.j.: Dz.U. 2023 poz. 1075 — ✅ [VER] RZĄD 1 2026-09-16d; ⛔ poprzedni zapis
  „dawniej: Dz.U. 2024 poz. 1284" wskazywał rozporządzenie MKiŚ — podmiana aktu). Implementuje unijne
  rozporządzenie 2016/429 ("Animal Health Law"). Zmiana MERYTORYCZNA, nie tylko
  metrykalna — nowa ustawa zmienia m.in. system odszkodowań (elastyczniejszy,
  częściowe obniżki zamiast całkowitej odmowy), wprowadza obowiązek rejestracji
  podmiotów dotąd niepodlegających zgłoszeniu, przenosi regulację schronisk dla
  zwierząt z aktu wykonawczego wprost do ustawy, wpisuje plan ograniczenia
  antybiotyków w hodowli o 50% do 2030 r. (Zielony Ład).
  ✅ [VER: 2026-08-21, RZĄD 1 (api.sejm.gov.pl/eli/acts/DU/2025/1795/text.pdf,
  ISAP WDU20250001795) + RZĄD 2/3 (PIW Opatów, PIW Pruszków, infor.pl, gofin) —
  Ustawa o zdrowiu zwierząt — Dz.U. 2025 poz. 1795]
  ⚠️ Zakres nowej ustawy vs starej NIE zweryfikowany art.-po-art. w tej sesji —
  jeśli poniższe sekcje "Zasady absolutne" (art. 42 dawnej u.o.z.z.) cytują
  numerację STAREJ ustawy, wymaga dedykowanej sesji przenumerowania (poza
  zakresem F-105, otwarcie kolejnej flagi jeśli potwierdzone)
- ⛔ **ZASTĄPIONA 2026-08-21 (F-105):** Ustawa o produktach pochodzenia
  zwierzęcego — poprzednio Dz.U. 2023 poz. 872 (t.j.), obecnie **Dz.U. 2026 poz. 981**
  (t.j. z 22.07.2026, obwieszczenie Marszałka Sejmu z 16.07.2026)
  ✅ [VER: 2026-08-21, RZĄD 2B (inforlex, rp.pl — obwieszczenie 16.07.2026)
  ⚠️ [NIEWERYFIKOWANE RZĄD 1] — ISAP/ELI nie potwierdzone bezpośrednio w tej
  sesji, do zrobienia przy najbliższej okazji]
  — nowy t.j. konsoliduje ustawę z 12.09.2025 (Dz.U. 2025 poz. 1424: nowe art. 21f–21j,
  zasady kontynuacji produkcji w zakładzie przy zmianie podmiotu prowadzącego —
  zmiana merytoryczna dot. przenoszenia decyzji administracyjnych powiatowego
  lekarza weterynarii) oraz zmiany konsekwencyjne z ustawy o zdrowiu zwierząt
  (Dz.U. 2025 poz. 1795, odesłania terminologiczne)

**Weryfikacja:** ELI (RZĄD 1) + GIW.gov.pl przed każdym cytowaniem.

## Zakres
Inspekcja Weterynaryjna (GIW/WIJHARS):
1. Nadzór nad zdrowiem zwierząt (zwalczanie chorób zakaźnych: ASF, pryszczyca, wścieklizna)
2. Nadzór nad jakością artykułów rolno-spożywczych pochodzenia zwierzęcego
3. Kontrola zakładów przetwórstwa mięsnego, mleczarskich, paszarni

Ubojnia: wymagany lekarz weterynarii urzędowy; badanie przedubojowe i poubojowe.

## Zasady absolutne
```
Choroba zakaźna:  Obowiązek natychmiastowego zgłoszenia
                  ⛔ [NUMERACJA NIEAKTUALNA 2026-08-21] — poprzednio art. 42 u.o.z.z.
                  (ustawy uchylonej 18.03.2026). Odpowiednik w nowej ustawie o
                  zdrowiu zwierząt (Dz.U. 2025 poz. 1795) POTWIERDZONY źródłami wtórnymi
                  jako obowiązujący nadal (RolnikInfo, LEX, PROKURENT — kary do
                  ~50 tys. zł za niezgłoszenie), ale DOKŁADNY numer artykułu
                  NIEUSTALONY w tej sesji (źródła cytują różne artykuły dla
                  pokrewnych obowiązków — np. art. 137 dot. rejestracji działalności,
                  nie samego zgłoszenia choroby). Wymaga odczytu pełnego tekstu
                  ISAP WDU20250001795 przy najbliższej sprawie dotykającej tego
                  przepisu — NIE cytować numeru artykułu z pamięci do tego czasu.
Zakaz:            Sprzedaż zwierząt z objawami choroby (odpowiedzialność karna)
Ognisko choroby:  PIW zarządza strefę zagrożenia, ubój sanitarny, zakaz przemieszczania
```

## Połącz z
- DR-10/mod-ustawa-bezpieczenstwo-zywnosci (żywność pochodzenia zwierzęcego)
- DR-10/mod-ustawa-rolne-zywnosc-weterynaria (prawo weterynaryjne ogólne)

## Weryfikacja online
```
web_search: "ustawa Inspekcja Weterynaryjna isap Dz.U. 2024 poz. 12"
web_search: "ustawa o zdrowiu zwierząt isap Dz.U. 2025 poz. 1795 art. zgłoszenie choroby"
web_search: "ASF afrykański pomór świń Polska 2026 aktualna strefa"
```
