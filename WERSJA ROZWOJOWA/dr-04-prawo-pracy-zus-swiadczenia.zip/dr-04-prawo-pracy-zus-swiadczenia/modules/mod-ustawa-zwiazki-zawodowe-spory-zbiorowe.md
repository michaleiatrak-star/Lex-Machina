# mod-ustawa-zwiazki-zawodowe-spory-zbiorowe

⚠️ **Nazwa pliku jest HISTORYCZNA i węższa niż rzeczywisty zakres** — ✅ ROZSTRZYGNIĘTE 2026-08-15 (F-28 pkt 4): moduł opisuje TRZY tematy, nie dwa sugerowane nazwą: (1) związki zawodowe, (2) UKŁADY ZBIOROWE PRACY (sekcja 3 — pominięte w nazwie, mimo że to jedna z dwóch ustaw źródłowych modułu), (3) spory zbiorowe. Rename pliku ŚWIADOMIE NIE wykonany — wymagałby synchronizacji 4 miejsc w 3 plikach (`SKILL.md`, `MAPA-AKTOW.md`, `prawo-polskie-v2/ROUTING-MAP.md` — 2 wiersze, oraz cross-odesłanie z `mod-ustawa-zwolnienia-grupowe.md`), z realnym ryzykiem rozerwania referencji, przy niskiej korzyści (moduł ma tylko 1 plik, łatwy do znalezienia przez treść). Zamiast tego — ten nagłówek jako trwałe wyjaśnienie zakresu.

**Status:** moduł klasy kancelaryjnej — poziom DR-03
**Źródło weryfikacji:** Ustawa o związkach zawodowych — Dz.U. 2026 poz. 549 t.j. (⏳ zm. Dz.U. 2026 poz. 1340 (ustawa z 4.09.2026, ogł. 15.10.2026) — w życie **30.10.2026**: art. 32 ust. 9¹ zd. 2 (powiadomienie w 7 dni od wniosku zarządu ZOZ złożonego na piśmie, w formie dokumentowej lub elektronicznej), nowy art. 32¹ (forma dokumentowa lub elektroniczna informacji z art. 26¹ ust. 1 i art. 32 ust. 9¹ zd. 1, jeśli przewiduje ją układ lub porozumienie) ✅ [VER] RZĄD 1 2026-10-17 (ELI DU/2026/1340 text.pdf)) | Ustawa o układach zbiorowych i porozumieniach zbiorowych — Dz.U. 2025 poz. 1661 (NOWA — od 13.12.2025)
**Data weryfikacji online:** 2026-06-05
**Zasada:** Każde brzmienie przepisu przed powołaniem → isap.sejm.gov.pl

---

## ⚡ ALERT LEGISLACYJNY — KRYTYCZNY

```
Ustawa z 05.11.2025 r. o układach zbiorowych pracy i porozumieniach zbiorowych
  → Dz.U. 2025 poz. 1661 — wejście w życie 13.12.2025
  → ZASTĄPIŁA:
    □ Ustawę o rozwiązywaniu sporów zbiorowych (1991) — UCHYLONA
    □ Przepisy o układach zbiorowych z Działu XI KP — ZASTĄPIONE
  → ZAWSZE cytuj nową ustawę Dz.U. 2025 poz. 1661, nie stare przepisy!
```

---

## 1. CORE

### Zakres
Związki zawodowe (zakładanie, prawa, ochrona działaczy), zakładowe organizacje związkowe (ZOZ), układy zbiorowe pracy, porozumienia zbiorowe, spory zbiorowe (rokowania, mediacja, arbitraż, strajk).

### Akty

| Akt | Dz.U. | Uwaga |
|---|---|---|
| Ustawa o związkach zawodowych | Dz.U. 2026 poz. 549 t.j. + ⏳ zm. Dz.U. 2026 poz. 1340 od 30.10.2026 (art. 32 ust. 9¹, art. 32¹) | Zawiera zm. z ustawy o układach zbiorowych; przed 30.10.2026 — brzmienie z t.j. 549, od 30.10.2026 — po zm. 1340 |
| Ustawa o informowaniu pracowników i przeprowadzaniu z nimi konsultacji | Dz.U. 2006 poz. 550 ze zm. (bez t.j.) + ⏳ zm. Dz.U. 2026 poz. 1340 od 30.10.2026 (art. 5 ust. 1 pkt 1a–1b, art. 13 ust. 2 zd. 2 i ust. 3 — wniosek i informacje rady pracowników także w formie dokumentowej lub elektronicznej) | Rada pracowników; brzmienie zawsze z ELI |
| Ustawa o układach zbiorowych i porozumieniach zbiorowych | Dz.U. 2025 poz. 1661 | NOWA od 13.12.2025 |

---

## 2. INTAKE

```
□ Jaki problem: ochrona działacza ZZ / układ zbiorowy / spór zbiorowy / strajk?
□ Czy ZOZ jest reprezentatywna (≥ 8% ogółu zatrudnionych — art. 24125d KP)?
□ Czy doszło do zwolnienia działacza ZZ bez zgody zarządu ZOZ (art. 32 ustawy)?
□ Czy pracodawca przeprowadził konsultację ZZ przy zwolnieniu?
□ Czy spór dotyczy zbiorowych interesów pracowniczych (nie indywidualnych)?
□ Na jakim etapie jest spór zbiorowy: rokowania / mediacja / arbitraż / strajk?
```

---

## 3. PROCEDURA

### Ochrona działacza związkowego

```
Zakaz wypowiedzenia / rozwiązania umowy z chronionym działaczem (art. 32 ustawy o ZZ):
  → Wymagana UPRZEDNIA ZGODA zarządu ZOZ
  → Brak zgody → zwolnienie bezskuteczne → roszczenie o przywrócenie
  → Ochrona: przez czas pełnienia funkcji + rok po zakończeniu

Ochrona przeciwko dyskryminacji (art. 35 §1 KP):
  → Zakaz nierównego traktowania za przynależność lub działalność związkową
```

### Kto może być członkiem ZZ (po nowelizacji 2019)

```
Nie tylko pracownicy:
  □ Pracownicy (art. 2 ustawy o ZZ)
  □ Osoby wykonujące pracę zarobkową (zleceniobiorcy, samozatrudnieni)
    gdy mają prawo koalicji (od nowelizacji 2019)
  ⚠️ Weryfikuj aktualne przepisy o przynależności w ELI (RZĄD 1).
```

### Układy zbiorowe pracy (nowa ustawa Dz.U. 2025 poz. 1661)

```
Strony: Pracodawca / organizacja pracodawców + ZOZ / federacja ZZ
Forma: Pisemna
Rejestracja: Okręgowy Inspektor Pracy (zakładowe) / MRiPS (ponadzakładowe)
Zasada uprzywilejowania: UZP stosuje się zamiast KP — korzystniej niż KP

⚠️ Dla szczegółów zawierania, rejestracji i wypowiadania UZP:
   → zawsze weryfikuj aktualny tekst Dz.U. 2025 poz. 1661 w ELI (RZĄD 1)
```

### Spory zbiorowe i strajk (nowa ustawa Dz.U. 2025 poz. 1661)

```
Procedura:
1. ROKOWANIA (obowiązkowe, min. kilka spotkań — weryfikuj w ustawie)
2. MEDIACJA (mediator ze wspólnej listy lub wyznaczony przez MRiPS)
3. ARBITRAŻ (Kolegium Arbitrażu Społecznego przy SN — dobrowolny)
4. STRAJK (ostateczność)
   → Wymaga referendum: frekwencja ≥ 50% + co najmniej 50% głosujących ZA
   → Zakaz strajku w służbach kluczowych — weryfikuj art. ustawy
   → Pracodawca NIE może wypowiadać umów w trakcie legalnego strajku

⚠️ Szczegółowe wymogi proceduralne — ZAWSZE weryfikuj aktualną ustawę Dz.U. 2025 poz. 1661
```

---

## 4. DOWODY

| Teza | Dowód | Źródło | Siła | Luka | Działanie |
|---|---|---|---|---|---|
| Brak zgody ZOZ na zwolnienie | Brak pisma ZOZ do pracodawcy | ZOZ / dokumenty HR | wysoka | ustna odmowa | żądaj pisemnej |
| Dyskryminacja za działalność ZZ | Porównanie traktowania innych pracowników | HR, zeznania | średnia | subiektywność | dokumentuj każde zdarzenie |
| Naruszenie procedury sporu zbiorowego | Brak protokołu rokowań, arbitraż pominięty | dokumenty ZOZ | wysoka | — | korespondencja pisemna |

---

## 5. STRATEGIA

### Perspektywa działacza ZZ

1. Sprawdź czy ZOZ wyrażała/odmawiała zgody na zwolnienie na piśmie.
2. Jeśli pracodawca zwolnił bez zgody → roszczenie o przywrócenie (art. 45 KP + ochrona z ustawy o ZZ).
3. Dokumentuj każde przejawy dyskryminacji za działalność związkową.

### Perspektywa pracodawcy

1. Zawsze uzyskaj pisemną zgodę zarządu ZOZ lub pisemną odmowę przed zwolnieniem działacza.
2. Zachowaj procedurę konsultacyjną przy zwolnieniach grupowych.
3. W sporze zbiorowym — prowadź pisemne protokoły z każdego etapu.

---

## 6. QUALITY GATE

- [ ] Nowa ustawa Dz.U. 2025 poz. 1661 zastosowana (nie stare przepisy)?
- [ ] Aktualny t.j. ustawy o ZZ (Dz.U. 2026 poz. 549) zweryfikowany? Zdarzenie od 30.10.2026 — art. 32 ust. 9¹ i art. 32¹ w brzmieniu po zm. Dz.U. 2026 poz. 1340?
- [ ] Reprezentatywność ZOZ (≥ 8%) ustalona?
- [ ] Ochrona działacza (zgoda zarządu ZOZ) sprawdzona?

---

## POWIĄZANIA

| Sytuacja | Skill / Moduł |
|---|---|
| Prawo pracy | `mod-KP-prawo-pracy` |
| Zwolnienia grupowe (konsultacja) | `mod-ustawa-zwolnienia-grupowe` |
| PIP (kontrola przestrzegania praw ZZ) | `mod-ustawa-PIP-inspekcja-pracy` |

---

**Źródła:** https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20260000549 | https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20251661
