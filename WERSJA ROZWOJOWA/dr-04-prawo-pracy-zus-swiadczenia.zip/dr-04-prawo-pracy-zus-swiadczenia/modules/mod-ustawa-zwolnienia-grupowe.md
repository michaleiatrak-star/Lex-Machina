# mod-ustawa-zwolnienia-grupowe

**Akt:** KP — t.j. Dz.U. 2026 poz. 1245 (stan 2026-08-27; zm. 2026/1046 od 2026-11-05 — art. 18³d, 94³, 94³ᵃ: mobbing i równe traktowanie, oba brzmienia w t.j. z odnośnikami).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

**Status:** moduł klasy kancelaryjnej — poziom DR-03
**Źródło weryfikacji:** Ustawa o zwolnieniach grupowych — **Dz.U. 2026 poz. 1195 t.j.** ✅ [VER] RZĄD 1 2026-09-10r (poprzednio 2025 poz. 570 — wygaśnięcie aktu) t.j.
**Data weryfikacji online:** 2026-08-27 — RZĄD 1 ELI
**Zasada:** Każde brzmienie przepisu przed powołaniem → ELI/ISAP. Źródło RZĄD 1: https://eli.gov.pl/eli/DU/2025/570/ogl

---

## 1. CORE

### Zakres
Rozwiązywanie stosunków pracy z przyczyn niedotyczących pracowników (ekonomiczne, organizacyjne, technologiczne), progi zwolnień grupowych, procedura konsultacyjna, odprawa, pierwszeństwo ponownego zatrudnienia.

### Akt

| Akt | Dz.U. |
|---|---|
| Ustawa z 13.03.2003 r. o szczególnych zasadach rozwiązywania z pracownikami stosunków pracy z przyczyn niedotyczących pracowników | **Dz.U. 2026 poz. 1195 t.j.** ✅ [VER] RZĄD 1 2026-09-10r (poprzednio 2025 poz. 570 — wygaśnięcie aktu) t.j. |

---

## 2. INTAKE

```
□ Ile pracowników zatrudnia pracodawca? (próg stosowania ustawy: ≥ 20)
□ Ile wypowiedzeń planowane w ciągu 30 dni? → sprawdź czy próg zwolnień grupowych
□ Jakie przyczyny: ekonomiczne / organizacyjne / technologiczne?
□ Czy przeprowadzono konsultację z ZOZ lub reprezentantami?
□ Czy przekazano informacje i zawiadomienia właściwemu PUP? (ustawa nie ustanawia tu równoległego obowiązku zawiadomienia PIP)
□ Czy pracownik otrzymał odprawę? Jaka wysokość?
□ Czy odróżniono moment dopuszczalności wypowiedzenia od momentu rozwiązania stosunku pracy (art. 6)?
```

---

## 3. PROCEDURA

### Progi zwolnień grupowych (art. 1 ust. 1 — weryfikuj w ELI (RZĄD 1))

```
Pracodawca ≥ 20 pracowników + w ciągu 30 dni:
  Zatrudnienie < 100 pracowników:    co najmniej 10 pracowników
  100 ≤ zatrudnienie < 300:          co najmniej 10% pracowników
  Zatrudnienie ≥ 300:                co najmniej 30 pracowników
Przyczyny: niedotyczące pracowników
```

### Procedura (art. 2–6 ustawy)

✅ [VER] RZĄD 1 2026-09-17o — t.j. `Dz.U. 2026 poz. 1195` (obwieszczenie z 1.09.2026, ogłoszone
4.09.2026; obejmuje nowelizację `2025/1661`); brak zmian po t.j.

```
1. Konsultacja z ZOZ / reprezentantami pracowników:
   → pracodawca przekazuje informacje wymagane art. 2 ust. 3
   → konsultacje mają dotyczyć możliwości uniknięcia/zmniejszenia zwolnień i spraw pracowniczych
   → porozumienie zawiera się w terminie NIE DŁUŻSZYM niż 20 dni od zawiadomienia z art. 2 ust. 3 (art. 3 ust. 1)

2. Informacja / zawiadomienie do właściwego PUP:
   → art. 2 ust. 6: przekazanie informacji o zamiarze grupowego zwolnienia
   → art. 4 ust. 1: po porozumieniu/regulaminie pisemne zawiadomienie PUP o przyjętych ustaleniach
   → NIE dopisuj PIP jako adresata obowiązku z art. 2–4

3. Porozumienie z ZOZ LUB regulamin:
   → gdy nie można zawrzeć porozumienia, pracodawca ustala zasady w regulaminie zgodnie z art. 3 ust. 4/5

4. Art. 6 — dwa różne momenty:
   → WYPOWIEDZENIE może nastąpić po dokonaniu zawiadomienia z art. 4 ust. 1 (albo po porozumieniu/regulaminie, gdy zawiadomienie nie jest wymagane)
   → ROZWIĄZANIE stosunku pracy co do zasady nie wcześniej niż po 30 dniach od właściwego zdarzenia wskazanego w art. 6 ust. 2
   → nie zapisuj automatycznie „30 dni przed wypowiedzeniem”
```

---

## 4. ODPRAWA (art. 8 ustawy — weryfikuj w ELI (RZĄD 1))

```
Należna z mocy prawa — pracodawca nie może się zwolnić:

Staż u danego pracodawcy:
  Do 2 lat:      1 miesięczne wynagrodzenie
  2–8 lat:       2 miesięczne wynagrodzenia
  Powyżej 8 lat: 3 miesięczne wynagrodzenia

Maximum: 15-krotność minimalnego wynagrodzenia za pracę
  ⚠️ Minimalne wynagrodzenie 2026: 4 806 zł → max odprawa: 72 090 zł
  ⚠️ Weryfikuj aktualną kwotę min. wynagrodzenia przed każdą sprawą

Uwaga: Odprawa jest zaliczana na poczet okresu, za który przysługuje zasiłek dla bezrobotnych.
```

---

## 5. PIERWSZEŃSTWO PONOWNEGO ZATRUDNIENIA (art. 9 ustawy)

```
Pracodawca ma obowiązek ponownego zatrudnienia zwolnionego pracownika:
  → Termin: 15 miesięcy od daty rozwiązania umowy
  → Warunek: pracodawca zatrudnia nowych pracowników na te same stanowiska
  → Pracownik musi w ciągu ROKU od rozwiązania stosunku pracy zgłosić zamiar
    podjęcia zatrudnienia (art. 9 ust. 1); ponowne zatrudnienie — w okresie
    15 miesięcy (ust. 2) — ✅ RZĄD 1 2026-09-17o

ODPRAWA (art. 8): 1 / 2 / 3-miesięczne wynagrodzenie (< 2 lata / 2–8 lat / > 8 lat);
  ⛔ nie więcej niż 15-KROTNOŚĆ minimalnego wynagrodzenia z dnia rozwiązania (ust. 4)

ZWOLNIENIA INDYWIDUALNE u pracodawcy ≥ 20 pracowników (art. 10):
  → odprawa z art. 8 także poza progiem z art. 1, gdy przyczyny niedotyczące
    pracownika są WYŁĄCZNYM powodem
  → pracownik szczególnie chroniony — wypowiedzenie tylko przy braku SPRZECIWU
    zakładowej organizacji związkowej w 14 DNI od otrzymania zawiadomienia (ust. 2)
```

---

## 6. DOWODY

| Teza | Dowód | Źródło | Siła | Luka | Działanie |
|---|---|---|---|---|---|
| Brak konsultacji ZOZ | Brak pisma, brak protokołu | dokumenty HR | wysoka | ustna konsultacja | żądaj dokumentów |
| Nieprawidłowa wysokość odprawy | Paski płacowe, staż pracy | pracodawca | wysoka | wypłata gotówkowa | zeznania, bank |
| Przekroczenie progu 30 dni | Daty wypowiedzeń vs zawiadomienie PUP | dokumenty | wysoka | — | korespondencja z PUP |
| Pozorność przyczyny | Nowe zatrudnienia po zwolnieniu | ogłoszenia pracy | średnia | — | internet, świadkowie |

---

## 7. STRATEGIA

### Perspektywa pracownika

1. Sprawdź procedurę (konsultacja, porozumienie/regulamin, PUP, rozdzielenie terminów z art. 6).
2. Oblicz należną odprawę (uwzględnij reformę stażu — zlecenia i JDG!).
3. Jeśli przyczyna jest kwestionowana lub dobór pracownika budzi zastrzeżenia → odwołanie do sądu po analizie KP i aktualnego orzecznictwa.
4. Sprawdź prawo do pierwszeństwa ponownego zatrudnienia w ciągu 15 miesięcy.

### Perspektywa pracodawcy

1. Zachowaj procedurę — uchybienia = wadliwość zwolnień i ryzyko roszczeń.
2. Dokumentuj przyczyny ekonomiczne / organizacyjne.
3. Odprawa należna z mocy prawa — nie możesz jej wyłączyć porozumieniem.

### Ryzyka

| Ryzyko | Opis | Działanie zaradcze |
|---|---|---|
| Wadliwa procedura | Brak konsultacji / wymaganych zawiadomień | ryzyko wadliwości procedury i roszczeń; sankcje oceniaj z właściwej podstawy |
| Pozorność przyczyny | Nowe zatrudnienia po zwolnieniu | Udokumentuj rzeczywiste przyczyny ekonomiczne |
| Błędna odprawa | Zaniżona o reformę stażu 2025/2026 | Przelicz uwzględniając nowe art. 30² KP |

---

## 8. QUALITY GATE

- [ ] Ustawa ma zastosowanie (pracodawca ≥ 20 pracowników)?
- [ ] Progi zwolnień grupowych osiągnięte?
- [ ] Procedura konsultacyjna zachowana?
- [ ] Odprawa obliczona z uwzględnieniem reformy stażu?
- [ ] Aktualny t.j. ustawy zweryfikowany w ISAP?

---

## 9. OUTPUT

Stan faktyczny → kwalifikacja → procedura → odprawa (obliczenie) → dowody → ryzyka → strategia → rekomendacja → ISAP/temporalność.

---

## POWIĄZANIA

| Sytuacja | Skill / Moduł |
|---|---|
| Prawo pracy ogólnie | `mod-KP-prawo-pracy` |
| Związki zawodowe (konsultacja ZOZ) | `mod-ustawa-zwiazki-zawodowe-spory-zbiorowe` |
| PIP (kontrola procedury) | `mod-ustawa-PIP-inspekcja-pracy` |
| Pismo: pozew o odprawę | `pisma-procesowe-v3` |

---

**Źródła:** https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20250000570
