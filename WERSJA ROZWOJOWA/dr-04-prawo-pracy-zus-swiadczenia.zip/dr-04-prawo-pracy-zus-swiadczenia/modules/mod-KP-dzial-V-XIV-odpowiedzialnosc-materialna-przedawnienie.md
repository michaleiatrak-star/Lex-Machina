# mod-KP-dzial-V-XIV-odpowiedzialnosc-materialna-przedawnienie

**Akt:** KP — t.j. Dz.U. 2026 poz. 1245 (stan 2026-08-27; zm. 2026/1046 od 2026-11-05 — art. 18³d, 94³, 94³ᵃ: mobbing i równe traktowanie, oba brzmienia w t.j. z odnośnikami).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

**Wersja:** 1.0 | **Dodano:** 2026-07-17
**Rola w systemie:** domyka priorytety wysokiego rzędu z audytu pokrycia
Kodeksu pracy — odpowiedzialność materialna pracowników (Dział V) i
przedawnienie roszczeń pracowniczych (Dział XIV, art. 291 — pytanie
pojawiające się praktycznie w KAŻDEJ sprawie pracowniczej). Połączono
w jeden moduł ze względu na ścisły związek praktyczny: termin
przedawnienia roszczenia o naprawienie szkody (Dział XIV) ma ODMIENNĄ
regułę niż ogólny 3-letni termin właśnie ze względu na specyfikę
odpowiedzialności materialnej (Dział V).

> ⛔ HARDGATE — zweryfikuj aktualny t.j. na ISAP przed użyciem.

---

## CZĘŚĆ A — ODPOWIEDZIALNOŚĆ MATERIALNA PRACOWNIKÓW (Dział V, art. 114-127)

### Przegląd

```
Rozdział I  — Odpowiedzialność pracownika za szkodę wyrządzoną
              pracodawcy (114-123)
Rozdział II — Odpowiedzialność za mienie powierzone pracownikowi
              (124-127)
```

### 1. Odpowiedzialność ZA SZKODĘ WYRZĄDZONĄ PRACODAWCY (art. 114-123)

**Podstawa (art. 114):** pracownik ponosi odpowiedzialność za szkodę
wyrządzoną pracodawcy z tytułu ZAWINIONEGO niewykonania lub nienależytego
wykonania OBOWIĄZKÓW PRACOWNICZYCH — **WYMAGANE ŁĄCZNIE:**
1. bezprawność zachowania pracownika,
2. wina,
3. szkoda,
4. związek przyczynowy między zachowaniem a szkodą.

⚠️ **Z samego faktu powstania szkody NIE MOŻNA domniemywać winy
pracownika ani niedopełnienia obowiązków** (odmiennie niż przy mieniu
POWIERZONYM — patrz Część 2 niżej, gdzie winę się DOMNIEMYWA) —
to kluczowe rozróżnienie dla linii obrony pracownika.

**Ograniczenie wysokości (art. 115, szkoda NIEUMYŚLNA):** pracownik
odpowiada w granicach RZECZYWISTEJ STRATY poniesionej przez pracodawcę
— NIE odpowiada za utracone korzyści (lucrum cessans).

**Limit kwotowy (art. 119 KP — ✅ POTWIERDZONE 2026-07-27, FAZA 3E/
ZASADA 14, dosłownym cytatem w 7+ zgodnych źródłach: PIP, inforlex.pl,
pckp.pl, adwokat-wroclaw.biz.pl — poprzednia niepewność w tej sesji
ROZSTRZYGNIĘTA):** przy szkodzie
NIEUMYŚLNEJ odpowiedzialność pracownika jest ograniczona do wysokości
rzeczywistej straty, NIE WIĘCEJ niż trzykrotność miesięcznego
wynagrodzenia przysługującego pracownikowi w dniu wyrządzenia szkody.

**Szkoda UMYŚLNA (art. 122):** pracownik zobowiązany jest do naprawienia
szkody **W PEŁNEJ WYSOKOŚCI** — BEZ ograniczenia do 3-miesięcznego
wynagrodzenia (to ograniczenie dotyczy WYŁĄCZNIE szkody nieumyślnej).

**Ciężar dowodu (art. 116):** pracodawca jest obowiązany WYKAZAĆ
okoliczności uzasadniające odpowiedzialność pracownika ORAZ wysokość
powstałej szkody.

**Przyczynienie się pracodawcy/osób trzecich (art. 117):** jeżeli
pracownik przyczynił się do powstania/zwiększenia szkody wraz z innymi
osobami (w tym pracodawcą) — odpowiada TYLKO za CZĘŚĆ szkody stosowną
do stopnia swojej winy; pracownik NIE odpowiada za szkodę wynikłą z
działania/zaniechania, do którego był zobowiązany, w zakresie, w jakim
pracodawca/przełożony ponosi za to współodpowiedzialność.

**Wielu pracowników wspólnie (art. 118):** przy wspólnym wyrządzeniu
szkody — odpowiedzialność każdego pracownika ustala się WEDŁUG STOPNIA
WINY oraz przyczynienia się do szkody; jeśli nie da się ustalić stopnia
winy poszczególnych osób — odpowiadają w częściach RÓWNYCH.

**Miarkowanie sądowe (art. 121):** sąd pracy MOŻE, ze względu na
OKOLICZNOŚCI SPRAWY (w szczególności możliwości zarobkowe/majątkowe
pracownika), obniżyć wysokość odszkodowania — ⚠️ dotyczy TYLKO szkody
NIEUMYŚLNEJ (miarkowanie nie ma zastosowania do szkody umyślnej, art. 122).

**Odpowiedzialność pracodawcy wobec OSÓB TRZECICH (art. 120):**
za szkodę wyrządzoną osobie trzeciej przez pracownika przy wykonywaniu
obowiązków pracowniczych odpowiada PRACODAWCA (nie pracownik bezpośrednio
wobec poszkodowanego) — pracodawcy przysługuje NASTĘPNIE roszczenie
REGRESOWE wobec pracownika na zasadach Działu V (art. 114-119).

### 2. Odpowiedzialność ZA MIENIE POWIERZONE (art. 124-127)

**Podstawa (art. 124 §1-2):** pracownik, któremu powierzono Z OBOWIĄZKIEM
ZWROTU albo DO WYLICZENIA SIĘ:
```
§1 — 1) pieniądze, papiery wartościowe lub kosztowności,
     2) narzędzia i instrumenty lub podobne przedmioty, a także środki
        ochrony indywidualnej oraz odzież i obuwie robocze
     → odpowiada W PEŁNEJ WYSOKOŚCI za szkodę powstałą w tym mieniu
§2 — TA SAMA pełna odpowiedzialność za szkodę w MIENIU INNYM niż
     wymienione w §1, powierzonym z obowiązkiem zwrotu/wyliczenia się
```

**⭐ KLUCZOWA RÓŻNICA względem Rozdziału I — DOMNIEMANIE WINY:**
przy mieniu POWIERZONYM wina pracownika jest DOMNIEMANA — to pracownik
musi się UWOLNIĆ od odpowiedzialności (§3), wykazując, że szkoda
powstała z przyczyn OD NIEGO NIEZALEŻNYCH, w szczególności wskutek
NIEZAPEWNIENIA przez pracodawcę warunków umożliwiających zabezpieczenie
powierzonego mienia. **To ODWRÓCENIE ciężaru dowodu względem art. 116**
(gdzie to pracodawca musi wykazać winę) — kluczowe rozróżnienie
proceduralne dla obu stron sporu.

**Warunek "PRAWIDŁOWEGO powierzenia" jako przesłanka surowszej
odpowiedzialności** (potwierdzone bogatym orzecznictwem SN/SA/SO —
14 pozycji w bazie standardyprawa.pl): jeśli powierzenie mienia było
WADLIWE (np. brak inwentaryzacji, brak faktycznego przekazania kontroli
nad mieniem pracownikowi) — surowszy reżim art. 124 NIE ma zastosowania,
sprawa wraca do zwykłych zasad z art. 114-119 (wina zwykła, nie domniemana).

**Wspólna odpowiedzialność materialna (art. 125):**
```
§1 — pracownicy MOGĄ przyjąć WSPÓLNĄ odpowiedzialność za mienie
     powierzone im ŁĄCZNIE z obowiązkiem wyliczenia się — WYMAGANA
     UMOWA O WSPÓŁODPOWIEDZIALNOŚCI MATERIALNEJ, zawarta NA PIŚMIE
     przez pracowników z pracodawcą
§2 — pracownicy odpowiadają w CZĘŚCIACH określonych w umowie; JEŻELI
     ustalono, że szkoda w całości/części została spowodowana przez
     NIEKTÓRYCH pracowników — za całość/odpowiednią część szkody
     odpowiadają TYLKO sprawcy (nie cała grupa proporcjonalnie)
```

**Delegacja do rozporządzenia (art. 126):** Rada Ministrów określa w
drodze rozporządzenia szczegółowy tryb łącznego powierzania mienia
(obligatoryjnie) oraz MOŻE określić warunki odpowiedzialności w
ograniczonej wysokości lub na zasadach z art. 114-116/118 dla mienia
z art. 124 §2 i art. 125 (fakultatywnie — elastyczność wg rodzaju mienia).

### Checklist kwalifikacyjny — zwykła odpowiedzialność czy mienie powierzone?

```
START: Czy mieniu towarzyszył FORMALNY akt powierzenia z obowiązkiem
       zwrotu/wyliczenia się (protokół przekazania, inwentaryzacja)?
  NIE → zwykła odpowiedzialność (art. 114-119) — WINA NIE jest
        domniemana, ciężar dowodu po stronie PRACODAWCY, ograniczenie
        do rzeczywistej straty (nieumyślnie) / 3-miesięczne wynagrodzenie
        jako limit (⚠️ zweryfikuj dokładny przepis limitujący)
  TAK → KROK 2

KROK 2: Czy powierzenie było PRAWIDŁOWE (faktyczna kontrola przekazana
        pracownikowi, właściwa dokumentacja)?
  NIE → mimo formalnego aktu, wadliwe powierzenie → WRACA do zwykłych
        zasad z art. 114-119 (kluczowa linia obrony pracownika!)
  TAK → art. 124 — WINA DOMNIEMANA, pracownik musi się UWOLNIĆ wykazując
        przyczyny od niego niezależne (w tym brak warunków
        zabezpieczenia mienia zapewnionych przez pracodawcę)

KROK 3: Czy mienie powierzono WSPÓLNIE kilku pracownikom?
  TAK → sprawdź czy istnieje PISEMNA umowa o współodpowiedzialności
        (art. 125) — brak umowy = brak podstawy do tego reżimu
```

---

## CZĘŚĆ B — PRZEDAWNIENIE ROSZCZEŃ (Dział XIV, art. 291-295)

### Zasada ogólna (art. 291 §1)

**Roszczenia ze stosunku pracy ulegają przedawnieniu z upływem 3 LAT
od dnia, w którym roszczenie stało się WYMAGALNE.** To dotyczy WIĘKSZOŚCI
roszczeń pracowniczych: o wynagrodzenie, dodatek za nadgodziny, ekwiwalent
za urlop, odszkodowanie za niezgodne z prawem rozwiązanie umowy itd.

### ⭐ Wyjątek — roszczenie PRACODAWCY o naprawienie szkody (art. 291 §2)

Roszczenie pracodawcy o naprawienie szkody wyrządzonej przez pracownika
wskutek niewykonania/nienależytego wykonania obowiązków pracowniczych
(Część A powyżej) ma ODMIENNY, bardziej złożony reżim przedawnienia —
bogata linia orzecznicza SN (potwierdzona wieloma pozycjami w bazie
standardyprawa.pl, w tym osobno dla szkody UMYŚLNEJ i NIEUMYŚLNIE
wyrządzonej), obejmująca m.in.:
- moment rozpoczęcia biegu terminu powiązany z DATĄ POWZIĘCIA przez
  pracodawcę WIADOMOŚCI o wyrządzonej szkodzie (nie od samego
  wyrządzenia szkody),
- zakres zastosowania art. 291 §2 różnicowany w orzecznictwie SN/SR/SO,
- odrębne zasady dla roszczenia REGRESOWEGO pracodawcy (po zapłaceniu
  odszkodowania osobie trzeciej na podstawie art. 120 — patrz Część A).

⚠️ **Dokładna treść §2 (długość terminu, moment jego rozpoczęcia) NIE
została w pełni zrekonstruowana w tej sesji** — wymaga odrębnej,
dogłębnej weryfikacji w ELI (RZĄD 1) i w aktualnym orzecznictwie SN przed
sporządzeniem pisma opartego na tym przepisie — to jeden z
najintensywniej komentowanych fragmentów Działu XIV, co samo w sobie
sugeruje częste spory o jego wykładnię.

### Pozostałe artykuły Działu XIV (art. 292-295) — ✅ ZWERYFIKOWANE (2026-08-18, F-29)

⭐ **Korekta wcześniejszego przypuszczenia:** te przepisy dotyczą SKUTKU
przedawnienia i jego ZAWIESZENIA, ale NIE "przerwania biegu przez wezwanie
do zapłaty" (to instytucja z KC, nie ma odpowiednika w tej formie w
Dziale XIV KP w art. 292-294; przerwanie biegu jest osobno w art. 295,
patrz niżej) — moduł wcześniej zgadywał kierunek, teraz potwierdzone
źródłowo (strefabiznesu.pl, e-prawnik.pl, infor.pl, lexlege.pl — zbieżne):

- **Art. 292 — SKUTEK przedawnienia:** przedawnienie NIE powoduje
  automatycznego wygaśnięcia roszczenia — daje jedynie prawo UCHYLENIA
  SIĘ od zaspokojenia (zarzut procesowy, trzeba go PODNIEŚĆ, sąd nie
  uwzględnia z urzędu). Zrzeczenie się zarzutu przedawnienia PRZED
  upływem terminu jest NIEWAŻNE (chroni słabszą stronę przed presją) —
  można się zrzec tylko PO upływie terminu.
- **Art. 293 — ZAWIESZENIE biegu przy SILE WYŻSZEJ:** bieg nie
  rozpoczyna się, a rozpoczęty ulega zawieszeniu, na czas przeszkody, gdy
  z powodu siły wyższej uprawniony nie może dochodzić roszczeń przed
  właściwym organem. **Art. 293¹ (dodany nowelizacją):** analogiczne
  zawieszenie biegu przedawnienia roszczenia o URLOP WYPOCZYNKOWY na czas
  korzystania z urlopu WYCHOWAWCZEGO.
- **Art. 294 — OCHRONA osób bez pełnej zdolności do czynności prawnych:**
  przedawnienie względem takiej osoby (lub osoby z podstawą do
  ubezwłasnowolnienia) nie może zakończyć się wcześniej niż 2 lata od
  ustanowienia przedstawiciela ustawowego / ustania przyczyny jego
  ustanowienia. Przy TERMINIE ROCZNYM (np. art. 291 §2 — roszczenie
  pracodawcy) bieg liczy się DOPIERO od ustanowienia przedstawiciela.
- **Art. 295 — PRZERWANIE biegu przedawnienia:** przerywa się przez
  KAŻDĄ czynność przed właściwym organem powołanym do rozstrzygania
  sporów (sąd pracy, komisja pojednawcza), podjętą w celu dochodzenia,
  ustalenia, zaspokojenia lub zabezpieczenia roszczenia — **to jest
  odpowiednik "przerwania przez wezwanie do zapłaty" z KC, ale w formie
  procesowej (czynność PRZED organem), nie samego pisma do dłużnika** —
  ⚠️ dokładna pełna treść art. 295 (czy obejmuje też wezwanie
  pozaprocesowe) NIE odczytana w pełni w tej sesji, wymaga dociągnięcia
  przy sprawie, gdzie to rozróżnienie jest kluczowe dla obrony.

**Wniosek praktyczny:** checklist niżej pozostaje aktualny, ale punkt o
"postępowaniu pojednawczym/wezwaniu przerywającym bieg" powinien
odsyłać do art. 295 (przerwanie), nie art. 292 (skutek) jak wcześniej
sugerowano.

### Checklist praktyczny

```
□ Czy roszczenie dotyczy PRACOWNIKA wobec pracodawcy (wynagrodzenie,
  nadgodziny, urlop, odszkodowanie za zwolnienie)? → 3 lata od
  wymagalności (art. 291 §1) — ZASADA DOMYŚLNA
□ Czy roszczenie dotyczy PRACODAWCY o naprawienie szkody wyrządzonej
  przez pracownika? → SPRAWDŹ ODRĘBNIE art. 291 §2 i aktualne
  orzecznictwo SN — NIE zakładaj automatycznie 3 lat od wymagalności,
  termin może liczyć się inaczej (od powzięcia wiadomości o szkodzie)
□ Czy istniało postępowanie przed sądem pracy/komisją pojednawczą mogące
  PRZERWAĆ bieg terminu? → art. 295 (ZWERYFIKOWANE 2026-08-18) — przerywa
  KAŻDA czynność PRZED właściwym organem, nie samo pismo/wezwanie
  pozaprocesowe do dłużnika (⚠️ pełna treść niuansu nie odczytana)
□ Zawsze licz termin OSOBNO dla każdego rodzaju roszczenia w tej samej
  sprawie (wynagrodzenie, nadgodziny, ekwiwalent za urlop mogą mieć
  różne daty wymagalności, mimo wspólnego źródła sporu)
```

---

## INTEGRACJA Z SYSTEMEM

- **`mod-KP-dzial-VI-czas-pracy.md`** — przedawnienie roszczenia o dodatek
  za nadgodziny (3 lata, zasada ogólna art. 291 §1).
- **`mod-KP-dzial-VII-urlopy-pracownicze.md`** — przedawnienie roszczenia
  o ekwiwalent za urlop.
- **`mod-wypadek-przy-pracy-choroba-zawodowa.md`** — możliwy zbieg z
  odpowiedzialnością materialną, jeśli szkoda pracodawcy wynika pośrednio
  z zdarzenia wypadkowego.
- **`mod-ustawa-PIP-inspekcja-pracy.md`** — odpowiedzialność materialna
  NIE jest tożsama z odpowiedzialnością za wykroczenia przeciwko prawom
  pracownika (Dział XIII KP, art. 281-283) — to odrębny reżim (sankcja
  publicznoprawna dla PRACODAWCY, nie roszczenie odszkodowawcze wobec
  PRACOWNIKA) — nie mylić.

---

## LITERATURA I ŹRÓDŁA (zweryfikowane online 2026-07-17)

- Tekst jednolity KP — ISAP/lexlege.pl/e-prawnik.pl (art. 114-127, 291
  potwierdzone z pełną/częściową treścią).
- Standardy Prawa (standardyprawa.pl) — bogata baza orzecznictwa SN/SA/SO
  do art. 114-127 i art. 291 §2 (kilkanaście odrębnych linii orzeczniczych
  zidentyfikowanych, nie w pełni zrekonstruowanych treściowo).
- inforlex.pl — komentarz praktyczny do art. 114-115 (ciężar dowodu,
  brak domniemania winy przy szkodzie niepowierzonej).
