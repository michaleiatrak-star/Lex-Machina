# Moduł — Aktywny Rodzic (babciowe i inne świadczenia)

**Akt:** UAktRodz (ustawa o wspieraniu rodziców w aktywności zawodowej — „Aktywny rodzic”) — t.j. Dz.U. 2026 poz. 532 (zm. 2026/1123 [OD 2028-01-01: 2026/1123] — m.in. art. 3, 7, 9, 10, 15, 18a, 18c, 29, 35, 44, 47–49b).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

**Status:** moduł klasy kancelaryjnej — poziom DR-03

## Akt prawny
**Ustawa z 15.05.2024 r. o wspieraniu rodziców w aktywności zawodowej oraz w wychowaniu dziecka — „Aktywny Rodzic"**
- **Dz.U. 2024 poz. 858** (weszła w życie 01.10.2024)
  ✅ VER: isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20240000858 [2026-05-31]

**Weryfikacja w ELI (RZĄD 1) przed każdym cytowaniem.**

## Zakres — trzy warianty świadczenia
⚠️ POPRAWKA 2026-07-27 (FAZA 3E/ZASADA 14) — 2 błędy naprawione:
(1) "babciowe" to potoczna nazwa WARIANTU 1 ("aktywni rodzice w
pracy"), NIE wariantu 3 jak błędnie wcześniej podpisano — potwierdzone
jednogłośnie w 7+ źródłach (infor.pl, bliskoedu.pl, interia.pl);
(2) pominięto wyższą stawkę 1900 zł dla dziecka z orzeczeniem o
niepełnosprawności — dotyczy WARIANTU 1, nie tylko podstawowych 1500 zł.
```
1. „Aktywni rodzice w pracy" (potocznie: BABCIOWE): 1500 zł/mc — gdy
   oboje rodzice pracują (lub jeden z niepełnosprawnością lub student);
   1900 zł/mc gdy DZIECKO ma orzeczenie o niepełnosprawności — dla
   opieki organizowanej poza żłobkiem (niania, babcia, opiekun)
2. „Aktywnie w żłobku":              do 1500 zł/mc — na opłacenie żłobka (klub dziecięcy,
                                      opiekun dzienny) — wiek dziecka do lat 3, kwota
                                      zależna od faktycznej opłaty placówki
3. „Aktywnie w domu":                500 zł/mc — gdy dziecko wychowywane w domu
                                      przez rodzica niepracującego (NIE "babciowe" —
                                      to osobna, trzecia nazwa/wariant)
```

## Warunki nabycia prawa
```
Dziecko: od 12 miesiąca życia do ukończenia 3 lat (lub 4 lat gdy brak miejsca w żłobku)
Wniosek: do ZUS przez PUE ZUS
Wykluczenia: Nie przysługuje gdy dziecko uczęszcza do żłobka finansowanego z budżetu
             (przy wariancie "aktywnie w domu")
```

## Zasady absolutne
```
Jedno ze świadczeń wyłącznie: Nie można łączyć wariantów na to samo dziecko
Opodatkowanie: Świadczenia ZWOLNIONE z PIT
Organ: ZUS (wypłata), gmina (rejestracja opiekuna przy babciowym)
Niania: Może być niezatrudniona formalnie — świadczenie możliwe
```

## Weryfikacja online
```
web_search: "aktywny rodzic babciowe Dz.U. 2024 poz. 858 warunki 2025"
web_search: "aktywni rodzice w pracy żłobek 1500 zł wniosek ZUS 2025"
```


---

## QUALITY GATE

- [ ] Aktualny tekst t.j. aktu zweryfikowany w ISAP?
- [ ] Stan prawny właściwy temporalnie (na dzień zdarzenia i na dzień orzekania)?
- [ ] Każda przesłanka ma przypisany dowód?
- [ ] Termin nie upłynął?
- [ ] Właściwy organ / sąd wskazany?
- [ ] Ryzyka formalne i dowodowe ocenione?
- [ ] Brzmienie przepisów ze źródeł, nie z pamięci modelu?

## OUTPUT

1. Stan faktyczny; 2. Stan prawny i źródła; 3. Kwalifikacja trybu i właściwość;
4. Terminy (obliczone, daty graniczne); 5. Przesłanki (spełnione / wątpliwe / niespełnione);
6. Matryca dowodowa (teza → dowód → siła → luka); 7. Zarzuty i kontrargumenty;
8. Analiza ryzyk; 9. Strategia (podstawowy + ewentualny); 10. Rekomendacja;
11. Kontrola ISAP/temporalności.
