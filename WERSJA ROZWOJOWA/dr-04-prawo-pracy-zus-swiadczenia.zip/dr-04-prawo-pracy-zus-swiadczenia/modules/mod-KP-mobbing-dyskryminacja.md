# mod-KP-mobbing-dyskryminacja.md

**Akt:** KP — t.j. Dz.U. 2026 poz. 1245 (stan 2026-08-27; zm. 2026/1046 od 2026-11-05 — art. 18³d, 94³, 94³ᵃ: mobbing i równe traktowanie, oba brzmienia w t.j. z odnośnikami).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).
## DR-04 · Prawo Pracy · Mobbing, dyskryminacja, molestowanie — kwalifikacja i strategia

> Wydzielony 2026-06-12 z mod-KP-prawo-pracy.md (ANEKS A).
> Definicja mobbingu i linia orzecznicza SN: → prawo-polskie-v2/krajowe/shared/definicje/DEF-PRACA.md
> (eliminacja duplikacji — ten moduł skupia się na KWALIFIKACJI RÓŻNICUJĄCEJ
> (mobbing/dyskryminacja/molestowanie) i STRATEGII PROCESOWEJ.

## ⛔ HARD GATE — ZAKAZ CYTOWANIA Z PAMIĘCI

**PRZED każdym powołaniem przepisu, artykułu, terminu lub sygnatury:**
1. Zweryfikuj brzmienie i Dz.U. w `ELI (RZĄD 1)`
2. Zweryfikuj orzeczenie w `orzeczenia.ms.gov.pl` / `nsa.gov.pl` / `sn.pl`
3. **NIGDY** nie podawaj artykułu, terminu, kary ani sygnatury wyłącznie z pamięci modelu.

---

## ANEKS A — MOBBING I DYSKRYMINACJA (art. 94³ i art. 18³a-18³e KP)

### ⛔⛔ REFORMA ANTYMOBBINGOWA — W VACATIO LEGIS DO 4.11.2026

Odczyt RZĄD 1 (`api.sejm.gov.pl/eli/acts/DU/2026/1046`, 2026-09-10):
**ogłoszenie 4.08.2026, WEJŚCIE W ŻYCIE 5.11.2026.**

| Zdarzenie | Stan prawny |
|---|---|
| **przed 5.11.2026** | ⛔ **STARE** brzmienie art. 94³ KP: wymóg rozstroju zdrowia, brak minimum zadośćuczynienia, brak art. 477⁶ᵃ KPC |
| **od 5.11.2026** | nowe brzmienie — wiersze oznaczone „PO REFORMIE" w tabeli niżej |

⛔ **Data 30.07.2026 to podpis Prezydenta, nie wejście w życie.** Wcześniejsza
wersja tego modułu używała jej jako cezury („PO REFORMIE (od 30.07.2026)"), co
przy sprawie z sierpnia albo września 2026 prowadziło do zastosowania przepisu,
który jeszcze nie obowiązuje. To jest błąd zakresu czasowego normy — klasa,
której pilnuje OŚ-GATE, popełniony w samym module.

⚠️ „Status: obowiązujący" w ELI znaczy tylko tyle, że akt nie został uchylony.
Data wejścia w życie jest osobnym polem i to ona rozstrzyga.

### ⚡ ZNALEZISKO 2026-07-30 — REFORMA PODPISANA PRZEZ PREZYDENTA

**Ustawa antymobbingowa** (zmiana KP + KPC) PODPISANA przez Prezydenta
Karola Nawrockiego **30.07.2026** (DZIŚ na dzień tej weryfikacji) —
wchodzi w życie za 3 miesiące od ogłoszenia. PEŁNA analiza zmian
(nowa definicja, kwota 6× minimalne wynagrodzenie ≈28 836 zł, próg 9
pracowników, prawo regresu, nowy art. 477⁶ᵃ KPC) →
`prawo-polskie-v2/krajowe/shared/definicje/DEF-PRACA.md`, sekcja MOBBING — TAM jest KANONICZNA
treść, NIE duplikuj tutaj. ✅ **TODO ZAMKNIĘTE 2026-09-10.** Wiersze „Powtarzalność" i „Min. odszkodowanie"
niosą już oba stany z jawną cezurą czasową. Zdanie „tabela OPISUJE STAN SPRZED
reformy" było nieaktualne wobec własnej treści tabeli — moduł przeczył sam sobie,
ta sama klasa co rozjazd nagłówek/treść z AUDYT-2026-09-10h.

### Rozróżnienie czynów — kwalifikator

| Cecha | Mobbing (art. 94³ KP) | Dyskryminacja (art. 18³a KP) | Molestowanie seksualne (art. 18³a §6 KP) |
|---|---|---|---|
| Cecha chroniona | NIE | TAK (płeć, wiek, religia, niepełnosprawność itd.) | TAK |
| Powtarzalność | ⚠️ **OD 5.11.2026**: "nawracający, powtarzający się lub stały" charakter, BEZ WZGLĘDU na skutki/motywacje (dawniej: uporczywe + długotrwałe, OBA łącznie) — patrz prawo-polskie-v2/krajowe/shared/definicje/DEF-PRACA.md | NIE — jednorazowe wystarczy | NIE |
| Ciężar dowodu | **Pracownik — przez cały proces** | Pracownik uprawdopodabnia → ciężar PRZESUWA SIĘ na pracodawcę | Pracodawca NIE może uzasadnić obiektywnie |
| Min. odszkodowanie | ⚠️ **OD 5.11.2026**: **6× minimalne wynagrodzenie** — ⛔ kwota złotowa zależy od minimalnego wynagrodzenia w dacie orzekania, sprawdzić w rozporządzeniu RM; do 4.11.2026: **brak minimum** | min. wynagrodzenie za pracę | min. wynagrodzenie za pracę |

### Definicja i przesłanki mobbingu

⚠️ TREŚĆ PRZENIESIONA 2026-06-12 — definicja ustawowa, 5 przesłanek i pełna
linia orzecznicza SN (przesłanki sporne: długotrwałość, uporczywość, wzorzec
"ofiary rozsądnej", zamiar sprawcy) są w jednym miejscu:
→ `view prawo-polskie-v2/krajowe/shared/definicje/DEF-PRACA.md` (sekcja MOBBING)

### Roszczenia

| Roszczenie | Podstawa | Przesłanki | Min. kwota |
|---|---|---|---|
| Zadośćuczynienie | art. 94³ §3 KP | Mobbing + rozstrój zdrowia | brak limitu dolnego |
| Odszkodowanie po rozwiązaniu umowy | art. 94³ §4–5 KP | Mobbing + rozwiązanie umowy przez pracownika | min. wynagrodzenie |
| Odszkodowanie za dyskryminację | art. 18³d KP | Dyskryminacja | min. wynagrodzenie |

### Strategia dowodowa pracownika (mobbing)

```
□ Dziennik mobbingu — data, godzina, opis, świadkowie, reakcja (prowadzić na bieżąco)
□ Screenshoty e-maili / SMS / komunikatorów (wyślij na prywatny adres)
□ Nagrania własnych rozmów z przełożonym (LEGALNE w Polsce jako dowód)
□ Dokumentacja medyczna — zaświadczenia, historia leczenia, psychiatra
□ Skargi złożone do pracodawcy + odpowiedzi
□ Protokół PIP z kontroli (jeśli złożono skargę)
□ Zeznania świadków (byli pracownicy zeznają swobodniej)
```

### Strategia obrony pracodawcy

```
□ Linia 1: Brak przesłanek — jednostkowe incydenty, uzasadniona krytyka zawodowa
□ Linia 2: Wdrożona WPA (Wewnętrzna Polityka Antymobbingowa)
□ Linia 3: Obiektywne przyczyny decyzji kadrowych (przy dyskryminacji)
□ Linia 4: Brak związku przyczynowego z rozstrojem zdrowia pracownika
```

### Projekt nowelizacji KP — UD183 / RM 17.02.2026 — WERYFIKUJ STATUS

```
⚠️ SCALONE 2026-06-12: ten projekt jest opisany w dwóch miejscach z różnymi
szczegółami — oba dotyczą TEGO SAMEGO projektu (numer RCL: UD183, przyjęty
przez Radę Ministrów 17.02.2026, stan na 10.06.2026: w Sejmie, NIE ustawa):

PLANOWANE ZMIANY (zestaw scalony):
  → Nowa definicja mobbingu — wykluczenie zachowań incydentalnych
  → "Nawracający lub stały" charakter zamiast "długotrwały"
  → Formy: fizyczna, werbalna, pozawerbalna
  → Sprawca: przełożony, współpracownik, podwładny LUB GRUPA
  → Min. zadośćuczynienie: 6× minimalne wynagrodzenie (2026: ~28 000 zł)
  → Obowiązek regulaminu antymobbingowego: pracodawca ≥10 osób
    (⚠️ POPRAWIONE 2026-08-08: próg PODNIESIONO z 9 na 10 między
    projektem a ostateczną, podpisaną ustawą z 19.06.2026 — art.
    94³a KP — szczegóły: prawo-polskie-v2/krajowe/shared/definicje/DEF-PRACA.md)
  → PRAWO REGRESU pracodawcy wobec mobbera (pracodawca, który wypłacił
    zadośćuczynienie, może żądać zwrotu od pracownika-mobbera)
  → Planowane odejście od wymogu intencjonalności sprawcy

Pełna treść alertu: → view prawo-polskie-v2/krajowe/shared/definicje/DEF-PRACA.md (sekcja MOBBING)
web_search: "UD183 nowelizacja kodeks pracy mobbing Sejm 2026 status pierwsze czytanie"
```

### Przedawnienie roszczeń mobbingowych

```
Roszczenia ze stosunku pracy: 3 lata (art. 291 KP)
Termin biegnie od dnia wymagalności roszczenia
⚠️ Weryfikuj aktualne brzmienie art. 291 KP w ELI (RZĄD 1).
```

---


---

## ŁĄCZ Z
- `prawo-polskie-v2/krajowe/shared/definicje/DEF-PRACA.md` — definicja mobbingu, 5 przesłanek, linia SN,
  pełny alert nowelizacji UD183
- `mod-KP-prawo-pracy.md` — gdy mobbing jest PRZYCZYNĄ rozwiązania umowy
  przez pracownika (art. 55 §1¹ KP — rozwiązanie z winy pracodawcy)
- DR-16 (pisma) — strategia dowodowa przy redagowaniu pozwu o mobbing

---
*mod-KP-mobbing-dyskryminacja.md · dr-04/modules/ · 2026-06-12*
*Wydzielony z mod-KP-prawo-pracy.md ANEKS A, scalono projekt UD183/RM 17.02.2026*
