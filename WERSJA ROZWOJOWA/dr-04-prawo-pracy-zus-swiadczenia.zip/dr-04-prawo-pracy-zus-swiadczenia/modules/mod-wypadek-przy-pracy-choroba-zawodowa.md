# mod-wypadek-przy-pracy-choroba-zawodowa.md

**Akt:** KP — t.j. Dz.U. 2026 poz. 1245 (stan 2026-08-27; zm. 2026/1046 od 2026-11-05 — art. 18³d, 94³, 94³ᵃ: mobbing i równe traktowanie, oba brzmienia w t.j. z odnośnikami).
**Akt:** UWyp (ustawa o ubezpieczeniu społecznym z tytułu wypadków przy pracy i chorób zawodowych) — t.j. Dz.U. 2025 poz. 1644 (zm. 2025/1083 od 2026-01-01 — art. 3, 5, 6; 2026/26 [OD 2027-01-01: 2026/26] — art. 2, 15, 16).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).
## DR-04 · Prawo Pracy/ZUS · Wypadek przy pracy i choroba zawodowa — procedura

> Wydzielony 2026-06-12 z mod-KP-prawo-pracy.md (ANEKS B).
> Definicja wypadku przy pracy (4 elementy + typy): → prawo-polskie-v2/krajowe/shared/definicje/DEF-PRACA.md
> Ten moduł skupia się na PROCEDURZE: intake, świadczenia, terminy, ścieżka sporna.

## ⛔ HARD GATE — ZAKAZ CYTOWANIA Z PAMIĘCI

**PRZED każdym powołaniem przepisu, artykułu, terminu lub sygnatury:**
1. Zweryfikuj brzmienie i Dz.U. w `ELI (RZĄD 1)`
2. Zweryfikuj orzeczenie w `orzeczenia.ms.gov.pl` / `nsa.gov.pl` / `sn.pl`
3. **NIGDY** nie podawaj artykułu, terminu, kary ani sygnatury wyłącznie z pamięci modelu.

---

## ANEKS B — WYPADEK PRZY PRACY I CHOROBA ZAWODOWA

### Akty prawne (weryfikuj Dz.U. w ELI (RZĄD 1))
```
Ustawa z dnia 30.10.2002 r. o ubezpieczeniu społecznym z tytułu wypadków
przy pracy i chorób zawodowych — Dz.U. 2025 poz. 1644 t.j. (obwieszczenie
Marszałka Sejmu z 28.11.2025), ze zm. Dz.U. 2026 poz. 26
  ✅ VER: isap.sejm.gov.pl (dokument źródłowy Kancelarii Sejmu, 28.11.2025),
    dziennikustaw.gov.pl (obwieszczenie MRPiPS 16.03.2026 wciąż cytuje ten
    t.j. jako aktualny), forsal.pl — 2026-08-14 (F-77)
  ⚠️ [F-77] poprzedni zapis modułu (Dz.U. 2022 poz. 2189) był DWUKROTNIE
  nieaktualny — pominięty pośredni t.j. Dz.U. 2025 poz. 1644 (21.02.2025)

Kodeks pracy — art. 234–237 KP (obowiązki pracodawcy po wypadku)
  → weryfikuj: Dz.U. 2026 poz. 1245 t.j. ze zm.
```

### Definicja wypadku przy pracy — 4 elementy

⚠️ TREŚĆ PRZENIESIONA 2026-06-12 — definicja ustawowa (art. 3 ust.1), 4 elementy
konieczne (nagłość/przyczyna zewnętrzna/uraz lub śmierć/związek z pracą),
typy wypadków (lekki/ciężki/śmiertelny/zbiorowy) i wypadek zrównany (art. 3 ust.2)
są w jednym, bardziej szczegółowym miejscu:
→ `view prawo-polskie-v2/krajowe/shared/definicje/DEF-PRACA.md` (sekcja H.1.4)

### INTAKE wypadkowy — pytania obowiązkowe
```
□ Data i miejsce wypadku?
□ Czy wypadek zgłoszono pracodawcy (art. 234 §1 KP — obowiązek niezwłocznie)?
□ ⭐ Czy wypadek jest CIĘŻKI/ŚMIERTELNY/ZBIOROWY — jeśli TAK, sprawdź
  czy pracodawca ZAWIADOMIŁ okręgowego inspektora PRACY i PROKURATORA
  (art. 234 §2 KP, patrz sekcja "ZAWIADOMIENIE PIP I PROKURATORA" niżej)
□ Czy sporządzono protokół powypadkowy (obowiązek ustalenia okoliczności — art. 234 §1 KP; termin 14 dni wynika z rozporządzenia o ustalaniu okoliczności i przyczyn wypadków, nie z KP ⚠️ [NIEWERYFIKOWANE])?
□ Czy pracownik podpisał/zakwestionował protokół?
  → Zakwestionowanie: złożyć uwagi na piśmie, wnioskować o uzupełnienie
□ Czy ZUS wydał decyzję o uznaniu/odmowie uznania wypadku?
□ Jaki uszczerbek na zdrowiu (stały / długotrwały)?
□ Czy pracodawca naruszył przepisy BHP → roszczenie uzupełniające z KC!
```

### Świadczenia z ubezpieczenia wypadkowego (weryfikuj kwoty w ELI (RZĄD 1))
```
JEDNORAZOWE ODSZKODOWANIE (art. 11 ustawy):
  → Wypłacane przez ZUS za stały lub długotrwały uszczerbek na zdrowiu
  → Kwota: X% × stawka za 1% uszczerbku (weryfikuj aktualną stawkę przez web_search)
  → Wniosek do ZUS; termin: nie wcześniej niż po zakończeniu leczenia i rehabilitacji

ZASIŁEK CHOROBOWY wypadkowy: 100% podstawy wymiaru (bez okresu wyczekiwania)

RENTA WYPADKOWA z ZUS: gdy niezdolność do pracy trwała po wypadku

ROSZCZENIA UZUPEŁNIAJĄCE Z KC (gdy wina pracodawcy):
  → Renta wyrównawcza (art. 444 §2 KC)
  → Zadośćuczynienie (art. 445 KC) — odrębne od jednorazowego odszkodowania ZUS
  → Odszkodowanie za koszty leczenia (art. 444 §1 KC)
  → Warunek: wykazanie winy pracodawcy (naruszenie BHP) + związek przyczynowy
```

### Terminy krytyczne
```
Zgłoszenie wypadku przez pracownika pracodawcy: NIEZWŁOCZNIE (art. 234 §2 KP)
Protokół powypadkowy: 14 dni od zawiadomienia — rozporządzenie o ustalaniu okoliczności i przyczyn wypadków przy pracy (art. 234 §1 KP nie zawiera terminu) ⚠️ [NIEWERYFIKOWANE]
Zatwierdzenie protokołu przez pracodawcę: niezwłocznie po sporządzeniu
Wniosek o jednorazowe odszkodowanie do ZUS: po zakończeniu leczenia/rehabilitacji
Przedawnienie roszczeń z KC (wypadek): 3 lata od dnia, gdy poszkodowany dowiedział
  się o szkodzie i zobowiązanym (art. 442¹ § 1 KC).
  ⛔ SZKODA NA OSOBIE (art. 442¹ § 3): przedawnienie nie może skończyć się wcześniej niż 3 lata od dowiedzenia się — granica 10 lat NIE obowiązuje
  — wypadek przy pracy to szkoda na osobie; małoletni — nie wcześniej niż 2 lata od
  pełnoletności (§ 4); przestępstwo — 20 lat od czynu (§ 2). ✅ [VER] RZĄD 1 2026-09-16f (KC `Dz.U. 2026 poz. 795`)
```

### Ścieżka sporna
```
Pracodawca kwestionuje wypadek w protokole?
  → Złóż pisemne zastrzeżenia do protokołu
  → Wniosek do ZUS o ustalenie okoliczności wypadku

ZUS odmawia świadczenia?
  → Odwołanie do Sądu Pracy (Wydział Pracy i Ubezpieczeń Społecznych)
  → Termin: 1 miesiąc od doręczenia decyzji ZUS (art. 477⁹ KPC)

Choroba zawodowa:
  → Wykaz chorób zawodowych: rozporządzenie RM z 30.06.2009 w sprawie chorób
    zawodowych — t.j. Dz.U. 2026 poz. 1297 (ELI 2026-10-09; przed powołaniem
    sprawdź nowelizacje po t.j. w ELI, RZĄD 1)
  → Organ: Państwowy Inspektor Sanitarny (PIS) → decyzja → ZUS → świadczenia
```

### Źródła online
```
web_search: "ustawa wypadkowa 2002 isap.sejm.gov.pl jednorazowe odszkodowanie stawka 2025 2026"
web_search: "choroba zawodowa wykaz rozporządzenie RM isap.sejm.gov.pl 2024 2025"
web_search: "wypadek przy pracy protokół powypadkowy BHP rozporządzenie wzór 2025"
```

---

---

## ⭐⭐ ZAWIADOMIENIE PIP I PROKURATORA — WYPADEK CIĘŻKI/ŚMIERTELNY/ZBIOROWY (art. 234 §2 KP) — dodane 2026-07-21

> Odrębny, DODATKOWY obowiązek — poza zwykłym zgłoszeniem pracodawcy
> (art. 234 §1, patrz INTAKE wyżej) i poza sporządzeniem protokołu
> powypadkowego.

```
□ OBOWIĄZEK: pracodawca MUSI NIEZWŁOCZNIE zawiadomić WŁAŚCIWEGO
  OKRĘGOWEGO INSPEKTORA PRACY i PROKURATORA o wypadku ŚMIERTELNYM,
  CIĘŻKIM lub ZBIOROWYM, oraz o KAŻDYM INNYM wypadku, KTÓRY wywołał
  TAKIE skutki, mającym związek z pracą, JEŻELI może być uznany za
  wypadek przy pracy
□ ⭐ MOMENT liczenia "niezwłoczności" — sporny w doktrynie, ALE
  PRZEWAŻAJĄCE stanowisko: termin liczy się NIE od SAMEGO zdarzenia,
  lecz od CHWILI, gdy pracodawca UZNAJE (kwalifikuje wstępnie), że
  zdarzenie NOSI cechy wypadku ciężkiego/śmiertelnego/zbiorowego — DO
  TEGO momentu, dopóki istnieją WĄTPLIWOŚCI co do kwalifikacji,
  pracodawca NIE MA jeszcze obowiązku zawiadomienia
□ NIEZALEŻNIE od tego, czy POLICJA, załoga POGOTOWIA, personel
  SZPITALA/przychodni JUŻ powiadomiły PIP o zdarzeniu — pracodawca MA
  WŁASNY, ODRĘBNY obowiązek zawiadomienia (obowiązki się NIE
  WYKLUCZAJĄ ani nie zastępują)
□ ⭐ SZCZEGÓLNA KONSEKWENCJA na miejscu zdarzenia: zgodę na
  URUCHOMIENIE maszyn LUB dokonanie ZMIAN w miejscu wypadku wyraża
  pracodawca PO UZGODNIENIU z WŁAŚCIWYM inspektorem pracy I
  prokuratorem — miejsce wypadku NIE MOŻE być dowolnie zmieniane do
  czasu tego uzgodnienia

⭐ SANKCJA za NIEZAWIADOMIENIE:
  □ Jeśli zdarzenie od POCZĄTKU WYPEŁNIAŁO przesłanki ciężkiego/
    śmiertelnego/zbiorowego wypadku, a pracodawca NIE zawiadomił —
    WYKROCZENIE z art. 283 §2 pkt 6 KP
  □ ⭐ JEŚLI dopiero PÓŹNIEJ ujawni się (np. po zatwierdzeniu protokołu
    powypadkowego, LUB nawet po prawomocnym wyroku sądu ustalającym
    NA NOWO treść protokołu), że zdarzenie BYŁO w istocie wypadkiem
    ciężkim/śmiertelnym/zbiorowym — MOŻLIWA odpowiedzialność ZA
    PÓŹNIEJSZE, ale zasadniczo BEZ winy za pierwotny brak zawiadomienia
    (skoro w momencie zdarzenia BRAK było przesłanek do jego
    rozpoznania jako takiego)

Checklist praktyczny:
□ Czy KWALIFIKACJA wypadku (ciężki/śmiertelny/zbiorowy) BYŁA możliwa
  do ustalenia OD RAZU, czy ujawniła się DOPIERO później — wpływa na
  ocenę, CZY doszło do NARUSZENIA obowiązku zawiadomienia
□ Czy zawiadomiono ZARÓWNO okręgowego inspektora pracy, JAK I
  prokuratora — OBA podmioty są wymagane, nie wystarczy jeden
□ Czy MIEJSCE wypadku było ZABEZPIECZONE do czasu uzgodnienia z
  inspektorem/prokuratorem możliwości uruchomienia maszyn/zmian
□ Czy klient (pracodawca) BRONI się argumentem "Policja/pogotowie już
  zgłosiło" — WYJAŚNIJ, że to NIE ZWALNIA z WŁASNEGO obowiązku
```

## ŁĄCZ Z

- `prawo-polskie-v2/krajowe/shared/definicje/DEF-PRACA.md` — definicja wypadku przy pracy (4 elementy),
  H.6 zasiłki/świadczenia ZUS
- `mod-KP-prawo-pracy.md` — gdy wypadek jest podstawą roszczeń pracowniczych
  (rozwiązanie umowy z winy pracodawcy przy naruszeniu BHP)
- DR-15 (compliance) — gdy sprawa dotyczy systemowych naruszeń BHP
- ⚠️ DODANE 2026-07-30: ASPEKT KARNY śmiertelnego wypadku (art. 220 KK
  — narażenie; art. 155 KK — jeśli śmierć faktycznie nastąpiła; art.
  283 §1 KP — wykroczenie gdy brak bezpośredniego związku) → DR-03,
  `mod-KK-art148-162-przeciwko-zyciu-zdrowiu.md` sekcja CROSS-
  REFERENCJE — TEN moduł (dr-04) dostarcza WYŁĄCZNIE aspekt
  administracyjno-pracowniczy, unikaj duplikacji

---
*mod-wypadek-przy-pracy-choroba-zawodowa.md · dr-04/modules/ · 2026-06-12*
*Wydzielony z mod-KP-prawo-pracy.md ANEKS B*
