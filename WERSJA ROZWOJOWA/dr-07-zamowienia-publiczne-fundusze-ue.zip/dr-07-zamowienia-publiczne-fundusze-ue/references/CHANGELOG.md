# CHANGELOG — dr-07-zamowienia-publiczne-fundusze-ue

- 3.26 (2026-11-15): DR-02: testy prawa upadłościowego (okno znacznika poziomu A); odesłania do KATALOG-TJ w DR; mapy_tj zachowuje katalog w przebiegu dziennym; check_procedowane zarejestrowany
- 3.25 (2026-11-15): Pełny katalog obowiązujących t.j. (2 664 akty z ELI) w KATALOG-TJ dziedzin i prawo-polskie-v2: dziedzina z nagłówka modułu, podstawy prawnej aktu wykonawczego albo tytułu; monitoring projektów ustaw (PROJEKTY-W-TOKU), lista zmian od ostatniej aktualizacji systemu (ZMIANY-OD-AKTUALIZACJI, STAN-AKTUALIZACJI.json)
- 3.24 (2026-11-14): Konwencja t.j.: KATALOG-TJ.md w DR-01…15 i prawo-polskie-v2 (akty z nagłówków modułów), MAPA-AKTOW tylko routing z sufiksem t.j., scripts/mapy_tj.py w dziennym workflow ELI
- 3.23 (2026-11-14): Mapy aktów w jednej konwencji t.j.: MAPA-AKTOW DR-01…15 uzupełnione o 105 aktów z nagłówków modułów (sekcja RAG bez wpływu na routing), sufiks t.j. w tabelach routingu, LEGAL-REGISTRY: 247 tekstów jednolitych systemu; scripts/mapy_tj.py w dziennym workflow ELI
- 3.22 (2026-11-14): DR-07: wskazania z kwalifikatorem (PZP 2026/793, PrNot, NIK, RIO, UNDFP, UZRFE, pomoc publiczna); UNDFP art. 31 ust. 4 zamiast art. 34; W-4 2026/1099
- 3.21 (2026-11-11, ELI 2026-11-11): MAPA-AKTOW: ustawa wdrożeniowa 2021–2027 — zmiany po t.j. 2025/1733: 2025/1844, 2026/912 art. 86.
- 3.20 (2026-11-11, ELI 2026-11-11): Ustawa o zasadach prowadzenia polityki rozwoju — t.j. Dz.U. 2026 poz. 1366 (zastępuje 2025/198; obejmuje 2025/1846: art. 5 pkt 7ac, art. 14ll–14lr, rozdz. 2ac; hierarchia dokumentów bez zmian); MAPA-AKTOW.
- 3.19 (2026-11-06): migracja prawa polskiego E3: ścieżki odwołań do modułów przeniesionych z shared i skilli wykonawczych do prawo-polskie-v2/krajowe/ (treść bez zmian)
- 3.18 (2026-10-20, LEXAGENTO-P1): mod-PZP XI-XII: pełna ścieżka modułu PIP
- 3.17 (2026-10-20, AUDYT-2026-10-20g): SKILL.md: znacznik `lex:wykonuje-aplikacja: REJESTR-MODULOW` nad rejestrem modułów — w trybie mechanicznym aplikacja podaje modelowi indeks nazw (moduły aktów dobiera z MAPA-AKTOW), w AUTO rejestr w całości
- 3.16 (2026-10-20, AUDYT-2026-10-20b): MAPA-AKTOW: Pzp — DU/2026/1347 art. 6 (art. 214 ust. 1 pkt 10, art. 364 ust. 1 pkt 1 bez „świadectw pochodzenia biogazu rolniczego”) od 1.12.2026.

- 3.15 (2026-10-09g, AUDYT-2026-10-09g): mod-ustawa-fundusze-UE-pomoc-publiczna: ustawa wdrożeniowa — t.j. 2025/1733 jest pierwszym t.j. (było „zastępuje t.j. 2024.1655” — rozp. MON); nowelizacje po t.j. 2025/1844, 2026/912.

- 3.14 (2026-10-05l, AUDYT-2026-10-05l): mod-PZP-wykonanie-umowy-compliance: linia „Hasła spraw”. Treść prawna bez zmian.

- 3.13 (2026-10-04n, AUDYT-2026-10-04n): Historia zmian SKILL.md i modułów przeniesiona z plików roboczych do `references/HISTORIA-ZMIAN-PLIKOW.md` (plik historyczny, niewczytywany przez model). Treść robocza bez zmian.

- 3.12 (2026-09-27e, AUDYT-2026-09-27e): claude.ai po dodaniu marketplace instalował wyłącznie 4 z 32 pluginów (shared, prawny-router-v3, analizator-dowodow-v3, przesluchanie-swiadkow-v2-min90); jedyna cecha wspólna tych 4, nieobecna w żadnym z 28 pozostałych, to klucz `dependencies` we frontmatterze SKILL.md. Dodano go (`requires: [shared]` — zgodnie ze stanem faktycznym) oraz jawny manifest pluginu (name, description = description z SKILL.md, author, repository, license) — host nie musi niczego wnioskować z SKILL.md. `version` w manifeście = `version:` z SKILL.md (pilnuje T38 w audyt-systemu-v4) — host rozpoznaje aktualizację po podbiciu wersji. Treść skilla bez zmian.
- 3.11 (2026-09-23, AUDYT-2026-09-23b): kanon E-1…E-5 (`shared/HIERARCHIA-ZRODEL.md` 1.10): instrukcje weryfikacji „w ISAP” / „isap.sejm.gov.pl →” zamienione na „w ELI (RZĄD 1)” (13 plików); ISAP pozostaje adresem dla człowieka; wpisy historyczne („zweryfikowano w ISAP …”) bez zmian.
- 3.10 (2026-09-16, F-189): mod-PZP-zamowienia-publiczne-KIO — sekcja 4 „Terminy” przebudowana z odczytu (RZĄD 1 — PZP 2026/793): ⛔ „10 dni od publikacji w BZP (gdy brak powiadomienia)” → 10 dni przy informacji przekazanej inną drogą niż elektroniczna; wpis — art. 517 ust. 2 (nie 519); dopisane art. 515 ust. 3–4, 514 ust. 2 i 528 pkt 6, 525, 509, 585 ust. 2, art. 398⁵ KPC, art. 34 KSCU; art. 544 ust. 1 zd. 2; ⛔ art. 138 — brak terminu ofert poniżej 15 dni (F-135).
- 3.9 (2026-08-27): dodano moduł uzupełniający PZP dla pozostałych luk Działów I/II/III/VIII/X; zsynchronizowano mapy/routing.

- 3.8 (2026-08-26): zarejestrowano istniejący moduł Działu IV PZP i
  zsynchronizowano licznik modułów 19/19.
- 3.7 (2026-08-26): ujednolicono metryki tekstów jednolitych w modułach
  notarialnym oraz funduszy UE.
