# Modul - Najwyzsza Izba Kontroli (NIK)

**Akt:** NIK (ustawa o Najwyższej Izbie Kontroli) — t.j. Dz.U. 2022 poz. 623 (zm. po t.j.: 2026/26 [OD 2027-01-01: 2026/26] — art. 92, 93).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

## Akt prawny
**Ustawa z 23.12.1994 r. o Najwyzszej Izbie Kontroli**
- Tekst jednolity: **Dz.U. 2022 poz. 623** (ze zm.)
  VER: isap.sejm.gov.pl [2026-05-31] - weryfikuj aktualny t.j.!
- Podstawa: art. 202-207 Konstytucji RP

**Weryfikacja w ELI (RZĄD 1) przed kazdy cytowaniem.**

## Status i niezaleznosc
NIK = naczelny organ kontroli panstwowej.
Podlega Sejmowi. Prezes NIK powoływany przez Sejm za zgoda Senatu.

## Zakres kontroli
```
Kontrola obowiazkowa (art. 2 ust. 1):
  - organy administracji rzadowej, NBP, panstwowe osoby prawne
  - inne jednostki organizacyjne w zakresie srodkow publicznych

Kontrola fakultatywna (art. 2 ust. 2):
  - organy samorzadu terytorialnego i JST
  - inne podmioty w zakresie wykorzystania dotacji z budzetu lub majtku publicznego
```

## Kryteria kontroli NIK (art. 5)
```
Legalnosc:    Zgodnosc z prawem
Gospodarczosc: Efektywnosc ekonomiczna
Celowosc:     Czy osiagnieto zakladane cele
Rzetelnosc:   Prawdziwosc danych, dokumentow
```

## Procedura kontrolna
```
Upowazmienie:  Kontroler legitimuje sie upowazmeniem
Protokol:      Podpisywany przez kierownika jednostki kontrolowanej (lub zastrzezenia)
Zastrzezenia:  ⚠️ POPRAWKA 2026-07-27 (FAZA 3E/ZASADA 14) — poprzednia
               wersja podawała błędnie "14 dni". Aktualny art. 54 ustawy
               o NIK (t.j. Dz.U. 2022 poz. 623, potwierdzone lexlege.pl,
               arslege.pl) stanowi: zastrzeżenia do WYSTĄPIENIA
               POKONTROLNEGO wnosi się w terminie 21 DNI od jego
               przekazania. ⚠️ NIEROZSTRZYGNIĘTE W TEJ SESJI: część
               starszych źródeł (z 2010 r.) mówi o odrębnym terminie
               14-dniowym dla zastrzeżeń do samego "protokołu kontroli"
               — ale te same starsze źródła wskazują, że nowelizacja z
               2010 r. wprowadziła REZYGNACJĘ ZE SPORZĄDZANIA ODRĘBNEGO
               PROTOKOŁU KONTROLI na rzecz wystąpienia pokontrolnego —
               możliwe, że "protokół kontroli" jako odrębny dokument z
               własnym terminem już nie istnieje w obecnej praktyce.
               SPRAWDŹ aktualny stan w ELI (RZĄD 1) przed użyciem w piśmie.
Wystapieniepokontrolne: Kierownik zawiadamia o sposobie realizacji wnioskow w terminie
               NIE KRÓTSZYM niż 14 dni (potwierdzone: gov.pl/NIK,
               nik.gov.pl — to inny termin niż zastrzeżenia, dotyczy
               informowania o wykonaniu wniosków, nie ich zaskarżenia)
```

## Zasady absolutne
```
NIK nie moze wydawac polecen lub decyzji - tylko wnioski i zalecenia
Odmowa udostepnienia danych: Kierownik odpowiada dyscyplinarnie i karnie (art. 98)
Tajemnica sluzbowa NIK:      Kontroler obowiazany do zachowania tajemnicy
```

## Weryfikacja online
```
web_search: "ustawa NIK Najwyzsza Izba Kontroli Dz.U. 2022 poz. 623 isap"
```


---

## QUALITY GATE

- [ ] Aktualny tekst t.j. aktu zweryfikowany w ISAP?
- [ ] Stan prawny właściwy temporalnie?
- [ ] Każda przesłanka ma przypisany dowód?
- [ ] Termin nie upłynął?
- [ ] Właściwy organ / sąd wskazany?
- [ ] Ryzyka formalne i dowodowe ocenione?
- [ ] Brzmienie przepisów ze źródeł, nie z pamięci modelu?

## OUTPUT

1. Stan faktyczny; 2. Stan prawny i źródła (Dz.U. z ISAP); 3. Kwalifikacja trybu;
4. Terminy (obliczone, daty graniczne); 5. Przesłanki (spełnione / wątpliwe / niespełnione);
6. Matryca dowodowa; 7. Zarzuty i kontrargumenty; 8. Analiza ryzyk;
9. Strategia (podstawowy + ewentualny); 10. Rekomendacja; 11. Kontrola ISAP/temporalności.

**Status:** moduł klasy kancelaryjnej — poziom DR-03
**Data weryfikacji online:** 2026-06-05

---

## WERYFIKACJA Dz.U. NIK

```
Ustawa o NIK: Dz.U. 2022 poz. 623 t.j.
  ✅ VER: isap.sejm.gov.pl 2026-06-05
  Nowszy t.j. NIE ogłoszony — Dz.U. 2022 poz. 623 jest aktualnym t.j.
  → Weryfikuj zmiany po t.j. w ELI (RZĄD 1): isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20220000623
  Podstawa konstytucyjna: art. 202–207 Konstytucji RP
```
