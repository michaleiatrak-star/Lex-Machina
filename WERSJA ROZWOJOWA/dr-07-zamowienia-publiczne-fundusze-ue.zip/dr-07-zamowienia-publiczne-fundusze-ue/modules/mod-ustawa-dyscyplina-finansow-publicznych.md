# Modul - Odpowiedzialnosc za naruszenie dyscypliny finansow publicznych

## Akt prawny
**Ustawa z 17.12.2004 r. o odpowiedzialnosci za naruszenie dyscypliny finansow publicznych**
- Tekst jednolity: **Dz.U. 2025 poz. 1484** (obwieszczenie Marszałka Sejmu z 20.10.2025,
  w życie 28.10.2025; zastępuje t.j. 2024.104) ze zm.
  VER: isap.sejm.gov.pl [2026-08-15] — FAZA 3E: kary (art. 31: pieniężna 0,25-3x
  wynagrodzenia miesięcznego, zapasowo 0,25-5x przeciętnego gdy nie da się ustalić
  wynagrodzenia; zakaz pełnienia funkcji 1-5 lat wg art. 34) POTWIERDZONE bez zmian;
  jedyne wyłączenie z t.j. dotyczy niezwiązanego z tym modułem art. 5 ustawy zmieniającej
  Ordynację podatkową (Dz.U. 2025 poz. 497)

**Weryfikacja w ELI (RZĄD 1) przed kazdy cytowaniem.**

## Zakres podmiotowy
Odpowiada: kierownik jednostki sektora finansow publicznych, glowny ksiegowy,
pracownicy odpowiedzialni za gosp. finansowa, czlonkowie zarzadow i rad nadzorczych JST

## Naruszenia dyscypliny (art. 5-18b)
```
Art. 5:   Wydatki bez planu finansowego lub z jego przekroczeniem
Art. 6:   Dochody nieodprowadzone w terminie
Art. 7:   Zobowiazania bez planu lub ponad plan
Art. 11:  Zaniechanie windykacji naleznosci
Art. 12:  Wykonanie zobowiazania z naruszoniem trybu
Art. 17:  Naruszenie PZP przy udzielaniu zamowien publicznych
Art. 18:  Nieprawidlowe rozliczenie srodkow z UE
```

## Postepowanie i kary
```
Organy orzekajace:  Komisje orzekajace przy RIO i MF
Instancja I:        Komisja orzekajaca (z MF lub RIO)
Instancja II:       Glowna Komisja Orzekajaca przy MF
Kasacja:            Naczelny Sad Administracyjny
```

```
Kary:
- Upomnienie
- Nagana
- Kara pieniezna (do 3x miesiecznego wynagrodzenia)
- Zakaz pelnienia funkcji (1-5 lat)
```

## Weryfikacja online
```
web_search: "dyscyplina finansow publicznych ustawa Dz.U. 2025 poz. 1484 isap"
web_search: "naruszenie dyscypliny finansow publicznych kary komisja orzekajaca 2026"
```


---

## QUALITY GATE

- [ ] Aktualny tekst t.j. aktu zweryfikowany w ISAP?
- [ ] Stan prawny właściwy temporalnie?
- [ ] Każda przesłanka ma przypisany dowód?
- [ ] Termin nie upłynął?
- [ ] Właściwy organ / sąd wskazany?
- [ ] Ryzyka formalne i dowodowe ocenione?
- [ ] Brzmienie przepisów ze źródeł, nie z pamięci modelu?

## OUTPUT

1. Stan faktyczny; 2. Stan prawny i źródła (Dz.U. z ISAP); 3. Kwalifikacja trybu;
4. Terminy (obliczone, daty graniczne); 5. Przesłanki (spełnione / wątpliwe / niespełnione);
6. Matryca dowodowa; 7. Zarzuty i kontrargumenty; 8. Analiza ryzyk;
9. Strategia (podstawowy + ewentualny); 10. Rekomendacja; 11. Kontrola ISAP/temporalności.

**Status:** moduł klasy kancelaryjnej — poziom DR-03
**Data weryfikacji online:** 2026-08-15
