# mod-PZP-zamowienia-publiczne-KIO

**Status:** moduł klasy kancelaryjnej — poziom DR-03
**Źródło weryfikacji:** PZP — Dz.U. 2026 poz. 793 t.j. (obwieszczenie Marszałka Sejmu z 27.05.2026, publ. 16.06.2026) | Progi UE 2026–2027: M.P. 2025 poz. 1247 / UZP | Wpisy KIO: Dz.U. 2020 poz. 2437, § 2; art. 517–519 PZP — re-ver 2026-08-28
**Data weryfikacji online:** 2026-08-15 (FAZA 3E — audyt-systemu-v4, korekta numeru t.j. + treść art. 226 pkt 17/19)
**Zasada:** Każde brzmienie przepisu i kwota wpisu → weryfikuj w ELI (RZĄD 1) / uzp.gov.pl przed powołaniem

---

## ⚡ ALERTY LEGISLACYJNE — CZYTAJ PRZED ANALIZĄ

| Zmiana | Status | Podstawa |
|---|---|---|
| **Nowy próg krajowy: 170 000 zł** (poprzednio 130 000 zł) | **OBOWIĄZUJE od 01.01.2026** | Dz.U. 2025 poz. 1173 |
| **Zdalne rozprawy KIO** | **OBOWIĄZUJE od 13.03.2026** — złóż wniosek | Dz.U. 2025 poz. 769 |
| **Certyfikacja wykonawców** | **OBOWIĄZUJE od 12.07.2026** — nowa ustawa | Dz.U. 2025 poz. 1235 |
| **Zm. PZP + ustawa koncesyjna** | **OBOWIĄZUJE** | Dz.U. 2025 poz. 1165 |
| **Progi UE 2026–2027 (kurs EUR: 4,31 zł)** | **OBOWIĄZUJĄ od 01.01.2026** | M.P. 2025 poz. 1247 |
| **Nowe przesłanki odrzucenia oferty ICT (art. 226 ust. 1 pkt 17/19)** | **OBOWIĄZUJE od 03.04.2026** — dotyczy też postępowań w toku | Dz.U. 2026 poz. 252 (zm. ustawy o KSC) |

---

## 1. CORE

### Zakres modułu
Postępowanie o udzielenie zamówienia publicznego, odwołanie do KIO, skarga na orzeczenie KIO do Sądu Okręgowego w Warszawie (Sąd Zamówień Publicznych), wykluczenie wykonawcy, odrzucenie oferty, rażąco niska cena, warunki udziału, SWZ / OPZ, umowa o zamówienie i jej zmiany, podwykonawstwo, compliance SWZ (art. 99 PZP), in-house, sektorowe, certyfikacja wykonawców.

### Akty i źródła kontrolne

| Akt | Dz.U. / źródło |
|---|---|
| Ustawa PZP | Dz.U. 2026 poz. 793 t.j. (obwieszczenie 27.05.2026; zastępuje t.j. 2024.1320) ze zm. poz. 252/2026 (odrzucenie ofert ICT, w życie 3.04.2026) |
| Rozporządzenie Prezesa RM o wpisach KIO | Dz.U. 2020 poz. 2437, status ELI: obowiązujący; re-ver 2026-08-28 | Stawki: dostawy/usługi 7 500 zł (< UE) / 15 000 zł (≥ UE); roboty budowlane 10 000 zł (< UE) / 20 000 zł (≥ UE) |
| Progi unijne 2026–2027 | M.P. 2025 poz. 1247 — obwieszczenie Prezesa UZP z 08.12.2025 |
| KC | stosowany posiłkowo do umów (art. 8 PZP) |

---

## 2. INTAKE

```
□ Rola: wykonawca / zamawiający / podwykonawca?
□ Rodzaj zamówienia: roboty budowlane / dostawy / usługi / usługi społeczne?
□ Wartość zamówienia — który próg:
  → < 170 000 zł → brak PZP (zasady wewnętrzne zamawiającego)
  → 170 000 zł – progi UE → PZP tryby krajowe
  → ≥ progi UE → PZP tryby unijne + pełne KIO
□ Jaka czynność zamawiającego jest kwestionowana?
  treść SWZ / wykluczenie / odrzucenie oferty / wybór najkorzystniejszej / zmiana umowy
□ KIEDY DOKŁADNIE wykonawca otrzymał informację?
  (data + godzina + forma: elektronicznie czy inny sposób → wyznacza termin odwołania!)
□ Czy złożono odwołanie do KIO? Jaki wynik?
□ Czy wpis od odwołania uiszczono?
□ Czy dotyczy treści SWZ/OPZ → uruchom sub-moduł COMPLIANCE (sekcja 8)
□ Czy dotyczy zmiany umowy → sprawdź art. 454–455 PZP
```

---

## 3. PROGI WARTOŚCI ZAMÓWIEŃ — TABELA (2026–2027)

> **Podstawa:** M.P. 2025 poz. 1247 — obwieszczenie Prezesa UZP z 08.12.2025 | Kurs EUR: 4,31 zł
> ⚠️ Progi zmieniają się co 2 lata — przed każdą sprawą weryfikuj: uzp.gov.pl

| Rodzaj zamówienia | Próg UE (EUR) | Próg UE (PLN) |
|---|---|---|
| **Roboty budowlane** (klasyczne i sektorowe) | 5 404 000 EUR | **23 291 240 zł** |
| **Dostawy/usługi** — adm. centralna (zał. I dyr. 2014/24/UE) | 140 000 EUR | **603 400 zł** |
| **Dostawy/usługi** — pozostali zamawiający | 216 000 EUR | **930 960 zł** |
| **Usługi społeczne i szczególne** (klasyczne) | 750 000 EUR | **3 232 500 zł** |
| **Dostawy/usługi** sektorowe | 432 000 EUR | **1 861 920 zł** |
| **Usługi społeczne** sektorowe | 1 000 000 EUR | **4 310 000 zł** |
| **Próg krajowy** (poniżej = brak PZP) | — | **170 000 zł** (od 01.01.2026) |

> Dla porównania — progi UE 2024–2025 (M.P. 2023 poz. 1344): roboty: 5 538 000 EUR / usługi: 143 000 / 221 000 EUR.

---

## 4. TERMINY — ABSOLUTNY PRIORYTET

```
✅ [VER] RZĄD 1 2026-09-16j — PZP t.j. `Dz.U. 2026 poz. 793` (ogłoszony 16.06.2026; obejmuje
zmiany z 13.03.2026 w art. 514, 518, 525, 528); KPC `2026/468` (art. 398⁵); KSCU `2025/1228` (art. 34).

⚠️ ODWOŁANIE WNIESIONE PO TERMINIE — Izba ODRZUCA (art. 528 pkt 3 PZP)
⚠️ PZP nie przewiduje równoważności nadania pocztowego dla ODWOŁANIA (przewiduje ją wprost
   tylko dla SKARGI — art. 580 ust. 2) — licz termin do wpływu do Prezesa KIO
⚠️ Terminy liczy się według prawa cywilnego; koniec w sobotę lub dzień wolny → następny dzień
   roboczy (art. 509)
⛔ PRZEKAZANIE ZAMAWIAJĄCEMU (art. 514 ust. 2–3): odwołanie (albo kopię) przekazać zamawiającemu
   PRZED upływem terminu tak, by mógł zapoznać się z treścią; brak = ODRZUCENIE (art. 528 pkt 6)

POWYŻEJ PROGÓW UE (art. 515 ust. 1 pkt 1, ust. 2 pkt 1, ust. 3 pkt 1 PZP):
  10 dni — od przekazania informacji o czynności środkami komunikacji elektronicznej
  15 dni — od przekazania informacji w inny sposób
  10 dni — na treść ogłoszenia / dokumentów zamówienia: od publikacji w DUUE lub zamieszczenia
           dokumentów na stronie
  10 dni — w pozostałych przypadkach: od powzięcia (albo możliwości powzięcia) wiadomości

PONIŻEJ PROGÓW UE (art. 515 ust. 1 pkt 2, ust. 2 pkt 2, ust. 3 pkt 2 PZP):
  5 dni  — od przekazania informacji elektronicznie
  10 dni — od przekazania informacji w INNY SPOSÓB niż elektronicznie
           (⛔ poprzednio błędnie: „od publikacji w BZP … gdy brak powiadomienia")
  5 dni  — na treść ogłoszenia / dokumentów: od zamieszczenia ogłoszenia w BZP lub dokumentów
  5 dni  — w pozostałych przypadkach: od powzięcia (albo możliwości powzięcia) wiadomości

BRAK OGŁOSZENIA / ZAWIADOMIENIA (art. 515 ust. 4) — terminy maksymalne, m.in.:
  15 dni od ogłoszenia o wyniku w BZP albo 30 dni od ogłoszenia o udzieleniu w DUUE;
  6 miesięcy od zawarcia umowy (brak ogłoszenia o udzieleniu w DUUE / brak uzasadnienia
  negocjacji bez ogłoszenia lub wolnej ręki); miesiąc od zawarcia umowy (brak ogłoszenia
  w BZP) — pełny katalog: odczyt art. 515 ust. 4 przy sprawie

PRZYSTĄPIENIE WYKONAWCY (art. 525 ust. 1): 3 dni od otrzymania odwołania albo jego kopii

WPIS OD ODWOŁANIA (art. 517 ust. 2 PZP; ⛔ poprzednio błędnie „art. 519" — to przepis o zwrocie):
  → Wpłacić najpóźniej do dnia upływu terminu na wniesienie odwołania
  → Kwoty (Dz.U. 2020 poz. 2437 — VER: 2026-06-09, nadal obowiązuje):
     • 7 500 zł  — dostawy/usługi lub konkurs poniżej progów unijnych
     • 10 000 zł — roboty budowlane poniżej progów unijnych
     • 15 000 zł — dostawy/usługi lub konkurs na poziomie progów unijnych lub powyżej
     • 20 000 zł — roboty budowlane na poziomie progów unijnych lub powyżej
  → Konto UZP: uzp.gov.pl/kio (rachunek podany na stronie UZP)
  ⚠️ Wpis musi być UISZCZONY najpóźniej do upływu terminu wniesienia odwołania (art. 517 ust. 2 PZP).
  ⚠️ 3-dniowe wezwanie z art. 518 PZP służy poprawieniu/uzupełnieniu braków albo złożeniu DOWODU uiszczenia wpisu w terminie; nie tworzy dodatkowego terminu na spóźnioną zapłatę.
     Brak = zwrot odwołania bez rozpoznania meritum

SKARGA NA ORZECZENIE KIO (art. 580 PZP):
  14 dni — od doręczenia orzeczenia KIO (albo postanowienia Prezesa KIO o zwrocie odwołania)
  → Do Sądu Zamówień Publicznych = SO w Warszawie (jeden ogólnopolski sąd)
  → Za pośrednictwem Prezesa KIO, z jednoczesnym przesłaniem odpisu przeciwnikowi
  → Nadanie w polskiej placówce pocztowej / na adres do doręczeń elektronicznych = wniesienie
  → Opłata stała: TRZYKROTNOŚĆ wpisu od odwołania (art. 34 ust. 1 KSCU)
  → Przywrócenie terminu w sądzie: 7 dni od ustania przyczyny (art. 585 ust. 2)

SKARGA KASACYJNA DO SN (art. 590 PZP w zw. z art. 398⁵ KPC):
  2 miesiące — od doręczenia orzeczenia z uzasadnieniem (art. 398⁵ § 1 KPC)
  Prezes UZP (przepisy o Prokuratorze Generalnym): 6 miesięcy od uprawomocnienia,
  a gdy strona żądała doręczenia z uzasadnieniem — od doręczenia (art. 398⁵ § 2 KPC)
```

---

## 5. TRYBY UDZIELANIA ZAMÓWIEŃ

```
TRYBY PODSTAWOWE:
  Przetarg nieograniczony (art. 132 PZP)   — otwarty; wszyscy mogą złożyć ofertę
    ⭐ ROZWINIĘTE 2026-07-18: JEDNOETAPOWY — brak etapu kwalifikacyjnego,
    oferty składają WSZYSCY zainteresowani bez wcześniejszego wniosku
    o dopuszczenie. Zamawiający NIE MUSI wykazywać ŻADNYCH przesłanek
    uzasadniających wybór tego trybu — stosuje się swobodnie (pod
    warunkiem progu wartości: TYLKO zamówienia ≥ progi unijne — dla
    zamówień poniżej progów odpowiednikiem jest tryb podstawowy wariant I,
    art. 275 pkt 1, bardzo zbliżony proceduralnie). Podstawowy TERMIN
    składania ofert: min. 35 DNI od dnia przekazania ogłoszenia do
    Urzędu Publikacji UE (art. 138 ust. 1). Skrócenie do NIE MNIEJ niż
    15 dni — tylko po wstępnym ogłoszeniu informacyjnym albo przy pilnej
    potrzebie (ust. 2); o 5 dni krócej przy składaniu ofert w całości
    elektronicznie (ust. 4); wydłużenie o 5 dni w sytuacjach z art. 133
    ust. 2–3 (ust. 3). ⛔ Ustawa NIE przewiduje terminu poniżej 15 dni
    (poprzedni zapis „poniżej 15 dni w sytuacjach nadzwyczajnych" — błędny;
    ✅ RZĄD 1 2026-09-16j). NAJCZĘŚCIEJ stosowany tryb w Polsce — najkrótszy
    czas trwania postępowania spośród trybów wieloetapowych.
  Przetarg ograniczony (art. 150 PZP)      — zaproszeni po kwalifikacji wstępnej
    ⭐ ROZWINIĘTE 2026-07-18: DWUETAPOWY. ETAP 1 — wszyscy zainteresowani
    składają WNIOSKI O DOPUSZCZENIE do udziału (termin min. 30 DNI od
    przekazania ogłoszenia); zamawiający weryfikuje spełnienie warunków
    udziału, MOŻE ograniczyć liczbę zapraszanych wykonawców do
    złożenia oferty. ETAP 2 — TYLKO zaproszeni (ci, którzy pozytywnie
    przeszli weryfikację) składają OFERTY; SWZ na etapie 1 NIE zawiera
    jeszcze elementów dot. samych ofert (termin związania, sposób
    składania, termin otwarcia). Data wszczęcia = dzień przekazania
    ogłoszenia do UPUE. Stosowany RZADZIEJ niż przetarg nieograniczony —
    głównie przy DUŻYCH, ZŁOŻONYCH kontraktach, gdzie zamawiającemu
    zależy na kontroli liczby/jakości wykonawców dopuszczonych do
    złożenia oferty. ⚠️ ROZBIEŻNOŚĆ NUMERACJI w źródłach tej sesji —
    część materiałów wskazuje art. 150, inne art. 140 dla przetargu
    ograniczonego — ZWERYFIKUJ dokładny numer na ISAP przed cytowaniem
    w piśmie, nie polegaj na żadnym z tych dwóch bez potwierdzenia.
  Tryb podstawowy (art. 275–296 PZP)       — poniżej progów UE; 3 warianty:
    Wariant I  (art. 275 pkt 1): bez negocjacji
    Wariant II (art. 275 pkt 2): negocjacje przed wyborem (fakultatywne)
    Wariant III (art. 275 pkt 3): negocjacje obligatoryjne

TRYBY NEGOCJACYJNE:
  Negocjacje z ogłoszeniem (art. 152)
  Negocjacje bez ogłoszenia (art. 214 ust. 1 pkt 4–5) — wyjątkowe przesłanki
  Zamówienie z wolnej ręki (art. 214) — katalog ZAMKNIĘTY; weryfikuj przesłanki!

UPROSZCZONE / SZCZEGÓLNE:
  Partnerstwo innowacyjne (art. 297)
  Dynamiczny system zakupów (DSZ) / umowy ramowe
  Zamówienia in-house (art. 214 ust. 1 pkt 11–14) — własna jednostka
  Zamówienia sektorowe (dział V PZP) — patrz `mod-PZP-dzial-V-VI-
    sektorowe-obronne-infrastruktura-krytyczna.md` (dodany 2026-07-18)
  Zamówienia obronne i bezpieczeństwa (dział VI PZP), w tym mechanizm
    infrastruktury krytycznej (art. 131a ust. 1a) → TEN SAM moduł jak
    wyżej (⚠️ POPRAWIONE 2026-07-18 — poprzednie odesłanie "→ DR-13"
    było MARTWYM ODNOŚNIKIEM, DR-13 nie ma odpowiedniego modułu)
```

---

## 6. WYKLUCZENIE WYKONAWCY (art. 108–110 PZP)

### Podstawy wykluczenia — kwalifikator

```
OBLIGATORYJNE (art. 108 PZP) — zamawiający nie może odstąpić:
  → Skazanie za przestępstwa z listy: korupcja, pranie pieniędzy, terroryzm,
    handel ludźmi, przestępstwa przeciwko wolności seksualnej (katalog w art. 108 §1 pkt 1)
  → Karalność za przestępstwo podatkowe (art. 108 §1 pkt 2)
  → Naruszenia obowiązków środowiskowych / społecznych / pracowniczych (potwierdzone)
  → Konflikty interesów (art. 108 §1 pkt 5)
  → Porozumienia cenowe / zmowy przetargowe

FAKULTATYWNE (art. 109 PZP) — zamawiający MUSI wskazać w SWZ:
  → Naruszenie obowiązków podatkowych
  → Rażące błędy zawodowe
  → Rozwiązanie umowy z zamówieniem z winy wykonawcy
  → Wprowadzenie zamawiającego w błąd
  ⚠️ Gdy brak wskazania w SWZ — przesłanka NIE działa

SELF-CLEANING (art. 110 PZP):
  Wykonawca mimo przesłanki wykluczenia może wykazać rzetelność przez:
  □ Naprawienie szkody / zapłatę odszkodowania
  □ Współpraca z organami ścigania / organem kontrolnym
  □ Środki techniczne, organizacyjne, kadrowe zapobiegające w przyszłości
  Zamawiający ocenia indywidualnie i uzasadnia odmowę self-cleaning
```

---

## 7. ODRZUCENIE OFERTY (art. 226 PZP)

```
NAJCZĘSTSZE PRZESŁANKI:
  □ Niezgodność z warunkami zamówienia (art. 226 ust. 1 pkt 5) — najczęstsza
  □ Rażąco niska cena (art. 224–225 PZP) — procedura wyjaśnień obowiązkowa PRZED odrzuceniem
  □ Błędy w obliczeniu ceny (pkt 10)
  □ Niezgodność z przepisami prawa (pkt 3)
  □ ⚡ NOWE (od 3.04.2026, wg [ustawa z 23.01.2026 o zm. ustawy o KSC, Dz.U. 2026
    poz. 252], stan na 15.06.2026 — zweryfikowano ISAP/UZP): pkt 17 — oferta
    obejmuje produkt ICT, usługę ICT lub proces ICT wskazane w rekomendacji
    Pełnomocnika Rządu ds. Cyberbezpieczeństwa (art. 33 ust. 4 ustawy o KSC)
    jako stwarzające zagrożenie dla podstawowego interesu bezpieczeństwa
    państwa (zmiana redakcyjna z "urządzenia informatyczne/oprogramowanie" na
    pojęcia ICT wg rozp. UE 2019/881); pkt 19 (NOWY) — oferta obejmuje produkt
    ICT, którego typ określono w decyzji o uznaniu dostawcy za dostawcę
    wysokiego ryzyka. ⚠️ Stosuje się RÓWNIEŻ do postępowań wszczętych i
    niezakończonych przed 3.04.2026 (brak przepisu przejściowego dla pkt 19)

RAŻĄCO NISKA CENA — PROCEDURA (art. 224–225 PZP):
  Zamawiający MUSI wezwać do wyjaśnień (brak wezwania = naruszenie PZP)
  Ciężar dowodu: na wykonawcy (wyjaśnienia muszą być konkretne i udokumentowane)
  Wyjaśnienia: oszczędności metody / innowacje / koszty pracy / pomoc publiczna
  Ogólnikowe wyjaśnienia bez dowodów = podstawa odrzucenia
  Brak odpowiedzi na wezwanie = obligatoryjne odrzucenie

OBRONA PRZY ODRZUCENIU:
  1. Odwołanie do KIO w terminie zawitym
  2. Zarzut: brak wezwania do wyjaśnień / brak procedury RNC
  3. Kwestionowanie oceny zamawiającego — własne kalkulacje i dowody
```

---

## 8. ŚRODKI OCHRONY PRAWNEJ

### Odwołanie do KIO (art. 513–578 PZP)

```
ZAKRES (art. 513 PZP):
  Powyżej progów UE: każda czynność lub zaniechanie niezgodne z PZP
  Poniżej progów UE: ograniczony katalog — weryfikuj aktualny art. 513 pkt 2 w ELI (RZĄD 1)

OBLIGATORYJNA TREŚĆ ODWOŁANIA (art. 516 PZP):
  □ Oznaczenie zamawiającego i postępowania (nr ogłoszenia)
  □ Zarzuty — konkretne, z powołaniem PRZEPISÓW (nie ogólnie „naruszenie PZP")
  □ Żądanie — precyzyjne: uchylenie / nakazanie czynności / unieważnienie
  □ Uzasadnienie faktyczne i prawne
  □ Dowody — złożone ŁĄCZNIE Z ODWOŁANIEM lub wskazane z wnioskiem

PLATFORMA: e-Zamówienia (ezamowienia.gov.pl)
  → Wymagany kwalifikowany podpis elektroniczny lub ePUAP

ZDALNE ROZPRAWY (od 13.03.2026 — Dz.U. 2025 poz. 769):
  → Możliwe na wniosek strony — złóż wniosek razem z odwołaniem lub przed rozprawą

TERMIN ROZPOZNANIA przez KIO:
  15 dni od doręczenia odwołania Prezesowi KIO (termin instrukcyjny — art. 544 ust. 1 PZP);
  po wezwaniu z art. 518 ust. 1 — liczony od poprawienia / uzupełnienia odwołania
```

### Skarga do Sądu Zamówień Publicznych

```
Sąd: Sąd Okręgowy w Warszawie — JEDEN ogólnopolski Sąd Zamówień Publicznych (art. 579 PZP)
Termin: 14 dni od doręczenia orzeczenia KIO (art. 580 ust. 2 PZP)
Za pośrednictwem: Prezesa KIO
Opłata: 3× wpis od odwołania (weryfikuj aktualnie)
Zakres: kontrola orzeczenia KIO — sąd nie rozpoznaje ponownie co do meritum
```

---

## 9. ZMIANA UMOWY O ZAMÓWIENIE (art. 454–455 PZP)

```
ZAKAZ ZMIAN ISTOTNYCH (art. 454 PZP):
  Zmiana istotna = bezprawna = wymagałoby nowego postępowania
  Istotna gdy zmienia: charakter / zakres / wartość / równowagę ekonomiczną / krąg wykonawców

DOPUSZCZALNE ZMIANY (art. 455 PZP) — katalog zamknięty:
  □ Klauzula przeglądowa przewidziana w SWZ (zakres, charakter, warunki zmian)
  □ Nowy wykonawca: sukcesja, restrukturyzacja, gwarancja (art. 455 ust. 1 pkt 2)
  □ Art. 455 ust. 2: łączna wartość zmian musi być jednocześnie mniejsza niż progi unijne i niższa niż 10% wartości pierwotnej umowy (dostawy/usługi) albo 15% (roboty budowlane); bez zmiany ogólnego charakteru umowy — re-ver ELI 2026-08-28
  □ Okoliczności nieprzewidywalne (art. 455 ust. 1 pkt 4):
    → COVID, konflikt zbrojny, gwałtowny wzrost cen materiałów, klęska żywiołowa
  □ Zmiana nieistotna (test: czy zmiana wpłynęłaby na krąg oferentów lub wynik przetargu)

NIEWAŻNOŚĆ Z MOCY PRAWA (art. 457 PZP): zmiana poza zakresem art. 455 PZP
```

---

## 10. SUB-MODUŁ COMPLIANCE SWZ / OPZ (art. 99 PZP)

*Stosuj gdy: SWZ dostarczona do weryfikacji / pytanie o art. 99 ust. 4–5 PZP / parametry techniczne / zarzut preferowania produktu*

→ Wydzielone do `mod-PZP-wykonanie-umowy-compliance.md` sekcja 1
  (procedura C1–C5, podstawa prawna art. 99 ust. 1/4/5/6 PZP, wzór pytania
  do zamawiającego, podstawa odwołania przy preferowaniu produktu).

---

## 11. CERTYFIKACJA WYKONAWCÓW (Dz.U. 2025 poz. 1235 — od 12.07.2026)

→ Wydzielone do `mod-PZP-wykonanie-umowy-compliance.md` sekcja 4
  (definicja certyfikatu, korzyści, podmioty certyfikujące — PCA, status wejścia w życie).
  Szczegółowy framework certyfikacji: `mod-ustawa-PZP-certyfikacja-wykonawcow`.

---

## 12. DOWODY

| Teza | Dowód | Źródło | Siła | Luka | Działanie |
|---|---|---|---|---|---|
| Termin odwołania dotrzymany | UPO z platformy e-Zamówienia / potwierdzenie złożenia | platforma | wysoka | brak UPO | zrzut ekranu z godziną |
| Naruszenie procedury RNC | Brak wezwania do wyjaśnień / brak odpowiedzi na wyjaśnienia | korespondencja | wysoka | — | dokumentuj całą komunikację |
| Preferowanie produktu (art. 99 ust. 4) | OPZ z datą + tabela parametrów jednego producenta | SWZ / strona | wysoka | — | analiza rynku alternatywnych produktów |
| Self-cleaning | Dowód naprawienia szkody / współpraca z organami | dokumenty | wysoka | niedoprecyzowane | konkretne środki, nie deklaracje |
| Zmiana umowy poza art. 455 | Porównanie umowy pierwotnej i aneksu | umowy | wysoka | brak aneksu | wniosek o udostępnienie |

---

## 13. STRATEGIA

### Perspektywa wykonawcy

1. Termin na odwołanie — oblicz co do dnia i godziny od momentu otrzymania informacji.
2. Wpis — zapłać PRZED złożeniem odwołania lub tego samego dnia.
3. Zarzuty muszą być konkretne z powołaniem przepisów — ogólniki = KIO oddali.
4. Dowody — złóż łącznie z odwołaniem lub wskaż z wnioskiem o dopuszczenie.
5. Rozważ pytanie do zamawiającego (art. 135 PZP) zanim złożysz odwołanie — może rozwiązać spór bez postępowania.

### Perspektywa zamawiającego

1. Każda czynność dokumentuj datą i formą przekazania (determinuje termin odwołania wykonawcy).
2. RNC: wezwanie do wyjaśnień jest obowiązkowe — pominięcie = naruszenie PZP.
3. Przesłanki fakultatywne (art. 109 PZP) — wskaż w SWZ, inaczej nie działają.
4. Zmiana umowy — sprawdź art. 455 PZP przed podpisaniem aneksu.

### Ryzyki

| Ryzyko | Opis | Działanie zaradcze |
|---|---|---|
| Przekroczenie terminu zawitego | KIO odrzuca bez rozpoznania meritum | Oblicz termin od daty/godziny otrzymania informacji |
| Brak wpisu | Zwrot odwołania | Wpłać PRZED lub w dniu złożenia odwołania |
| Odwołanie na treść SWZ po terminie | Niedopuszczalne — termin od zamieszczenia SWZ | Monitoruj SWZ od momentu publikacji |
| Ogólnikowe zarzuty | Oddalenie | Każdy zarzut = konkretny przepis + konkretne działanie/zaniechanie |

---

## 14. ORZECZNICTWO

```
⚠️ KOREKTA (2026-07-05d): kio.gov.pl NIE hostuje wyszukiwarki — przekierowuje
   na strony informacyjne uzp.gov.pl/kio (o KIO, skład, kontakt). Właściwa
   wyszukiwarka orzeczeń: https://orzeczenia.uzp.gov.pl (obejmuje KIO + SO/
   SA/SN ws. skarg na orzeczenia KIO). Procedura pełna: orzeczenia-sadowe-v2
   → Faza 1-K.

Wyszukiwarka orzeczeń (KIO + SO/SA/SN): https://orzeczenia.uzp.gov.pl
UZP (wytyczne i interpretacje): https://uzp.gov.pl

→ Dla wyszukiwania orzecznictwa KIO ZAWSZE deleguj do:
  view orzeczenia-sadowe-v2/SKILL.md → Faza 1-K
  (procedura zweryfikowana bezpośrednim fetchem: Home/Search?Phrase=...,
  cytowanie z polem "Sposób rozstrzygnięcia" jako tani test zgodności tezy)

web_search: "KIO wykluczenie odrzucenie rażąco niska cena wyrok 2025 2026"
web_search: "KIO art 99 ust 4 PZP preferowanie produktu równoważność wyrok 2025"
web_search: "KIO self-cleaning art 110 PZP środki naprawcze 2025 2026"
web_search: "PZP zmiana umowy art 455 okoliczności nieprzewidywalne KIO 2025"
⚠️ NIGDY nie cytuj sygnatur z pamięci — zawsze weryfikuj przez orzeczenia.uzp.gov.pl
   (Faza 1-K w orzeczenia-sadowe-v2), NIE przez nieistniejącą wyszukiwarkę na kio.gov.pl
```

---

## 15. QUALITY GATE

- [ ] Termin odwołania obliczony (data + godzina + forma przekazania)?
- [ ] Wpis od odwołania uiszczony / kwota zweryfikowana (Dz.U. 2020 poz. 2437)?
- [ ] Progi UE właściwe (M.P. 2025 poz. 1247 — 2026–2027)?
- [ ] Nowy próg krajowy 170 000 zł (od 01.01.2026) zastosowany?
- [ ] Zarzuty konkretne z powołaniem przepisów?
- [ ] Dowody złożone łącznie lub wskazane?
- [ ] Zmiana umowy — sprawdzony art. 455 PZP?
- [ ] Aktualne brzmienie PZP zweryfikowane w ISAP?

---

## 16. OUTPUT I PREDYKCJA

```
PREDYKCJA WYNIKU:
Szanse: [0–100%]
IN PLUS: uchybienie formalne zamawiającego (brak wezwania do RNC, brak wskazania
         przesłanki w SWZ, brak uzasadnienia), preferowanie produktu bez równoważności,
         self-cleaning skuteczny, zmiana umowy poza art. 455
IN MINUS: upływ terminu zawitego, brak wpisu, odwołanie na treść SWZ po terminie,
          zarzuty nieprecyzyjne, brak dowodów złożonych łącznie z odwołaniem

BENCHMARKING: → orzeczenia.uzp.gov.pl (bezpłatna wyszukiwarka wyroków KIO/SO/SA/SN
  — kio.gov.pl NIE hostuje wyszukiwarki, patrz korekta w sekcji 14)
  (NIGDY nie cytuj sygnatur z pamięci — ZAWSZE weryfikuj online)
REKOMENDACJA: □ Odwołanie do KIO  □ Pytanie do zamawiającego (art. 135)
              □ Skarga do SO  □ Wyjaśnienia RNC  □ Self-cleaning
```

**Output:** stan faktyczny → kwalifikacja (próg / tryb) → terminy → zarzuty → dowody → strategia → predykcja → rekomendacja → kontrola ISAP.

---

## POWIĄZANIA

| Sytuacja | Skill / Moduł |
|---|---|
| Odwołanie do KIO (projekt pisma) | `pisma-procesowe-v3` |
| Analiza szans odwołania | `analiza-sadowa-v6` |
| Analiza umowy / aneksów | `analizator-umow-v1` |
| Orzecznictwo KIO / SO | `orzeczenia-sadowe-v2` |
| Certyfikacja wykonawców | `mod-ustawa-PZP-certyfikacja-wykonawcow` |
| Dyscyplina finansów (zamawiający) | `mod-ustawa-dyscyplina-finansow-publicznych` |
| Compliance SWZ — art. 99 PZP | `mod-PZP-wykonanie-umowy-compliance.md` sekcja 1 |
| Podwykonawstwo / zabezpieczenie | `mod-PZP-wykonanie-umowy-compliance.md` sekcje 2–3 |

---

## ŹRÓDŁA ONLINE

- PZP: https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20241320
- Progi UE: https://uzp.gov.pl/aktualnosci/progi-unijne
- KIO (wyroki, wyszukiwarka): https://orzeczenia.uzp.gov.pl (kio.gov.pl NIE
  hostuje wyszukiwarki od korekty 2026-07-05d — przekierowuje na uzp.gov.pl/kio)
- UZP (wytyczne): https://uzp.gov.pl
- e-Zamówienia: https://ezamowienia.gov.pl
- PCA (certyfikacja): https://www.pca.gov.pl

---

## ANEKS A — WYKONANIE UMOWY: PODWYKONAWSTWO I ZABEZPIECZENIE

→ Wydzielone do `mod-PZP-wykonanie-umowy-compliance.md`:
- sekcja 2 — Podwykonawstwo (art. 462–475 PZP): zgłoszenie podwykonawcy,
  bezpośrednia zapłata (art. 465 PZP), udostępnienie zasobów podmiotów trzecich
- sekcja 3 — Zabezpieczenie należytego wykonania (art. 449–453 PZP): wysokość,
  formy, zwrot, gwarancja jakości
