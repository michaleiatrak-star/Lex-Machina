# Moduł — Regionalne Izby Obrachunkowe (RIO)

## Akt prawny / źródło
- Ustawa o regionalnych izbach obrachunkowych — Dz.U. 2025 poz. 7 (t.j., obwieszczenie
  Marszałka Sejmu z 23.12.2024; zastępuje t.j. 2023.1325)
  ✅ [VER: isap.sejm.gov.pl, 2026-08-15 — FAZA 3E: jedyna zmiana ujęta w nowym t.j.
  wynika z ustawy o dochodach JST (Dz.U. 2024 poz. 1572), nie dotyka art. 1, 11, 90 u.s.g.
  ani funkcji nadzorczej/kontrolnej/opiniodawczej/orzeczniczej opisanych niżej — treść
  modułu ZGODNA]

**Weryfikacja:** ELI (RZĄD 1) przed każdym cytowaniem.

## Zakres
RIO = organ kontroli i nadzoru finansowego JST (gmin, powiatów, województw,
SPZOZ, instytucji kultury, samorządowych osób prawnych).

Funkcje:
1. **Nadzorcza:** badanie legalności uchwał budżetowych i finansowych JST; unieważnienie
   uchwały sprzecznej z prawem (art. 11 u.r.i.o.)
2. **Kontrolna:** audyt wykonania budżetu, zamówień publicznych, dotacji
3. **Opiniodawcza:** opinie o budżetach, WPF, możliwości spłaty zadłużenia
4. **Orzecznicza:** orzekanie o naruszeniu dyscypliny finansów publicznych

## Zasady absolutne
```
Budżet JST:    Uchwała budżetowa na rok następny — do 31.01 jeśli nie uchwalono
               RIO może ustalić budżet zastępczy
Deficyt:       Uchwała z przekroczeniem limitu zadłużenia → nieważność (art. 90 u.s.g.)
Dyscyplina fin. publicznych: Odpowiedzialność członków zarządu JST (ustawa o DFP)
Opinia RIO:    Obowiązkowa przy emisji obligacji komunalnych i pożyczkach z BP
```

## Weryfikacja online
```
web_search: "ustawa regionalne izby obrachunkowe RIO isap tekst jednolity 2025"
web_search: "RIO nadzór uchwała nieważność budżet JST 2026"
```


---

## QUALITY GATE

- [ ] Aktualny tekst t.j. aktu zweryfikowany w ISAP?
- [ ] Stan prawny właściwy temporalnie?
- [ ] Każda przesłanka ma przypisany dowód?
- [ ] Termin nie upłynął?
- [ ] Właściwy organ / sąd wskazany?
- [ ] Ryzyka formalne i dowodowe ocenione?
- [ ] Brzmienie przepisów ze źródeł, nie z pamięci modelu?

## OUTPUT

1. Stan faktyczny; 2. Stan prawny i źródła (Dz.U. z ISAP); 3. Kwalifikacja trybu;
4. Terminy (obliczone, daty graniczne); 5. Przesłanki (spełnione / wątpliwe / niespełnione);
6. Matryca dowodowa; 7. Zarzuty i kontrargumenty; 8. Analiza ryzyk;
9. Strategia (podstawowy + ewentualny); 10. Rekomendacja; 11. Kontrola ISAP/temporalności.

**Status:** moduł klasy kancelaryjnej — poziom DR-03
**Data weryfikacji online:** 2026-08-15
