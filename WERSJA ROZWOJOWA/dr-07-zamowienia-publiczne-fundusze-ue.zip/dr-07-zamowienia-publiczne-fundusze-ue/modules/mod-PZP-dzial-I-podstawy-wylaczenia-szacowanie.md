# mod-PZP-dzial-I-podstawy-wylaczenia-szacowanie

**Akt:** PZP (Prawo zamówień publicznych) — t.j. Dz.U. 2026 poz. 793 (zm. po t.j.: 2026/1347 [OD 2026-12-01: 2026/1347] — art. 214, 364).
**Akt:** KPC (Kodeks postępowania cywilnego) — t.j. Dz.U. 2026 poz. 468 (zm. po t.j.: 2026/473 od 2026-07-08 — art. 460, 461, 465, 476, 631, 632, 3982, 4771b, 4771c, 4771d, 4777a, 7555, 7556; 2026/830 od 2026-07-08 — art. 4; 2026/1003 od 2026-10-28 — zakres: tekst nowelizacji w ELI; 2026/1046 od 2026-11-05 — art. 1, 2, 47, 94, 461, 477; 2026/1296 od 2026-11-06 — art. 17).
**Akt:** KC (Kodeks cywilny) — t.j. Dz.U. 2026 poz. 795.
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

**Wersja:** 1.1 | **Dodano:** 2026-07-18 | **Zaktualizowano:** 2026-07-18 (konflikt interesów, sekcja 6.1)
**Rola w systemie:** wypełnia najwyższy priorytet z audytu pokrycia PZP —
Dział I to fundament, od którego zaczyna się KAŻDA sprawa zamówieniowa
("czy ustawa w ogóle się stosuje", "jaki jest właściwy próg"), dotąd
nieobecny jako samodzielny temat mimo bardzo dobrego pokrycia dalszych
etapów postępowania w innych modułach DR-07.

> ⛔ HARDGATE — zweryfikuj aktualny t.j. na ISAP. Próg podstawowy PZP
> zmienił się z 130 000 zł na **170 000 zł** od 1.01.2026 (ustawa z
> 25.07.2025, Dz.U. 2025 poz. 1173) — sprawdź, czy to nadal aktualne.

---

## 1. PRZEGLĄD DZIAŁU I (art. 1-82)

```
Rozdział 1 — Przedmiot regulacji
  Oddział 1 — Zakres spraw regulowanych ustawą (1-8)
  Oddział 2 — Wyłączenia stosowania przepisów ustawy (9-15)
Rozdział 2 — Zasady udzielania zamówień (16-20)
Rozdział 3 — Polityka zakupowa państwa oraz plan postępowań (21-23)
Rozdział 4 — Stosowanie przepisów do zamówień o charakterze mieszanym (24-27)
Rozdział 5 — Szacowanie wartości zamówienia i konkursu (28-36)
Rozdział 6 — Zamawiający i wykonawcy (37-60)
Rozdział 7 — Komunikacja zamawiającego z wykonawcami (61-70)
Rozdział 8 — Dokumentowanie przebiegu postępowania (71-82)
```

---

## 2. PRÓG PODSTAWOWY I RODZAJE ZAMAWIAJĄCYCH (art. 2)

```
PRÓG PODSTAWOWY (zamawiający KLASYCZNI): 170 000 zł
  (podniesiony z 130 000 zł ustawą z 25.07.2025, Dz.U. 2025 poz. 1173,
  w życie 1.01.2026 — ✅ potwierdzone drugą weryfikacją 2026-07-18)
PROGI UNIJNE — RÓŻNE dla różnych kategorii zamawiających:
  Zamawiający KLASYCZNI: niższy próg unijny
  Zamawiający SEKTOROWI oraz w dziedzinach OBRONNOŚCI/BEZPIECZEŃSTWA:
    WYŻSZY próg unijny (ten sam co dla siebie nawzajem — patrz
    `mod-PZP-dzial-V-VI-sektorowe-obronne-infrastruktura-krytyczna.md`)
  Roboty budowlane: JEDEN próg niezależnie od rodzaju zamawiającego
⚠️ Aktualne kwoty progów unijnych zmieniają się co 2 lata (obwieszczenie
Prezesa UZP) — zweryfikuj aktualne obwieszczenie na dany rok przed
każdym wyliczeniem, nie polegaj na kwotach z tej sesji badawczej.
```

---

## 3. WYŁĄCZENIA STOSOWANIA USTAWY (art. 9-15) — PIERWSZE PYTANIE W KAŻDEJ SPRAWIE

**Zasada interpretacyjna nadrzędna:** wyłączenia stanowią WYJĄTEK od
zasady stosowania PZP — podlegają WYKŁADNI ZAWĘŻAJĄCEJ (ścisłej).
Ciężar dowodu, że przesłanki wyłączenia zaistniały, spoczywa na
PODMIOCIE, który z wyłączenia chce skorzystać (potwierdzone orzecznictwem
TSUE, cytowanym przez UZP).

### Katalog najważniejszych wyłączeń (nie wyczerpujący — sprawdź pełną
listę na ISAP przy konkretnej sprawie):

```
□ Zamówienia realizowane na podstawie INNEJ, szczególnej procedury
  (np. wynikającej z umowy międzynarodowej)
□ Usługi PRAWNE związane z zastępstwem procesowym (arbitraż, postępowanie
  sądowe, pojednawcze) świadczone przez adwokata/radcę prawnego/prawnika
  zagranicznego — ORAZ doradztwo prawne w przygotowaniu takich postępowań
  — podstawa: art. 51 TFUE (nie dotyczy zwykłych opinii prawnych/
  projektów decyzji administracyjnych na zlecenie władzy publicznej —
  te WCIĄŻ podlegają PZP)
□ Usługi Narodowego Banku Polskiego, usługi Banku Gospodarstwa Krajowego
  (określony zakres)
□ Umowy z zakresu prawa pracy, w tym zarządzanie PPK (pracownicze plany
  kapitałowe)
□ Nabycie WŁASNOŚCI NIERUCHOMOŚCI i innych praw do nieruchomości
  — ⚠️ KLUCZOWE ZASTRZEŻENIE (SN, wyrok z 16.09.2009, sygn. II CSK
  104/09): wyłączenie NIE OBEJMUJE nieruchomości, która JESZCZE NIE
  POWSTAŁA lub wymaga PRZEPROWADZENIA ZNACZNYCH ROBÓT BUDOWLANYCH
  (przebudowa/rozbudowa) w zakresie oczekiwanym przez zamawiającego —
  celem tego zastrzeżenia jest zapobieżenie obchodzeniu PZP przez
  fikcyjne "umowy deweloperskie" maskujące w istocie zamówienie na
  roboty budowlane. Dotyczy WYŁĄCZNIE "czystych" umów obrotu
  nieruchomościami (ze względu na unikatowy charakter każdej
  nieruchomości) — TSUE
□ Usługi w zakresie BADAŃ NAUKOWYCH, prac rozwojowych, usług badawczych
  — ALE TYLKO gdy ŁĄCZNIE: (a) dostawy/usługi służą WYŁĄCZNIE celom
  badawczym/eksperymentalnym (NIE mieszanym z bieżącą działalnością
  zamawiającego), (b) wartość poniżej progu z rozporządzenia wykonawczego,
  (c) NIE służą produkcji seryjnej mającej na celu rentowność rynkową
  ani pokryciu kosztów badań. Sam zakup APARATURY/sprzętu do badań to
  DOSTAWA — podlega PZP normalnie, wyłączenie dotyczy wyłącznie SAMEJ
  usługi badawczej
□ Usługi transportu pasażerskiego koleją lub metrem (określony zakres)
```

**Zastosowanie praktyczne — checklist:**
```
□ Czy przesłanka wyłączenia jest w PEŁNI spełniona (WSZYSTKIE elementy
  łącznie, nie tylko część)? Częściowe spełnienie = wyłączenie NIE
  działa, wraca zasada ogólna (PZP się stosuje)
□ Czy to nie jest próba "opakowania" zamówienia na roboty budowlane/
  usługi jako co innego (np. "sprzedaż nieruchomości", żeby ominąć PZP)?
□ Kto ponosi ciężar dowodu? — zawsze podmiot chcący skorzystać z
  wyłączenia, nie ten kto je kwestionuje
```

---

## 4. ZASADY UDZIELANIA ZAMÓWIEŃ (art. 16-20)

Podstawowe zasady, do których odwołuje się cała ustawa przy ocenie
prawidłowości konkretnych działań zamawiającego (w tym przy ocenie opisu
przedmiotu zamówienia — patrz `mod-PZP-opis-przedmiotu-zakaz-znakow-
towarowych.md`):
```
□ Zachowanie UCZCIWEJ KONKURENCJI oraz RÓWNE TRAKTOWANIE wykonawców
□ PROPORCJONALNOŚĆ i PRZEJRZYSTOŚĆ
□ Bezstronność i obiektywizm osób wykonujących czynności w postępowaniu
□ Pisemność postępowania
□ Jawność postępowania (z zastrzeżeniami dot. tajemnicy przedsiębiorstwa)
```
Te zasady są PODSTAWĄ do kwestionowania konkretnych działań zamawiającego
nawet gdy nie naruszają one wprost żadnego SZCZEGÓŁOWEGO przepisu — sądy
i KIO powołują się na nie jako samodzielną podstawę oceny.

---

## 5. SZACOWANIE WARTOŚCI ZAMÓWIENIA (art. 28-36) — ZAKAZ DZIELENIA ZAMÓWIEŃ

**Zasada podstawowa:** wartość zamówienia ustala się z NALEŻYTĄ
STARANNOŚCIĄ, na podstawie CAŁKOWITEGO SZACOWANEGO WYNAGRODZENIA
wykonawcy, bez podatku VAT.

**⭐ ZAKAZ DZIELENIA ZAMÓWIENIA (art. 29-30, częsty zarzut w praktyce):**
zamawiający NIE MOŻE dzielić zamówienia na odrębne części/zamówienia
CELEM UNIKNIĘCIA stosowania przepisów ustawy (np. by zejść poniżej progu
170 000 zł lub progu unijnego). Kryteria oceny, czy doszło do
niedozwolonego podziału:
```
□ Czy zamówienia dotyczą TEGO SAMEGO PRZEDMIOTU/rodzaju robót-dostaw-usług?
□ Czy są udzielane w ZBLIŻONYM CZASIE (ten sam okres, np. rok budżetowy)?
□ Czy mogą być wykonane przez JEDNEGO wykonawcę (brak obiektywnych
  przeszkód technicznych/organizacyjnych do połączenia)?
□ Czy PODZIAŁ ma uzasadnienie OBIEKTYWNE (np. różne lokalizacje
  wymagające różnych specjalistów, różne źródła finansowania z odrębnymi
  reżimami) — jeśli TAK, podział może być dopuszczalny
```
**Konsekwencja stwierdzonego niedozwolonego podziału:** wartości
zamówień SUMUJE SIĘ dla celu ustalenia właściwego progu/trybu — jeśli
suma przekracza próg, którego zamawiający unikał, postępowanie może być
unieważnione/zakwestionowane przez kontrolę Prezesa UZP (patrz
`mod-PZP-dzial-XI-XII-kontrola-kary-UZP.md`) jako naruszenie mogące mieć
wpływ na wynik.

**Agregacja zamówień tego samego rodzaju (art. 30):** przy PLANOWANIU
zakupów na dany rok zamawiający powinien zsumować przewidywane zamówienia
tego samego rodzaju, żeby prawidłowo ustalić, czy sumaryczna wartość
przekracza próg — to zapobiega NIEUMYŚLNEMU (nie tylko celowemu)
zaniżeniu wartości przez brak planowania.

---

## 6. ZAMAWIAJĄCY I WYKONAWCY (art. 37-60) — SKRÓCONY PRZEGLĄD

```
□ Zamawiający PUBLICZNI — jednostki sektora finansów publicznych i
  podobne (najliczniejsza grupa)
□ Zamawiający SEKTOROWI — patrz moduł Dział V/VI (osobny, dedykowany)
□ WYKONAWCY — mogą wspólnie ubiegać się o zamówienie (konsorcjum),
  zasady odpowiedzialności solidarnej, pełnomocnictwo do reprezentowania
  konsorcjum — ⚠️ powiązanie z `mod-KK-slupy-fikcyjna-reprezentacja-
  spolki.md` (DR-03) przy problemach z umocowaniem pełnomocnika konsorcjum
```

### ⭐⭐ 6.1 KONFLIKT INTERESÓW OSÓB PROWADZĄCYCH POSTĘPOWANIE (art. 56-57 PZP, dodane 2026-07-18)

> Odpowiedź na pytanie użytkownika o pokrycie konfliktu interesów
> (rodzina/pracownik) w KONTEKŚCIE PRZETARGÓW — dotąd nieobecne mimo że
> to jeden z NAJCZĘŚCIEJ analizowanych tematów w praktyce PZP. Umiejscowione
> w Dziale I, Rozdział 6 (Zamawiający i wykonawcy) — stąd w TYM module.

**Kogo dotyczy (art. 56 ust. 1):**
```
□ Kierownik zamawiającego (lub osoba, której powierzył zastrzeżone
  dla siebie czynności)
□ Członkowie KOMISJI PRZETARGOWEJ
□ INNE osoby wykonujące czynności związane z przeprowadzeniem
  postępowania PO STRONIE ZAMAWIAJĄCEGO — w tym PRACOWNICY zamawiającego
  ORAZ osoby zatrudnione przez zamawiającego na podstawie UMÓW
  CYWILNOPRAWNYCH, a także BIEGLI powołani na podstawie art. 55 ust. 4
  (⚠️ potwierdzone wprost: radca prawny wydający opinię dla komisji
  przetargowej TEŻ podlega temu obowiązkowi — KIO, sprawa dot.
  niezłożenia oświadczenia przez radcę prawnego)
□ Osoby MOGĄCE WPŁYNĄĆ na wynik postępowania (katalog OTWARTY, nie
  tylko formalni członkowie komisji)
□ Osoby UDZIELAJĄCE zamówienia
```

**Trzy główne przesłanki konfliktu interesów (art. 56 ust. 2):**

```
PRZESŁANKA 1 (pkt 1) — osoba SAMA ubiega się o dane zamówienie

PRZESŁANKA 2 (pkt 2) — ⭐ ASPEKT RODZINNY:
  Osoba pozostaje z WYKONAWCĄ (lub jego przedstawicielem/członkiem
  organów zarządzających/nadzorczych) w:
  □ ZWIĄZKU MAŁŻEŃSKIM
  □ STOSUNKU POKREWIEŃSTWA/POWINOWACTWA W LINII PROSTEJ (bez ograniczenia
    stopnia — rodzice/dzieci/dziadkowie/wnuki)
  □ POKREWIEŃSTWA/POWINOWACTWA W LINII BOCZNEJ DO 2. STOPNIA (rodzeństwo,
    ⚠️ węższy zakres niż przy wyłączeniu SĘDZIEGO z art. 48 KPC, gdzie
    linia boczna sięga do 4. stopnia — NIE MYL tych dwóch różnych
    zakresów pokrewieństwa w różnych kontekstach proceduralnych!)
  □ Więzi z tytułu PRZYSPOSOBIENIA, OPIEKI lub KURATELI
  □ WSPÓLNEGO POŻYCIA (konkubinat) z wykonawcą/jego przedstawicielem/
    członkiem organów wykonawcy

PRZESŁANKA 3 (pkt 3) — ⭐⭐ ASPEKT PRACOWNICZY (dokładna odpowiedź na
  pytanie użytkownika):
  W OKRESIE 3 LAT przed wszczęciem postępowania, osoba:
  □ POZOSTAWAŁA W STOSUNKU PRACY LUB ZLECENIA z wykonawcą, LUB
  □ OTRZYMYWAŁA OD WYKONAWCY WYNAGRODZENIE Z INNEGO TYTUŁU, LUB
  □ BYŁA CZŁONKIEM organów ZARZĄDZAJĄCYCH lub NADZORCZYCH wykonawcy
  ubiegającego się o dane zamówienie

PRZESŁANKA 4 (dodatkowa, karna) — osoba została PRAWOMOCNIE SKAZANA za
  przestępstwo popełnione W ZWIĄZKU z postępowaniem o udzielenie
  zamówienia — katalog: art. 228-230a KK (korupcja urzędnicza), art. 270
  KK (fałszerstwo dokumentu), art. 276 KK, art. 286-287 KK (oszustwo),
  art. 296-296a KK (nadużycie zaufania/korupcja sektora prywatnego),
  art. 297 KK (wyłudzenie kredytu), art. 303 KK i inne (⚠️ pełna lista
  niepotwierdzona w tej sesji) — BEZPOŚREDNIE powiązanie z modułami
  DR-03 wymienionymi w sekcji integracji
```

**Procedura (art. 56 ust. 4 i n.):**
```
□ Osoby objęte art. 56 ust. 1 SKŁADAJĄ OŚWIADCZENIE dotyczące istnienia
  albo BRAKU konfliktu interesów
□ Termin: oświadczenie o BRAKU konfliktu — NIE PÓŹNIEJ niż przed
  zakończeniem postępowania; oświadczenie dot. niekaralności (Przesłanka
  4) — PRZED rozpoczęciem czynności w postępowaniu
□ Stwierdzenie konfliktu → WYŁĄCZENIE danej osoby z dokonywania czynności
  NIEZWŁOCZNIE po ustaleniu kręgu wykonawców i powzięciu wiadomości o
  podstawie wyłączenia
□ SKUTEK wyłączenia: czynności podjęte przez osobę PODLEGAJĄCĄ wyłączeniu
  PODLEGAJĄ POWTÓRZENIU — Z WYJĄTKIEM otwarcia ofert oraz innych czynności
  FAKTYCZNYCH niewpływających na wynik postępowania
□ ⚠️ Praktyczna wskazówka orzecznicza (KIO 1037/11): osoba wykonująca
  czynności powinna ZAPRZESTAĆ prac JUŻ OD MOMENTU UJAWNIENIA SIĘ
  podmiotu, z którym była powiązana — nie czekać na formalne stwierdzenie
```

**Konsekwencja dla WYKONAWCY (nie tylko dla osoby po stronie zamawiającego):**
konflikt interesów w rozumieniu art. 56 ust. 1-2 jest RÓWNIEŻ podstawą
WYKLUCZENIA WYKONAWCY z postępowania (odesłanie w przepisach o
wykluczeniu — patrz `mod-PZP-zamowienia-publiczne-KIO.md` sekcja 6,
wykluczenie wykonawcy art. 108-110) — to jest MECHANIZM DWUSTRONNY: chroni
zarówno przed stronniczością osoby PO STRONIE ZAMAWIAJĄCEGO, jak i przed
UZYSKANIEM zamówienia przez wykonawcę korzystającego z takich powiązań.

**Checklist praktyczny:**
```
□ Czy którykolwiek członek komisji przetargowej / kierownik zamawiającego
  / biegły ma powiązanie RODZINNE z którymkolwiek wykonawcą składającym
  ofertę (sprawdź: małżeństwo, pokrewieństwo/powinowactwo do 2. stopnia
  w linii bocznej LUB bez ograniczenia w linii prostej, przysposobienie/
  opieka/kuratela, konkubinat)?
□ Czy którakolwiek z tych osób pozostawała w STOSUNKU PRACY/ZLECENIA z
  którymkolwiek wykonawcą W CIĄGU OSTATNICH 3 LAT — sprawdź to
  SYSTEMATYCZNIE dla każdej osoby wykonującej czynności, nie tylko dla
  formalnych członków komisji (katalog jest szerszy — obejmuje "inne
  osoby mogące wpłynąć na wynik")
□ Czy oświadczenia o (braku) konfliktu interesów zostały złożone w
  PRAWIDŁOWYM terminie przez WSZYSTKIE osoby objęte obowiązkiem
  (w tym zewnętrzni biegli/radcowie prawni wydający opinie dla komisji)?
□ Jeśli konflikt ujawniono PO dokonaniu czynności — czy czynności
  zostały PRAWIDŁOWO POWTÓRZONE (z zachowaniem wyjątku dla otwarcia
  ofert)?
```

✅ **ROZDZ. 7-8 ZWERYFIKOWANE (2026-08-19, F-38)** — od punktu startowego do
konkretnej, użytecznej treści:

**ROZDZIAŁ 7 — Komunikacja elektroniczna (art. 61-70):**
```
□ Art. 61 ust. 1 — ZASADA: komunikacja w postępowaniu (składanie ofert,
  wniosków o dopuszczenie, wymiana informacji, dokumenty/oświadczenia)
  odbywa się WYŁĄCZNIE przy użyciu środków komunikacji ELEKTRONICZNEJ,
  z wyjątkami określonymi w ustawie. Dotyczy zarówno zamówień, jak i
  KONKURSÓW.
□ Art. 61 ust. 2 — WYJĄTEK: komunikacja USTNA dopuszczalna w toku
  NEGOCJACJI lub DIALOGU oraz co do informacji NIEISTOTNYCH (te NIE
  obejmują ogłoszenia o zamówieniu, dokumentów zamówienia ani ofert) —
  ALE treść komunikacji ustnej MUSI być UTRWALONA (protokół, notatka,
  streszczenie, nagranie) i dołączona jako ZAŁĄCZNIK do protokołu
  (art. 71 i n.) — ⭐ obowiązek dokumentowania powstaje NIEZALEŻNIE od
  formy komunikacji.
□ Wymóg NARZĘDZI: zamawiający może używać TYLKO narzędzi
  niedyskryminujących, ogólnie dostępnych, interoperacyjnych — jeśli
  narzędzie NIE jest ogólnie dostępne, musi zapewnić wykonawcom
  BEZPŁATNY dostęp do niego.
□ Art. 65 — WYJĄTKI od obowiązku elektronizacji: (1) gdy wymagałoby to
  specjalistycznych formatów/urządzeń niedostępnych ogólnie (pkt 1);
  (2) gdy wymagałoby pozyskania specjalistycznych urządzeń biurowych
  przez zamawiającego (pkt 2) — katalog zamknięty, wąski.
□ Art. 78¹ §1 KC (forma elektroniczna) — oświadczenie w postaci
  elektronicznej z kwalifikowanym podpisem elektronicznym wystarcza do
  zachowania formy elektronicznej wymaganej ustawą.
□ Art. 63 ust. 2 — dla zamówień PONIŻEJ progów UE: ofertę/oświadczenia
  składa się pod RYGOREM NIEWAŻNOŚCI w formie elektronicznej ALBO w
  postaci elektronicznej z podpisem osobistym/zaufanym (szerszy katalog
  niż powyżej progów UE, gdzie zwykle wymagany kwalifikowany podpis).
□ Art. 61-70, gdy mowa o "ofercie" — obejmuje TAKŻE ofertę wariantową,
  częściową, wstępną, dodatkową i podlegającą negocjacjom (rozszerzenie
  interpretacyjne wprost w ustawie).
```

**ROZDZIAŁ 8 — Dokumentowanie przebiegu postępowania (art. 71-82):**
```
□ Art. 71 i n. — obowiązek prowadzenia PROTOKOŁU postępowania powstaje
  BEZ WZGLĘDU na przyjęty sposób komunikowania się — zarówno przy
  komunikacji elektronicznej, jak i przy dopuszczalnych wyjątkach od niej.
□ Art. 72 — protokół musi zawierać m.in. informację o TRYBIE udzielenia
  zamówienia i wskazanie OKOLICZNOŚCI uzasadniających jego zastosowanie
  (przy trybach niekonkurencyjnych — kluczowe dla kontroli legalności).
□ Dokumentacja z postępowania UDOSTĘPNIANA na wniosek — MUSI być
  przekazana przy użyciu środków komunikacji ELEKTRONICZNEJ (tak samo
  jak sam protokół), niezależnie od formy, w jakiej pierwotnie
  prowadzono postępowanie.
```

⚠️ Pozostaje do dociągnięcia przy konkretnej sprawie: pełna, szczegółowa
treść poszczególnych artykułów 62/64/66-70 (specyfika komunikacji przy
poszczególnych czynnościach) oraz art. 73-82 (elementy protokołu,
załączniki, okres przechowywania) — powyższe to szkielet z kluczowymi
zasadami, nie wyczerpujący komentarz. Potwierdzone źródłowo: lexlege.pl,
ekomentarzpzp.uzp.gov.pl (oficjalny komentarz UZP — Rząd 1-adjacent),
legalnabudowa.pl, przetargipubliczne.pl, gov.pl (opracowanie UZP).

---

## 7. INTEGRACJA Z SYSTEMEM

- **`mod-PZP-zamowienia-publiczne-KIO.md`** — progi wartości (tabela już
  tam istniejąca), tryby udzielania — ten moduł dostarcza WYŁĄCZNIE
  fundamenty (czy ustawa się stosuje, jak liczyć wartość), nie duplikuje
  trybów/wykluczenia/odwołań.
- **`mod-PZP-opis-przedmiotu-zakaz-znakow-towarowych.md`** — zasady z
  art. 16-20 (sekcja 4) jako podstawa oceny opisu przedmiotu zamówienia.
- **`mod-PZP-dzial-XI-XII-kontrola-kary-UZP.md`** — niedozwolony podział
  zamówienia jako podstawa kontroli/kary.
- **`mod-KK-slupy-fikcyjna-reprezentacja-spolki.md`** (DR-03) — wadliwe
  umocowanie pełnomocnika konsorcjum wykonawców.
- **`mod-KP-konflikt-interesow-rodzina-nepotyzm.md`** (DR-04) — ogólna
  perspektywa pracownicza konfliktu interesów (rodzina/nepotyzm) —
  sekcja 6.1 tego modułu dostarcza SPECYFICZNE, ustawowe zastosowanie
  w kontekście PZP (art. 56), z węższym zakresem pokrewieństwa (2.
  stopień w linii bocznej) niż ogólne rozważania compliance.
- **`prawo-polskie-v2/krajowe/shared/definicje/DEF-INTERES-WLASNY-WYLACZENIA.md`** — analogiczny
  mechanizm wyłączenia sędziego (art. 48-49 KPC, pokrewieństwo do 4.
  stopnia w linii bocznej — SZERSZY zakres niż art. 56 PZP) i biegłego
  sądowego (art. 281 KPC) — dla porównania między reżimami proceduralnymi.
- **`mod-KK-art228-231-korupcja-urzednicza.md`, `mod-KK-art296a-korupcja-
  sektor-prywatny.md`, `mod-KK-art270-310-falszerstwa-dokumentow.md`**
  (DR-03) — przestępstwa z Przesłanki 4 (art. 56 ust. 3).

---

## 8. LITERATURA I ŹRÓDŁA (zweryfikowane online 2026-07-18)

- Tekst jednolity PZP — ISAP/lexlege.pl/gofin.pl (struktura Działu I,
  próg 170 000 zł potwierdzony).
- ekomentarzpzp.uzp.gov.pl — oficjalny e-komentarz UZP do art. 9, 11
  (wyłączenia, w tym usługi prawne, badania naukowe).
- SN, wyrok z 16.09.2009, sygn. II CSK 104/09 (Legalis) — wyłączenie
  nieruchomości nie obejmuje nieruchomości niepowstałej/wymagającej
  znacznych robót.
- gov.pl/web/uzp — oficjalne opinie UZP nt. wyłączenia dla badań
  naukowych (art. 4 pkt 8a dawnej numeracji).
- apexnet.com.pl, zamowienia.org.pl — praktyczne omówienia wyłączeń i
  zakazu dzielenia zamówień.
