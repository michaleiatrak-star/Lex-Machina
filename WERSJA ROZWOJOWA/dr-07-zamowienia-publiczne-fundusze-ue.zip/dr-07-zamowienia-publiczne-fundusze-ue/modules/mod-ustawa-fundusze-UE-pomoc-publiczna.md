# mod-ustawa-fundusze-UE-pomoc-publiczna

**Akt:** PZP (Prawo zamówień publicznych) — t.j. Dz.U. 2026 poz. 793 (zm. po t.j.: 2026/1347 [OD 2026-12-01: 2026/1347] — art. 214, 364).
**Akt:** NIK (ustawa o Najwyższej Izbie Kontroli) — t.j. Dz.U. 2022 poz. 623 (zm. po t.j.: 2026/26 [OD 2027-01-01: 2026/26] — art. 92, 93).
**Akt:** URIO (ustawa o regionalnych izbach obrachunkowych) — t.j. Dz.U. 2025 poz. 7.
**Akt:** UFP (ustawa o finansach publicznych) — t.j. Dz.U. 2026 poz. 1447.
**Akt:** UZRFE (ustawa o zasadach realizacji zadań finansowanych ze środków europejskich 2021–2027) — t.j. Dz.U. 2025 poz. 1733.
**Akt:** UPSPP (ustawa o postępowaniu w sprawach dotyczących pomocy publicznej) — t.j. Dz.U. 2026 poz. 500.
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

**Status:** moduł klasy kancelaryjnej — poziom DR-03
**Źródło weryfikacji:** Ustawa wdrożeniowa 2021-2027 (zasady realizacji zadań finansowanych
ze środków europejskich w perspektywie finansowej 2021-2027, z 28.04.2022) — Dz.U. 2025
poz. 1733 t.j. (pierwszy t.j.; akt pierwotny Dz.U. 2022 poz. 1079; po t.j.: 2025/1844, 2026/912 — ELI 2026-10-09) | Ustawa o zasadach prowadzenia polityki rozwoju
(z 6.12.2006) — Dz.U. 2026 poz. 1366 t.j. (obwieszczenie 17.09.2026, stan na 8.09.2026; ELI 2026-11-11; obejmuje Dz.U. 2025 poz. 1846: art. 5 pkt 7ac, art. 14ll–14lr, nowy rozdz. 2ac — inwestycja KPO w zakresie bezpieczeństwa i obronności; hierarchia dokumentów strategicznych bez zmian; poprzedni t.j. 2025.198)
| Ustawa o postępowaniu w sprawach pomocy publicznej — Dz.U. 2026 poz. 500 t.j. (poprzedni
t.j.: Dz.U. 2024 poz. 1635; Dz.U. 2023 poz. 702) ✅ VER: 2026-08-15
**Data weryfikacji online:** 2026-08-15 — FAZA 3E (audyt-systemu-v4): ⛔ CRIT-TREŚĆ
naprawiony — moduł błędnie przypisywał numer 2025.1733 (który należy do ustawy
WDROŻENIOWEJ 2021-2027) do ustawy o POLITYCE ROZWOJU; to są dwa odrębne akty z odrębnymi
t.j. (potwierdzone: gofin.pl + isap.sejm.gov.pl, oba źródła niezależnie)
**Zasada:** Każde brzmienie przepisu przed powołaniem → isap.sejm.gov.pl

---

## 1. CORE

### Zakres
Perspektywa finansowa UE 2021–2027 (EFRR, EFS+, Fundusz Spójności, FST), instytucje zarządzające (IZ), wdrażające (IP, IW), nabory wniosków, umowy o dofinansowanie, kontrole, zwrot dotacji, korekty finansowe. Pomoc publiczna (art. 107 TFUE), de minimis, GBER, notyfikacja KE. Polityka rozwoju (dokumenty strategiczne, kontrakty programowe).

### Akty

| Akt | Dz.U. |
|---|---|
| Ustawa wdrożeniowa 2021–2027 (realizacja zadań fin. ze środków europejskich, 28.04.2022) | Dz.U. 2025 poz. 1733 t.j. (pierwszy t.j.; akt pierwotny Dz.U. 2022 poz. 1079; po t.j.: 2025/1844, 2026/912 — ELI 2026-10-09) |
| Ustawa o zasadach prowadzenia polityki rozwoju (6.12.2006) | Dz.U. 2026 poz. 1366 t.j. (obwieszczenie 17.09.2026; poprzedni t.j. 2025.198) |
| Ustawa o postępowaniu w sprawach pomocy publicznej | Dz.U. 2026 poz. 500 t.j. (poprzedni t.j.: Dz.U. 2024 poz. 1635; Dz.U. 2023 poz. 702) ✅ VER: 2026-08-15 |
| Rozporządzenie ogólne UE 2021/1060 | stosowane bezpośrednio — funduszowe |
| Rozporządzenia EFRR, EFS+, FS | stosowane bezpośrednio |
| Rozporządzenie de minimis | Rozp. (UE) 2023/2831 — nowe od 01.01.2024 |

---

## 2. INTAKE

```
□ Perspektywa finansowa: 2021–2027 (aktualna) czy 2014–2020 (rozliczana)?
□ Etap: nabór wniosków / ocena / umowa / realizacja / kontrola / zwrot?
□ Czy jest decyzja o naborze, umowa dofinansowania lub decyzja o zwrocie?
□ Data doręczenia decyzji → termin odwołania!
□ Czy dotyczy pomocy publicznej? Który instrument: de minimis / GBER / notyfikacja?
□ Kwota dofinansowania / kwota do zwrotu?
□ Czy przeprowadzono kontrolę? Jakie ustalenia?
```

---

## 3. FUNDUSZE UE 2021–2027 — PROCEDURA

### Architektura systemu

```
Komisja Europejska (KE)
  → Umowa Partnerstwa z Polską (UPP 2021–2027)
    → Programy Operacyjne (krajowe i regionalne):
       FENG (innowacje), FERC (kolej), FEPW (wschód), FEnIKS (infrastruktura),
       FEW (woj. odpowiedniki — 16 programów regionalnych)
       KPO (Krajowy Plan Odbudowy — odrębny instrument)

Instytucje w systemie:
  IZ (Zarządzająca) — ministerstwo / marszałek
  IP (Pośrednicząca) — delegowane zadania
  IW (Wdrażająca) — nabory wniosków, umowy z beneficjentami
```

### Ścieżka odwoławcza beneficjenta

```
Negatywna ocena wniosku / odmowa dofinansowania:
  → Protest do IZ (termin: 14 dni od doręczenia informacji)
  → Wynik protestu → skarga do WSA (termin: 14 dni od wyniku protestu)
  → NSA (skarga kasacyjna: 30 dni od wyroku WSA)
  ⚠️ Terminy — weryfikuj aktualne w ustawie o realizacji funduszy UE w ELI (RZĄD 1)

Decyzja o zwrocie dotacji:
  → KPA → odwołanie (14 dni) → WSA → NSA
```

### Zwrot dotacji — typowe przyczyny

```
□ Naruszenie zasad PZP przy zamówieniach w projekcie
□ Kwalifikowalność wydatków (wykazanie poniesienia i związku z projektem)
□ Nieosiągnięcie wskaźników rezultatu
□ Podwójne finansowanie (ten sam wydatek z dwóch źródeł)
□ Nieprawidłowości w dokumentacji (faktury, zestawienia, raporty)
□ Zmiana przeznaczenia dofinansowanego majątku (trwałość projektu)

KOREKTY FINANSOWE:
  → Taryfikator korekt (MFiPR) — weryfikuj aktualny
  → Naruszenie PZP: korekta 5% / 10% / 25% / 100% w zależności od wagi naruszenia
```

---

## 4. POMOC PUBLICZNA

### Zasady absolutne

```
ZAKAZ (art. 107 ust. 1 TFUE):
  Selektywna korzyść dla przedsiębiorstwa finansowana z zasobów państwowych,
  zakłócająca konkurencję i wpływająca na wymianę handlową w UE

WYJĄTKI:
  → De minimis: do 300 000 EUR / 3 lata obrotowe (Rozp. UE 2023/2831, od 01.01.2024)
    ⚠️ NOWE ROZPORZĄDZENIE od 01.01.2024 — poprzednie: 200 000 EUR
    Rolnictwo: 20 000 EUR / 3 lata (Rozp. UE 2023/2832)
    Transport: 300 000 EUR / 3 lata
  → GBER (Rozp. UE 2022/2472 — nowy od 2023):
    Wyłączenia blokowe dla wybranych kategorii (B+R, MŚP, inwestycje, szkolenia)
  → Pomoc indywidualna: notyfikacja KE i zatwierdzenie przed udzieleniem

KUMULACJA POMOCY:
  → Zakaz przekraczania intensywności z różnych programów / instrumentów
  → Rejestracja w SUDOP (System Udostępniania Danych o Pomocy Publicznej)

ZWROT POMOCY NIEZGODNEJ:
  → Decyzja KE + odsetki (rynkowe od dnia udzielenia)
  → Zawieszenie de minimis gdy przekroczony limit
```

---

## 5. DOKUMENTY POLITYKI ROZWOJU

```
Ustawa o polityce rozwoju — Dz.U. 2026 poz. 1366 t.j. (obwieszczenie 17.09.2026):

Hierarchia dokumentów:
  DSRK — Długookresowa Strategia Rozwoju Kraju (> 10 lat)
  SSRK — Średniookresowa Strategia Rozwoju Kraju (5–10 lat)
  Strategie sektorowe i tematyczne
  Strategia Rozwoju Województwa (SRW)
  Strategie Rozwoju Ponadlokalnego
  Strategie Gminne

Instrumenty realizacji:
  Kontrakt programowy (MFiPR ↔ marszałek woj.)
  Porozumienie terytorialne (wiele podmiotów JST + agencje)
  Umowa Partnerstwa 2021–2027 (Polska ↔ KE)
```

---

## 6. DOWODY

| Teza | Dowód | Źródło | Siła | Luka | Działanie |
|---|---|---|---|---|---|
| Kwalifikowalność wydatku | Faktura + dowód zapłaty + protokół odbioru | projekt | wysoka | brak protokołu | uzupełnij dokumentację |
| Naruszenie PZP w projekcie | Dokumentacja postępowania przetargowego | projekt | wysoka | brak protokołu KIO | wyjaśnienia do IZ |
| Limit de minimis nieprzekroczony | Zaświadczenia z SUDOP / oświadczenie | SUDOP | wysoka | brak danych histor. | weryfikacja w SUDOP |
| Trwałość projektu | Dokumenty własności / użytkowania majątku | projekt | wysoka | zmiana przeznaczenia | wyjaśnienia |

---

## 7. STRATEGIA, QUALITY GATE, OUTPUT

**Strategia:** Przy zwrocie dotacji — zaskarż decyzję i kwestionuj taryfikator korekt (nieproporcjonalne). Przy de minimis — zawsze weryfikuj limit w SUDOP przed udzieleniem. Przy kontroli — dostarcz pełną dokumentację zanim wynik kontroli zostanie zatwierdzony.

**Quality gate:** Termin protestu (14 dni) / odwołania (14 dni) obliczony? Nowe de minimis 300 000 EUR (od 01.01.2024) zastosowane? Ustawa wdrożeniowa 2021-2027 — aktualny t.j. Dz.U. 2025 poz. 1733? Ustawa polityki rozwoju — aktualny t.j. Dz.U. 2026 poz. 1366?

**Output:** Kwalifikacja (fundusz / instrument) → etap → termin → dowody → korekty → strategia → rekomendacja.

**Powiązania:** `mod-PZP-zamowienia-publiczne-KIO` (PZP w projektach) | `dr-06` → `mod-UFP-finanse-publiczne-NIK-RIO` | `pisma-procesowe-v3` | `orzeczenia-sadowe-v2`

**Źródła:** https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20250001733 (ustawa wdrożeniowa) | https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20250000198 (polityka rozwoju) | https://funduszeeuropejskie.gov.pl | https://sudop.uokik.gov.pl
