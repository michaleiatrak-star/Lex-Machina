# mod-ustawa-zaskarzanie-decyzji-wlasnosci

**Akt:** KPA — t.j. Dz.U. 2025 poz. 1691 (stan 2025-11-03).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy i progi porównane z t.j.).

**Status:** moduł klasy kancelaryjnej — poziom DR-03
**Źródło weryfikacji:** KPA art. 156 §2 — Dz.U. 2025 poz. 1691 | Ustawa reprywatyzacyjna — Dz.U. 2021 poz. 795 ze zm.
**Data weryfikacji online:** 2026-06-05
⚠️ POPRAWKA 2026-07-27 (FAZA 3E/ZASADA 14): cały moduł błędnie cytował
"art. 156 §2a KPA" — poprawnie to art. 156 **§2** (bez litery "a").
Sama TREŚĆ progów (10/30 lat) była już poprawna i potwierdzona w 6+
zgodnych źródłach (kancelariarewers.pl, prawo.pl, infor.pl,
krotoski-adwokaci.pl, prawobiznesu.com) — poprawiono WYŁĄCZNIE numer
paragrafu we wszystkich 8 wystąpieniach w tym pliku.
**Zasada:** Każde brzmienie przepisu przed powołaniem → isap.sejm.gov.pl

---

## 1. CORE

### Zakres
Art. 156 § 2 KPA — nie stwierdza się nieważności z przyczyn wymienionych w § 1, jeżeli upłynęło 10 LAT od doręczenia lub ogłoszenia albo decyzja wywołała nieodwracalne skutki prawne; art. 158 § 3 KPA — po 30 LATACH od doręczenia/ogłoszenia decyzji z art. 156 § 2 nie wszczyna się postępowania (✅ [VER] RZĄD 1 2026-09-16m; ⛔ poprzednio „156 § 2 — nieruchomości po 30 latach" — obie reguły dotyczą wszystkich decyzji, nie tylko nieruchomości); ustawa reprywatyzacyjna (dekret warszawski — komisja ds. reprywatyzacji); odszkodowanie jako alternatywa po upływie terminu nieważności.

### Akty

| Akt | Dz.U. |
|---|---|
| KPA art. 156 §2 i art. 158 §3 | Dz.U. 2025 poz. 1691 t.j. |
| Ustawa z 11.08.2021 r. o zmianie KPA (art. 156 §2) | Dz.U. 2021 poz. 1491 (ELI 2026-10-09; było błędnie „z 09.06.2021, Dz.U. 2021 poz. 1706” — rozporządzenie MKiŚ) |
| Ustawa reprywatyzacyjna (nieruchomości warszawskie) | Dz.U. 2021 poz. 795 ze zm. |

---

## 2. INTAKE

```
□ Kiedy została wydana i doręczona kwestionowana decyzja?
□ Czy minęło 10 lat? (ograniczenie stwierdzenia nieważności)
□ Czy minęło 30 lat? (całkowity zakaz nieważności — możliwe tylko odszkodowanie)
□ Czy dotyczy nieruchomości (art. 156 §2 KPA) czy innej sprawy?
□ Czy to sprawa warszawska (dekret Bieruta 1945)?
□ Kto jest stroną: dawny właściciel / następca prawny / nabywca od gminy / inwestor?
```

---

## 3. PROCEDURA

### Ograniczenia nieważności decyzji dot. nieruchomości (art. 156 §2 KPA)

```
Nowelizacja KPA (Dz.U. 2021 poz. 1491 — w życie od 16.09.2021):

DO 10 LAT od doręczenia decyzji:
  → Stwierdzenie nieważności MOŻLIWE (art. 156 §1 KPA)

PO 10 LATACH od doręczenia decyzji:
  → NIE stwierdza się nieważności decyzji dotyczącej nieruchomości
  → Możliwe wyłącznie: stwierdzenie wydania decyzji z naruszeniem prawa
  → Skutek: podstawa roszczenia odszkodowawczego (art. 4171 §2 KC)

PO 30 LATACH od doręczenia decyzji:
  → ZAKAZ wszczęcia postępowania nieważnościowego (art. 158 §3 KPA)
  → Postępowania wszczęte po 30 latach umarza się z mocy prawa
  → Możliwe wyłącznie: odszkodowanie z KC

⚠️ Weryfikuj aktualne brzmienie art. 156 §2 i art. 158 §3 KPA w ELI (RZĄD 1).
```

### Ustawa reprywatyzacyjna (nieruchomości warszawskie)

```
Komisja ds. reprywatyzacji nieruchomości warszawskich:
  → Bada decyzje zwrotowe wydane na podstawie dekretu Bieruta (1945)
  → Może uchylić decyzję zwrotową: w ciągu 5 lat od jej wydania
  → Dotyczy: nieruchomości na terenie m.st. Warszawy

Dawni właściciele / następcy prawni:
  → Po 30 latach od decyzji wywłaszczeniowej: wyłącznie odszkodowanie
  → Odszkodowanie: art. 417¹ § 2 KC (szkoda wyrządzona decyzją — po stwierdzeniu jej
    nieważności albo wydania z naruszeniem prawa); przedawnienie — art. 442¹ KC
    ⛔ art. 160 KPA jest UCHYLONY (✅ [VER] RZĄD 1 2026-09-16m) — nie powołuj go jako podstawy ani terminu;
    dla decyzji sprzed jego uchylenia — przepisy przejściowe, odczyt przy sprawie
```

---

## 4. KALKULATOR TERMINÓW

```
Data decyzji wywłaszczeniowej / nacjonalizacyjnej: [___]
                                                          ↓
+ 10 lat → [___] = ostatni dzień na stwierdzenie nieważności
+ 30 lat → [___] = ostatni dzień na wszczęcie postępowania nieważnościowego
                    po tej dacie: wyłącznie odszkodowanie

⚠️ Sprawdź przepisy przejściowe ustawy z 2021 r. — weryfikuj ISAP.
```

---

## 5. STRATEGIA, DOWODY, QUALITY GATE, OUTPUT

**Strategia:** Przed wszczęciem postępowania — oblicz terminy z art. 156 §2 i art. 158 §3 KPA. Przy upływie 10 lat — wniosek o stwierdzenie naruszenia prawa + odszkodowanie z art. 4171 KC. Dla spraw warszawskich — sprawdź czy komisja reprywatyzacyjna ma właściwość.

**Dowody:** Data doręczenia decyzji (potwierdzenie z akt archiwalnych) + dokumenty własności + dokumenty nacjonalizacji/wywłaszczenia + wycena nieruchomości (przy odszkodowaniu).

**Quality gate:** Termin 10/30 lat obliczony? KPA art. 156 §2 zweryfikowany? Przepisy przejściowe (2021) sprawdzone?

**Output:** 1. Kwalifikacja (termin od decyzji); 2. Dopuszczalny tryb (nieważność / naruszenie prawa / odszkodowanie); 3. Dowody; 4. Strategia; 5. Rekomendacja.

**Powiązania:** `dr-02` → `mod-KC-cywilne-zobowiazania-odpowiedzialnosc` (odszkodowanie z art. 4171 KC) | `dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-KPA-postepowanie-administracyjne.md` | `pisma-procesowe-v3`

**Źródła:** https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20251691 (KPA) | https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20210000795 (ustawa reprywatyzacyjna)
