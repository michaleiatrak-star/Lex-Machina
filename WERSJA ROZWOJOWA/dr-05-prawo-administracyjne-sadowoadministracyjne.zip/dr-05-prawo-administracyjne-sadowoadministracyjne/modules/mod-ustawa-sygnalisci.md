# mod-ustawa-sygnalisci — Ochrona Sygnalistów [PERSPEKTYWA PROCESOWA]

**Akt:** USygn (ustawa o ochronie sygnalistów) — Dz.U. 2024 poz. 928 (akt pierwotny, bez t.j.; bez zmian w ELI na 2026-11-14).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy i progi porównane z t.j.).

**Zakres modułu:** SYGNALISTA jako podmiot chroniący swoje prawa — zgłoszenie, kanały, ochrona przed odwetem, roszczenia, pisma procesowe.
**Wersja kanoniczna dla compliance pracodawcy / CMS / ISO 37301:** `dr-15` → `mod-ustawa-sygnalisci.md`
**Świadome utrzymanie dwóch wersji:** TAK — zakresy się nie pokrywają; tu perspektywa procesowo-pracownicza, w DR-15 perspektywa compliance pracodawcy.

**Status:** moduł klasy kancelaryjnej
**Źródło weryfikacji:** Ustawa o ochronie sygnalistów — Dz.U. 2024 poz. 928 (w życie: 25.09.2024)
**Data weryfikacji online:** 2026-06-05
**Zasada:** Każde brzmienie przepisu przed powołaniem → isap.sejm.gov.pl

---

## ⚡ ALERT — NOWA USTAWA OD 25.09.2024

```
Ustawa z 14.06.2024 r. o ochronie sygnalistów (Dz.U. 2024 poz. 928)
  → Implementacja Dyrektywy UE 2019/1937
  → W życie: 25.09.2024 (kanały zewnętrzne) / 01.01.2025 (małe podmioty 50–249 pracowników)
  → Zastąpiła fragmentaryczną ochronę z KP i innych aktów
```

---

## 1. CORE

### Zakres tego modułu (DR-05)
Ochrona sygnalisty zgłaszającego naruszenia: dobór kanału zgłoszenia (wewnętrzny / zewnętrzny / publiczny), prawa sygnalisty wobec organu i pracodawcy, ochrona przed działaniami odwetowymi (roszczenia, domniemanie), ścieżka procesowa gdy doszło do odwetu, pisma: zawiadomienie do RPO/PIP, pozew o odszkodowanie, zawiadomienie o przestępstwie.

### Akty

| Akt | Dz.U. |
|---|---|
| Ustawa o ochronie sygnalistów | Dz.U. 2024 poz. 928 |
| Dyrektywa UE 2019/1937 | bezpośrednio stosowana pomocniczo |

---

## 2. INTAKE

```
□ Jaki rodzaj naruszenia: korupcja / prawo podatkowe / ochrona środowiska /
  zamówienia publiczne / ochrona konsumentów / usługi finansowe / AML / inne?
  ⚠️ POPRAWKA KRYTYCZNA 2026-07-27 (FAZA 3E/ZASADA 14, ta sama poprawka
  co w dr-15-compliance-iso-governance-audyt/modules/mod-ustawa-sygnalisci.md): PRAWO PRACY, WŁĄCZNIE Z BHP,
  ZOSTAŁO WPROST USUNIĘTE Z ZAMKNIĘTEGO KATALOGU na etapie senackim,
  mimo że pierwotny projekt MRPiPS je zawierał (potwierdzone: inforlex.pl,
  forbes.pl, sygnalista24.info). W TYM MODULE (perspektywa pracownicza)
  to ZNACZY: pracownik zgłaszający WYŁĄCZNIE naruszenie prawa pracy/BHP
  (bez elementu z innej dziedziny katalogu, np. korupcji) NIE korzysta
  z trybu/ochrony TEJ ustawy — ma inną, wcześniejszą podstawę ochrony
  przed odwetem (nowelizacja KP z 21.11.2008), oraz zwykłą skargę
  pracowniczą do PIP (NIE tryb "sygnalisty")
□ Czy naruszenie mieści się w zakresie dyrektywy/ustawy (katalog art. 3 —
  BEZ prawa pracy/BHP, patrz wyżej)?
□ Który kanał zgłoszenia wybrać: wewnętrzny (pracodawca) / zewnętrzny (organ) / jawny?
□ Czy nastąpiły już działania odwetowe (zwolnienie, pominięcie awansu, szykana)?
□ Jaki status prawny sygnalisty: pracownik / zleceniobiorca / samozatrudniony / b. pracownik?
□ Czy sygnalista chce ujawnić tożsamość czy działać anonimowo?
□ Czy zachodzi ryzyko przedawnienia roszczenia pracowniczego?
```

---

## 3. PROCEDURA

### Kanały zgłoszenia (ścieżka sygnalisty)

```
WEWNĘTRZNY (do pracodawcy):
  → Pracodawcy ≥ 50 pracowników muszą mieć procedurę wewnętrzną
  → Termin: 7 dni na potwierdzenie przyjęcia + 3 miesiące na informację
    o podjętych działaniach (weryfikuj w ustawie — ISAP)
  → Sygnalista NIE ma obowiązku korzystania z kanału wewnętrznego

ZEWNĘTRZNY (do organów publicznych, ZALEŻNIE OD DZIEDZINY naruszenia):
  → RPO (bip.brpo.gov.pl) — organ DOMYŚLNY dla dziedzin bez własnego
    organu (konstytucyjne prawa/wolności) + koordynacja/przekierowanie
  → ⚠️ PIP — NIE dla prawa pracy/BHP jako takiego w TRYBIE SYGNALISTY
    (patrz poprawka wyżej) — właściwa tylko dla ODWETU związanego z
    zatrudnieniem (mobbing/degradacja za zgłoszenie INNEJ dziedziny)
  → UOKiK — ochrona konsumentów / nieuczciwa konkurencja (TYLKO interes
    zbiorowy/publiczny, nie spory indywidualne)
  → KNF — sektor finansowy, w tym AML
  → inne organy branżowe (UODO, GIOŚ i in.) — weryfikuj właściwość wg
    dziedziny z katalogu art. 3

KANAŁ JAWNY (ujawnienie publiczne):
  → Dopuszczalne gdy: brak działania organów po zgłoszeniu wewnętrznym/zewnętrznym
    LUB bezpośrednie i oczywiste zagrożenie interesu publicznego
    LUB działania odwetowe
```

### Ochrona sygnalisty — zakres

```
ZAKAZ DZIAŁAŃ ODWETOWYCH (art. 12 ustawy — weryfikuj w ELI (RZĄD 1)):
  → Zakaz zwolnienia, degradacji, pominięcia awansu
  → Zakaz szykanowania, izolacji, mobbingu
  → Zakaz ujawnienia tożsamości sygnalisty
  → DOMNIEMANIE: działanie po zgłoszeniu = działanie odwetowe (ciężar obalenia na pracodawcy)

OCHRONA TOŻSAMOŚCI:
  → Dane sygnalisty: objęte ochroną — nie ujawnia się bez zgody
  → Wyjątek: wymogi postępowania sądowego

OCHRONA MAJĄTKOWA SYGNALISTY (przy działaniach odwetowych):
  → Prawo do odszkodowania (min. 3-krotność średniego wynagrodzenia — weryfikuj w ustawie)
  → Przywrócenie do pracy lub równoważna ochrona
```

---

## 4. DOWODY

| Teza | Dowód | Źródło | Siła | Luka | Działanie |
|---|---|---|---|---|---|
| Złożenie zgłoszenia | Potwierdzenie przyjęcia / UPO | organ/pracodawca | wysoka | — | zachowaj kopię ze znacznikiem czasu |
| Działanie odwetowe po zgłoszeniu | Data zgłoszenia vs data działania odwetowego | korespondencja | wysoka | związek przyczynowy | dokumentuj chronologię |
| Naruszenie prawa (treść zgłoszenia) | Dokumenty, e-maile, screenshoty | wnioskodawca | wysoka | brak dostępu | wnioskuj o zabezpieczenie |
| Dobra wiara sygnalisty | Okoliczności powzięcia wiedzy, brak korzyści | pośredni | średnia | subiektywne | zeznania świadków |

---

## 5. STRATEGIA

### Dla sygnalisty

1. Zbierz dowody naruszenia ZANIM złożysz zgłoszenie — po zgłoszeniu dostęp może być utrudniony.
2. Zachowaj potwierdzenie złożenia z datą.
3. Dokumentuj każde działanie pracodawcy po zgłoszeniu — domniemanie odwetu działa na korzyść.
4. Kanał zewnętrzny (RPO/PIP) daje pełną ochronę i jest bezpłatny.
5. Pozew o odszkodowanie → `pisma-procesowe-v3` (pismo złożone, wątek pracowniczy + ustawa).

---

## 6. QUALITY GATE / OUTPUT

**Quality gate:** Naruszenie w zakresie ustawy? Właściwy kanał wybrany? Dobra wiara sygnalisty? Aktualna ustawa z ISAP? Termin nie upłynął?

**Output:** 1. Kwalifikacja (zakres naruszenia / kanał); 2. Procedura zgłoszenia; 3. Ochrona sygnalisty; 4. Działania odwetowe (dowody i roszczenia); 5. Rekomendacja + ewentualne pisma.

**Powiązania:**
- `dr-04` → `mod-KP-prawo-pracy` — zwolnienie, roszczenia pracownicze
- `dr-04` → `mod-ustawa-PIP-inspekcja-pracy` — PIP jako organ kontroli i kanał zewnętrzny
- `dr-04` → `mod-KP-naduzycia-pracodawcy-limity-kary-degradacja` (dodane
  2026-07-17) — GDY odwet wobec sygnalisty przybiera formę DEGRADACJI:
  ten moduł (DR-05) dostarcza domniemanie odwetu, tamten (DR-04) dostarcza
  analizę formalnej poprawności samego trybu degradacji (wypowiedzenie
  zmieniające art. 42 KP vs próba zamaskowania kary porządkowej poza
  zamkniętym katalogiem art. 108 KP) — stosuj oba łącznie
- `pisma-procesowe-v3` — pozew o odszkodowanie za odwet, zawiadomienie do RPO
- `dr-04-prawo-pracy-zus-swiadczenia/modules/mod-klasyfikacja-naruszen-bhp-prawa-pracy.md` — GDZIE ZGŁOSIĆ
  naruszenie BHP/prawa pracy, skoro NIE w trybie sygnalisty (dodano 2026-07-27)
- `dr-15` → `mod-ustawa-sygnalisci.md` — perspektywa compliance pracodawcy / CMS / ISO 37301

**Źródła:**
- https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20240000928
- https://bip.brpo.gov.pl (zgłoszenia sygnalistów)
- https://pip.gov.pl
