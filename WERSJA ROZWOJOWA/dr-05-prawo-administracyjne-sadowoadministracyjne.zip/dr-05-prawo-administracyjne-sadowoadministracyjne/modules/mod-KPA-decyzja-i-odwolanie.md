# Moduł — KPA: decyzja administracyjna i odwołanie (elementy, procedura, postanowienia, zażalenia)

**Akt:** KPA — t.j. Dz.U. 2025 poz. 1691 (stan 2025-11-03).
**Akt:** PPSA — t.j. Dz.U. 2026 poz. 143 (zm. 2025/1882 od 2026-03-01 — art. 1, 2, 175; 2026/846 od 2026-06-26 — art. 53 § 1, 264 § 2; 2023/1860 [OD 2029-10-01: 2023/1860] — art. 66 (doręczenia)).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy i progi porównane z t.j.).

> ⚠️ TEN moduł jest CZĘŚCIĄ RODZINY plików KPA, PODZIELONEJ
> 2026-08-12 (NOTA-4, audyt-systemu-v4/references/CHECKLIST-DEDUP.md — moduł
> źródłowy osiągnął 1115 linii, ~2,8x próg 400 linii). RODZINA
> czterech plików: mod-KPA-postepowanie-administracyjne.md (rdzeń:
> zasady ogólne, strona, wyłączenie, doręczenia, wszczęcie
> postępowania, terminy, mapa postępowania), mod-KPA-mechanizmy-w-toku-sprawy.md (zawieszenie,
> dowody, rozprawa, terminy-obliczanie/przywrócenie), mod-KPA-decyzja-i-odwolanie.md (elementy
> decyzji, odwołanie, postanowienia/zażalenia), mod-KPA-tryby-
> nadzwyczajne-i-strategia.md (wznowienie, nieważność, załatwianie
> spraw/ponaglenie, bezczynność, postępowanie uproszczone,
> właściwość organów, kary, skarga do WSA, strategia).
>
> **⚠️ PRZY PODZIALE naprawiono kolejność:** sekcja o postępowaniu
> dowodowym (art. 75-88a) BYŁA omyłkowo umieszczona W nieprawidłowym
> miejscu oryginalnego pliku (między "skarga do WSA" a "checklist
> dowodowy") — TERAZ znajduje się we WŁAŚCIWYM, tematycznym miejscu
> obok zawieszenia postępowania i rozprawy.
>
> **⚠️ AUDYT 2026-08-13 — 4 luki uzupełnione w rodzinie plików**
> (ZASADA 7 OUTPUT-COMPLETENESS): art. 106/106a (współdziałanie
> organów), art. 189g-189k (przedawnienie/zaległość/ulgi kar), art.
> 265-267 (koszty postępowania), art. 22 §3 (spory kompetencyjne) —
> wszystkie w `mod-KPA-tryby-nadzwyczajne-i-strategia.md`. Dział IVa
> KPA (art. 189a-189k) domknięty w całości po naprawie regresji z
> tej samej sesji (przywrócona treść art. 189d/189f, uzupełnione
> art. 189a-189c/189e). Szczegóły:
> `audyt-systemu-v4/references/CHECKLIST-DEDUP.md`, NOTA-11/NOTA-12/NOTA-13. Kontynuacja: mediacja (96a-96n),
> metryki/protokoly (66a-72), udostepnianie akt (73-74a) w
> mod-KPA-mechanizmy-w-toku-sprawy.md; skarga na akty prawa
> miejscowego/nadzoru (art. 3 par. 2 pkt 5-7, 147-148, 152 PPSA)
> w mod-KPA-tryby-nadzwyczajne-i-strategia.md.

---

## 3c. ⭐⭐⭐ DECYZJA ADMINISTRACYJNA — ELEMENTY I WADLIWOŚĆ (art.
104-113 KPA) — dodano 2026-08-12, na żądanie użytkownika — dotąd
CAŁKOWICIE nieobecne

```
⭐⭐⭐ ART. 107 §1 — DZIEWIĘĆ elementów, KTÓRE decyzja MUSI zawierać:
  1) OZNACZENIE organu administracji PUBLICZNEJ
  2) DATĘ wydania
  3) OZNACZENIE strony LUB stron
  4) POWOŁANIE podstawy PRAWNEJ
  5) ROZSTRZYGNIĘCIE
  6) UZASADNIENIE faktyczne I prawne
  7) POUCZENIE, czy I w JAKIM trybie SŁUŻY odwołanie ORAZ o
     PRAWIE do zrzeczenia SIĘ odwołania i SKUTKACH zrzeczenia
  8) PODPIS z podaniem IMIENIA i nazwiska ORAZ stanowiska
     SŁUŻBOWEGO pracownika UPOWAŻNIONEGO do wydania decyzji
  9) (DLA decyzji, wobec KTÓREJ może być WNIESIONE powództwo do
     sądu POWSZECHNEGO, sprzeciw OD decyzji lub SKARGA do sądu
     administracyjnego) — POUCZENIE o dopuszczalności TYCH środków
     oraz WYSOKOŚCI opłaty

⭐⭐ §3: UZASADNIENIE faktyczne — POWINNO zawierać WSKAZANIE faktów
  UZNANYCH za udowodnione, DOWODÓW na których organ SIĘ oparł,
  oraz PRZYCZYN odmowy wiarygodności INNYM dowodom — UZASADNIENIE
  prawne — wyjaśnienie PODSTAWY prawnej Z przytoczeniem PRZEPISÓW

⭐⭐ §4-5 — WYJĄTKI od obowiązku UZASADNIENIA: MOŻNA odstąpić, GDY
  decyzja W CAŁOŚCI uwzględnia ŻĄDANIE strony — ⚠️ NIE dotyczy
  decyzji ROZSTRZYGAJĄCYCH sporne interesy STRON ani decyzji
  WYDANYCH na skutek ODWOŁANIA — RÓWNIEŻ MOŻNA odstąpić ZE względu
  na bezpieczeństwo PAŃSTWA/porządek publiczny

⭐⭐⭐ KLUCZOWE, PRAKTYCZNE rozróżnienie Z DOKTRYNY — elementy
  PIERWSZORZĘDNE vs DRUGORZĘDNE:
  → ELEMENTY PIERWSZORZĘDNE — ich BRAK powoduje WADLIWOŚĆ
    kwalifikowaną, UZASADNIAJĄCĄ stwierdzenie NIEWAŻNOŚCI (patrz
    sekcja 4 NIŻEJ) — PRZYKŁAD: PODPIS — MUSI być JEDNOZNACZNY
    (imię+NAZWISKO) — ⭐⭐⭐ DLA organów KOLEGIALNYCH: WSZYSCY
    członkowie MUSZĄ podpisać decyzję — POTWIERDZONE wyrokiem NSA Z
    **31.01.1991 R.** (sygn. SA/Kr 1304/40) — decyzja PODPISANA
    tylko PRZEZ NIEKTÓRYCH członków JEST nieważna Z powodu
    RAŻĄCEGO naruszenia prawa (art. 156 §1 pkt 2)
  → ELEMENTY DRUGORZĘDNE — BRAK/błąd NIE wpływa NA kwalifikację
    jako DECYZJI, tylko RODZI inne konsekwencje — PRZYKŁAD:
    POUCZENIE (pkt 7) — BŁĄD/brak NIE wywołuje SKUTKÓW w zakresie
    KWALIFIKACJI jako decyzji ADMINISTRACYJNEJ — stosuje SIĘ
    wówczas art. 112 KPA (zasada, że BŁĘDNE pouczenie NIE MOŻE
    szkodzić STRONIE — powiązanie Z sekcją 1a, zasady OGÓLNE)

⭐⭐ OZNACZENIE ORGANU — GRANICA wadliwości: CAŁKOWITY brak
  oznaczenia ORGANU (LUB jego aparatu POMOCNICZEGO) = wada
  KWALIFIKOWANA, uniemożliwiająca ZIDENTYFIKOWANIE organu →
  uzasadnia STWIERDZENIE nieważności — ALE sam BŁĄD/niedokładność
  (np. wskazanie APARATU pomocniczego zamiast SAMEGO organu) NIE
  wpływa na WAŻNOŚĆ, JEŚLI z treści SENTENCJI wynika jednoznacznie,
  KTO wydał decyzję

⭐⭐ PODSTAWA PRAWNA — TYLKO przepisy POWSZECHNIE obowiązujące:
  NIEDOPUSZCZALNE jest POWOŁYWANIE się na ZARZĄDZENIE ministra,
  uchwałę RADY Ministrów itp. — ⭐ POWIĄZANIE Z zasadą
  PRAWORZĄDNOŚCI (art. 6, sekcja 1a wyżej W tym module)

Potwierdzone w 8+ zgodnych źródeł, w tym BEZPOŚREDNIO dosłowny
tekst art. 107 (arslege.pl, lexlege.pl), studocu.com [Z pełnym
omówieniem PIERWSZORZĘDNYCH/drugorzędnych elementów], lexplay.pl [Z
cytowanym wyrokiem NSA SA/Kr 1304/40], inforlex.pl [×2, komentarz
KPA], salvoiure.pl [×2].
```

---

## 3d. ⭐⭐⭐ PROCEDURA ODWOŁANIA (art. 127-140 KPA) — dodano
2026-08-12, na żądanie użytkownika — dotąd TYLKO sam TERMIN był
opisany (sekcja "TERMINY" wyżej), BEZ samej materialnej procedury

```
⭐ ART. 127 §1: odwołanie PRZYSŁUGUJE stronie NIEZADOWOLONEJ z
  decyzji — wnosi SIĘ do organu ODWOŁAWCZEGO ZA pośrednictwem
  organu, KTÓRY wydał decyzję (NIE bezpośrednio DO organu wyższego)

⭐⭐⭐ ART. 132 — AUTOKONTROLA organu I INSTANCJI (⭐⭐⭐ KLUCZOWY,
  praktyczny mechanizm):
  → JEŻELI WSZYSTKIE strony postępowania WNIOSŁY odwołanie, A
    organ, KTÓRY wydał decyzję, UZNA, że ZASŁUGUJE ono W CAŁOŚCI
    na UWZGLĘDNIENIE — MOŻE wydać NOWĄ decyzję, W której UCHYLI
    lub ZMIENI zaskarżoną decyzję — BEZ przekazywania SPRAWY
    organowi wyższej INSTANCJI
  → TA SAMA zasada, GDY odwołanie WNIOSŁA tylko JEDNA ze stron,
    ale POZOSTAŁE strony WYRAZIŁY zgodę na UCHYLENIE/zmianę
  → ⭐⭐⭐ WAŻNE ograniczenie: uprawnienie TO NIE przysługuje
    organowi ODWOŁAWCZEMU — WYŁĄCZNIE organowi I instancji
    (potwierdzone WYROKIEM WSA Bydgoszcz Z 18.12.2007, sygn.
    II SA/Bd 449/07)
  → ZWROT akt sprawy organowi I INSTANCJI w NASTĘPSTWIE uchylenia
    decyzji (PRZEZ organ odwoławczy LUB sąd administracyjny) — NIE
    powoduje REAKTYWOWANIA uprawnienia DO autokontroli
  → ⭐ ŚWIEŻY, PRAKTYCZNY problem sygnalizowany PRZEZ urzędy (2026):
    BRAK dowodu ODBIORU decyzji przez STRONĘ powoduje, że organ I
    instancji NIE MOŻE ustalić, CZY odwołanie zostało ZŁOŻONE w
    ustawowym TERMINIE — utrudnia to STOSOWANIE art. 132 w PRAKTYCE

⭐ ART. 133: organ I instancji MA obowiązek PRZEKAZAĆ odwołanie
  WRAZ z aktami SPRAWY organowi odwoławczemu W terminie **7 DNI**
  (JEŚLI nie SKORZYSTAŁ z autokontroli)

⭐⭐⭐ ZAKRES DZIAŁANIA (KOGNICJA) organu ODWOŁAWCZEGO — ISTOTNY,
  praktyczny NIUANS: skutkiem WNIESIENIA odwołania jest
  ROZPOZNANIE CAŁEJ sprawy administracyjnej OD początku — organ
  ODWOŁAWCZY NIE jest ZWIĄZANY zakresem żądania WYRAŻONEGO w
  odwołaniu, NAWET GDY strona wyraża NIEZADOWOLENIE tylko CO do
  CZĘŚCI decyzji — ⭐ POTWIERDZONE W praktyce: KONTROLA instancyjna
  OBEJMUJE CAŁOŚĆ sprawy — sentencja TYPU "utrzymuje zaskarżoną
  decyzję W kwestionowanym ZAKRESIE W mocy" jest WADLIWA — sugeruje
  BŁĘDNIE, że W zakresie NIEKWESTIONOWANYM decyzja JEST już
  prawomocna, a SPRAWA W tym zakresie NIE była przedmiotem KONTROLI

⭐ ART. 136 — POSTĘPOWANIE WYJAŚNIAJĄCE w II instancji: organ
  ODWOŁAWCZY MOŻE samodzielnie UZUPEŁNIĆ postępowanie dowodowe
  ALBO zlecić TO organowi I instancji

⭐ ART. 137: strona MOŻE cofnąć ODWOŁANIE do CZASU wydania decyzji
  przez organ ODWOŁAWCZY — cofnięcie POWODUJE, że decyzja I
  instancji STAJE się ostateczna

⭐⭐⭐ ART. 138 — RODZAJE decyzji organu ODWOŁAWCZEGO:
  → decyzja REFORMATORYJNA — organ ORZEKA co do ISTOTY sprawy
    (zmienia ZASKARŻONĄ decyzję)
  → decyzja KASATORYJNA — uchylenie I przekazanie SPRAWY do
    ponownego rozpatrzenia (⭐ WYJĄTKOWO, NIE standardowe
    rozwiązanie)
  → UMORZENIE postępowania odwoławczego (§1 pkt 3) — GDY
    postępowanie STAŁO się bezprzedmiotowe, LUB gdy okaże SIĘ w
    toku, że WNOSZĄCY odwołanie NIE jest STRONĄ

⭐⭐⭐ ⚡ ART. 139 — ZAKAZ REFORMATIONIS IN PEIUS (⭐ jedna Z
  najważniejszych, praktycznych GWARANCJI procesowych): organ
  ODWOŁAWCZY NIE MOŻE wydać decyzji NA niekorzyść strony
  ODWOŁUJĄCEJ się — WYJĄTEK: GDY zaskarżona decyzja RAŻĄCO narusza
  PRAWO lub interes SPOŁECZNY — ⭐ NIE dotyczy decyzji KASACYJNEJ
  (utrwalony pogląd W orzecznictwie) — ⭐ WAŻNE: JEŚLI odwołanie
  WNOSZĄ OBIE strony (np. spór SĄSIEDZKI o pozwolenie NA budowę) —
  organ MOŻE orzec NA niekorzyść KAŻDEJ z nich

Potwierdzone w 8+ zgodnych, BARDZO aktualnych źródeł, w tym
gov.pl [Rząd 1, komunikat Mazowieckiego Urzędu Wojewódzkiego,
2026], dejnowicz.pl [czerwiec 2026, NAJŚWIEŻSZE], rp.pl [maj 2015,
Z cytowanym orzecznictwem], wyszukiwarka.legal [marzec 2026],
temidium.pl [Z omówieniem KOGNICJI], sip.lex.pl/OpenLEX, prawodlakazdego.pl,
wpia.uwm.edu.pl [materiał akademicki].
```

---

### Ostateczność a prawomocność decyzji — pytanie „klauzula ostateczności czy prawomocności?”

✅ [VER: ELI DU/2025/1691 (KPA t.j.), art. 16 — odczyt 2026-10-31; DU/2026/143 (PPSA t.j.), art. 52 § 3 — odczyt 2026-10-31, RZĄD 1]

- **art. 16 § 1 KPA:** decyzja, od której nie służy odwołanie ani wniosek o ponowne rozpatrzenie → **ostateczna**.
- **art. 16 § 3 KPA:** decyzja ostateczna, której nie można zaskarżyć do sądu → **prawomocna**.
- **art. 52 § 3 PPSA:** gdy stronie przysługuje wniosek o ponowne rozpatrzenie sprawy (decyzje ministrów, organów
  centralnych), strona może wnieść skargę do WSA **bez** skorzystania z tego wniosku (wyjątek: minister spraw
  zagranicznych w sprawach z ustawy o cudzoziemcach i konsul).
- ⛔ **„Klauzula prawomocności” to instytucja KPC (art. 363–364)** — sąd stwierdza prawomocność orzeczenia sądu.
  Decyzja administracyjna nie dostaje klauzuli z KPC; organ może natomiast **stwierdzić ostateczność, a po upływie
  terminu do skargi (albo po prawomocnym wyroku sądu administracyjnego) — prawomocność**, w praktyce adnotacją lub
  **zaświadczeniem** (art. 217 KPA).
- ⛔ **Konkluzja przy pytaniu „klauzula/stwierdzenie ostateczności czy prawomocności?” dla decyzji zaskarżalnej
  do WSA (np. zezwolenie ministra): PRAWOMOCNOŚĆ** — decyzja ministra staje się ostateczna po upływie terminu na
  wniosek o ponowne rozpatrzenie (lub po jego rozpoznaniu), ale ponieważ można ją zaskarżyć do WSA (art. 52 § 3
  PPSA — także bez wniosku), **prawomocna** jest dopiero po bezskutecznym upływie terminu do skargi albo po
  prawomocnym oddaleniu skargi (art. 16 § 3 KPA). To prawomocność potwierdza się zaświadczeniem organu, które
  wydał decyzję (art. 217 KPA; wydawanie takich zaświadczeń przez organ — praktyka, nie wymóg przepisu — oznacz).
  Nie zaczynaj odpowiedzi od „ostateczność” — wskaż ją jako etap wcześniejszy.


## 3e. ⭐⭐⭐ POSTANOWIENIA I ZAŻALENIA (art. 123-126, 141-144 KPA) —
dodano 2026-08-12, na żądanie użytkownika — dotąd CAŁKOWICIE
nieobecne, mimo że MODUŁ WIELOKROTNIE odsyła do "postanowień" w
INNYCH sekcjach (zawieszenie, wyłączenie), BEZ wyjaśnienia SAMEJ
tej instytucji

```
⭐⭐⭐ ART. 123 — CZYM JEST postanowienie (KLUCZOWA różnica OD
  decyzji): §1 W toku POSTĘPOWANIA organ WYDAJE postanowienia —
  §2 postanowienia DOTYCZĄ poszczególnych KWESTII wynikających W
  toku postępowania, LECZ NIE rozstrzygają O ISTOCIE sprawy,
  CHYBA że przepisy KODEKSU stanowią inaczej — ⭐⭐ TO fundamentalne
  rozróżnienie: DECYZJA kończy sprawę CO do MERITUM, postanowienie
  dotyczy kwestii PROCEDURALNYCH/wpadkowych (np. zawieszenie
  postępowania, WYŁĄCZENIE pracownika, dopuszczenie DOWODU)

⭐ ART. 124 — ELEMENTY: postanowienie POWINNO zawierać UZASADNIENIE
  faktyczne i PRAWNE, JEŻELI służy na NIE zażalenie, LUB skarga do
  sądu ADMINISTRACYJNEGO lub SŁUŻY od niego sprzeciw, ORAZ gdy
  zostało WYDANE na skutek ZAŻALENIA na postanowienie

⭐ ART. 125: postanowienie, NA które służy ZAŻALENIE/skarga/
  sprzeciw — DORĘCZA się NA piśmie

⭐⭐⭐ ART. 126 — ODESŁANIE do przepisów O decyzjach (⭐⭐⭐ WAŻNE
  uzupełnienie już OPISANEJ sekcji 4, TRYBY nadzwyczajne): DO
  postanowień STOSUJE się odpowiednio PRZEPISY art. 105, art. 107
  §2-5 oraz art. 109-113, A DO postanowień, OD których PRZYSŁUGUJE
  zażalenie, ORAZ do postanowień OKREŚLONYCH w art. 134 (o
  NIEDOPUSZCZALNOŚCI odwołania) — RÓWNIEŻ art. 145-152 oraz
  art. 156-159 — ⭐⭐⭐ OZNACZA to, że WZNOWIENIE postępowania I
  STWIERDZENIE nieważności MOGĄ dotyczyć TAKŻE postanowień, NIE
  tylko decyzji — Z TĄ różnicą, że ZAMIAST decyzji WYDAJE się
  wówczas POSTANOWIENIE

⭐ POTWIERDZENIE orzecznicze (wyrok WSA Warszawa Z 7.02.2008, sygn.
  IV SA/Wa 1547/07): uprawnienie DO doręczenia postanowienia MA
  TYLKO organ WYDAJĄCY to postanowienie — FAKT przesłania
  postanowienia PRZEZ inny organ NIE otwiera stronie BIEGU
  terminu do wniesienia ZAŻALENIA

⭐⭐⭐ ART. 141-144 — ZAŻALENIA (⭐ termin 7 dni JUŻ opisany W sekcji
  "TERMINY", TU materialna PROCEDURA):
  → art. 141 §1: zażalenie NA postanowienie PRZYSŁUGUJE TYLKO
    GDY przepisy KODEKSU tak STANOWIĄ (⭐ NIE każde POSTANOWIENIE
    można zaskarżyć — TYLKO te WYRAŹNIE wskazane, NP. odmowa
    przywrócenia TERMINU)
  → art. 142: postanowienie, NA które NIE służy ZAŻALENIE — strona
    MOŻE zaskarżyć TYLKO w ODWOŁANIU od decyzji (⭐ NIE jest więc
    CAŁKOWICIE pozbawiona kontroli — TYLKO odroczona DO momentu
    odwołania od DECYZJI kończącej sprawę)
  → ⭐⭐ art. 143: wniesienie ZAŻALENIA NIE wstrzymuje wykonania
    postanowienia — JEDNAK organ, KTÓRY je WYDAŁ, MOŻE wstrzymać
    jego WYKONANIE, gdy uzna TO za uzasadnione — ⭐ RÓŻNICA
    względem ODWOŁANIA od decyzji, GDZIE zasadą jest WSTRZYMANIE
    wykonania (art. 130, patrz mapa POSTĘPOWANIA wyżej)
  → art. 144: W sprawach NIEUREGULOWANYCH w TYM rozdziale — DO
    zażaleń MAJĄ odpowiednie ZASTOSOWANIE przepisy DOTYCZĄCE
    odwołań (powiązanie Z sekcją 3d WYŻEJ)

Potwierdzone w 7+ zgodnych źródeł, w tym BEZPOŚREDNIO dosłowny
tekst art. 123-126 i 141-144 (e-prawnik.pl [×2], lexlege.pl [×3]),
rp.pl [Z cytowanym wyrokiem WSA Warszawa], przepisy.gofin.pl
[kwiecień 2024].
```

---

---

## Połącz z
- DR-05/mod-KPA-postepowanie-administracyjne (moduł MACIERZYSTY)
- DR-05/mod-KPA-tryby-nadzwyczajne-i-strategia (wznowienie/nieważność MOGĄ dotyczyć też postanowień)

## Odwołanie w praktyce (dodano 2026-11-19)

> Praktyka ze źródeł (2026-11-19): każda reguła ma źródło (Pn). Orzeczenia przytoczone przez źródła wtórne oznaczone `[ORZ-DO-WERYFIKACJI]` — przed powołaniem `weryfikator-orzeczen`. Tezy źródeł starszych niż t.j. sprawdzone z t.j.; rozbieżność = KOREKTA.

### SO-5 — Odwołanie od decyzji administracyjnej (KPA)

- **Treść (art. 128):** nie wymaga szczegółowego uzasadnienia — wystarczy niezadowolenie; przepisy szczególne mogą wymagać więcej (sprawdź ustawę materialną: podatkowe, budowlane, środowiskowe). Praktyka (P9): przy sprawach złożonych formułuj zarzuty precyzyjnie, bo wyznaczają kierunek kontroli i przyszłą skargę do WSA.
- **Droga i termin (art. 129):** do organu odwoławczego za pośrednictwem organu, który wydał decyzję; 14 dni od doręczenia (od ogłoszenia — decyzja ustna). Częsty błąd: złożenie wprost do organu wyższego stopnia (P10) — organ przekazuje pismo (art. 65 § 1 KPA), a podanie wniesione do organu niewłaściwego przed upływem terminu uważa się za wniesione w terminie (art. 65 § 2) — ale przekazanie wydłuża sprawę; wnoś za pośrednictwem organu I instancji i zachowaj dowód nadania (P9). Uchybienie terminu: prośba o przywrócenie w 7 dni od ustania przyczyny z dopełnieniem czynności (art. 58 § 1–2); o przywróceniu terminu do odwołania postanawia ostatecznie organ odwoławczy (art. 59 § 2).
- **Autokontrola (art. 132):** organ I instancji może uwzględnić odwołanie w całości, gdy wniosły je wszystkie strony albo pozostałe się zgodziły; inaczej przekazuje akta w 7 dni (art. 133).
- **Postępowanie wyjaśniające w II instancji (art. 136 § 2–3):** na zgodny wniosek stron zawarty w odwołaniu organ odwoławczy przeprowadza je sam zamiast kasacji — rozważ ten wniosek, gdy zależy na czasie.
- **Rozstrzygnięcia (art. 138):** utrzymanie, uchylenie i orzeczenie co do istoty, umorzenie; kasacja tylko przy naruszeniu procedury i istotnym zakresie do wyjaśnienia (§ 2), z wytycznymi wykładni (§ 2a).
- **Zakaz reformationis in peius (art. 139):** wyjątek — rażące naruszenie prawa lub interesu społecznego; oceń ryzyko przed wniesieniem odwołania od decyzji częściowo korzystnej.
- **Niedopuszczalność i uchybienie terminu** stwierdza organ odwoławczy postanowieniem ostatecznym (art. 134) — droga dalej: przywrócenie terminu (art. 58–59 KPA); zaskarżalność postanowienia do WSA sprawdź w PPSA przed wskazaniem tej drogi.
- Silnik ogólny: `references/engines/admin-pleading-engine-v8.md`.

#### Źródła praktyki (odczyt 2026-11-19)

- P9 — Odwołanie od decyzji administracyjnej, e-prawnik.pl i infor.pl (omówienia art. 128–129 KPA): https://e-prawnik.pl/artykuly/odwolanie-od-decyzji-administracyjnej.html
- P10 — Postępowanie sądowoadministracyjne — zajęcia 5, Wydział Prawa UWr: https://prawo.uni.wroc.pl/sites/default/files/students-resources/Post%C4%99powanie%20s%C4%85dowoadministracyjne%20-%20zaj%C4%99cia%205.pdf
