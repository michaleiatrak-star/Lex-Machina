# mod-ustawa-skargi-przewleklosc-dostep-sadu

**Akt:** KPA — t.j. Dz.U. 2025 poz. 1691 (stan 2025-11-03).
**Akt:** PPSA — t.j. Dz.U. 2026 poz. 143 (zm. 2025/1882 od 2026-03-01 — art. 1, 2, 175; 2026/846 od 2026-06-26 — art. 53 § 1, 264 § 2; 2023/1860 [OD 2029-10-01: 2023/1860] — art. 66 (doręczenia)).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy i progi porównane z t.j.).

**Status:** moduł klasy kancelaryjnej — poziom DR-03
**Źródło weryfikacji:** Ustawa o skardze na przewlekłość — weryfikuj aktualny t.j. w ELI (RZĄD 1) | PPSA — Dz.U. 2026 poz. 143 | KPA — Dz.U. 2025 poz. 1691
**Data weryfikacji online:** 2026-06-05
**Zasada:** Każde brzmienie przepisu przed powołaniem → isap.sejm.gov.pl

---

## 1. CORE

### Zakres
Skarga na przewlekłość postępowania administracyjnego (art. 36–38 KPA + skarga do WSA), skarga na przewlekłość postępowania sądowego (ustawa o skardze na przewlekłość), prawo do sądu (art. 45 Konstytucji), dostęp do sądu dla osób z niepełnosprawnościami.

### Akty

| Akt | Dz.U. |
|---|---|
| KPA art. 36–38 (bezczynność i przewlekłość organu) | Dz.U. 2025 poz. 1691 t.j. |
| Ustawa o skardze na naruszenie prawa strony do rozpoznania sprawy bez nieuzasadnionej zwłoki | weryfikuj aktualny t.j. w ELI (RZĄD 1) |
| PPSA art. 3 §2 pkt 8 (skarga do WSA na bezczynność) | Dz.U. 2026 poz. 143 t.j. |

---

## 2. INTAKE

```
□ Jaki rodzaj przewlekłości: organ administracyjny czy sąd?
□ Od kiedy toczy się postępowanie — jak długo bez rozstrzygnięcia?
□ Czy złożono ponaglenie do organu wyższego stopnia (KPA)?
□ Czy organ odpowiedział na ponaglenie?
□ Jaki sąd prowadzi sprawę (SR / SO / WSA / NSA)?
□ Czy zachodzi szczególna pilność (stan zdrowia, ryzyko szkody)?
```

---

## 3. PROCEDURA

### Przewlekłość organu administracyjnego (KPA)

```
KROK 1: Ponaglenie do organu wyższego stopnia (art. 37 §1 KPA)
  → Brak ustawowego terminu na złożenie ponaglenia
  → Organ wyższy rozpatruje w 7 dniach
  → Może: wskazać termin + uznać przewlekłość + nakazać wyjaśnienia

KROK 2: Skarga do WSA na bezczynność / przewlekłość (art. 3 §2 pkt 8 PPSA)
  → Po wniesieniu ponaglenia
  → Składana za pośrednictwem organu
  → WSA może: zobowiązać do działania + stwierdzić bezczynność +
    wymierzyć GRZYWNĘ organowi + przyznać SUMĘ PIENIĘŻNĄ stronie
    ⚠️ POPRAWKA 2026-07-27 (FAZA 3E/ZASADA 14) — poprzednia wersja
    miała błędnie "do 1 000 zł". To DWIE RÓŻNE kwoty na PODSTAWIE
    ART. 154 §6 PPSA (nie kwota organu rozpatrującego ponaglenie —
    TEN nie ma własnego uprawnienia do grzywny/sumy, jedynie
    wskazuje termin i stwierdza przewlekłość w 7 dniach, patrz KROK 1):
      • GRZYWNA (dla organu, na rzecz Skarbu Państwa) — do 10-KROTNOŚCI
        przeciętnego wynagrodzenia miesięcznego z poprzedniego roku
        (ok. 89 000 zł przy aktualnym poziomie wynagrodzeń — KWOTA
        ZMIENNA co roku, sprawdź aktualne przeciętne wynagrodzenie GUS)
      • SUMA PIENIĘŻNA (dla strony skarżącej) — do POŁOWY powyższej
        kwoty grzywny (ok. 44 500 zł) — to środek FAKULTATYWNY,
        stosowany wg uznania sądu, "w szczególnie drastycznych
        przypadkach" (linia orzecznicza WSA), NIE automatycznie przy
        każdej stwierdzonej bezczynności
    Potwierdzone w 6+ zgodnych źródłach (stasik-kancelaria.pl,
    prawo.pl, orzecznictwo WSA/NSA)
```

### Skarga na przewlekłość postępowania sądowego

```
WARUNKI (ustawa o skardze na przewlekłość — weryfikuj w ELI (RZĄD 1)):
  □ Postępowanie sądowe (cywilne, karne, sądowoadministracyjne)
  □ Nieuzasadniona zwłoka w działaniu sądu

Właściwy sąd: sąd przełożony nad sądem prowadzącym sprawę
Opłata: weryfikuj aktualną kwotę w ustawie w ELI (RZĄD 1)
Żądania: stwierdzenie przewlekłości + zalecenie + suma pieniężna (100–20 000 zł)
  Minimalna suma: 2 000 zł za każdy rok przewlekłości — weryfikuj w ELI (RZĄD 1)
Ponowna skarga: nie wcześniej niż po 12 miesiącach od poprzedniej
```

---

## 4. DOWODY

| Teza | Dowód | Źródło | Siła | Luka | Działanie |
|---|---|---|---|---|---|
| Nieuzasadniona zwłoka | Zestawienie dat czynności vs standardy | akta / korespondencja | wysoka | — | tabela chronologiczna |
| Złożenie ponaglenia | Potwierdzenie nadania / złożenia | poczta / UPO | wysoka | brak potwierdzenia | list polecony / ePUAP |
| Szczególna pilność | Dokumentacja medyczna, umowy, terminy | różne | wysoka | — | zbierz przed złożeniem skargi |

---

## 5. STRATEGIA, RYZYKA, QUALITY GATE, OUTPUT

**Strategia:** Złóż ponaglenie jak najszybciej — skraca czas do skargi do WSA. Przy sądzie — zbierz tabelę datową wszystkich czynności. Dokumentuj szkodę spowodowaną przewlekłością — zwiększa sumę pieniężną.

**Ryzyka:** Brak ponaglenia → WSA odrzuci skargę na bezczynność organu. Zbyt wczesna skarga sądowa → niedopuszczalna.

**Quality gate:** Ponaglenie złożone? Właściwy sąd przełożony ustalony? Aktualne przepisy z ISAP?

**Output:** 1. Stan faktyczny (daty); 2. Kwalifikacja trybu; 3. Ponaglenie + skarga; 4. Żądania (suma pieniężna); 5. Dowody; 6. Rekomendacja.

**Powiązania:** `dr-05` → `mod-KPA-postepowanie-administracyjne` | `dr-01` → `mod-USP-ustroj-sadow-powszechnych` | `pisma-procesowe-v3`

**Źródła:** https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20260000143

---

## SZCZEGÓŁY ZWERYFIKOWANE ONLINE (Dz.U. 2023 poz. 1725)

### Opłata od skargi na przewlekłość postępowania sądowego

```
Stała opłata: 200 zł (art. 17 ustawy — Dz.U. 2023 poz. 1725)
  → Każda ze stron wnoszących skargę uiszcza osobno
⚠️ Weryfikuj aktualne brzmienie art. 17 w ELI (RZĄD 1) przed złożeniem skargi.
```

### Skarga na przewlekłość — tryb złożenia

```
Skargę składa się do sądu, przed którym toczy się postępowanie
  (art. 5 ust. 2 ustawy — sąd przekazuje do sądu przełożonego)
  ⚠️ Weryfikuj aktualny art. 5 w ELI (RZĄD 1)
```

### Dostępność postępowania dla osób z niepełnosprawnościami

```
Prawo do sądu (art. 45 Konstytucji) obejmuje dostępność proceduralną:
  → Tłumacz migowy na rozprawie (art. 5 KPC — weryfikuj w ELI (RZĄD 1))
  → Przesłuchanie w miejscu zamieszkania
  → Elektroniczne składanie pism (e-sąd, portal informacyjny)
  → WCAG na stronach sądów: ustawa o dostępności (Dz.U. 2022 poz. 2240)
  → Wnioski o dostępność: mod-ustawa-dostepnosc-niepelnosprawni (DR-05)
```

**Źródła:** https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20230001725
