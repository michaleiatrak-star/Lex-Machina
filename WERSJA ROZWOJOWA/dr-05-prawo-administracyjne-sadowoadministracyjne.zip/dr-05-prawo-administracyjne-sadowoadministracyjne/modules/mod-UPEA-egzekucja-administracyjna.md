# mod-UPEA-egzekucja-administracyjna

**Status:** moduł klasy kancelaryjnej — poziom DR-03
**Źródło weryfikacji:** UPEA — Dz.U. 2026 poz. 268 t.j. | KPA — Dz.U. 2025 poz. 1691 | PPSA — Dz.U. 2026 poz. 143
**Data weryfikacji online:** 2026-06-05
**Zasada:** Każde brzmienie przepisu przed powołaniem → isap.sejm.gov.pl

---

## ⚠️ ZASADA KRYTYCZNA — EGZEKUCJA ADMINISTRACYJNA ≠ EGZEKUCJA KOMORNICZA

```
Egzekucja administracyjna (UPEA) — obowiązki z aktów administracyjnych
  → Wierzycielem jest organ (US, ZUS, organ samorządowy, inne)
  → Organem egzekucyjnym jest naczelnik US, dyrektor oddziału ZUS, starosta lub inny
  → Środki egzekucyjne: zajęcie wynagrodzenia, rachunku, wierzytelności, ruchomości
  → Kontrola: zarzuty (do wierzyciela, ZA POŚREDNICTWEM organu
    egzekucyjnego, art. 33 §1 UPEA) → zażalenie na postanowienie w sprawie
    zarzutów (do organu odwoławczego WŁAŚCIWEGO DLA WIERZYCIELA, ZA
    POŚREDNICTWEM organu, który wydał postanowienie, art. 17 i art. 34 §3
    UPEA — WYJĄTEK: zażalenie na oszacowanie przez poborcę skarbowego
    rozpoznaje SAM organ egzekucyjny) → skarga do WSA. Zweryfikowano
    online 2026-07-25 — patrz `shared/ZAZALENIE-ADRESAT-GATE.md`.

Egzekucja komornicza (KPC) — obowiązki z wyroków i nakazów sądowych
  → DR-02 → mod-KPC-egzekucja-windykacja
```

---

## 1. CORE

### Zakres modułu
Tytuł wykonawczy administracyjny, upomnienie, zarzuty w postępowaniu egzekucyjnym, skarga na czynności egzekucyjne, zajęcie wynagrodzenia / rachunku bankowego / wierzytelności / ruchomości / nieruchomości, koszty egzekucyjne, zawieszenie i umorzenie egzekucji, egzekucja obowiązków niepieniężnych.

### Akty i źródła kontrolne

| Akt | Dz.U. |
|---|---|
| Ustawa o postępowaniu egzekucyjnym w administracji (UPEA) | Dz.U. 2026 poz. 268 t.j. |
| KPA | Dz.U. 2025 poz. 1691 t.j. |
| PPSA | Dz.U. 2026 poz. 143 t.j. |

> ⚠️ **NOWELIZACJA PO TEKŚCIE JEDNOLITYM — ustawa z 15.05.2026, Dz.U. 2026 poz. 739**
> (ustalona 2026-08-15 przy zamykaniu flagi audytowej F-16; wcześniej znany był
> wyłącznie numer druku sejmowego 2319). Zakres:
> 1. **art. 67da — „Portal eLicytacje KAS"**: system teleinformatyczny prowadzony przez
>    Szefa KAS; naczelnik urzędu skarbowego prowadzi w nim licytacje elektroniczne oraz
>    sprzedaż z wolnej ręki ruchomości i nieruchomości, a także publikuje obwieszczenia
>    i protokoły opisu i oszacowania nieruchomości.
> 2. **art. 3a § 1** — rozszerzenie katalogu o środki z doładowań (art. 331 ust. 9 Prawa
>    komunikacji elektronicznej).
> 3. Wejście w życie: po upływie 14 dni od dnia ogłoszenia.
>
> ⛔ Wiersz „Zajęcie nieruchomości → licytacja" w sekcji środków egzekucyjnych opisuje
> stan SPRZED tej zmiany. **Przed powołaniem trybu licytacji w piśmie** — sprawdzić
> brzmienie art. 67da i przepisów o sprzedaży (art. 105–111f UPEA) w ISAP.
> Weryfikacja: dziennikustaw.gov.pl (Rząd 1, snippet — bezpośredni `web_fetch`
> ROBOTS_DISALLOWED) + prosteustawy.pl/akt/WDU20260000739 (Rząd 2B).

---

## 2. INTAKE

```
□ Rodzaj obowiązku: pieniężny (podatek, ZUS, grzywna) czy niepieniężny?
□ Kto jest wierzycielem (organ egzekucyjny)?
□ Czy istnieje tytuł wykonawczy (TW-1 lub inny)?
□ Czy doręczono upomnienie (przy obowiązkach pieniężnych)?
□ Jaki środek egzekucyjny zastosowano?
□ Czy jest podstawa do zarzutów (art. 33 UPEA)?
□ Terminy: kiedy doręczono zajęcie / upomnienie / tytuł wykonawczy?
□ Czy istnieje podstawa do zawieszenia lub umorzenia?
```

---

## 3. PROCEDURA

### Schemat egzekucji administracyjnej

```
Powstanie obowiązku (decyzja, przepis ustawy, deklaracja podatkowa)
  ↓
Wierzytelność wymagalna → wymagane UPOMNIENIE (obowiązki pieniężne)
  → Egzekucja może być wszczęta dopiero po upływie 7 dni od DORĘCZENIA
    upomnienia (art. 15 § 1 zd. 2 UPEA) ✅ [VER] RZĄD 1 2026-09-12h
    ⚠️ Koszty upomnienia obciążają zobowiązanego i powstają z chwilą
      doręczenia upomnienia (art. 15 § 2)
  ↓ [brak zapłaty]
Wystawienie TYTUŁU WYKONAWCZEGO (TW-1 lub inny wzór)
  ↓
Wszczęcie egzekucji — zawiadomienie o zajęciu
  ↓
ZARZUT w sprawie egzekucji administracyjnej (art. 33 UPEA)
  ⛔ NIE MA terminu "7 dni od doręczenia TW" — art. 33 § 5 podaje wyłącznie
     terminy KOŃCOWE ("nie później niż"), patrz sekcja Terminy
  → wnoszony DO WIERZYCIELA, za pośrednictwem organu egzekucyjnego (§ 1)
  ↓ [rozpatrzenie przez wierzyciela i organ egzekucyjny]
ZAŻALENIE na postanowienie o zarzutach — 7 dni
  ↓
SKARGA DO WSA na postanowienie ostateczne
```

### Terminy — ABSOLUTNY PRIORYTET

```
⛔⛔ ZARZUT (art. 33 UPEA) — NIE MA TERMINU BIEGNĄCEGO OD DORĘCZENIA TW

Art. 33 § 5 podaje wyłącznie terminy KOŃCOWE, po których zarzut jest spóźniony:
  1) 30 dni od dnia WYEGZEKWOWANIA W CAŁOŚCI obowiązku, kosztów upomnienia
     i kosztów egzekucyjnych
  2) do dnia WYKONANIA W CAŁOŚCI obowiązku niepieniężnego albo zapłaty
     w całości należności pieniężnej wraz z odsetkami, kosztami upomnienia
     i kosztami egzekucyjnymi
  3) 7 dni od doręczenia POSTANOWIENIA O UMORZENIU postępowania
     egzekucyjnego w całości albo w części

⛔ Dopóki egzekucja trwa i obowiązek nie został wykonany, zarzut NIE JEST
   SPÓŹNIONY. Odesłanie klienta z informacją "minęło 7 dni od TW, za późno"
   pozbawia go środka, który mu przysługuje.

Skarga na CZYNNOŚĆ EGZEKUCYJNĄ (art. 54 § 3 UPEA):
                                          7 dni — NIE 14 — od doręczenia
                                          zobowiązanemu odpisu dokumentu
                                          stanowiącego podstawę zaskarżonej
                                          czynności; wnoszona DO ORGANU
                                          EGZEKUCYJNEGO, który jej dokonał
Zażalenie na postanowienie:               7 dni od doręczenia postanowienia (adresat: patrz sekcja wyżej i `shared/ZAZALENIE-ADRESAT-GATE.md` — NIE zakładaj domyślnie sądu)
Skarga do WSA na postanowienie ostateczne: 30 dni od doręczenia (art. 53 § 1 PPSA)
Termin po upomnieniu (art. 15 § 1 UPEA):  egzekucja może być wszczęta dopiero
                                          po upływie 7 dni od doręczenia
                                          upomnienia
✅ [VER] RZĄD 1 2026-09-12h — odczyt treści UPEA `Dz.U. 2026 poz. 268`.
⛔ Nowelizacja `Dz.U. 2026 poz. 739` (15.05.2026) SPRAWDZONA: zmienia art. 3a,
   dodaje art. 67da i przebudowuje przepisy o sprzedaży (art. 105a-111n).
   NIE DOTYKA art. 15, 33, 34 ani 54 — brzmienia wyżej są aktualne.
```

### ⛔⛔ Podstawy zarzutu — KATALOG ZMIENIONY, stary jest w obiegu

✅ [VER] RZĄD 1 2026-09-12h — odczyt treści art. 33 § 2 UPEA
(`Dz.U. 2026 poz. 268`). **Sześć podstaw, katalog zamknięty:**

```
1) nieistnienie obowiązku
2) określenie obowiązku niezgodnie z treścią obowiązku wynikającego z:
   a) orzeczenia (art. 3 i art. 4 UPEA)
   b) dokumentu (art. 3a § 1 UPEA)
   c) przepisu prawa, jeżeli obowiązek wynika bezpośrednio z tego przepisu
3) błąd co do zobowiązanego
4) brak uprzedniego doręczenia upomnienia, jeżeli jest wymagane
5) wygaśnięcie obowiązku w całości albo w części
6) brak wymagalności obowiązku w przypadku:
   a) odroczenia terminu wykonania obowiązku
   b) rozłożenia na raty spłaty należności pieniężnej
   c) wystąpienia innej przyczyny
```

⛔ **Czego w katalogu JUŻ NIE MA — a krąży w starszych opracowaniach:**

| Dawna podstawa zarzutu | Gdzie jest dziś |
|---|---|
| „zastosowanie zbyt uciążliwego środka egzekucyjnego" | **art. 54 § 1 pkt 2 UPEA — SKARGA na czynność egzekucyjną**, nie zarzut |
| „dokonanie czynności z naruszeniem ustawy" | art. 54 § 1 pkt 1 UPEA — skarga na czynność |
| „prowadzenie egzekucji przez niewłaściwy organ" | brak w katalogu art. 33 § 2 — rozważyć art. 54 albo tryb nadzorczy |

⛔ **To nie jest różnica redakcyjna.** Zarzut oparty na „zbyt uciążliwym środku"
zostanie **oddalony**, bo nie mieści się w zamkniętym katalogu art. 33 § 2 —
a ten sam argument wniesiony jako **skarga z art. 54** jest trafiony.
Instrument ma być dobrany do podstawy, nie odwrotnie.

⚠️ **Art. 33 § 3:** przy należnościach z art. 2 § 1 pkt 8 i 9 przepisów o zarzucie
**nie stosuje się** — stosuje się art. 17a.
⚠️ **Art. 33 § 4:** zarzut musi określać **istotę i zakres żądania oraz dowody**.
⚠️ **Art. 34 § 2 pkt 3:** wierzyciel stwierdza **niedopuszczalność** zarzutu, jeżeli
był on przedmiotem odrębnego postępowania albo gdy zobowiązany kwestionuje
wysokość należności ustaloną w orzeczeniu, od którego służy środek zaskarżenia.
⚠️ **Art. 34 § 3:** na postanowienie w sprawie zarzutu przysługuje **zażalenie**.


---

## 4. ŚRODKI EGZEKUCYJNE — KWALIFIKATOR

### Obowiązki pieniężne

| Środek | Organ egzekucyjny | Uwagi |
|---|---|---|
| Zajęcie wynagrodzenia za pracę | Naczelnik US | Kwoty wolne: art. 9 UPEA w zw. z przepisami KP o potrąceniach — ⛔ odczytaj przy sprawie |
| Zajęcie rachunku bankowego | Naczelnik US | Tryb: art. 80 § 1 UPEA (zajęcie z chwilą doręczenia bankowi zawiadomienia, § 2). ⛔ **Kwota wolna NIE jest w UPEA** — ustanawia ją art. 54 ustawy Prawo bankowe i jest zakotwiczona w **minimalnym wynagrodzeniu**, więc zmienia się co roku (`shared/TABELE-OPLAT.md` sekcja 4f). Odczytaj przy sprawie. |
| Zajęcie wierzytelności pieniężnej | Naczelnik US | |
| Zajęcie ruchomości | Naczelnik US | Spis i oszacowanie |
| Zajęcie nieruchomości | Naczelnik US | Wpis do KW, licytacja |
| Przymusowe ściągnięcie | Naczelnik US | |

### Obowiązki niepieniężne

```
Grzywna w celu przymuszenia:
  → Nakładana wielokrotnie do wykonania obowiązku
  → Max łączna kwota: weryfikuj art. 121 UPEA w ISAP
  
Wykonanie zastępcze:
  → Organ wykonuje obowiązek na koszt zobowiązanego

Odebranie rzeczy ruchomych / nieruchomości:
  → Przy obowiązku wydania

Przymus bezpośredni:
  → Ostateczność — przy obowiązkach o charakterze osobistym
```

---

## 5. ZAWIESZENIE I UMORZENIE EGZEKUCJI

```
ZAWIESZENIE (art. 56 UPEA — weryfikuj w ISAP):
  → Na wniosek wierzyciela
  → Śmierć zobowiązanego (postępowanie spadkowe)
  → Wniesienie przez zobowiązanego środka zaskarżenia na decyzję źródłową
    (tylko gdy środek ma skutek zawieszający)

UMORZENIE (art. 59 UPEA — weryfikuj w ISAP):
  □ Obowiązek wygasł (spłata, przedawnienie, uchylenie decyzji)
  □ Zobowiązany nie posiada majątku i brak perspektyw uzyskania
  □ Egzekucja jest niedopuszczalna
  □ Wierzyciel wnosi o umorzenie
```

---

## 6. KOSZTY EGZEKUCYJNE

> ⚠️ Stawki opłat egzekucyjnych — weryfikuj aktualne przepisy UPEA i rozporządzeń w ISAP.

```
Koszty egzekucyjne obciążają zobowiązanego:
  → Opłata egzekucyjna (% wyegzekwowanej kwoty — weryfikuj w UPEA)
  → Koszty upomnienia
  → Koszty czynności egzekucyjnych

Zarzut kosztów:
  → W trybie art. 33 UPEA lub osobna skarga — weryfikuj tryb w UPEA
```

---

## 7. DOWODY

| Teza | Dowód | Źródło | Siła | Luka | Działanie |
|---|---|---|---|---|---|
| Brak doręczenia upomnienia | Brak potwierdzenia odbioru | wnioskodawca | wysoka | spór o doręczenie | awizo / usługa pocztowa |
| Wygaśnięcie obowiązku | Dowód zapłaty, decyzja uchylająca | bank / organ | wysoka | — | wyciąg bankowy + pokwitowanie |
| Błąd co do osoby | PESEL, dane z TW vs rzeczywiste | dokumenty tożsamości | wysoka | — | porównanie danych |
| Zbyt uciążliwy środek | Proporcja środka do kwoty / sytuacja majątkowa | dokumenty finansowe | średnia | — | dowód innych aktywów |
| Niedopuszczalność egzekucji | Brak podstawy prawnej TW / przedawnienie | akta organu | wysoka | — | oblicz termin przedawnienia |

---

## 8. STRATEGIA

### Perspektywa zobowiązanego

1. Sprawdź czy doręczono upomnienie i tytuł wykonawczy prawidłowo.
2. Złóż zarzuty w terminie 7 dni — wyłącznie w zakresie art. 33 UPEA.
3. Przy kwestionowaniu decyzji źródłowej — tryb odwoławczy KPA, nie zarzuty.
4. Przy zawieszeniu: wniesienie środka zaskarżenia na decyzję źródłową może zawiesić egzekucję.
5. Przy nieregularnych dochodach — wnioskuj o rozłożenie na raty (tryb KPA).

### Perspektywa wierzyciela / organu

1. Upomnienie musi być doręczone przed wszczęciem egzekucji — brak = wada formalna.
2. TW musi zawierać wszystkie wymagane elementy — błąd = skuteczne zarzuty.
3. Zasada stosowania najmniej uciążliwego środka (proporcjonalność).

### Ryzyka

| Ryzyko | Opis | Działanie zaradcze |
|---|---|---|
| Brak zarzutów w terminie 7 dni | Utrata prawa do zarzutów | Bezwzględny priorytet — złóż natychmiast |
| Zarzuty w złym trybie | WSA odrzuci skargę | Ustal właściwy środek (zarzuty vs KPA) |
| Egzekucja mimo uchylenia decyzji | Kontynuacja mimo wygaśnięcia obowiązku | Wniosek o umorzenie z dowodem uchylenia |

---

## 9. ORZECZNICTWO

```
web_search: "egzekucja administracyjna zarzuty art 33 UPEA NSA orzecznictwo 2025 2026"
web_search: "tytuł wykonawczy brak doręczenia upomnienia egzekucja wadliwość NSA"
web_search: "UPEA Dz.U. 2026 poz. 268 isap.sejm.gov.pl tekst jednolity"
```

---

## 10. QUALITY GATE

- [ ] Rodzaj obowiązku (pieniężny / niepieniężny) ustalony?
- [ ] Upomnienie i tytuł wykonawczy doręczone prawidłowo?
- [ ] Termin 7 dni na zarzuty nie upłynął?
- [ ] Właściwy organ egzekucyjny wskazany?
- [ ] Aktualny t.j. UPEA (Dz.U. 2026 poz. 268) zweryfikowany?
- [ ] Tryb (zarzuty vs KPA vs WSA) prawidłowo dobrany?

---

## 11. OUTPUT

1. Stan faktyczny; 2. Kwalifikacja (pieniężny/niepieniężny, organ egzekucyjny); 3. Stan prawny; 4. Terminy (zarzuty 7 dni); 5. Podstawy zarzutów; 6. Matryca dowodowa; 7. Strategia; 8. Ryzyka; 9. Rekomendacja; 10. Kontrola ISAP/temporalności.

---

## POWIĄZANIA

| Sytuacja | Skill / Moduł |
|---|---|
| Egzekucja komornicza (KPC) | `dr-02` → `mod-KPC-egzekucja-windykacja` |
| Postępowanie administracyjne (KPA) | `dr-05` → `mod-KPA-postepowanie-administracyjne` |
| Podatki (zaległości US) | `dr-06` |
| ZUS (zaległości składek) | `dr-04` → `mod-SUS-ZUS-ubezpieczenia-spoleczne` |
| Pismo: zarzuty / skarga do WSA | `pisma-procesowe-v3` |

---

**Źródła:** https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20260000268
