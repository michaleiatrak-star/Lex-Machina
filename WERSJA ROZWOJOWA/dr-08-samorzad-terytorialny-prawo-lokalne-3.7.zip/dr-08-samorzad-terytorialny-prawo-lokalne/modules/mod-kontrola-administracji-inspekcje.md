# mod-DA-procedury-kontrolne-inspekcje.md — Procedury kontrolne inspekcji i organów administracji

Status: moduł prawa polskiego klasy wzorcowej. **RZĄD 1 VER 2026-08-28:** ustawa z 15.07.2011 r. o kontroli w administracji rządowej — **Dz.U. 2026 poz. 158 t.j.**, stan t.j. 06.02.2026; uwzględnia m.in. cyfryzację trybu kontroli.

## 1. Akt macierzysty i zakres ustawowy

**Ustawa o kontroli w administracji rządowej — Dz.U. 2026 poz. 158 t.j.**

- **art. 1-2:** ustawa reguluje kontrolę działalności organów administracji rządowej, urzędów i jednostek im podległych/nadzorowanych; w zakresie wykonywania zadań administracji rządowej obejmuje również organy JST oraz inne podmioty realizujące zadania finansowane z budżetu państwa;
- **art. 3:** celem kontroli jest ustalenie stanu faktycznego i jego ocena według kryteriów; przy nieprawidłowościach ustala się ich zakres, przyczyny, skutki i osoby odpowiedzialne oraz formułuje zalecenia;
- **art. 4:** podstawowe kryteria to legalność, gospodarność, celowość i rzetelność, z modyfikacjami wskazanymi w ustawie dla części podmiotów;
- **art. 6:** ustawa określa organy uprawnione do kontroli w strukturze administracji rządowej;
- **art. 11:** kontrolę prowadzi się w trybie zwykłym albo uproszczonym;
- **art. 13:** w sprawach nieuregulowanych odpowiednio stosuje się wskazane przepisy KPA dotyczące m.in. doręczeń, terminów i protokołów;
- **art. 16:** kontroler wykonuje czynności na podstawie imiennego upoważnienia i po okazaniu dokumentu tożsamości / właściwym uwierzytelnieniu.

⛔ Ten akt **nie jest uniwersalną ustawą o wszystkich inspekcjach**. Dla PIP, KAS, Inspekcji Sanitarnej, WIOŚ, ITD, UDT, PSP itd. najpierw stosuj ich ustawy ustrojowe i proceduralne; ustawę o kontroli w administracji rządowej stosuj tylko w jej zakresie podmiotowym/przedmiotowym.

## 1a. Akty branżowe do weryfikacji
- Prawo przedsiębiorców
- KPA
- ustawy inspekcyjne: PIP, UDT, PSP, Sanepid, WIOŚ, ITD, UOKiK, KAS
- PPSA

Nie cytuj literalnego brzmienia przepisu bez aktualnego sprawdzenia źródła. Przed użyciem artykułu ustal:

- akt i Dz.U.,
- status obowiązywania,
- wersję temporalną na dzień zdarzenia,
- wersję na dzień sporządzania pisma,
- przepisy przejściowe,
- właściwy organ i tryb zaskarżenia.

## 2. Zakres spraw
- zawiadomienie o kontroli
- protokół kontroli
- zastrzeżenia
- zalecenia pokontrolne
- kara administracyjna
- kontrola legalności organu

## 3. Intake
Ustal obowiązkowo:

1. kto jest stroną / uczestnikiem / funkcjonariuszem / organem,
2. jaki akt, czynność albo zaniechanie jest kwestionowane,
3. data czynności, doręczenia, powzięcia wiadomości i termin do reakcji,
4. organ pierwszej instancji i organ odwoławczy,
5. czy sprawa jest administracyjna, cywilna, karna, dyscyplinarna, służbowa albo mieszana,
6. czy istnieje dokument urzędowy: decyzja, postanowienie, zarządzenie, protokół, notatka, polecenie, uchwała,
7. czy zachodzi ryzyko prekluzji, przedawnienia, bezczynności albo bezskuteczności środka.

## 4. Mapa proceduralna
Stosuj ścieżkę:

`zdarzenie/czynność → kwalifikacja prawna → właściwość organu → środek zwykły → środek nadzwyczajny → kontrola sądowa → wykonanie rozstrzygnięcia → odpowiedzialność odszkodowawcza/dyscyplinarna`

W sprawach publicznoprawnych zawsze rozważ równolegle:

- środek w toku sprawy,
- skargę na bezczynność/przewlekłość,
- wniosek o wstrzymanie wykonania,
- zabezpieczenie dowodów,
- odpowiedzialność funkcjonariusza/organu,
- dostęp do akt i informacji publicznej,
- ochronę danych osobowych i informacji niejawnych.

## 5. Warunki skuteczności
Sprawdź:

- termin,
- właściwość organu/sądu,
- legitymację,
- interes prawny albo faktyczny,
- podpis,
- pełnomocnictwo,
- opłatę,
- odpisy,
- załączniki,
- dowód doręczenia,
- wskazanie żądania,
- wskazanie zarzutów,
- relację dowód → fakt → norma.

## 6. Matryca dowodowa
Dla każdego faktu zbuduj tabelę:

| Fakt | Dowód | Źródło | Siła | Luka | Ryzyko |
|---|---|---|---|---|---|

Typowe dowody:

- decyzje, postanowienia, protokoły, notatki, zarządzenia,
- korespondencja z organem,
- nagrania, zdjęcia, logi, metadane,
- zeznania świadków,
- dokumentacja medyczna/techniczna/księgowa,
- opinie biegłych,
- akty prawa miejscowego,
- wydruki z BIP, rejestrów, systemów publicznych.

## 7. Zarzuty typowe
Rozważ co najmniej:

- naruszenie właściwości,
- naruszenie prawa do udziału w sprawie,
- brak podstawy prawnej,
- błędna wykładnia przepisu,
- dowolna ocena dowodów,
- brak uzasadnienia,
- nieproporcjonalność,
- nierówne traktowanie,
- naruszenie zaufania do organu,
- naruszenie terminów,
- brak rozpoznania istoty sprawy,
- pominięcie dowodu,
- wadliwe pouczenie.

## 8. Kontrargumenty organu / strony przeciwnej
Przewiduj:

- formalny brak legitymacji,
- spóźnienie środka,
- brak interesu prawnego,
- domniemanie prawidłowości dokumentu urzędowego,
- uznaniowość organu,
- tajemnicę ustawowo chronioną,
- bezpieczeństwo publiczne,
- brak szkody albo związku przyczynowego,
- nieadekwatność środka.

## 9. Strategia
Priorytety:

1. zabezpiecz termin i dowód doręczenia,
2. uzyskaj akta i pełną podstawę rozstrzygnięcia,
3. oddziel zarzuty formalne od materialnych,
4. wskaż fakty decydujące, nie wszystkie fakty,
5. buduj żądanie główne i ewentualne,
6. przygotuj wariant: organ → sąd administracyjny/cywilny/karny/dyscyplinarny,
7. oceń, czy korzystniejsze jest uchylenie, zmiana, stwierdzenie nieważności, wznowienie, odszkodowanie lub skarga.

## 10. Orzecznictwo
Nie wpisuj fikcyjnych sygnatur. Szukaj tylko realnych orzeczeń w:

- SN / NSA / TK,
- CBOSA,
- Portalu Orzeczeń Sądów Powszechnych,
- orzeczeniach sądów dyscyplinarnych, jeżeli publicznie dostępne,
- LEX/Legalis pomocniczo.

Każde orzeczenie oceniaj według: aktualność, hierarchia sądu, analogiczność stanu faktycznego, linia dominująca/odmienna.

## 11. Ryzyka
Oceń:

- ryzyko zwrotu/odrzucenia,
- ryzyko spóźnienia,
- ryzyko braku legitymacji,
- ryzyko niewykazania faktu,
- ryzyko niedopuszczalności dowodu,
- ryzyko uznania organu,
- ryzyko kosztowe,
- ryzyko retorsji służbowej/dyscyplinarnej,
- ryzyko równoległych postępowań.

## 12. Quality gate
Przed odpowiedzią lub pismem zastosuj:

- `shared/POLISH-LAW-FINAL-COMPLETENESS-GATE.md`,
- `shared/ISAP-AUDIT-PROTOCOL.md`,
- `shared/TEMPORAL-LAW-CHECK.md`,
- `shared/LEGAL-QUALITY-GATE.md`,
- `shared/RISK-ASSESSMENT.md`, jeżeli istnieje,
- `shared/FORMAL-CHECK.md`, jeżeli powstaje pismo.


---

## QUALITY GATE

- [ ] Aktualny tekst t.j. aktu zweryfikowany w ISAP?
- [ ] Stan prawny właściwy temporalnie?
- [ ] Każda przesłanka ma przypisany dowód?
- [ ] Termin nie upłynął?
- [ ] Właściwy organ / sąd wskazany?
- [ ] Ryzyka formalne i dowodowe ocenione?
- [ ] Brzmienie przepisów ze źródeł, nie z pamięci modelu?

## OUTPUT

1. Stan faktyczny; 2. Stan prawny i źródła (Dz.U. z ISAP); 3. Kwalifikacja trybu;
4. Terminy (obliczone, daty graniczne); 5. Przesłanki;
6. Matryca dowodowa; 7. Zarzuty i kontrargumenty; 8. Analiza ryzyk;
9. Strategia; 10. Rekomendacja; 11. Kontrola ISAP/temporalności.

**Status:** moduł klasy kancelaryjnej — poziom DR-03
**Data weryfikacji online:** 2026-08-28 (RZĄD 1 ELI dla Dz.U. 2026 poz. 158)
