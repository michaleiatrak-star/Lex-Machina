# CHANGELOG — dr-08-samorzad-terytorialny-prawo-lokalne

- 3.26 (2026-11-14): 2026/912 w modułach DR-08/DR-09; poprawki: skarga na uchwałę RIO do WSA (art. 98 USG), decyzja WZ wygasa po 5 latach (art. 64c UPZP)
- 3.25 (2026-11-11, ELI 2026-11-11): NOWY mod-zwiazki-metropolitalne: ustawa o związku metropolitalnym w woj. pomorskim (Dz.U. 2026 poz. 912, od 31.07.2026; związek nieutworzony — brak rozporządzenia RM w ELI) i ustawa śląska (t.j. 2025/186 + 2026/912 art. 81; rozporządzenie RM 2017/1290); MAPA-AKTOW: wiersze związków i zmiany po t.j. (USG 912 art. 65, ⏳ 2026/1273; USP 2026/252, 912; ogłaszanie aktów 912 art. 71; MPZP 2026/781, 864, 912; czystość 912 art. 68; rewitalizacja 912 art. 80); MAPA-POKRYCIA.
- 3.24 (2026-11-06): migracja prawa polskiego E3: ścieżki odwołań do modułów przeniesionych z shared i skilli wykonawczych do prawo-polskie-v2/krajowe/ (treść bez zmian)
- 3.23 (2026-10-22, AUDYT-2026-10-22): mod-UDP-strefy-platnego-parkowania: KW t.j. Dz.U. 2026 poz. 1372 (było 2025/734); art. 92 §1 bez zmian.
- 3.22 (2026-10-20, AUDYT-2026-10-20g): SKILL.md: znacznik `lex:wykonuje-aplikacja: REJESTR-MODULOW` nad rejestrem modułów — w trybie mechanicznym aplikacja podaje modelowi indeks nazw (moduły aktów dobiera z MAPA-AKTOW), w AUTO rejestr w całości
- 3.21 (2026-10-12b, AUDYT-2026-10-12b): mod-ustawa-zarzadzanie-kryzysowe: plany zarządzania kryzysowego po 2026/815 (plan zarządzania ryzykiem i plan reagowania kryzysowego, cykl do 3 lat, przepisy przejściowe art. 29); link źródłowy WDU20241194 (dozór techniczny) zastąpiony; mod-UDP: UPEA 2026/1311, UDP ze zm. 815, 982. ELI 2026-10-12.

- 3.20 (2026-10-09g, AUDYT-2026-10-09g): Drogi publiczne: po t.j. 2025/889 także Dz.U. 2026 poz. 815 art. 2 (od 4.07.2026). ELI 2026-10-09.

- 3.19 (2026-10-09f, AUDYT-2026-10-09f): ⛔ mod-ustawa-zarzadzanie-kryzysowe i MAPA-AKTOW: dwie ustawy łączone pod numerem 2024/1907 — rozdzielone: zarządzanie kryzysowe t.j. 2026/574 (+815, +1206 art. 15 od 11.01.2027), ochrona ludności i obrona cywilna 2024/1907 (+646, +815, ⏳ 1705 od 1.01.2027); ⛔ „ustawa z 2022 r.” → z 5.12.2024. ELI 2026-10-09.

- 3.18 (2026-10-09, AUDYT-2026-10-09): dochody JST — pierwszy t.j. Dz.U. 2026 poz. 1252 ⛔ zawiera 2026/875 (od 1.01.2027); transport zbiorowy — t.j. Dz.U. 2026 poz. 1231 (ELI 2026-10-09).

- 3.17 (2026-10-06): nowelizacje po t.j. (ELI 2026-10-06): PRD/u.k.p./drogi publiczne/transport drogowy — Dz.U. 2025 poz. 1676, 1734, 1843; Dz.U. 2026 poz. 180, 982; nowa ustawa o zdrowiu zwierząt Dz.U. 2025 poz. 1795

- 3.16 (2026-10-05l, AUDYT-2026-10-05l): mod-MPZP-WZ-planowanie-przestrzenne: linia „Hasła spraw”. Treść prawna bez zmian.

- 3.15 (2026-10-04c, AUDYT-2026-10-04c): **F-227 (zamknięta).** SKILL.md nie wczytywał `MAPA-POKRYCIA.md`, choć `prawny-router-v3/references/pokrycie-dziedzinowe.md` nazywa lokalną mapę jedynym bieżącym źródłem statusu pokrycia — dodana sekcja „Mapa pokrycia treściowego” z `view`, wzorem DR-02…DR-06 i DR-16. Treść prawa bez zmian. Pełny opis: `audyt-systemu-v4/references/AUDIT-JOURNAL.md`, AUDYT-2026-10-04c.

- 3.14 (2026-09-27e, AUDYT-2026-09-27e): claude.ai po dodaniu marketplace instalował wyłącznie 4 z 32 pluginów (shared, prawny-router-v3, analizator-dowodow-v3, przesluchanie-swiadkow-v2-min90); jedyna cecha wspólna tych 4, nieobecna w żadnym z 28 pozostałych, to klucz `dependencies` we frontmatterze SKILL.md. Dodano go (`requires: [shared]` — zgodnie ze stanem faktycznym) oraz jawny manifest pluginu (name, description = description z SKILL.md, author, repository, license) — host nie musi niczego wnioskować z SKILL.md. `version` w manifeście = `version:` z SKILL.md (pilnuje T38 w audyt-systemu-v4) — host rozpoznaje aktualizację po podbiciu wersji. Treść skilla bez zmian.
- 3.13 (2026-09-23, AUDYT-2026-09-23b): kanon E-1…E-5 (`shared/HIERARCHIA-ZRODEL.md` 1.10): instrukcje weryfikacji „w ISAP” / „isap.sejm.gov.pl →” zamienione na „w ELI (RZĄD 1)” (11 plików); ISAP pozostaje adresem dla człowieka; wpisy historyczne („zweryfikowano w ISAP …”) bez zmian.
- 3.12 (2026-09-10o, F-181): dochody JST: stara ustawa uchylona, jej t.j. 2024/356 tez uchylony - podstawa jest NOWA ustawa z 1.10.2024, Dz.U. 2024 poz. 1572 (zm. 2025/1659), bez tekstu jednolitego
- 3.11 (2026-09-10d, F-148a/F-135/F-141): mod-ustawa-zarzadzanie-kryzysowe: BŁĄD PODMIANY AKTU skorygowany (2024/1194 = t.j. ustawy o dozorze technicznym → 2026/574) + KROK 2C dla Dz.U. 2026 poz. 815 (F-148a)
- 3.10 (2026-09-01k, flaga F-156): **cofnięte oznaczanie nowelizacji po t.j. w mapie.**
  Wersja 3.9 wpisywała przy pozycjach liczbę nowelizacji — w ciągu doby trzy się
  rozjechały. Kolejna wersja zostawiła sam znacznik ⚠️ bez liczby; to też cofnięto,
  z mocniejszego powodu: **znacznik przy jednych pozycjach twierdzi coś o pozostałych**
  — wiersz bez ⚠️ czyta się jako „tu t.j. wystarczy", czyli jako zdanie o stanie
  rejestru na dzień oznaczania, nie na dzień użycia mapy. Zamiast oznaczeń nowa sekcja
  **„Gdzie sprawdzić nowelizacje po tekście jednolitym"**: sekcja ELI w `/references`,
  kontrola uzupełniająca aktami zmieniającymi aktu bazowego, KROK 2C HARD GATE,
  bramka F-153 i test T24. Zachowana dotychczasowa sekcja „Weryfikacja w źródle
  urzędowym" (21/21, 17/17, 17/17) — to datowany POMIAR, nie bieżące zapewnienie.
- 3.9 (2026-09-01h): **pełna weryfikacja MAPA-AKTOW w żywym ELI — 21 pozycji.**
  Numer i status `obowiązujący`: 21/21. Tytuł aktu zgodny z zakresem (kontrola podmiany,
  klasa F-149): 17/17 obwieszczeń. Wskazany t.j. jest najnowszym obowiązującym dla
  swojego aktu: 17/17. **Nie znaleziono błędu numeru ani podmiany aktu.**
  Znalezione ryzyko innego rodzaju: **11 z 17 aktów ma nowelizacje ogłoszone PO dacie
  t.j.** (transport zbiorowy 4, zabytki 3, planowanie przestrzenne i samorząd powiatowy
  po 2, sześć kolejnych po 1), a mapa oznaczała je jako 🟢 bez żadnego sygnału.
  Tekst jednolity ich nie zawiera, więc odczyt samego t.j. daje wynik niepełny
  w sposób niewidoczny. Wiersze oznaczone ⚠️ z liczbą nowelizacji; dwie pozycje
  bez t.j. (dochody JST, ochrona ludności) opisane jako ustawy z 3 aktami zmieniającymi
  każda. Dodano sekcję „Weryfikacja w źródle urzędowym" z metodą i wynikiem oraz
  zastrzeżenie, że akt prawa miejscowego z założenia nie ma numeru Dz.U. i idzie
  ŚCIEŻKĄ B-L.
- 3.8 (2026-09-01g, flaga F-154): **poprawiony adres publikatora aktów prawa
  miejscowego.** W sześciu plikach (SKILL.md + `mod-dzienniki-urzedowe-BIP-publikacja`,
  `mod-MPZP-WZ-planowanie-przestrzenne`, `mod-lokalne-podatki-oplaty-taryfy`,
  `mod-nadzor-wojewody-RIO-legalnosc-uchwal`, `mod-procedury-JST-statuty-regulaminy`),
  12 wystąpień, wskazywano `dzienniki.gov.pl`. Portalem prowadzonym przez RCL jest
  `dziennikiurzedowe.gov.pl` (dawniej `dziennikiurzedowe.rcl.gov.pl`). Dodatkowo:
  ⛔ zakaz budowania adresu serwisu wojewódzkiego z szablonu — formy różnią się
  między województwami (`edziennik.malopolska.uw.gov.pl`,
  `e-dziennik.szczecin.uw.gov.pl`, mazowieckie przez `gov.pl/web/uw-mazowiecki`);
  wejście wyłącznie przez portal zbiorczy. SKILL.md odsyła do nowej ŚCIEŻKI B-L
  w `shared/PRAWO-HARDGATE.md`.
- 3.7 (2026-08-27): F-108 P3/27 i P3/28 — wydzielono ustawy o samorządzie powiatowym i województwa do odrębnych modułów B+ opartych na ELI.

- 3.6 (2026-08-26): ujednolicono metryki tekstów jednolitych w mapie i
  modułach ustrojowych, planistycznych, nadzorczych oraz komunalnych.
