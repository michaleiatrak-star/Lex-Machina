# mod-ustawa-komunalne-wod-kan-transport-czystosc

**Akt:** KPA (Kodeks postępowania administracyjnego) — t.j. Dz.U. 2025 poz. 1691.
**Akt:** UZZW (ustawa o zbiorowym zaopatrzeniu w wodę i zbiorowym odprowadzaniu ścieków) — t.j. Dz.U. 2024 poz. 757 (zm. po t.j.: 2026/605 od 2026-05-21 — art. 1, 1a, 1b, 2, 2a, 2b, 4a, 4b, 4c, 4d, 4e, 4f, 4g, 4i, 4j, 4k, 4m, 4p, 5, 7).
**Akt:** UCPG (ustawa o utrzymaniu czystości i porządku w gminach) — t.j. Dz.U. 2025 poz. 733 (zm. po t.j.: 2026/912 od 2026-07-31 — art. 3, 4c, 4ca).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

**Status:** moduł klasy kancelaryjnej — poziom DR-03
**Źródło weryfikacji — RZĄD 1 / VER 2026-08-28:**
- Wod-kan: Dz.U. 2024 poz. 757 t.j. ✅ VER: 2026-06-05
- Transport zbiorowy: **Dz.U. 2026 poz. 1231 t.j.** z 1.09.2026 ✅ [VER] RZĄD 1 2026-10-09 (ELI) (poprzedni t.j. 2025/285 z 14.02.2025, VER 2026-06-05)
- Czystość i porządek: **Dz.U. 2025 poz. 733 t.j. ze zm.**; ELI tekst ujednolicony sprawdzony w stanie 03.08.2026
**Zasada:** Każde brzmienie przepisu przed powołaniem → isap.sejm.gov.pl

---

## 1. CORE

### Zakres
Zbiorowe zaopatrzenie w wodę i odprowadzanie ścieków (ustawa wod-kan: taryfy, umowy z odbiorcami, Wody Polskie jako organ regulacyjny), publiczny transport zbiorowy (PTZ: organizator, operator, plan transportowy, in-house), utrzymanie czystości i porządku w gminach (GOCH: opłata za śmieci, frakcje, PSZOK).

---

## 2. WOD-KAN (Dz.U. 2024 poz. 757)

```
Organ regulacyjny: Wody Polskie (PGW) — NIE gmina
  → Przedsiębiorstwo wod-kan składa wniosek taryfowy do RZGW (Wody Polskie)
  → Wody Polskie zatwierdzają taryfę na 3 lata (lub odmawiają)
  → Odwołanie od decyzji RZGW: do Dyrektora Departamentu Zarządzania Środowiskiem Wodnym
  → Zaskarżenie do WSA: 30 dni

Umowa z odbiorcą:
  → Obowiązek zawarcia umowy przez przedsiębiorstwo
  → Regulamin dostarczania wody: uchwała rady gminy
  → Przyłącze: koszt po stronie właściciela nieruchomości
  → Wodomierz: przedsiębiorstwo zapewnia i kalibruje

Prawo do niższej opłaty:
  → Przy udokumentowanym przecieku za wodomierzem — weryfikuj przepisy w ELI (RZĄD 1)
```

---

## 3. TRANSPORT ZBIOROWY (Dz.U. 2025 poz. 285)

```
Organizator PTZ: gmina, powiat, związek komunalny, województwo
Operator: podmiot świadczący usługę — wybierany w przetargu lub in-house
In-house (art. 22): możliwe gdy JST kontroluje podmiot (100% udziałów)
Umowa: max 10 lat (tramwaj/metro/kolej: max 15 lat)

Plan transportowy: obowiązkowy dla gmin ≥ 50 000 mieszkańców
  → Zawiera: sieć komunikacyjną, standardy dostępności, rodzaje pojazdów
  → Aktualizacja: co 4 lata

Ulgi ustawowe: 20%, 37%, 49%, 78%, 100% — rekompensata z budżetu państwa
  ⚠️ Weryfikuj aktualny katalog uprawnionych w ELI (RZĄD 1)
```

---

## 4. CZYSTOŚĆ I PORZĄDEK (Dz.U. 2025 poz. 733 t.j. ze zm.)

```
Selektywna zbiórka odpadów: obowiązkowa we wszystkich gminach
Frakcje: papier, metal/tworzywa/wielomateriałowe, szkło, bioodpady, zmieszane
PSZOK (Punkt Selektywnej Zbiórki): gmina obowiązana do prowadzenia

Opłata za GOCH:
  → Uchwalana przez radę gminy (kryterium do wyboru: os./m²/gosp./ilość wody)
  → Stawka dla niesegregujących: min. 2× wyższa
  → Uchybienie obowiązku selektywnej zbiórki → podwyższona opłata
  → Decyzja o wymiarze → KPA → SKO → WSA

Kary pieniężne — art. 9x i nast.:
  → art. 9x dotyczy przede wszystkim przedsiębiorców odbierających odpady
    komunalne (m.in. działalność bez wpisu do rejestru, naruszenia obowiązków
    sprawozdawczych i poziomów), a **nie** ogólnej odpowiedzialności
    „zarządcy nieruchomości za nielegalne składowanie”
  → art. 9zb rozdziela właściwość do nakładania kar pomiędzy wójta/
    burmistrza/prezydenta miasta i WIOŚ zależnie od rodzaju naruszenia
  → przed kwalifikacją dzikiego wysypiska/porzucenia odpadów sprawdź także
    ustawę o odpadach i przepisy ochrony środowiska — nie przypisuj automatycznie art. 9x
```

---

## 5. QUALITY GATE / OUTPUT

**Quality gate:** Nowe t.j. (transport: Dz.U. 2025 poz. 285; czystość: Dz.U. 2025 poz. 733) zastosowane? Organ regulacyjny dla taryf wod-kan: Wody Polskie (nie gmina)?

**Output:** Kwalifikacja usługi komunalnej → organ regulacyjny → tryb → terminy → rekomendacja.

**Powiązania:** `mod-lokalne-podatki-oplaty-taryfy` | `dr-09` (Prawo wodne, ochrona środowiska) | `dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-KPA-postepowanie-administracyjne.md` | `pisma-procesowe-v3`

**Źródła:**
- Wod-kan: https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20240000757
- Transport: https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20250000285
- Czystość: https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20250000733
- Wody Polskie: https://wody.gov.pl
