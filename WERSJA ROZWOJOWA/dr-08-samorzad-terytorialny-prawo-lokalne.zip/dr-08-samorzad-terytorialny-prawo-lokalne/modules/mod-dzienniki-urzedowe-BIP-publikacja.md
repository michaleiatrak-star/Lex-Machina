# mod-dzienniki-urzedowe-BIP-publikacja

**Akt:** UWoj (ustawa o wojewodzie i administracji rządowej w województwie) — t.j. Dz.U. 2025 poz. 428.
**Akt:** UOAN (ustawa o ogłaszaniu aktów normatywnych) — t.j. Dz.U. 2019 poz. 1461 (zm. po t.j.: 2026/912 od 2026-07-31 — art. 13).
**Akt:** UDIP (ustawa o dostępie do informacji publicznej) — t.j. Dz.U. 2022 poz. 902 (zm. po t.j.: 2025/1844 od 2026-07-01 — art. 10).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

**Status:** moduł klasy kancelaryjnej — poziom DR-03
**Źródło weryfikacji:** Ustawa o ogłaszaniu aktów normatywnych — weryfikuj aktualny t.j. w ELI (RZĄD 1)
**Data weryfikacji online:** 2026-06-05

---

## 1. CORE

### Zakres
Publikacja aktów prawa miejscowego w dziennikach urzędowych województw (dziennikiurzedowe.gov.pl), BIP jako kanał publikacji wewnętrznych uchwał JST, termin wejścia w życie, vacatio legis, prostowanie błędów, błędy publikacyjne a ważność aktu.

### Akty
Ustawa z 20.07.2000 r. o ogłaszaniu aktów normatywnych i niektórych innych aktów prawnych — weryfikuj aktualny t.j. w ELI (RZĄD 1).

---

## 2. PROCEDURA

### Co wymaga publikacji w dzienniku urzędowym województwa

```
OBOWIĄZKOWO w dzienniku urzędowym województwa (akty prawa miejscowego):
  □ Uchwały rad gmin, powiatów, sejmiku województwa stanowiące prawo miejscowe
  □ Rozporządzenia porządkowe Wojewody
  □ Statut gminy, powiatu, województwa

WYŁĄCZNIE w BIP (akty wewnętrzne, nieobowiązujące powszechnie):
  □ Zarządzenia wewnętrzne organów wykonawczych
  □ Uchwały niepowszechnego zastosowania
  □ Protokoły sesji, sprawozdania, informacje

Portal: https://dziennikiurzedowe.gov.pl — portal wszystkich dzienników urzędowych woj.
⚡ KOREKTA 2026-09-01g (F-154): do 2026-09-01 moduł podawał adres
`dzienniki.gov.pl`. Portalem prowadzonym przez RCL jest
`dziennikiurzedowe.gov.pl` (dawniej `dziennikiurzedowe.rcl.gov.pl`).
⛔ Serwisy poszczególnych województw NIE mają jednolitego wzorca adresu —
zmierzone przykłady: `edziennik.malopolska.uw.gov.pl`,
`e-dziennik.szczecin.uw.gov.pl` (inna forma!), a mazowieckie prowadzi wejście
przez `gov.pl/web/uw-mazowiecki`. Adresu województwa NIE buduj z szablonu —
wejdź przez portal zbiorczy i weź link stamtąd.
```

### ⭐⭐ ŹRÓDŁA — PEŁNA LISTA 16 WOJEWÓDZTW (dodane 2026-07-21)

> Odpowiedź na pytanie użytkownika czy moduł wskazuje wszystkie 16
> województw — dotąd był TYLKO ogólny portal zbiorczy, bez
> wyszczególnienia poszczególnych źródeł per województwo.

```
⭐ ROZRÓŻNIENIE DWÓCH RODZAJÓW ŹRÓDEŁ (NIE MYLIĆ):
  1) DZIENNIK URZĘDOWY WOJEWÓDZTWA (oficjalna, PRAWNIE WIĄŻĄCA
     publikacja aktów prawa miejscowego, w tym uchwał sejmiku) —
     WSZYSTKIE 16 dostępne CENTRALNIE przez jeden portal:
     https://dziennikiurzedowe.gov.pl (wybierz województwo z listy) — TO
     JEST podstawowe, MIARODAJNE źródło dla ustalenia treści i daty
     wejścia w życie uchwały
  2) BIP URZĘDU MARSZAŁKOWSKIEGO / strona sejmiku danego województwa —
     źródło POMOCNICZE (projekty uchwał PRZED sesją, porządek obrad,
     protokoły, transmisje, uchwały o charakterze WEWNĘTRZNYM
     niepodlegające obowiązkowi publikacji w dzienniku urzędowym) —
     NIE zastępuje dziennika urzędowego jako źródła OFICJALNEGO tekstu

TABELA — BIP Urzędu Marszałkowskiego / Sejmiku dla KAŻDEGO z 16
województw (zweryfikowane online 2026-07-21, WSZYSTKIE 16
POTWIERDZONE — Łódzkie potwierdzone bezpośrednio przez użytkownika
2026-07-21 po wcześniejszym błędnym trafieniu na stronę wojewody;
⚠️ sprawdź aktualność adresu przy każdym użyciu — strony bywają
migrowane):

⭐ PRAKTYCZNA OBSERWACJA (na przykładzie bip.lodzkie.pl/uchwaly): wiele
BIP marszałkowskich prowadzi CZYTELNY rejestr uchwał sejmiku z
OZNACZENIEM przy każdej pozycji, czy jest to "akt prawa miejscowego"
(podlegający obowiązkowi publikacji w dzienniku urzędowym) czy zwykły
"link" (uchwała WEWNĘTRZNA, np. o powołaniu składu komisji, rozpatrzeniu
skargi) — TO OZNACZENIE jest PRAKTYCZNIE bardzo pomocne przy szybkim
ustaleniu, czy DANA uchwała w ogóle WYMAGA sprawdzenia w dzienniku
urzędowym, czy wystarczy sama strona BIP jako źródło.

| Województwo | BIP Urzędu Marszałkowskiego / Sejmiku |
|---|---|
| Dolnośląskie | bip.dolnyslask.pl |
| Kujawsko-Pomorskie | bip.kujawsko-pomorskie.pl |
| Lubelskie | umwl.bip.lubelskie.pl |
| Lubuskie | bip.lubuskie.pl |
| Łódzkie | bip.lodzkie.pl (POTWIERDZONE 2026-07-21 — sekcja /uchwaly zawiera pełny rejestr uchwał sejmiku z linkami do plików PDF i oznaczeniem "akt prawa miejscowego" przy uchwałach podlegających publikacji w dzienniku urzędowym) |
| Małopolskie | bip.malopolska.pl/umwm |
| Mazowieckie | bip.mazovia.pl |
| Opolskie | bip.opolskie.pl |
| Podkarpackie | bip.podkarpackie.pl |
| Podlaskie | bip.wrotapodlasia.pl |
| Pomorskie | bip.pomorskie.eu |
| Śląskie | bip.slaskie.pl |
| Świętokrzyskie | bip.sejmik.kielce.pl |
| Warmińsko-Mazurskie | bip.warmia.mazury.pl |
| Wielkopolskie | bip.umww.pl |
| Zachodniopomorskie | bip.wzp.pl |

⭐ PRAKTYCZNA REKOMENDACJA: przy poszukiwaniu KONKRETNEJ uchwały
sejmiku — ZACZNIJ od dziennikiurzedowe.gov.pl (wybór województwa + rok +
numer pozycji, jeśli znany) jako źródła MIARODAJNEGO; BIP marszałkowskie
z tabeli wyżej sprawdź DODATKOWO, gdy potrzebujesz projektu uchwały
SPRZED sesji, uzasadnienia, protokołu głosowania lub gdy dziennik
urzędowy jeszcze NIE opublikował aktu (opóźnienie publikacyjne).
```

### Wejście w życie

```
Zasada: 14 dni od ogłoszenia w dzienniku urzędowym województwa
  Wyjątki:
  □ Akt wymaga wcześniejszego wejścia w życie z uwagi na ważny interes publiczny
    → możliwe krótsze vacatio legis lub natychmiastowe wejście w życie
    → wymaga uzasadnienia
  □ Uchwała budżetowa: wchodzi w życie z dniem podjęcia z mocą od 1 stycznia

Błąd: akt podjęty ale niepublikowany → NIE wchodzi w życie!
```

---

## 3. QUALITY GATE / OUTPUT

**Quality gate:** Akt potwierdzony w dziennikiurzedowe.gov.pl? Data ogłoszenia i data wejścia w życie obliczona? BIP aktualny?

**Output:** Weryfikacja publikacji → data wejścia w życie → vacatio legis → ważność aktu.

**Powiązania:** `mod-JST-ustroj-samorzad-gminny-powiatowy-wojewodztwa` | `dr-05` → `mod-UDIP-dostep-informacji-publicznej`

**Źródła:** https://dziennikiurzedowe.gov.pl | https://isap.sejm.gov.pl
