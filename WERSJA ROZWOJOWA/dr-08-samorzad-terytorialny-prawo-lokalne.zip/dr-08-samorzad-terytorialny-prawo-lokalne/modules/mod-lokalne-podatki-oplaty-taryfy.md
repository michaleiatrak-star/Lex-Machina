# mod-lokalne-podatki-oplaty-taryfy

**Akt:** USG (ustawa o samorządzie gminnym) — t.j. Dz.U. 2026 poz. 662 (zm. po t.j.: 2026/912 od 2026-07-31 — art. 10b; 2026/1273 [OD 2027-03-30: 2026/1273] — art. 1, 36, 37, 37d, 37e).
**Akt:** UWoj (ustawa o wojewodzie i administracji rządowej w województwie) — t.j. Dz.U. 2025 poz. 428.
**Akt:** UPOL (ustawa o podatkach i opłatach lokalnych) — t.j. Dz.U. 2025 poz. 707 (zm. po t.j.: 2026/1354 [OD 2027-01-01: 2026/1354] — art. 1a, 17, 19, 20, 20a).
**Akt:** UZZW (ustawa o zbiorowym zaopatrzeniu w wodę i zbiorowym odprowadzaniu ścieków) — t.j. Dz.U. 2024 poz. 757 (zm. po t.j.: 2026/605 od 2026-05-21 — art. 1, 1a, 1b, 2, 2a, 2b, 4a, 4b, 4c, 4d, 4e, 4f, 4g, 4i, 4j, 4k, 4m, 4p, 5, 7).
**Akt:** UCPG (ustawa o utrzymaniu czystości i porządku w gminach) — t.j. Dz.U. 2025 poz. 733 (zm. po t.j.: 2026/912 od 2026-07-31 — art. 3, 4c, 4ca).
**Akt:** UOAN (ustawa o ogłaszaniu aktów normatywnych) — t.j. Dz.U. 2019 poz. 1461 (zm. po t.j.: 2026/912 od 2026-07-31 — art. 13).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

**Status:** moduł klasy kancelaryjnej — poziom DR-03
**Źródło weryfikacji:** Ustawa o podatkach i opłatach lokalnych — **Dz.U. 2025 poz. 707 t.j.** (reforma od 01.01.2025) → patrz DR-06 | Ustawa wod-kan — Dz.U. 2024 poz. 757
**Data weryfikacji online:** 2026-06-05
**Zasada:** Każde brzmienie przepisu przed powołaniem → isap.sejm.gov.pl

---

## 1. CORE

### Zakres
Lokalne podatki i opłaty (podatek od nieruchomości, rolny, leśny, opłata za śmieci, opłata targowa, miejscowa, uzdrowiskowa), taryfy komunalne (wod-kan), zwolnienia lokalne, stawki uchwalane przez rady gmin.

### ⚠️ KLUCZOWE ODESŁANIE

```
Podatek od nieruchomości (reforma od 01.01.2025 — nowe definicje budowli i budynku):
→ DR-06 → mod-ustawa-podatek-nieruchomosci-i-lokalne
  (tam: Dz.U. 2025 poz. 707 t.j., wyrok TK SK 14/21, nowe definicje, orzecznictwo WSA)

Taryfy wod-kan (zatwierdzane przez Wody Polskie, nie gminę):
→ mod-ustawa-komunalne-wod-kan-transport-czystosc (niniejszy DR-08)
```

---

## 2. PROCEDURA

### Stawki lokalne — mechanizm

```
STAWKI UCHWALANE PRZEZ RADĘ GMINY w granicach maksymalnych z obwieszczenia MF:
  → Obwieszczenie MF: co roku (weryfikuj aktualne!):
    web_search: "stawki maksymalne podatek nieruchomości 2026 MF obwieszczenie"
  → Uchwała rady: do 30 listopada na rok następny (jeśli brak — obowiązują stawki poprzednie)
  → Publikacja: dziennik urzędowy województwa

OPŁATA ZA ŚMIECI (opłata za gospodarowanie odpadami komunalnymi):
  → Rada gminy: uchwalenie stawek i regulaminu
  → Kryteria: od osoby / od m² / od gospodarstwa / od ilości wody (do wyboru)
  → Stawka dla niesegregujących: NIE MOŻE być niższa niż 2× ani wyższa niż 4× stawki podstawowej (art. 6k ust. 3 ustawy o utrzymaniu czystości i porządku w gminach) — ⚠️ UZUPEŁNIONE 2026-07-27 (FAZA 3E/ZASADA 14): poprzednia wersja podawała TYLKO dolną granicę ("min. 2×"), pomijając górną (max 4×), którą część gmin faktycznie stosuje (np. Słupsk — 4× jako maksimum dozwolone ustawą). Potwierdzone w 5+ źródłach 2026 r. (portalsamorzadowy.pl, biznes.gov.pl, przyjazne-deklaracje.pl, forsal.pl [marzec 2026])
  → Zaskarżenie uchwały: tryb art. 101 USG + WSA

OPŁATA TARGOWA, MIEJSCOWA, UZDROWISKOWA:
  → Rada gminy uchwalana w granicach ustawy
  → Weryfikuj katalog i limity w ustawie o podatkach i opłatach lokalnych
```

---

## 3. QUALITY GATE / OUTPUT

**Quality gate:** Stawki z aktualnej uchwały gminy (nie z ustawy — stawki są lokalne)? Uchwała opublikowana w dzienniku woj.? Reforma podatku od nieruchomości 2025 uwzględniona?

**Output:** Kwalifikacja podatku/opłaty → stawka lokalna → podstawa uchwały → zaskarżenie.

**Powiązania:** `dr-06` → `mod-ustawa-podatek-nieruchomosci-i-lokalne` (reforma 2025!) | `mod-JST-ustroj-samorzad-gminny-powiatowy-wojewodztwa` | `mod-skargi-na-prawo-miejscowe-WSA-NSA`

**Źródła:** https://isap.sejm.gov.pl | https://dziennikiurzedowe.gov.pl | https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20250000707
