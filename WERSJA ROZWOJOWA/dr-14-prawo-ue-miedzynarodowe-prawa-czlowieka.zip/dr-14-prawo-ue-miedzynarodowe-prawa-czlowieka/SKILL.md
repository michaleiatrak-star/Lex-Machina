---
name: dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka
version: "3.17"
description: "Prawo UE, międzynarodowe i prawa człowieka: prawo pierwotne i wtórne UE, TSUE, EKPC/ETPC, traktaty, kolizje jurysdykcji i standardy praw człowieka."
dependencies:
  requires:
    - shared
  # 2026-09-27e: jawna zależność (każdy skill systemu korzysta z `shared`); pole czytane przy imporcie z marketplace
---

> **Universal runtime:** przed wykonaniem zastosuj kanoniczny `shared/UNIVERSAL-RUNTIME-ADAPTER.md` z osobnego skilla `shared`. Lokalna sekcja adaptera poniżej jedynie go doprecyzowuje.


## ADAPTER RUNTIME — PORTABILITY (ChatGPT / Claude / inne hosty)

Ta sekcja zmienia wyłącznie wykonanie operacji technicznych. Merytoryka dziedzinowa, mapy aktów, hard gate’y, kolejność modułów i kryteria jakości tego DR-skilla pozostają bez zmian.

1. `view dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/<plik>` oraz `view modules/...` / `view references/...` oznaczają świeży odczyt odpowiedniego lokalnego pliku tego skilla. Literalna ścieżka `/mnt/skills/user` nie jest wymagana.
2. `view shared/<plik>` oznacza świeży odczyt z osobnego, kanonicznego skilla `shared`. NIE kopiuj `shared` do tej paczki. Brak obowiązkowego zasobu shared = fail-closed, nie substytucja pamięcią modelu.
3. `view <inny-skill>/<plik>` oznacza aktywację/odczyt wskazanego osobnego skilla. Nie vendoryzuj innych skilli do tego ZIP-a.
4. `web_search` / `web_fetch` i podobne nazwy oznaczają świeże wyszukanie/odczyt online przez równoważną funkcję hosta. Zachowaj wymagane źródła oficjalne, statusy weryfikacji i zakaz cytowania prawa z pamięci.
5. `show_widget`, `visualize:read_me`, `present_files`, `create_file`, shell/Python i podobne operacje są nazwami semantycznymi. Jeśli host nie ma literalnego narzędzia, użyj równoważnej funkcji natywnej bez omijania bramek jakości.
6. `/mnt/user-data/...` oznacza rzeczywiste załączniki użytkownika dostępne w bieżącym hoście; wymagany ponowny odczyt ma być faktycznym odczytem źródła.

**Zasada nadrzędna:** instrukcje, które są już zrozumiałe i wykonalne w bieżącym hoście, wykonuj bez konwersji. Adapter działa wyłącznie na granicy runtime.


# DR-14 — Prawo UE, Międzynarodowe, Prawa Człowieka

## ⛔ HARD GATE — ZAKAZ CYTOWANIA Z PAMIĘCI

**PRZED każdym powołaniem przepisu, numeru rozporządzenia, artykułu traktatu, daty stosowania lub sygnatury:**
1. Zweryfikuj akty krajowe w `ELI (RZĄD 1)`
2. Zweryfikuj prawo UE i traktaty w `eur-lex.europa.eu`
3. Zweryfikuj orzeczenia ETPC w `hudoc.echr.coe.int`
4. Zweryfikuj orzeczenia TSUE w `curia.europa.eu`
5. **NIGDY** nie podawaj artykułu, terminu, etapu stosowania ani sygnatury wyłącznie z pamięci modelu.

**Kluczowe daty bezwzględnie weryfikować online:**
- EKPC: termin skargi do ETPC = **4 miesiące** (od 01.02.2022; poprzednio 6 miesięcy)
- Bruksela Ia: znosi exequatur w UE (od 10.01.2015) — weryfikuj wyjątki
- Pytanie prejudycjalne art. 267 TFUE: sąd ostatniej instancji ma OBOWIĄZEK, niższy — prawo


> ⛔ **BRAMKI MIĘDZYNARODOWE — obowiązkowe dla całej dziedziny** (dodane 2026-09-04,
> po audycie porównawczym 14 kazusów: ustalenia K-01 zlanie warstw jurysdykcja/prawo
> właściwe/wykonalność, K-02 atrybucja per podmiot zamiast per zachowanie, K-06 reżim
> odpowiedzialności założony zamiast odczytanego z tekstu):
>
> ```
> view shared/HIERARCHIA-ZRODEL-MIEDZYNARODOWE.md
> view shared/MIEDZYNARODOWE-GATES.md
> view shared/MOD-CN-GATE.md      ← CN-GATE, NIE podlega podmianie przez MG
> view shared/MOD-REM-GATE.md     ← REM-GATE, NIE podlega podmianie przez MG
> ```
>
> Fail-closed: brak odczytu = zakaz formułowania konkluzji opartej na traktacie,
> akcie UE lub orzeczeniu organu międzynarodowego.
>
> ⛔ **KOREKTA KANAŁU (2026-09-05, F-162).** Poprzednie brzmienie głosiło, że
> `bash_tool`/`curl` „NIE sięga domen międzynarodowych". Zmierzone — to
> nieprawda: `eur-lex.europa.eu` i `legal.un.org` zwracają HTTP 200 i pełny
> tekst, co pozwala pracować na RZĘDZIE 1 zamiast na snippetach. Blokada
> dotyczy `unoosa.org` (przekierowanie na `www.`, 403), `cites.org` (detekcja
> bota), `icsid.worldbank.org` i `uncitral.un.org` — tam `web_search` →
> `web_fetch`. Aktualna tabela kanałów: `HIERARCHIA-ZRODEL-MIEDZYNARODOWE.md` §2.
> Zanim orzekniesz o niedostępności, sprawdź kształt żądania
> (`shared/DOSTEP-MASZYNOWY-API.md §1`) — klasa błędu F-151.

> ⛔ **SELF-CHECK ANTY-FASADA — obowiązkowy przed wysłaniem odpowiedzi/pisma**
> (podłączone 2026-08-24, flaga F-115 P3 — zamknięcie zakresu 16 skilli DR):
>
> ```
> view shared/SELF-CHECK-ANTY-FASADA.md
> ```
>
> Sprawdza dwie rzeczy: (1) czy w tekście stoi „zweryfikowano", data weryfikacji
> albo URL przy przepisie, dla którego NIE wywołano narzędzia W TEJ ODPOWIEDZI;
> (2) czy znacznik statusu nie został nadany treści WYGENEROWANEJ w tej odpowiedzi
> (AF-6). Treść listy jest w module, nie tutaj — celowo, żeby nie powstało kolejne
> miejsce dryfu (7 wcześniejszych kopii rozjechało się ze źródłem przy pierwszej
> zmianie brzmienia).
>
> ⛔ Wyzwalaczem jest BRAK WYWOŁANIA NARZĘDZIA dla danego twierdzenia w danej
> odpowiedzi — nie brak narzędzi w sesji. Niedostępność ELI (oba kanały) nie zwalnia z
> oznaczenia, tylko je wymusza; niedostępność ISAP to stan normalny.

---

## Zasada architektoniczna
- Jeden moduł = jeden akt / obszar prawa UE lub prawa międzynarodowego
- Ten sam akt NIE może pokrywać dwóch różnych DR-skills
- **Zakaz cytowania przepisów z pamięci — weryfikuj w ELI (RZĄD 1) i EUR-Lex**
- **Prawo UE zmienia się dynamicznie — etapy stosowania weryfikuj online**

---

## ORKA-BAS — Definicje wspomagające (shared/ORKA-BAS-LEKSYKON.md)

Przy sprawach z tej dziedziny rozważ doładowanie (`view`) definicji:
- BAS-113 Płeć społeczno-kulturowa / gender (brak definicji legalnej w PL;
  Konwencja stambulska CETS 210 art. 3 lit. c)
- prawo-polskie-v2/krajowe/shared/mod-niewidomy-prawa-prawne.md — Konwencja ONZ o prawach osób niepełnosprawnych
  art. 13 (dostosowania proceduralne — skuteczny dostęp do wymiaru sprawiedliwości)

## DEFINICJE — prawo-polskie-v2/krajowe/shared/definicje/ (nieobecne — adnotacja audytowa 2026-06-14)

Ta dziedzina nie ma dedykowanego pliku w `prawo-polskie-v2/krajowe/shared/definicje/`. Prawo UE, międzynarodowe, prawa człowieka — definicje TFUE/TUE/KPP/EKPC mają charakter pierwotny (prawo traktatowe) i są pokryte wprost w modułach dziedzinowych (mod-KPP-karta-praw-podstawowych-UE, mod-EKPC-ETPC-prawa-czlowieka). Żaden plik prawo-polskie-v2/krajowe/shared/definicje/ nie obejmuje tej dziedziny.
<!-- lex:wykonuje-aplikacja: REJESTR-MODULOW -->
## Moduły (12 łącznie — ✓ 12 OK, ☐ 0 STUB)

```
PRAWO PIERWOTNE UE I PROCEDURY TSUE:
  [✓] OK    mod-TFUE-TUE-prawo-pierwotne-UE
              (TUE + TFUE — Dz.Urz. UE C 326/2012; test transgraniczny;
               pytanie prejudycjalne art. 267 TFUE — tryb zwykły i pilny (PPU);
               pierwszeństwo prawa UE (Simmenthal/Costa); bezpośredni skutek
               (wertykalny/horyzontalny); odpowiedzialność odszkodowawcza państwa
               (Francovich/Brasserie du Pêcheur — art. 417¹ § 1 KC);
               rozporządzenia kolizyjne: Bruksela Ia, Rzym I/II, ENZ, ESCP)

PRAWA CZŁOWIEKA — STRASBURG:
  [✓] OK    mod-EKPC-ETPC-prawa-czlowieka
              (EKPC Dz.U. 1993 nr 61 poz. 284 ze zm.; KPP UE (Dz.Urz. UE C 326);
               skarga do ETPC: 4 miesiące + wyczerpanie środków + istotna niekorzyść;
               baza HUDOC; intake 8-punktowy; matryca dowodowa; strategia; ryzyka;
               7 protokołów dodatkowych ratyfikowanych przez Polskę — weryfikuj)

PRAWA CZŁOWIEKA — EUROPA/UE:
  [✓] OK    mod-KPP-karta-praw-podstawowych-UE
              (KPP — 7 tytułów, art. 1–54; stosowanie: tylko gdy wdrażane prawo UE;
               art. 47 — prawo do sądu; art. 50 — ne bis in idem; art. 7–8 — prywatność)

EGZEKUCJA I PROCEDURY TRANSGRANICZNE:
  [✓] OK    mod-KPC-egzekucja-transgraniczna-UE
              (KPC Dz.U. 2026 poz. 468 t.j.; Bruksela Ia — znosi exequatur;
               Bruksela IIb 2019/1111 (od 01.08.2022) — sprawy rodzinne;
               ENZ — europejski nakaz zapłaty (formularz A, sprzeciw);
               ESCP — drobne roszczenia do 5 000 EUR;
               doręczenia: Rozp. 2020/1784; apostille Haga 1961;
               uznanie art. 1145–1149 KPC; intake; 12 typowych zarzutów;
               3 warianty strategii; quality gate)

PRAWO PRYWATNE MIĘDZYNARODOWE:
  [✓] OK    mod-PMPP-prawo-prywatne-miedzynarodowe
              (ustawa PPM Dz.U. 2023 poz. 503 t.j.; Rzym I — ochrona konsumenta/pracownika;
               Rzym II — lex loci damni; Rozp. spadkowe 650/2012 — zwykłe miejsce pobytu;
               Haga 1980 (uprowadzenie dziecka), 1996, 2007 (alimenty);
               intake; matryca dowodowa; strategia; ryzyka; quality gate)

PRAWA CZŁOWIEKA — ONZ:
  [✓] OK    mod-ONZ-pakty-prawa-czlowieka
              (MPPOiP Dz.U. 1977 nr 38 poz. 167; MPPGSiK Dz.U. 1977 nr 38 poz. 169;
               CRPD Dz.U. 2012 poz. 1169; Komitet Praw Człowieka ONZ;
               skargi indywidualne po wyczerpaniu środków krajowych;
               hierarchia: umowy > ustawa, nie > Konstytucja)

NATO I UMOWY OBRONNE:
  [✓] OK    mod-NATO-umowy-miedzynarodowe
              (Traktat Waszyngtoński Dz.U. 2000 poz. 970;
               SOFA Dz.U. 2000 nr 21 poz. 257;
               art. 5 — klauzula wzajemnej obrony; jurysdykcja nad obcymi żołnierzami;
               art. 42 TUE — wspólna obrona UE; zgoda Sejmu art. 117 Konstytucji)

GRANICE I RUCH OSOBOWY:
  [✓] NOWY  mod-maly-ruch-graniczny
              (utworzony 2026-07-15; rozp. UE 1931/2006 + 1342/2011; umowy
               dwustronne PL-Ukraina (Dz.U. 2009 poz. 858), PL-Rosja
               (Dz.U. 2012 poz. 814, zawieszona od 2016), PL-Białoruś (Dz.U.
               2010.122.823, nigdy nie weszła w życie) — ⛔ temat wysoce
               zmienny politycznie, zawsze web_search aktualnego statusu)

INWESTYCJE TRANSGRANICZNE:
  [✓] NOWY  mod-inwestycje-transgraniczne-FDI-BIT
              (zaktualizowany 2026-07-18: dodano przykład roboczy —
               inwestor rosyjski w przemyśle zbrojeniowym, 4 równoległe
               warstwy kontroli: Mechanizm 1+2 ustawy o kontroli
               inwestycji + sankcje UE + compliance łańcucha dostaw)
              (utworzony 2026-07-15; DWA reżimy: A) kontrola FDI — ustawa
               o kontroli niektórych inwestycji Dz.U. 2026 poz. 47 t.j.
               (⏳ po t.j.: Dz.U. 2026 poz. 815, od 4.07.2026),
               mechanizm podstawowy + art. 12a-12k uczyniony bezterminowym
               nowelizacją 2025.973; rama UE rozp. 2019/452; B) ochrona
               traktatowa BIT/ISDS — Achmea C-284/16, Komstroy C-741/19,
               PL Holdings C-109/20, porozumienie 2020 o wygaśnięciu BIT-ów
               intra-UE; ⛔ Polska NIE ratyfikowała Konwencji ICSID — fakt
               łatwy do pomylenia, jawnie odnotowany w module)

PRAWO DYPLOMATYCZNE I KONSULARNE:
  [✓] NOWY  mod-konwencje-wiedenskie-dyplomatyczne-konsularne
              (utworzony 2026-08-20 — naprawa F-60: temat miał ZERO
               wzmianek w całym systemie. Konwencja 1961 [dyplomatyczna]:
               persona non grata bez obowiązku uzasadnienia [art. 9],
               nietykalność pomieszczeń misji [art. 22 ust. 3, zakaz
               egzekucji], nietykalność osobista ABSOLUTNA i immunitet
               jurysdykcyjny z 3 wyjątkami cywilnymi [art. 29, 31],
               zrzeczenie immunitetu WYŁĄCZNIE przez państwo wysyłające
               [art. 32], hierarchia ochrony rodzina/personel [art.
               37-38]. Konwencja 1963 [konsularna]: nietykalność
               archiwów bezterminowa [art. 33], prawo do kontaktu
               konsularnego przy zatrzymaniu cudzoziemca [art. 36,
               obowiązek warunkowy na wniosek osoby — potencjalny most
               do dr-03/KPK], KLUCZOWA różnica: nietykalność konsula
               WĘŻSZA niż dyplomaty [art. 41 — wyjątek dla ciężkiej
               zbrodni], immunitet FUNKCJONALNY ratione materiae a nie
               osobowy ratione personae [art. 43]. ⚠️ [NIEWERYFIKOWANE
               RZĄD 1] większość treści — ISAP zablokowany)

  [✓] NOWY  mod-konwencja-genewska-uchodzcy-1951-protokol-1967
              (utworzony 2026-08-20 — naprawa F-61: Konwencja genewska
               i Protokół nowojorski miały ZERO wzmianek na poziomie
               traktatowym [dr-05 wspominał tylko ogólnie, bez numerów
               artykułów]. Definicja uchodźcy — 5 przesłanek
               kumulatywnych + klauzule ustania [1C] i wyłączające
               [1F, zbrodnie wojenne] [art. 1]; zasada NON-REFOULEMENT
               z 2 wyjątkami zamkniętymi [art. 33 — status zbliżony do
               ius cogens]; niekaranie za nielegalny wjazd przy
               spełnieniu warunków bezpośredniości i zgłoszenia się
               [art. 31, z odniesieniem do TSUE C-481/13] — potencjalny
               most do dr-03; wydalenie uchodźcy legalnie przebywającego
               tylko z 2 przesłanek [art. 32]; mechanizm Protokołu 1967
               [odczyt Konwencji bez cezury czasowej, art. 1/3/4/16/33
               niederogowalne zastrzeżeniami]. ⚠️ [NIEWERYFIKOWANE
               RZĄD 1] większość treści; numer Dz.U. Protokołu
               niepotwierdzony)

NARZĘDZIE METODYCZNE:
  [✓] OK    mod-rejestr-zrodla-prawa-lifecycle
              (workflow kancelaryjny aktualności prawa: audyt RZĘDU 1 (ELI), stan prawny
               na dzień zdarzenia / pisma / orzekania; przepisy przejściowe;
               integruje: shared/ISAP-AUDIT-PROTOCOL + shared/TEMPORAL-LAW-CHECK +
               shared/LEGAL-LIFECYCLE-MANAGEMENT + shared/LEGAL-QUALITY-GATE)
```

---

## Jak wywołać

```
view dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/modules/[nazwa-modulu].md
```

## Lokalna mapa aktów prawnych

```
view dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/MAPA-AKTOW.md
```

## Mapa pokrycia treściowego (planowanie rozwoju skilla)

Rejestr informacyjny — NIE krok obowiązkowy przy obsłudze konkretnej sprawy.
Jedyne bieżące źródło statusu pokrycia tego DR (por. `prawny-router-v3/references/pokrycie-dziedzinowe.md`);
przy nowelizacji pokazuje, czy dotknięty fragment ma treść do zaktualizowania:

```
view dr-14-prawo-ue-miedzynarodowe-prawa-czlowieka/MAPA-POKRYCIA.md
```

---

## Powiązania zewnętrzne
- Wchodzi z: `prawo-polskie-v2` → `ROUTING-MAP.md` → ten skill
- Cyberprzestępstwa transgraniczne (dyrektywa NIS2, Budapest) → `dr-11`
- AI Act, DSA, DMA — regulacje sektorowe UE wymagają analizy merytorycznej → `dr-11` (mod-AI-Act-framework, mod-DSA-digital-services-act, mod-DMA-digital-markets-act); ten skill dostarcza podstawę praw podstawowych (KPP art. 47, EKPC) gdy decyzja krajowa na bazie tych regulacji jest zaskarżana
- Prawo karne UE (ENA, dyrektywy ofiarowe, Eurojust) → `dr-03`
- Prawo pracy UE (swoboda przepływu, dyrektywy pracownicze) → `dr-04`
- Zamówienia publiczne UE (dyrektywy 2014/24, 2014/25) → `dr-07`
- Obrona narodowa / NATO → `dr-13` → `mod-ustawa-obrona-ojczyzny-mobilizacja`
- Weryfikacja orzecznictwa TSUE/ETPC → `orzeczenia-sadowe-v2`
- Wychodzi do: `pisma-procesowe-v3` / `analiza-sadowa-v6` / `orzeczenia-sadowe-v2`
- Weryfikacja: ELI (RZĄD 1) | eur-lex.europa.eu | echr.coe.int | curia.europa.eu | hcch.net

## ⚖️ DISCLAIMER (obowiązkowy)

Po zakończeniu analizy lub przed oddaniem odpowiedzi zawierającej ocenę prawną:

```text
view shared/DISCLAIMER.md
```

Wybierz wariant odpowiedni do trybu:
- **PRAWNIK / kancelaria** → wariant techniczny (art. 4 Prawa o adwokaturze / art. 6 u.r.p.)
- **LAIK / pro se** → wariant uproszczony (informacja ≠ porada prawna)

Disclaimer musi być **ostatnim elementem** każdej odpowiedzi zawierającej analizę prawną,
ocenę szans, kwalifikację prawną lub interpretację przepisu.
