# Moduł — Pakty ONZ dotyczące praw człowieka

**Akt:** Konst (Konstytucja RP) — akt pierwotny, bez t.j.: Dz.U. 1997 poz. 483.
**Akt:** UUM (ustawa o umowach międzynarodowych) — t.j. Dz.U. 2020 poz. 127.
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

## Akt prawny / źródło
- Międzynarodowy Pakt Praw Obywatelskich i Politycznych (MPPOiP)
  Dz.U. 1977 nr 38 poz. 167; ratyfikowany przez Polskę
  ✅ VER: isap.sejm.gov.pl 2026-06-07
- Międzynarodowy Pakt Praw Gospodarczych, Społecznych i Kulturalnych (MPPGSiK)
  Dz.U. 1977 nr 38 poz. 169
- Protokół fakultatywny do MPPOiP (skarga indywidualna do KPCz ONZ)
  Dz.U. 1994 nr 23 poz. 80

**Weryfikacja:** ELI (RZĄD 1) + ohchr.org przed każdym cytowaniem.

## Zakres
MPPOiP: prawo do życia, zakaz tortur, wolność od niewolnictwa, prawo do sądu,
wolność myśli/sumienia/wyznania, wolność słowa, prawo do prywatności.
Komitet Praw Człowieka ONZ (KPCz) — organ traktatowy nadzorujący wykonanie MPPOiP.
Skargi indywidualne do KPCz: możliwe po wyczerpaniu krajowych środków ochrony.

MPPGSiK: prawo do pracy, godziwego wynagrodzenia, edukacji, zdrowia, opieki społecznej.
Monitorowanie: Komitet Praw Gospodarczych, Społecznych i Kulturalnych ONZ.

Konwencja ONZ o prawach osób z niepełnosprawnościami (CRPD) — Dz.U. 2012 poz. 1169.

## Zasady absolutne
```
Hierarchia:     MPPOiP ratyfikowany = część polskiego porządku prawnego (art. 91 Konstytucji)
Pierwszeństwo: Umowa międzynarodowa ponad ustawą (nie ponad Konstytucją)
KPCz:          Opinie KPCz nie są wiążące — ale stanowią wykładnię autorytatywną
```

## Weryfikacja online
```
web_search: "MPPOiP Polska ratyfikacja isap.sejm.gov.pl tekst"
web_search: "Komitet Praw Człowieka ONZ Polska 2025 sprawozdanie"
```
