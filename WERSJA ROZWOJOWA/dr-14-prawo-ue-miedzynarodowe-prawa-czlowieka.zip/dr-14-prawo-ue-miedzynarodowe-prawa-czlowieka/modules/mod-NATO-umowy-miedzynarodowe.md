# Moduł — NATO, umowy obronne i sojusznicze

## Akt prawny / źródło
- Traktat Północnoatlantycki (Traktat Waszyngtoński) — 4.04.1949
  Ratyfikowany przez Polskę: Dz.U. 1999 nr 87 poz. 970
  ✅ VER: isap.sejm.gov.pl 2026-06-07
- Umowa SOFA (Status of Forces Agreement) w ramach NATO — Dz.U. 2000 nr 21 poz. 257
- Ustawa o zasadach pobytu wojsk obcych na terytorium RP, ich
  przemieszczania i udzielania pomocy wojskom sojuszniczym —
  **Dz.U. 2024 poz. 1770 t.j.** (VER ELI 2026-08-26)

**Weryfikacja:** ELI (RZĄD 1) i nato.int przed każdym cytowaniem.

## Zakres
Art. 5 Traktatu Waszyngtońskiego: klauzula wzajemnej obrony — atak na jednego = atak
na wszystkich (collectve defence). Nie jest jednak automatyczny — każde państwo decyduje
o własnych działaniach.

STANAG: standardy techniczne i operacyjne NATO — nie są publikowane w Dz.U.,
dostęp przez oficjalne kanały wojskowe. Znaczenie prawne: obowiązek wdrożenia przez
siły zbrojne RP (ustawa o obronie Ojczyzny).

SOFA: jurysdykcja nad żołnierzami obcych państw na terytorium RP.

## Zasady absolutne
```
Art. 5:     "Atak zbrojny" — definicja hybrydowa po aktualizacji doktryny (cyber, dezinfo)
SOFA:       Jurysdykcja karna nad obcym żołnierzem — państwo wysyłające ma pierwszeństwo
            przy przestępstwach w służbie; przyjmujące przy innych
Ustawa:     Zgoda Sejmu na wejście obcych wojsk na terytorium RP (art. 117 Konstytucji)
```

## Połącz z
- DR-13/mod-ustawa-obrona-ojczyzny-mobilizacja (obrona RP)
- DR-14/mod-TFUE-TUE-prawo-pierwotne-UE (art. 42 TUE — wspólna obrona UE)

## Weryfikacja online
```
web_search: "Traktat Waszyngtoński art. 5 NATO Polska Dz.U. 1999 poz. 970"
web_search: "NATO SOFA umowa Polska 2025 aktualizacja"
```
