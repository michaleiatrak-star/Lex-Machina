# CHANGELOG — prawo-polskie-v2

- 6.108 (2026-11-14): DR-09: wskazania z kwalifikatorem (PrBud, POŚ 2026/1453, UOP, PrLow, PrWod, PrEn, OZE, transport); PrBud art. 29 altana/basen; UOP art. 83f progi i zgłoszenie
- 6.107 (2026-11-14): DR-08: wskazania z kwalifikatorem; dochody JST — model ustawy z 1.10.2024 (art. 8: udziały od dochodów), t.j. 2026/1252; UDP art. 13b ust. 4–5 i 13f z płacą min. 2026/2027; W-4 2024/1907
- 6.106 (2026-11-14): DR-07: wskazania z kwalifikatorem (PZP 2026/793, PrNot, NIK, RIO, UNDFP, UZRFE, pomoc publiczna); UNDFP art. 31 ust. 4 zamiast art. 34; W-4 2026/1099
- 6.105 (2026-11-14): DR-06: wskazania z kwalifikatorem (OP, VAT, PIT, CIT, PCC, akcyza, KAS, AML); akcyza 2026 — podstawa art. 165a; PCC próg 3000 zł od 3.11.2026; W-4 dla 2026/1102, 1270, 1347, 1354, 1446
- 6.104 (2026-11-14): DR-03 komplet: 71 modułów + 8 części kwalifikatora w formacie wskazań; poprawki zagrożeń art. 234-244b KK, przedawnienie cyber, art. 244 przy nakazie Policji, tabela kar frameworku
- 6.103 (2026-11-14): DR-02 komplet: ostatnie 10 modułów (ubezpieczenia obowiązkowe, cudzoziemcy, parabanki, piecza, fundacja rodzinna, pomoc publiczna, frankowa 2026/985, doradca restr., reklama, KSH-uzupełnienie, weksle/kontrola)
- 6.102 (2026-11-14): DR-02: mobbing wg art. 94³ KP od 2026-11-05 (2026/1046), skład sądu, timeshare/zastaw, transakcje handlowe, przedsiębiorcy zagraniczni
- 6.101 (2026-11-14): DR-02: spółdzielnie, własność lokali, UOKiK, KW, prawa konsumenta, ochrona lokatorów, prawo spółdzielcze, fundacje/stowarzyszenia, deweloperska, UZNK w formacie wskazań
- 6.100 (2026-11-14): DR-01: wszystkie 15 modułów w formacie wskazań z kwalifikatorem (poprawki: art. 157-160 Konstytucji, referendum lokalne, inicjatywa obywatelska, referendum zatwierdzające)
- 6.99 (2026-11-14): 2026/912 w modułach DR-08/DR-09; poprawki: skarga na uchwałę RIO do WSA (art. 98 USG), decyzja WZ wygasa po 5 latach (art. 64c UPZP)
- 6.98 (2026-11-14): Bazy urzędów i sądów dyscyplinarnych w orzeczenia-sadowe-v2; KAS na t.j. 2026/1492 (poprawki art. 63, 77, 82-83 UKAS); DR-02: Prawo przedsiębiorców, zastaw rejestrowy (2025/1792 i 2026/1073 jeszcze nie obowiązują)
- 6.97 (2026-11-14): DR-02: konwersja modułów KC i KRO na wskazania z kwalifikatorem (W-1; poprawki: art. 442¹, 88 § 2, 388 § 2, 554, 1007 § 2–4)
- 6.96 (2026-11-14): METODYKA W-1: 26 modułów PrRestr (t.j. 2026/533) i PrUp (t.j. 2026/913) — wartości i terminy zgodne z t.j.; nagłówki z kontraktem wskazań i znacznikami [OD] (2026/1206, 2026/176, 2026/1466)
- 6.95 (2026-11-14): Moduł wrogiego przejęcia: skrót OfPubl (monitoring ustawy o ofercie publicznej); rejestr: W-4 dla 2026/1074 i 2026/1206
- 6.94 (2026-11-14): METODYKA W-1…W-7: mod-ustawa-KRS-rejestr-sadowy (t.j. 2025/869 + 7 nowelizacji, pułapka MSiG od 2025-11-29) i mod-KSH-wrogie-przejecie (KSH + uoof t.j. 2025/592, art. 80a–80b); DR-12: OIRP Katowice i Rzeszów; rejestr zmian w czasie
- 6.93 (2026-11-13): REJESTR-ZMIAN-W-CZASIE: zmiany nadchodzące modułów paczki 2 DR-02 (UGH 2026/1040, KK 2026/1466, NBP 2026/1098) i odczyty W-4 w tabeli C
- 6.92 (2026-11-13): REJESTR-ZMIAN-W-CZASIE: KSCU 2026/346 (od 2028-09-30) w tabeli A; tabela B: przepisy przejściowe KPC 2026/473 art. 15, 2026/830 art. 19, 2026/1046 art. 5; tabela C: odczyty W-4 dla 2026/346, 473, 830, 1046
- 6.91 (2026-11-13): REJESTR-ZMIAN-W-CZASIE (JUR:rejestr-zmian-w-czasie): zmiany z datą przyszłą (tabela generowana z ELI, wiersz znika w dniu wejścia w życie) i przepisy czasowe z okresem Od–Do (2026/1440 art. 3; 2026/176 art. 28, 29, 31–34 — z treści nowelizacji w ELI 2026-11-13); STAN-PRAWNY-PL: odesłanie przed KROKIEM T-2; JURYSDYKCJA: nowy klucz; tabela C: odczyt W-4 dla 2026/1440, 176, 187, 644, 1206
- 6.90 (2026-11-13): mod-FA-founders: odesłanie JDG / działalność nierejestrowana → DR-02 mod-prawo-przedsiebiorcow
- 6.89 (2026-11-13): nowe t.j. (ELI 2026-11-13): Prawo przedsiębiorców Dz.U. 2026 poz. 1484 (zastępuje 2025/1480; obejmuje 2025/1795, 1826, 2026/507), KAS Dz.U. 2026 poz. 1492 (zastępuje 2025/1131; obejmuje 2026/1281) — ROUTING-MAP, ISAP-METRYKI-AKTOW, DEF-PODATKOWE, DEF-PODMIOTY-WLASNOSC, leksykon ORKA-BAS, mod-FA-founders; ROUTING-MAP: ustawa antymobbingowa 2026/1046 opisana jako ustawa zmieniająca, nie t.j.
- 6.88 (2026-11-13): konektory MCP po zgłoszeniu ActiFlow: eurlex_tekst (treść aktu UE z Cellar, artykuł, domyślnie najnowsza konsolidacja); eurlex_lookup bez fałszywej daty końca (MAX z dat Cellar, data sprzeczna ze statusem pominięta), tytul_aktu bez „- Deklaracja”, konsolidacja_najnowsza i tekst_url_cellar; CBOSA: awaria kanału zawsze ERROR z przyczyną (kod, etap DNS/TCP/TLS/HTTP, IP, retryable) i kanałem zastępczym, cbosa_diagnoza, User-Agent z LEX_CBOSA_USER_AGENT; isap_lookup: „ustawa o …” rozpoznaje akt bazowy.
- 6.87 (2026-11-12): HIERARCHIA-ZRODEL i PRAWO-HARDGATE-ORZECZENIA: orzeczenia odczytane na portalu samego sądu dyscyplinarnego (wsd.adwokatura.pl, wsd.kirp.pl, nil.org.pl/orzeczenia) = RZĄD 2A → ✅ [VER], jak sn.pl (wcześniej traktowane jako RZĄD 3 / 🟨); odpisy i omówienia na innych stronach pozostają tropem; wiersz „Sądy dyscyplinarne” w tabeli routingu wykonawczego (RD 121/26).
- 6.86 (2026-11-11, ELI 2026-11-11): ROUTING-MAP: związki metropolitalne (pomorski 2026/912, śląski 2025/186) → dr-08 mod-zwiazki-metropolitalne; zmiany po t.j. z ELI: deweloperska 2026/1077, prawo autorskie 2026/1477, CIT, USG, USP, ogłaszanie aktów, czystość, rewitalizacja, MPZP, UGN, wdrożeniowa (2026/912); słowa kluczowe DR-08: związek metropolitalny.
- 6.85 (2026-11-11): konektory MCP — wspólna warstwa wspolne/sesja-przegladarki.mjs (lex-mcp.js): strona ochrony antybotowej (Cloudflare, DataDome, Imperva, F5) zamiast danych kończy się LAW_SOURCE_VERIFICATION_REQUIRED:<host> (nie brak danych); sesja z okna weryfikacji aplikacji (LEX_BROWSER_SESSIONS_FILE) dokładana do zapytań danego hosta; sn.pl bez zmian (własna obsługa); dist/lex-mcp.mjs przebudowany.
- 6.84 (2026-11-11, ELI 2026-11-11): ROUTING-MAP, ISAP-METRYKI-AKTOW, leksykon ORKA-BAS, kotwice opłat: nowe t.j. UFP 2026/1447, polityka rozwoju 2026/1366, POŚ 2026/1453, Prawo geodezyjne 2026/1389, SUS 2026/1474 (powołane artykuły porównane w ELI).
- 6.83 (2026-11-11, ELI 2026-11-11): ROUTING-MAP: ustawa o PSP — t.j. Dz.U. 2026 poz. 1473 (sync z dr-13 3.22).
- 6.82 (2026-11-09): konwencje przewozowe i CMR przy prawie polskim — ROUTING-MAP: Prawo przewozowe (t.j. 2024/1262) z KC art. 774–793, CMR (1962/238) z Protokołem 1978 (2011/382) i e-CMR (2019/1487), Konwencja montrealska (2007/235) i system warszawski (1933/49, 1963/189, 1965/167), COTIF (1985/158) z Protokołem wileńskim (2007/674), Konwencja o konosamentach (1937/258) z Protokołami (1980/48, 1985/26) → DR-09 mod-umowa-przewozu-CMR-konwencje-przewozowe; słowa kluczowe DR-09 (CMR, e-CMR, konwencja montrealska, zagubiony bagaż, COTIF, CIM, konosament); metryki z ELI 2026-11-09
- 6.81 (2026-11-08): Rozdział metody i parametrów PL: TEMPORAL-LAW-CHECK, LEGAL-LIFECYCLE-MANAGEMENT, POLISH-LAW-MAX-COVERAGE-STANDARD, LEGAL-QUALITY-GATE, CROSS-DOMAIN-CONFLICT-ROUTER w pojęciach ELI; parametry krajowe kluczami JUR:stan-prawny, JUR:ryzyko-dezaktualizacji, JUR:konflikt-dziedzin
- 6.80 (2026-11-07): pole prefiks-dziedzin w bloku DOSTAWCA JURYSDYKCJI (dr dla PL; inne kraje: kod kraju); T50 wymaga pola
- 6.79 (2026-11-06): konektory MCP prawa polskiego (mcp-servers/, .mcp.json; 16 serwerów) przeniesione z audyt-systemu-v4 — plugin prawo-polskie-v2 startuje serwery lex-*; JURYSDYKCJA.md: blok DOSTAWCA JURYSDYKCJI (kraj, język, waluta, dziedziny, konektory, dostawcy komponentów aplikacji)
- 6.78 (2026-11-06): migracja prawa polskiego E3: pakiet przyjął 95 modułów prawa krajowego (krajowe/<skill>/…) ze skilli wykonawczych i shared; JURYSDYKCJA.md wskazuje nowe miejsca, klucze bez zmian
- 6.77 (2026-11-06, migracja prawa polskiego E1b): JURYSDYKCJA.md — pełna mapa modułów prawa polskiego: 95 nowych kluczy `JUR:` (moduły klasy MODUŁ PL z mapy E0b, opłaty `shared/oplaty/01–07`, procedura: wymogi formalne, braki, właściwość, sygnatury, tryby, prekluzja, liczenie terminów, kanony weryfikacji; kopie opłat w skillach wykonawczych) — adres, nie przeniesienie.
- 6.76 (2026-11-06, migracja prawa polskiego E1): `JURYSDYKCJA.md` — manifest kluczy `JUR:` (terminy-procesowe, oplaty-sadowe, hierarchia-zrodel, zrodla-aktow, mapa-dziedzin) → moduły prawa polskiego; pakiet jurysdykcji PL, do którego skille wykonawcze odsyłają zamiast powtarzać treść krajową.
- 6.75 (2026-11-04, AUDYT-2026-11-04): ROUTING-MAP: nowy wiersz kontroli operacyjnej (Dz.U. 2026 poz. 1281 → dr-13 mod-ustawa-sluzby-operacyjne-retencja-danych); 1281 przy KAS, PrProk, ABW, CBA, SKW/SWW; ZZ i informowanie pracowników — 2026/1340 w mocy od 30.10.2026; ustawa antykorupcyjna — 2026/1003 art. 118 w mocy od 28.10.2026; MONITORING: KSCU — 1003 w mocy (zostaje 346), wiersz 2026/1348 usunięty (w mocy w całości od 31.10.2026).
- 6.74 (2026-10-31, AUDYT-2026-10-31): ROUTING-MAP: nowe t.j. — opłata skarbowa 2026/1395, Prawo lotnicze 2026/1407, bezpieczeństwo żywności 2026/1399 (ELI RZĄD 1).
- 6.73 (2026-10-22, AUDYT-2026-10-22): t.j. KW Dz.U. 2026 poz. 1372 (stan 23.09.2026; zastąpił 2025/734) w wierszach KW ROUTING-MAP; t.j. PSWN Dz.U. 2026 poz. 1362 (stan 10.09.2026; zastąpił 2024/1571) w wierszach oświata/uczelnie.
- 6.72 (2026-10-20, PROBE-2026-10-21): routing błyskawiczny DR-02: uprowadzenie / wywiezienie dziecka za granicę (z DR-14 przy elemencie zagranicznym)
- 6.71 (2026-10-20, LEXAGENTO-P2): routing błyskawiczny: skarga na komornika -> DR-02 (art. 767 KPC, DR-12 drugi); orzecznictwo SN / Sądu Najwyższego -> DR-16 jako druga dziedzina po sprawie
- 6.70 (2026-10-20, AUDYT-2026-10-20e): ROUTING-MAP: KOREKTA dat 1872 (bez 03.06.2026) i zakres zmian (KPK 295 § 1a, KPW, u.w.r.n.); 1818 — pełny zakres i data 2.01.2026
- 6.69 (2026-10-20, AUDYT-2026-10-20d): ROUTING-MAP: wiersze nowych modułów (KZN 1299, SIOZ 1304, obszary morskie 1305, przedsiębiorcy zagraniczni 1313, umowa PL–Japonia 1326), rozp. VAT 2023/2670 (13 nowelizacji, ostatnia 1288); 1354 odczytana (PCC 3000 zł od 3.11.2026, PIT, u.p.o.l.); 1358 odczytana (kąpieliska)
- 6.68 (2026-10-20, AUDYT-2026-10-20c): ROUTING-MAP: DU/2026/1296 (u.ś.u.d.e. — KOREKTA: nowelizacja z 18.12.2025 nie weszła w życie, DSA wdraża 1296; PrAut, PWP, UOKiK), 1287 (podatki sektorowe, PIT, CIT), 1348 (MONITORING — treść), 1354 (u.p.o.l.), 1358 (Prawo wodne po t.j.).

- 6.67 (2026-10-20, AUDYT-2026-10-20b): ROUTING-MAP: KK — tekst t.j. 1342 opublikowany w ELI; DU/2026/1347 w wierszach PE/URE/OZE, Prawo budowlane, Pzp, PIT; MONITORING: 1347 (etapy do 17.10.2027) i 1348.

- 6.66 (2026-10-19a, AUDYT-2026-10-19a): ROUTING-MAP: KK — t.j. Dz.U. 2026 poz. 1342 (wiersze DR-03, tekst w ELI nieopublikowany — do publikacji 2025/383 + 4 nowelizacje); ⛔ KOREKTA: wiersz KK podawał „zm. 2026.638” — to nowelizacja KPK; Prawo o adwokaturze 1290: ⚡ WCHODZI → W MOCY od 17.10.2026; nowe wiersze ustawy o prawnikach zagranicznych (2020/823 + 1290 art. 2).
- 6.65 (2026-10-17c, AUDYT-2026-10-17c): ROUTING-MAP: rozporządzenie MS w sprawie siedzib i obszarów właściwości sądów powszechnych (t.j. Dz.U. 2026 poz. 492) → DR-12 mod-wlasciwosc-miejscowa-sadow-powszechnych.
- 6.64 (2026-10-17b, AUDYT-2026-10-17b): ROUTING-MAP: ZZ — ⏳ zm. 2026/1340 od 30.10.2026; nowy wiersz ustawy o informowaniu pracowników (2006/550 + 2026/1340); nowy wiersz ustawy o ochronie i pomocy dla pokrzywdzonego i świadka (t.j. 2026/1306). ELI 2026-10-17.
- 6.63 (2026-10-17a, AUDYT-2026-10-17a): ROUTING-MAP: KPW — nowy t.j. Dz.U. 2026 poz. 1336 (obwieszczenie z 2.10.2026, ogłoszone 15.10.2026; stan prawny na 27.09.2026; obejmuje Dz.U. 2025 poz. 1178, 1661, 1814, 1818, 1872 i 2026 poz. 473; brak zmian po t.j. — ELI 2026-10-17) (wiersz KPW i wiersz grzywna/mandat).
- 6.62 (2026-10-15c, AUDYT-2026-10-15c): ROUTING-MAP: t.j. transport kolejowy 2026/1324, Prawo wodne 2026/1335, odpady 2026/1328 (brak zmian po t.j.); ⛔ VAT — 2026/507 art. 6 od 1.11.2028 (było 14.10.2026); nowy wiersz ustawy o CEIDG (t.j. 2026/30, zm. 2026/734, 507); KC ⏳ art. 860 § 3–4 od 1.11.2028; SUS ⏳ 507 art. 5 od 1.11.2028; rynek pracy 507 art. 11 od 14.10.2026. ELI 2026-10-15.

- 6.61 (2026-10-12c, AUDYT-2026-10-12c): ⛔ KOREKTA błędu z 12b: t.j. UPEA Dz.U. 2026 poz. 1311 OBEJMUJE zm. 2026/1003 (obwieszczenie pkt 1 ppkt 3; art. 17 § 1a w dwóch brzmieniach — do 27.10.2026 i od 28.10.2026, odnośniki 13–14); wpisy „⏳ po t.j.: 2026/1003” usunięte. Obwieszczenia 1311 i 1315 odczytane z ELI (text.pdf, 2026-10-12). ROUTING-MAP wiersze UPEA.

- 6.60 (2026-10-12b, AUDYT-2026-10-12b): ROUTING-MAP: UPEA t.j. 2026/1311 (⏳ 2026/1003 od 28.10.2026), ochrona przyrody t.j. 2026/1315; zmiany po t.j. z 2026/815 przy 20 aktach (Policja, SG, ŻW, SOP, obrona Ojczyzny, ochrona ludności, śpbp, ppoż., KSC, PKE, megaustawa, Prawo wodne, odpady, kontrola inwestycji); rzeczy znalezione — 2026/184 (od 19.05.2026, art. 187 KC: 6 miesięcy / rok). ELI 2026-10-12.

- 6.59 (2026-10-11b, AUDYT-2026-10-11a): ROUTING-MAP: nowa sekcja „SKILLE WYKONAWCZE I SHARED — akty powołane poza DR (monitoring t.j.)” — u.k.s.c. (t.j. 2025/1228, zmiany 2026/473, 1003, 346), ZTP (2026/300), Prawo o adwokaturze, ustawa o radcach prawnych, z miejscami powołań; MONITORING: u.k.s.c. 1003 (28.10.2026) i 346 (30.09.2028), adwokatura 1290 (17.10.2026); wiersze DR-12 uzupełnione o zmiany po t.j. (adwokatura +1172, 370, 846; radcy +846). ELI `/references` 2026-10-11.

- 6.58 (2026-10-11a): Routing błyskawiczny DR-02: „umowa najmu na czas określony”, „umowa najmu na czas nieokreślony”. „Napisz umowę najmu mieszkania na czas określony” stawiało DR-04 na pierwszym miejscu: fraza DR-04 „umowa na czas określony” (trzy słowa) przeważała nad „umowa najmu” (dwa). Fraza DR-02 z czterech słów obejmuje najem; pytania o umowę o pracę na czas określony zostają w DR-04. Dokumenty korporacyjne: „uchwała wspólników”, „zgromadzenie wspólników”, „walne zgromadzenie”, „uchwała zarządu” w DR-02 — „Przygotuj uchwałę zgromadzenia wspólników” trafiało do DR-08 (samorząd) przez jednowyrazowe „uchwała”.

- 6.57 (2026-10-10a): Routing błyskawiczny: „egzekucja komornicza”, „zajęcie rachunku”, „zajęcie wynagrodzenia”, „egzekucja z wynagrodzenia”, „kwota wolna od zajęcia” przeniesione z DR-03 do DR-02 (KPC, `mod-KPC-egzekucja-windykacja`), nowe „skarga na czynność komornika”, „powództwo przeciwegzekucyjne”, „zwolnienie spod egzekucji”; „komornik” z DR-03 do DR-12 (`mod-ustawa-komornicy-sadowi-zawod`). DR-03 nie ma treści o egzekucji cywilnej — sprawy komornicze trafiały do prawa karnego (benchmark aplikacji: 1000 kazusów, 2026-10-10).

- 6.56 (2026-10-09h, AUDYT-2026-10-09h): SKILL.md: przykład modułu aktu wskazywał nieistniejący `modules/mod-KP-kodeks-pracy.md` — poprawione na `mod-KP-prawo-pracy.md`.

- 6.55 (2026-10-09g, AUDYT-2026-10-09g): ROUTING-MAP (ELI 2026-10-09, daty z przepisów o wejściu w życie): KSH (+644, ⏳176, ⏳187), lombardowa i kredyt konsumencki (⏳ 1206 art. 21/38 od 11.01.2027 — nie 29.09.2026), antykorupcja (⏳ 1003 art. 118), VAT (⏳ 2026/1270), transport, POŚ, trzeźwość/tytoń (t.j. 2026/1214 obejmuje 2025/427 i 799); ⛔ UPEA bez „2026/532” (Aktywny rodzic), leśna/łowiecka bez „2024/1219” (rozp. MSiT), KSeF 2021/2076 (było 2021/1237), PrEnergetyczne t.j. 2026/43, ustawa o ochronie danych osobowych 2018 — obowiązująca (nie „historyczna”).

- 6.54 (2026-10-09f, AUDYT-2026-10-09f): ROUTING-MAP: ⛔ wiersz „ustawa o zarządzaniu kryzysowym i ochronie ludności — 2024/1907” rozdzielony na dwie ustawy; zarządzanie kryzysowe — nowelizacje po t.j. 815 i 1206 art. 15 (od 11.01.2027); nowy wiersz rozp. w sprawie chorób zawodowych (t.j. 2026/1297); 7 wzmianek historycznych zapisanych jako RRRR/NNNN, żeby indeks RAG nie pobierał wygasłych t.j. ELI 2026-10-09.

- 6.53 (2026-10-09e, AUDYT-2026-10-09e): Routing błyskawiczny DR-01: „Sąd Najwyższy” zastąpione przez „ustawa o Sądzie Najwyższym”, „Izba Kontroli Nadzwyczajnej” — nazwa sądu w pytaniu o orzecznictwo („wyszukaj wyrok SN o grupie przestępczej”) wskazywała DR-01 zamiast dziedziny sprawy (DR-03).

- 6.52 (2026-10-09d, AUDYT-2026-10-09d): Routing błyskawiczny: DR-02 „wspólnota”, „zarząd wspólnoty” (wcześniej trafiało tylko przypadkiem przez rdzeń „wspólnika”), DR-10 „pielęgniarka środowiskowa”, DR-11 „zdjęcie bez zgody”, DR-12 „koszty pozwu”. Treść prawna bez zmian.

- 6.51 (2026-10-09c, AUDYT-2026-10-09c): Routing błyskawiczny — sprawy wielodziedzinowe i najsłabsze DR: DR-05 (Karta Polaka, kurator oświaty, braki wniosku, wszczęcie postępowania administracyjnego, legalizacja pobytu, skarga na bezczynność), DR-09 (linia wysokiego napięcia, koncesja geologiczna, panele fotowoltaiczne, wycięcie drzewa), DR-11 (przejęcie konta, fałszywy profil, chatbot musi informować, przekazanie danych, sprostowanie danych), DR-13 (dostęp służb do danych, billingi, dane telekomunikacyjne), DR-14 (sankcje UE, towary podwójnego zastosowania, uznanie orzeczenia, rozwód za granicą), DR-16 (sprostowanie artykułu, gazeta, wymeldowanie, przegląd/zestawienie orzecznictwa, plan przesłuchania), DR-03 (nadużycie zaufania, korupcja, łapówka, porwanie rodzicielskie). Treść prawna bez zmian.

- 6.50 (2026-10-09b, AUDYT-2026-10-09b): ROUTING-MAP: Prawo o adwokaturze + Dz.U. 2026 poz. 1290 (w życie 17.10.2026); nowy wiersz „ochrona przysługująca funkcjonariuszowi publicznemu — adwokat i radca prawny” → DR-03 mod-KK-art222-226 + DR-12; Routing błyskawiczny DR-12: ochrona adwokata/radcy, adwokat/radca funkcjonariusz publiczny, nowelizacja prawa o adwokaturze, kancelaria adwokacka, tytuł adwokata (pytanie „od kiedy adwokaci mają ochronę funkcjonariuszy” trafiało tylko do DR-13).

- 6.49 (2026-10-09, AUDYT-2026-10-09): ROUTING-MAP: nowe t.j. z ELI (2026-10-09) — KP 2026/1245 (⛔ 2026/1046 od 5.11.2026), VAT 2026/1263 (⛔ 2026/507 od 14.10.2026), prawa konsumenta 2026/1244, mandat posła 2026/1282, świadczenia rodzinne 2026/1240, doradztwo 2026/1274, transport 2026/1231, informatyzacja 2026/1241, dochody JST 2026/1252, KKW 2026/1307, rzeczy znalezione 2023/501, usługi zaufania 2024/1725, Ukraina 2026/1293, ochrona cudzoziemców 2026/862; KOREKTA NATO: Dz.U. 2000 poz. 970; wiersz 2026/1161 z jawnym t.j. PrBud 2026/524 (RAG nadawał nowelizacji etykietę wiersza).

- 6.48 (2026-10-09): Routing błyskawiczny DR-01–DR-16: słownictwo z pytań laików i opisów spraw (m.in. DR-01 kadencja/kontrasygnata, DR-02 dział spadku/sprzeciw od nakazu zapłaty, DR-04 przełożony/szef w pracy, DR-05 zezwolenie na pobyt/decyzja wojewody, DR-15 lista sankcyjna/mapa ryzyk); usunięte frazy zbyt szerokie (darowizna, umowa sprzedaży, kara umowna, nakaz zapłaty, spółka z o.o., skarga do WSA i in.) oraz nazwy tematów bez sprawy (oprogramowanie, TikTok, kurs online, sztuczna inteligencja), które otwierały skille prawne dla pytań nieprawnych. Top-1 DR: kontrolny zestaw 160 pytań 64.4% → 85.0%, 10000 pytań 60.7% → 88.1%, 500 pytań 93.6% → 94.6%.

- 6.47 (2026-10-08): Routing błyskawiczny DR-02: „ojcostwo”, „ustalenie ojcostwa”, „zaprzeczenie ojcostwa”, „upadłość konsumencka”. Pytanie „Ustalenie ojcostwa dziecka po rozstaniu” nie trafiało do żadnej dziedziny: brak słowa w tabeli, a dopasowanie przez mapę aktów DR-02 spadło poniżej progu po dodaniu wierszy PrUp/PrRestr w 6.46.

- 6.46 (2026-10-07f, AUDYT-2026-10-07f): ROUTING-MAP — sekcja „Prawo upadłościowe i restrukturyzacyjne — źródła i procedury” z PR #85 (26 wierszy modułów PrUp/PrRestr); nowy wiersz zmian po t.j. jeszcze nie w życiu: Dz.U. 2026 poz. 1206 (od 11.01.2027) i Dz.U. 2026 poz. 176 (od 18.02.2027), ELI 2026-10-07; licencja doradcy restrukturyzacyjnego — „[sprawdź nowszy t.j.]” zastąpione weryfikacją ELI (2022/1007 najnowszy t.j. dla DU/2007/850, brak późniejszych zmian).

- 6.45 (2026-10-06): nowelizacje po t.j. (ELI 2026-10-06): PRD/u.k.p./drogi publiczne/transport drogowy — Dz.U. 2025 poz. 1676, 1734, 1843; Dz.U. 2026 poz. 180, 982; nowa ustawa o zdrowiu zwierząt Dz.U. 2025 poz. 1795

- 6.44 (2026-10-05p, AUDYT-2026-10-05p): Routing błyskawiczny: DR-03 „podrobić podpis”, „sfałszować”, „pijany kierowca”, „KKS”, „karny skarbowy” (rdzeń „podrobienie” nie łapał „podrobił”); DR-04 „wynagrodzenie”.

- 6.43 (2026-10-05m, AUDYT-2026-10-05m): Routing błyskawiczny: słownictwo obszarów prawa dla DR-01–DR-16 po teście 500 pytań (m.in. DR-01 Sejm/weto/źródła prawa, DR-12 zawody i koszty, DR-14 jurysdykcja/prawo właściwe/za granicą, DR-15 DORA/audyt wewnętrzny, DR-16 prasa/meldunek); DR-01 „wybory” zawężone do wyborów powszechnych, DR-16 bez „orzecznictwo” (orzecznictwo to skill wykonawczy, nie dziedzina).

- 6.42 (2026-10-05l, AUDYT-2026-10-05l): Routing błyskawiczny: słownictwo spraw klientów dla DR-01–DR-16 (m.in. RODO: monitoring wizyjny, IOD, rejestr czynności, powierzenie, wizerunek, spam, cookies, profilowanie; karne: pobicie, kradzież, jazda po alkoholu; praca: mobbing, L4, nadgodziny).

- 6.41 (2026-10-04n, AUDYT-2026-10-04n): Historia zmian SKILL.md i modułów przeniesiona z plików roboczych do `references/HISTORIA-ZMIAN-PLIKOW.md` (plik historyczny, niewczytywany przez model). Treść robocza bez zmian.

- 6.40 (2026-10-04l, AUDYT-2026-10-04l): ROUTING-MAP — wiersz umowy PL–UA o zabezpieczeniu społecznym przeniesiony z sekcji DR-14 do DR-04 (moduł leży w DR-04; T2 check_rejestracja_modulow); w wierszu MRG PL–UA nieaktualne „brak modułu w systemie” zastąpione odesłaniem do modułu DR-04. Bez zmian numerów Dz.U. Pełny opis: `audyt-systemu-v4/references/AUDIT-JOURNAL.md`, AUDYT-2026-10-04l.

- 6.39 (2026-10-04j, AUDYT-2026-10-04j): ROUTING-MAP — (1) wiersz umowy PL–UA o zabezpieczeniu społecznym uzupełniony o instytucje wskazane w porozumieniu administracyjnym Dz.U. 2013 poz. 1375 (ZUS Centrala, KRUS Centrala, MPiPS jako instytucje łącznikowe; ZUS, KRUS i wojewódzkie urzędy pracy jako właściwe; zaświadczenie o ustawodawstwie właściwym z art. 4); (2) wiersz umowy MRG PL–Rosja (Dz.U. 2012 poz. 814) opatrzony znacznikiem weryfikacji i limitem pobytu z art. 4 ust. 1 (30 dni każdorazowo, łącznie 90 dni w 6 miesiącach) — F-233.

- 6.38 (2026-10-04i, AUDYT-2026-10-04i): ROUTING-MAP — (1) nowy wiersz „KK art. 278–295 — przestępstwa przeciwko mieniu" (rozdz. XXXV: kradzież, rozbój, przywłaszczenie, **oszustwo art. 286**, oszustwo komputerowe, zniszczenie mienia, zabór pojazdu, paserstwo, art. 294–295) → `dr-03/modules/mod-KK-art278-295-przestepstwa-przeciwko-mieniu.md`; ⛔ KROK 2C: cztery nowelizacje KK po t.j. (2025/1818, 2025/1872, 2026/902, 2026/988) nie zmieniają art. 278–295 (kontrola krzyżowa dwóch zapisów ELI). (2) Wiersz „KK art. 286 — oszustwo" przekierowany z `mod-KK-KPK-framework-karne.md → ANEKS` na nowy moduł. (3) Wiersz paserstwa/prania zawężony do art. 291–293 i 299. (4) Nowy wiersz „Umowa RP–Ukraina o zabezpieczeniu społecznym" (Dz.U. 2013 poz. 1373) → `dr-04/modules/mod-umowa-PL-UA-zabezpieczenie-spoleczne.md` (F-231). (5) Wiersz MRG PL–UA uzupełniony o zakres zmian Drugiego protokołu (Dz.U. 2016 poz. 664) — w tym aktualny limit pobytu 90 dni każdorazowo (F-232).

- 6.37 (2026-10-04h, AUDYT-2026-10-04h): ROUTING-MAP — trzy wiersze zweryfikowane w ELI (RZĄD 1, 2026-10-04): (1) nowy wiersz „Warunki techniczne budynków — reżim przejściowy” (rozp. WT 2002, Dz.U. 2002 poz. 690 — uznane za uchylone; stosowanie przejściowe wg art. 102a–102c PrBud, Dz.U. 2026 poz. 1161; synchronizacja z DR-09 i mapą centralną); (2) nowy wiersz MRG Polska–Ukraina (Dz.U. 2009 poz. 858; Drugi protokół Dz.U. 2016 poz. 664) — ⛔ numer 2009/858 to umowa o małym ruchu granicznym, NIE o zabezpieczeniu społecznym (ta: Dz.U. 2013 poz. 1373, brak modułu); (3) wiersz refundacji PrFarm: „⚠️ zweryfikuj t.j.” → Prawo farmaceutyczne Dz.U. 2026 poz. 612 t.j. (+ 791, 1004, 1079) i ustawa refundacyjna Dz.U. 2026 poz. 253 t.j. (+ 791). Pełny opis: `audyt-systemu-v4/references/AUDIT-JOURNAL.md`, AUDYT-2026-10-04h.

- 6.36 (2026-10-04g, AUDYT-2026-10-04g): ROUTING-MAP — wiersz KK fałszerstw zawężony do „art. 270-277d, 310” (wg nagłówka modułu DR-03; synchronizacja z DR-03 3.51).

- 6.35 (2026-10-04f, AUDYT-2026-10-04f): ROUTING-MAP (synchronizacja T11): transport drogowy — t.j. Dz.U. 2025 poz. 1490 (było 2024/1539 — nieaktualny t.j.); nowe wiersze: taryfikator mandatów (rozp. PRM z 24.11.2003, t.j. 2013/1624 ze zm.) i ustawa o państwowej kompensacie (t.j. 2016/325); opłaty w sprawach karnych — zakres t.j. 2023/123. Pełny opis: `audyt-systemu-v4/references/AUDIT-JOURNAL.md`, AUDYT-2026-10-04f.

- 6.34 (2026-10-04e, AUDYT-2026-10-04e): **ROUTING-MAP czytelna maszynowo (F-229).** 129 wierszy w 20 segmentach tabel bez nagłówka (oddzielone pustą linią lub `---` od tabeli macierzystej) scalone z tabelami o tej samej liczbie kolumn; 1 wiersz bez wiodącego `|`; 5 wierszy z nadmiarowymi komórkami (komentarz scalony z ostatnią kolumną; 3 komórki Dz.U. w wierszu rolnictwa scalone w jedną) i 1 z brakującą komórką (KPK — kolumna daty). Zbiór odwołań do modułów bez zmian (porównanie przed/po). Elektromobilność: Dz.U. 2026 poz. 1243 t.j. Pełny opis: `audyt-systemu-v4/references/AUDIT-JOURNAL.md`, AUDYT-2026-10-04e.

- 6.33 (2026-10-04, AUDYT-2026-10-04): ROUTING-MAP — nowelizacja Dz.U. 2026 poz. 1161 (RZĄD 1 ELI): wiersz Prawa budowlanego (zmiany po t.j. 605/646/1161; usunięta nieaktualna adnotacja „⚡ pozostaje art. 1 pkt 1 i 3 → wchodzi 20.09.2026” — w mocy), wiersz uzupełnienia PrBud (§ 9a), wiersz samorządów architektów/inżynierów (ze zm. 2026/1161, art. 3–4), wiersz patodeweloperki (rozp. WT z 2002 r. nie obowiązuje od 20.09.2026, F-224); źródło centralne → `mapa_dzu_2026-10-04.md`.

- 6.32 (2026-09-27p, AUDYT-2026-09-27p): ROUTING-MAP: „źródło centralne” wskazywało mapę Dz.U. z 2026-07-15 (nieaktualna); teraz bieżąca generacja audyt-systemu-v4/references/mapa_dzu_2026-09-22.md.

- 6.31 (2026-09-27e, AUDYT-2026-09-27e): claude.ai po dodaniu marketplace instalował wyłącznie 4 z 32 pluginów (shared, prawny-router-v3, analizator-dowodow-v3, przesluchanie-swiadkow-v2-min90); jedyna cecha wspólna tych 4, nieobecna w żadnym z 28 pozostałych, to klucz `dependencies` we frontmatterze SKILL.md. Dodano go (`requires: [shared]` — zgodnie ze stanem faktycznym) oraz jawny manifest pluginu (name, description = description z SKILL.md, author, repository, license) — host nie musi niczego wnioskować z SKILL.md. `version` w manifeście = `version:` z SKILL.md (pilnuje T38 w audyt-systemu-v4) — host rozpoznaje aktualizację po podbiciu wersji. Treść skilla bez zmian.
- 6.30 (2026-09-23, AUDYT-2026-09-23b): Zasady workflow i sekcja Weryfikacja: ISAP → kanon E-1…E-5; ROUTING-MAP: instrukcje „weryfikuj w ISAP” → ELI (RZĄD 1); wpisy historyczne bez zmian.
- 6.29 (2026-09-22, F-195): ROUTING-MAP — wiersz MONITORING Ordynacji podatkowej: zamiast ⬛ sześć nowelizacji po t.j. 2026/622 z terminami z artykułów końcowych (RZĄD 1 ELI): 825 — 24.09.2026, 846 — 1.10.2026, 1154 — 16.09.2026 (w mocy), 875 i 1098 — 1.01.2027, 1206 — 11.01.2027. ⛔ 875, 1098, 1206 nie występowały wcześniej w żadnym rejestrze systemu.
- 6.28 (2026-09-22, F-195): ROUTING-MAP — tabela MONITORING przejrzana przez artykuły końcowe w ELI (RZĄD 1): KPK 2026/638 (w mocy 28.05.2026) i PrBud 2025/1847 art. 1 pkt 1 i 3 (w mocy 20.09.2026) usunięte; wiersz DR-03 KPK 2026.638 uzupełniony o stan; 2026/516 — reszta ustawy od 30.04.2026 (nie 16.04.2026); OP 2026/622 oznaczona ⬛ (t.j., nie nowelizacja; terminy bez źródła). Licznik zbiorczy nieprzeliczany — adnotacja pod licznikiem.
- 6.27 (2026-09-22, F-193): ROUTING-MAP — wiersz ustawy zasiłkowej (t.j. 2026/854): dopisana cezura 1.01.2027 dla art. 17 ust. 1d–1e (L4 z jednego tytułu) i art. 9 ust. 4 wprowadzonych Dz.U. 2026 poz. 26; art. 17 ust. 1–1c od 13.04.2026 (RZĄD 1 ELI, art. 43 ustawy). Kolejność wg reguły użytkownika: mapa zbiorcza przed modułami DR.
- 6.26 (2026-09-16, F-189): ROUTING-MAP — wiersz alkohol/tytoń: t.j. ustawy tytoniowej `2024/1162` → `2026/1214` (ogłoszony 16.09.2026; T15 NEWER_TJ; RZĄD 1).
- 6.25 (2026-09-16, F-189): ROUTING-MAP — ustawa o przeciwdziałaniu przemocy domowej: wygasły t.j. `2021/1249` → `2024/1673` w dwóch wierszach (KK art. 207; przemoc domowa szczegółowo) — RZĄD 1; T27.
- 6.24 (2026-09-16, F-189): ROUTING-MAP — T31 (RZĄD 1): PODMIANY AKTU usunięte w 5 wierszach (UOKiK → 2025/1714; Prawo energetyczne → 2026/43; „Prawo gazowe” → Prawo energetyczne 2026/43; charakterystyka energetyczna → 2024/101; rolnictwo ekologiczne → 2023/1235); nazwy wierszy poprawione (ustawa o zapewnianiu dostępności 2024/1411; PUSP + ustawa o kuratorach sądowych 2026/200); nowy wiersz — ustawa o opłacie skarbowej (2025/1154).
- 6.23 (2026-09-16, F-189): ROUTING-MAP — wiersze F-190: podatek od kopalin → nowy moduł dr-06; poz. 516 → sekcja w dr-09 (pokryte); działalność lecznicza — numer t.j. w modułach dr-10. Znacznik T28-OK przy wierszu dokumentującym podmianę aktu.
- 6.22 (2026-09-16, F-189): ROUTING-MAP — T5 widmowe pokrycie (AUDYT-2026-09-16b), RZĄD 1 ELI: 11 wskaźników przepiętych na moduły z treścią; ⛔ podmiany aktu: podatek od wydobycia kopalin `2024/44` (t.j. ustawy o rehabilitacji) → `2026/454`, `2024/1564` to Prawo o adwokaturze (wiersz łączył ją z zawodami medycznymi); tytuł „ustawa o ubezpieczeniach obowiązkowych lekarzy” → ustawa o ubezpieczeniach obowiązkowych, UFG i PBUK; `2026/638` KPK — w mocy od 28.05.2026; widma oznaczone (kopaliny, `2026/516`).
- 6.21 (2026-09-16, F-189): T12: pole YAML `changelog:` (numer 6.18 przy version 6.20) skrócone do odesłania (ZASADA 15). Treść bez zmian.
- 6.20 (2026-09-13b): ROUTING-MAP — do wierszy PPWR i EUDR dopisane wyniki weryfikacji uzupelniajacej. PPWR: ustawa o gospodarce opakowaniami (Dz.U. 2026 poz. 619 t.j.) NIE ZOSTALA dostosowana - zero nowelizacji po t.j. z 30.04.2026, ostatnia zmiana z 9.01.2026 dotyczy systemu kaucyjnego bez odeslan do rozp. 2025/40; luka w egzekwowaniu, nie w obowiazku. EUDR: przeszukanie ELI po tytule dalo zero polskich aktow - wynik negatywny wylacznie w zakresie tytulu, do monitorowania blizej 30.12.2026
- 6.19 (2026-09-13): ROUTING-MAP — dopisane do sekcji DR-09 dwa ROZPORZADZENIA UE BEZPOSREDNIO STOSOWANE: PPWR (UE) 2025/40, CELEX 32025R0040, stosuje sie od 12.08.2026 (juz obowiazuje), uchyla dyrektywe 94/62/WE; EUDR (UE) 2023/1115, CELEX 32023R1115, wersja skonsolidowana 02023R1115-20251226, data stosowania 30.12.2026 / 30.06.2027 dla mikro i malych przedsiebiorstw. EUDR dopisany takze do tabeli MONITORING jako akt jeszcze niestosowany (⏳ OCZEKUJE) z ostrzezeniem o DWUKROTNYM przesunieciu daty. Zaktualizowany licznik DR-09 (27 -> 29 aktow, razem 31) i slowa kluczowe routingu (9 -> 11). Oba akty ✅ VER RZAD 1 2026-09-13 przez EUR-Lex
- 6.18 (2026-09-10r, O-10): cezury czasowe dla 2026/346 (w zycie 30.09.2028) i zwolnienia grupowe 2025/570 na 2026/1195
- 6.17 (2026-09-10q, F-135): ROUTING-MAP: wiersz KP art. 94 par. 3 opatrzony cezura czasowa reformy antymobbingowej - vacatio legis do 4.11.2026
- 6.16 (2026-09-10o, F-181): ROUTING-MAP: ARiMR 2025/1363 na 2026/942 (RZAD 1)
- 6.15 (2026-09-10j): ROUTING-MAP:685 — nazwa i łańcuch przepisane po wykryciu DWÓCH PODMIAN AKTU (2022/2162 opisane jako nowa ustawa o medycynie laboratoryjnej, a jest t.j. STAREJ ustawy z 2001; 2023/1517 opisane jako stara ustawa, a jest rozporządzeniem MSWiA)
- 6.14 (2026-09-10i): ROUTING-MAP:646 — PODWÓJNY BŁĄD skorygowany: wiersz delegowania kierowców twierdził „brak t.j." i opisywał Dz.U. 2025 poz. 797 jako nowelizację; 2025/797 JEST tekstem jednolitym tej ustawy (✅ RZĄD 1)
- 6.13 (2026-09-10h): ROUTING-MAP: wiersz ustawy refundacyjnej uzupełniony o KROK 2C (Dz.U. 2026 poz. 791) i o wskazanie kanałów wykazu leków refundowanych — wykaz NIE jest aktem Dz.U.
- 6.12 (2026-09-10g): ROUTING-MAP — wiersz „POŚ Szczegóły" rozstrzygnięty; zakres modułu ustalony jako warstwa proceduralna, akty (UOOŚiS 2026/670, POŚ 2025/647, ochrona przyrody 2026/13, KK 2025/383, KPA 2025/1691) zweryfikowane w RZĘDZIE 1 z listami nowelizacji po tekstach jednolitych
- 6.11 (2026-09-10f): ROUTING-MAP: domknięte 13 pozycji oznaczonych do weryfikacji po odczycie RZĄD 1. TRZECI BŁĄD PODMIANY AKTU skorygowany — „ustawa antylichwiarska Dz.U. 2023 poz. 1028" to wygasły t.j. ustawy o KREDYCIE KONSUMENCKIM; poprawnie Dz.U. 2022 poz. 2339. Zamknięty sygnał ❌ NUMER BŁĘDNY przy KPK. Antymobbingowa 2026/1046 podniesiona z RZĘDU 2B do RZĘDU 1. Dopisane listy nowelizacji po tekście jednolitym (KK 4, KPK 5, VAT 5, antykorupcyjna 2, trzeźwość 2, UDIP 1, łowieckie 1, zarządzanie kryzysowe 1)
- 6.10 (2026-09-10e): ROUTING-MAP: +2 wiersze (przekształcenie UW 2005 i 2018) oraz nowa sekcja nagłówkowa KOLEJNOŚĆ AKTUALIZACJI REJESTRÓW — praca idzie od źródła urzędowego przez mapę zbiorczą do modułów DR, przy zachowaniu zakazu traktowania ROUTING-MAP jako źródła weryfikacji (F-141)
- 6.9 (2026-09-10d, F-148a/F-135/F-141): ROUTING-MAP: 9 wierszy rozstrzygniętych w RZĘDZIE 1 (F-135, F-141), 1 błąd podmiany aktu skorygowany (F-148a: ustawa antyterrorystyczna 2024/1474 → 2025/194)
- 6.8 (2026-09-01i, flaga F-155): **propagacja trzech korekt tekstów jednolitych do mapy
  centralnej.** Ustawa o świadczeniu wspierającym: Dz.U. 2023 poz. 1429 → **Dz.U. 2026 poz. 873 t.j.**;
  ustawa o wyrobach medycznych (dwa wiersze, w tym jeden z adnotacją „zweryfikuj t.j. na ISAP"):
  → **Dz.U. 2024 poz. 1620 t.j.**; ustawa „Aktywny Rodzic": zapis „brak dotąd ogłoszonego t.j.,
  cytować jako Dz.U. 2024 poz. 858 ze zm." był NIEAKTUALNY, a poz. **2026.532** figurowała tam
  BŁĘDNIE wśród nowelizacji — to obwieszczenie z 27.03.2026 ogłaszające tekst jednolity
  ✅ [VER: api.sejm.gov.pl/eli, 2026-09-01]. Wykryte przeglądem 16 map w żywym ELI; T3 wyłapał
  rozjazd mapy lokalnej z centralną po poprawieniu map dziedzinowych.
- 6.7 (2026-08-28) — domknięto F-108 do **52/52 B+/COV**: centralny routing wskazuje current-state indeksy KW, SUS, ustawy zasiłkowej i zwolnień grupowych; KW otrzymał także fizyczny moduł brakującego zakresu art. 65–69. `COV` pozostaje rozdzielone od `FULL`, a konkretna jednostka nadal podlega fresh/temporal gate.

- 6.6 — F-108 P1: zarejestrowano osobne moduły UFG/PBUK, opłat w sprawach karnych i fundacji rodzinnej; rozdzielono błędnie połączone metryki KC (Dz.U. 2026 poz. 795) i ustawy UFG/PBUK (Dz.U. 2026 poz. 783). (2026-08-27)

- 6.5 — F-108/46: rejestracja modułu DR-02; historycznych liczników nie przedstawia się jako pomiaru aktualnego pokrycia. (2026-08-27)

- 6.4 (2026-08-26): skorygowano fałszywe metryki PUSA (`2024/1297` →
  `2024/1267`), POŚ (`2026/670`, akt OOŚ → `2025/647` t.j. POŚ), Prawa
  lotniczego i ustawy o timeshare; dodano routing zakresów F-86.
- 6.3 (2026-08-26): zsynchronizowano ROUTING-MAP z aktualnymi tekstami
  jednolitymi i centralną mapą Dz.U.; usunięto luki wykryte przez T11.

> Lokalizacja kanoniczna historii wersji tego skilla (ZASADA 15 w
> `audyt-systemu-v4/SKILL.md`). Plik założony 2026-08-23g przy okazji naprawy
> F-123 — skill był na wersji 6.1 bez żadnego pliku historii i bez pola
> `changelog:` w YAML.
>
> ⛔ **LUKA JAWNA — wersje 1.x–6.1 NIE zostały odtworzone.** Nie ma ich w żadnym
> pliku tego skilla; jedynym śladem jest `audyt-systemu-v4/references/AUDIT-JOURNAL.md`.
> Odtwarzanie ich z pamięci byłoby zmyślaniem — dokładnie ten błąd, który w sesji
> 2026-08-20z3 (F-102) groził dopisaniem pięciu nieistniejących wpisów do
> `pisma-procesowe-v3`. Kto potrzebuje historii sprzed 6.2: `grep -n "prawo-polskie-v2"
> audyt-systemu-v4/references/AUDIT-JOURNAL.md`.

- 6.2 (2026-08-23g, sesja audytowa audyt-systemu-v4, flaga F-123): zapisana
  DECYZJA o zakresie `shared/PRAWO-HARDGATE.md` w tym skillu. Rozstrzygnięcie
  rozdzielne: `SKILL.md` — bramka NIE obowiązuje (czysta fasada routingu, nie
  twierdzi nic o treści prawa, bramka odpala się w DR-skillu, w którym przepis
  faktycznie pada); `ROUTING-MAP.md` — podlega reżimowi mapy (FAZA 3 A–D +
  ZASADA 8 + REGUŁA 3), bo nosi numery i statusy Dz.U., czyli weryfikowalne
  twierdzenia o stanie prawnym, a błędny numer propaguje się w każdą sprawę
  przechodzącą przez ten routing (klasa F-82). Dopisany wyzwalacz wygaśnięcia
  decyzji: pierwsze twierdzenie o TREŚCI prawa w którymkolwiek pliku skilla
  przywraca obowiązek bramki. Powód zapisania decyzji, a nie samego jej
  podjęcia: bez utrwalenia ten sam pomiar `grep` wracałby jako nowe zgłoszenie
  w każdym kolejnym audycie. Przy okazji: stopka przestała nieść własny numer
  wersji (niosła „5.2" przy `version: 6.1` — rozjazd o dziewięć wersji),
  zgodnie z decyzją generalną F-102(C); `version` ujęty w cudzysłów
  (profilaktyka pułapki float, F-102(B)). Pełny opis:
  `audyt-systemu-v4/references/AUDIT-JOURNAL.md`, wpis AUDYT-2026-08-23g.

## 2026-10-04 — pełny korpus PrUp + PrRestr

Pełne źródła obu ustaw (603 + 407 nagłówków), metryki, 11 aktów pomocniczych,
czytniki, kontrola dat, rejestr jednostek i routing. Dodano 11 modułów;
przepisano nieaktualne moduły układu, układu częściowego, organów i wierzycieli.
Skorygowano reguły reformy 2025/1085, przyszłe brzmienie art. 156 PrRestr,
odesłanie art. 266f PrUp i pozostałości dawnej upadłości układowej.
Testy techniczne nie stanowią niezależnego audytu każdej wykładni.
