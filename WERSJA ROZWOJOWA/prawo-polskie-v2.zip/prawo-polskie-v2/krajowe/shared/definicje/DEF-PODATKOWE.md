# prawo-polskie-v2/krajowe/shared/definicje/DEF-PODATKOWE.md
## prawo-polskie-v2/krajowe/shared/definicje/ · Definicje podatkowe — ustawowe i ministerialne

> Wydzielony z DEFINICJE-KLUCZOWE.md (Blok G + H.3).
> Główne zastosowanie: **DR-06** (podatki/finanse publiczne/AML).
> Powiązane rekordy ORKA: BAS-074, BAS-099, BAS-100, BAS-104, BAS-W06-W08, BAS-W14.

## ⛔ HARD GATE — ZAKAZ CYTOWANIA Z PAMIĘCI

**PRZED każdym powołaniem definicji, artykułu lub Dz.U.:**
1. Zweryfikuj aktualny tekst jednolity w `ELI (RZĄD 1)`
2. Definicje ulegają zmianie nowelizacjami — NIE cytuj z pamięci modelu.

---

## BLOK G — DEFINICJE PODATKOWE

```
PRZYCHÓD (art. 11 ust. 1 PIT / art. 12 ust. 1 CIT — weryfikuj w ELI (RZĄD 1)):
  = "Przychodami są otrzymane lub postawione do dyspozycji podatnika pieniądze
  i wartości pieniężne oraz wartość otrzymanych świadczeń w naturze
  i innych nieodpłatnych świadczeń"
  → PIT: ELI (RZĄD 1) → ustawa o PIT Dz.U. 2026 poz. 592 t.j. art. 11
    (⚠️ POPRAWIONE 2026-08-08: poprzednio "2024 poz. 226" — TEN numer
    JEST PRZESTARZAŁY, od tego czasu ogłoszono JESZCZE DWA kolejne
    teksty jednolite [2025 poz. 163, oraz aktualny 2026 poz. 592 z
    17.04.2026] — potwierdzone bezpośrednio ISAP [Rząd 1] — PIT
    jest NOWELIZOWANY BARDZO CZĘSTO, sprawdzaj numer t.j. PRZY
    KAŻDYM użyciu, NIE ufaj numerowi starszemu niż kilka miesięcy)

KOSZT UZYSKANIA PRZYCHODU (art. 22 ust. 1 PIT / art. 15 ust. 1 CIT — weryfikuj):
  = koszty poniesione w celu osiągnięcia przychodów lub zachowania/zabezpieczenia
  ich źródła, z wyłączeniem kosztów wymienionych w art. 23 PIT / art. 16 CIT
  Warunek: racjonalność + związek z przychodem

REZYDENT PODATKOWY (art. 3 PIT — weryfikuj):
  Polska rezydencja: centrum interesów osobistych lub gosp. w PL LUB przebywanie
  w PL przez >183 dni w roku podatkowym
  → nieograniczony obowiązek podatkowy
  → ograniczony: tylko przychody ze źródeł w Polsce
  → web_search: "rezydent podatkowy Polska art 3 PIT 2025 centrum interesów"

DZIAŁALNOŚĆ GOSPODARCZA (podatki — art. 5a pkt 6 PIT — weryfikuj):
  = działalność zarobkowa: wytwórcza, budowlana, handlowa, usługowa,
  polegająca na poszukiwaniu/rozpoznaniu/wydobywaniu kopalin, na wykorzystaniu
  rzeczy i wartości niematerialnych, prowadzona we własnym imieniu,
  bez względu na rezultat, w sposób ZORGANIZOWANY I CIĄGŁY
```

---

## WERYFIKACJA DEFINICJI

```
Obowiązkowe przed każdym powołaniem:
  1. ELI (RZĄD 1) → aktualny t.j. ustawy → konkretny art.
  2. Jeśli zmieniła się definicja (nowelizacja) → weryfikuj datę zmiany i datę sprawy
  3. Dla terminów: sprawdź czy ZAWITY czy PRZEDAWNIENIA (różne skutki!)

Źródła urzędowych wyjaśnień i interpelacji:
  pip.gov.pl/porady-prawne — prawo pracy (państwowy organ kontroli)
  biznes.gov.pl — definicje dla przedsiębiorców
  podatki.gov.pl — definicje podatkowe i interpretacje
  uokik.gov.pl — definicje konsumenckie i antymonopolowe
  sejm.gov.pl/Sejm10.nsf — interpelacje X kadencji (2023–)
  orka2.sejm.gov.pl — archiwalne kadencje (dostęp przez wyszukiwarkę)
```

---

*DEFINICJE-KLUCZOWE.md · shared/ · Analizator Prawa Polskiego*
*Weryfikacja źródeł: KC Dz.U. 2026 poz. 795 · KP Dz.U. 2025 poz. 277 · Prawo przedsiębiorców Dz.U. 2026 poz. 1484 t.j.*
*Interpelacje: pip.gov.pl · biznes.gov.pl · gov.pl · sejm.gov.pl*
*Data weryfikacji: 2026-06-09 · Weryfikuj ZAWSZE przed powołaniem w ELI (RZĄD 1)*

---


---

## H.3 PODATKI — DEFINICJE I WYKŁADNIA INTERP. (orka2.sejm.gov.pl)

### H.3 PODATKI — DEFINICJE I WYKŁADNIA INTERP. (orka2.sejm.gov.pl)

#### H.3.1 Dochód, przychód, koszty — wykładnia MF (IZ6.nsf, INT7.nsf)

```
PRZYCHÓD vs DOCHÓD (wyjaśnienie IZ6.nsf/6A0E7E37 — MF):
  Przychód = wartość uzyskana przez podatnika
  Dochód = przychód pomniejszony o koszty uzyskania przychodów
  Obliczanie podatku: od DOCHODU (nie przychodu) przy zasadach ogólnych

KOSZTY PRZY UMOWIE ZLECENIA I O DZIEŁO:
  KUP = 20% przychodu pomniejszonego o składki ZUS potrącone przez płatnika
  Podstawa: art. 22 ust. 9 pkt 4 ustawy PIT
  → Weryfikuj aktualne stawki: ELI (RZĄD 1) → PIT Dz.U. 2026 poz. 592 art. 22 (⚠️ zob. korekta wyżej — numer 2024 poz. 226 nieaktualny)

ZALICZKA NA PODATEK:
  Przy stosunku pracy: pobiera PŁATNIK (pracodawca), art. 31 PIT
  Przy umowie zlecenia: tylko gdy zleceniodawca jest osobą fizyczną prowadzącą DG,
    osobą prawną lub inną jednostką organizacyjną, art. 41 ust. 1 PIT
  Termin przekazania: do 20. dnia miesiąca następnego

RYCZAŁT — szczególna sytuacja (IZ4.nsf/1D1D3180 — MF):
  Przy ryczałcie od przychodów ewidencjonowanych: podstawa = PRZYCHÓD (bez KUP)
  → Niemożliwe dokładne ustalenie dochodu
  → Dla celów świadczeń rodzinnych: dochód deklarowany w oświadczeniu
  → Próg ochronny: dochód nie niższy niż 6× (podatek + składka zdrowotna)
```

#### H.3.2 Koszty uzyskania — zakłady pracy chronionej (IZ6.nsf/2592F9C1 — MF)

```
ZALICZANIE DO KUP ZWOLNIEŃ PODATKOWYCH ZPChr (interpretacja ogólna MF):
  Numer: DD6/8213/165/KWW/09/BMI9/11871
  Kwota wynagrodzenia brutto pomniejszana jest o zaliczkę na podatek dochodowy
  → Kosztem podatkowym = CAŁA kwota wynagrodzenia (od której obliczana jest zaliczka)
  Podatnicy zwolnieni od podatku od nieruchomości: wykazują dane w formularzu ZN-1B
    (nie podaje się wysokości podatku od zwalnianych przedmiotów)
  → Weryfikuj status interpretacji: podatki.gov.pl/interpretacje
```

---


---
*prawo-polskie-v2/krajowe/shared/definicje/DEF-PODATKOWE.md · prawo-polskie-v2/krajowe/shared/definicje/ · 2026-06-12*
*Wydzielono z DEFINICJE-KLUCZOWE.md (Blok G + H.3)*
