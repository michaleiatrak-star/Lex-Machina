# prawo-polskie-v2/krajowe/shared/definicje/DEF-PROCEDURA.md
## prawo-polskie-v2/krajowe/shared/definicje/ · Terminy procesowe, strona postępowania

> Wydzielony i SCALONY z DEFINICJE-KLUCZOWE.md (E.1-E.2) + ORKA-BAS-LEKSYKON.md
> (BAS-W27, usunięty jako duplikat — patrz stub w ORKA).
> Główne zastosowanie: **DR-02/DR-03/DR-05/DR-16** (każde pismo procesowe —
> KRYTYCZNE rozróżnienie terminów).
>
> PATRZ TEŻ: `shared/ORKA-BAS-LEKSYKON.md` BAS-W32 — KONKRETNE terminy
> przedawnienia cywilnego (6 lat ogólny, 3 lata B2B, terminy szczególne)
> + odrębny reżim przedawnienia podatkowego. Ten plik opisuje KATEGORIE
> terminów (czym przedawnienie różni się od zawitego/instrukcyjnego),
> BAS-W32 opisuje WARTOŚCI konkretnych terminów.

## ⛔ HARD GATE — ZAKAZ CYTOWANIA Z PAMIĘCI

**PRZED każdym powołaniem definicji, artykułu lub Dz.U.:**
1. Zweryfikuj aktualny tekst jednolity w `ELI (RZĄD 1)`
2. Definicje ulegają zmianie nowelizacjami — NIE cytuj z pamięci modelu.

---

## TERMIN ZAWITY vs PRZEDAWNIENIA vs INSTRUKCYJNY (wersja scalona, BAS-W27)

```
Weryfikacja: KC art. 117–125 (przedawnienie), KPC art. 168–172 (przywrócenie),
  KPK art. 122–127, KPA art. 58–59

TRZY FUNDAMENTALNIE RÓŻNE INSTYTUCJE — najczęstszy błąd prawnika:

  TERMIN PRZEDAWNIENIA:
  → Upływ = roszczenie staje się NIEZUPEŁNYM (naturalnym)
  → Dłużnik MOŻE uchylić się od zaspokojenia (zarzut przedawnienia)
  → ALE: roszczenie NIE wygasa — bez zarzutu dłużnik nadal zobowiązany
  → Sąd nie bierze pod uwagę z URZĘDU (w sprawach między przedsiębiorcami)
  → Można go zawiesić, przerwać (art. 121–124 KC)
  → Terminy: ogólny 6 lat; świadczenia okresowe/DG → 3 lata (art. 118 KC)
  → Bieg: od wymagalności roszczenia

  TERMIN ZAWITY (prekluzyjny):
  → Upływ = prawo/uprawnienie WYGASA z mocy prawa
  → Sąd bierze pod uwagę z URZĘDU (bez zarzutu strony!)
  → NIE można go zawiesić ani przerwać (wyjątki: wyraźne w ustawie)
  → Nie podlega przywróceniu na zasadach ogólnych KPC
  → Przykłady zawite w KC: art. 568 §1 (rękojmia — 2 lata)
  → Przykłady w KPA: art. 129 § 2 KPA — odwołanie (14 dni); art. 141 § 2 — zażalenie (7 dni)
    ⛔ KOREKTA 2026-09-16m: poprzednio „art. 128 KPA — odwołanie" (art. 128 dotyczy treści
    odwołania) i „art. 33 UPEA — zarzuty 7 dni" (taki termin nie istnieje — terminy
    końcowe z art. 33 § 5 UPEA; patrz `prawo-polskie-v2/krajowe/shared/terminy.md`, UPEA) — ✅ [VER] RZĄD 1 2026-09-16m
  → Przykłady zawite w KPK: zażalenia, apelacje (14 dni od doręczenia)

  TERMIN INSTRUKCYJNY (porządkowy):
  → Upływ = czynność NADAL SKUTECZNA; brak sankcji materialnych
  → Naruszenie = możliwa odpowiedzialność dyscyplinarna organu; kara porządkowa
  → Przykłady: art. 35 KPA — załatwienie sprawy w 1 mies./2 mies.
  → Przekroczenie → zażalenie na bezczynność (art. 37 KPA)

TABELA RÓŻNIC:
  Cecha              | Przedawnienie | Zawity    | Instrukcyjny
  -------------------|---------------|-----------|---------------
  Skutek upływu      | Niezupełność  | Wygaśnięcie| Brak
  Uwzgl. z urzędu    | NIE (co do zasady)| TAK   | —
  Przerwa/zawieszenie| TAK           | NIE       | —
  Przywrócenie       | —             | Wyjątki   | —

REGUŁA PRAKTYCZNA: przed każdym terminem prawniczym ustal jego CHARAKTER
  — mylenie zawitego z instrukcyjnym = katastrofalne (utrata prawa);
  mylenie zawitego z przedawnieniem = podniesiony z urzędu i oddalenie powództwa
```

---

### E.2 STRONA POSTĘPOWANIA / UCZESTNIK

```
STRONA (art. 28 KPA):
  = każdy czyjego interesu prawnego lub obowiązku dotyczy postępowanie
    albo kto żąda czynności organu ze względu na swój interes prawny lub obowiązek
  Interes prawny ≠ faktyczny (musi wynikać z normy prawnej)

UCZESTNIK NA PRAWACH STRONY:
  Organizacja społeczna, RPO, prokurator — gdy przemawia interes publiczny/jednostki

PEŁNOMOCNIK (art. 32–33 KPA):
  Strona może działać przez pełnomocnika (pisemne/ustne do protokołu)
  Adwokat/radca: zawodowy pełnomocnik
  Bliski krewny: bez pełnomocnictwa
```


---
*prawo-polskie-v2/krajowe/shared/definicje/DEF-PROCEDURA.md · prawo-polskie-v2/krajowe/shared/definicje/ · 2026-06-12*
*Scalono: DEFINICJE-KLUCZOWE.md Blok E.1-E.2 + ORKA-BAS-LEKSYKON.md BAS-W27*
