# DR-02 — Lokalna Mapa Aktów Prawnych

## Prawo cywilne, rodzinne i gospodarcze

Mapa runtime zawiera wyłącznie bieżące przypisanie **akt / zakres → moduł**. Historia napraw, poprzednie metryki, zamknięte flagi i opisy sesji audytowych pozostają poza runtime.

### Kodeks cywilny i KPC

**KC:** Dz.U. 2026 poz. 795 t.j. ze zm.; ⏳ 2026/507 art. 2 (dodany art. 860 § 3–4 — umowa spółki cywilnej i inne czynności na wzorach w systemie CEIDG) od 1.11.2028 — brzmienie zawarte już w t.j. 2026/795; do tej daty NIE stosować (✅ [VER] RZĄD 1 2026-10-15, ELI)  
**KPC:** Dz.U. 2026 poz. 468 t.j. ze zm.

| Zakres | Moduł / routing | Status runtime |
|---|---|---|
| KC — indeks current-state całego kodeksu | `mod-KC-current-state-COV.md` | 🟢 B+/COV |
| KC — zobowiązania / odpowiedzialność | `mod-KC-cywilne-zobowiazania-odpowiedzialnosc` | ✅ aktywny; fresh gate |
| KC — konsumenckie | `mod-KC-konsumenckie` | ✅ aktywny; fresh gate |
| KC — spadki, część główna | `mod-KC-spadki` | ✅ aktywny |
| KC — zachowek / dział / rozrządzenia | `mod-KC-spadki-zachowek-dzial-rozrzadzenia` | ✅ aktywny |
| KC — długi spadkowe / umowy / transgraniczne | `mod-KC-spadki-dlugi-umowy-transgraniczne` | ✅ aktywny; fresh gate UE |
| KC — ubezpieczenia | `mod-KC-ubezpieczenia` | ✅ aktywny |
| KC — kredyty frankowe / abuzywność | `mod-KC-kredyty-frankowe` | ✅ aktywny; fresh gate |
| Rzeczy znalezione / zasiedzenie | `mod-rzeczy-znalezione-zasiedzenie` | ✅ aktywny |
| Odpowiedzialność za zwierzę / droga rowerowa | `mod-pies-droga-rowerowa-odpowiedzialnosc.md` | ✅ aktywny; fresh gate |
| KP art. 94³ — mobbing / dyskryminacja (routing przekrojowy) | `mod-KP-art943-mobbing-dyskryminacja` | ✅ aktywny; fresh gate |
| KPC — indeks current-state całego kodeksu | `mod-KPC-current-state-COV.md` | 🟢 B+/COV |
| KPC — art. 162, zastrzeżenie do protokołu | `mod-KPC-art162-zastrzezenie-protokol` | ✅ aktywny; fresh gate |
| KPC — egzekucja / windykacja | `mod-KPC-egzekucja-windykacja` | ✅ aktywny |
| KPC — prawomocność / granice apelacji | `mod-KPC-prawomocnosc-granice-apelacji` | ✅ aktywny |
| KPC — nieproces, część ogólna | `mod-KPC-nieproces-czesc-ogolna` | ✅ aktywny |
| KPC — uzupełnienie pokrycia | `mod-KPC-uzupelnienie-pokrycia-2026` | 🟡 B+ |
| Pełnomocnicy / aplikanci / skład sądu | `mod-liczba-pelnomocnikow-strona-samodzielna.md` + `mod-sklad-sadu-liczba-sedziow.md` | ✅ aktywny; fresh gate |

### Rodzina i piecza

| Akt / zakres | Bieżąca podstawa | Moduł / routing | Status runtime |
|---|---|---|---|
| Kodeks rodzinny i opiekuńczy — rozwód, separacja, alimenty, władza rodzicielska, kontakty z dzieckiem | Dz.U. 2026 poz. 236 t.j. ze zm. | `mod-KRO-rodzinne` | 🟢 B+/COV |
| KRO — zawarcie małżeństwa / bigamia / transgraniczne | jw. + właściwe prawo międzynarodowe | `mod-KRO-zawarcie-malzenstwa-bigamia-transgraniczne` | ✅ aktywny; fresh gate |
| KRO — przysposobienie | jw. + Konwencja haska 1993 | `mod-KRO-przysposobienie-adopcja-miedzynarodowa` | ✅ aktywny |
| KRO — opieka i kuratela | jw. | `mod-KRO-opieka-i-kuratela` | ✅ aktywny |
| Ubezwłasnowolnienie / opieka / kuratela | KC/KRO/KPC jw. | `mod-ubezwlasnowolnienie-opieka-kuratela` | ✅ aktywny |
| OZSS | Dz.U. 2018 poz. 708 t.j. ze zm. | `mod-KRO-rodzinne` | ✅ aktywny |
| Piecza zastępcza | Dz.U. 2026 poz. 980 t.j. ze zm. | `mod-piecza-zastepcza-rodzina-zastepcza` | ✅ aktywny |

### Spółki, przedsiębiorcy, restrukturyzacja i rejestry

| Akt / zakres | Bieżąca podstawa | Moduł / routing | Status runtime |
|---|---|---|---|
| Kodeks spółek handlowych | Dz.U. 2024 poz. 18 t.j. ze zm. | `mod-KSH-spolki-handlowe` | ✅ aktywny; fresh gate |
| KSH — wrogie przejęcie / obrona | jw. | `mod-KSH-wrogie-przejecie-obrona-bialy-rycerz` | ✅ aktywny |
| KSH — uzupełnienie pokrycia | jw. | `mod-KSH-uzupelnienie-pokrycia-2026` | 🟡 B |
| KSH — organy sp. z o.o. | jw. | `mod-KSH-organy-spolki-zoo` | ✅ aktywny |
| KSH — spółki osobowe / rada nadzorcza | jw. | `mod-KSH-spolki-osobowe-rada-nadzorcza` | ✅ aktywny |
| Prawo przedsiębiorców — current-state | Dz.U. 2025 poz. 1480 t.j. ze zm. (m.in. 2026/507 art. 7 — w życie 14.10.2026) | `mod-Prawo-przedsiebiorcow-current-state-COV.md` + `mod-prawo-przedsiebiorcow` | 🟢 B+/COV |
| Prawo przedsiębiorców — kontrola / koncesje + weksle | jw. + akty wekslowe | `mod-wekslowe-kontrola-przedsiebiorcy-koncesje` | ✅ aktywny |
| Ustawa o CEIDG i Punkcie Informacji dla Przedsiębiorcy | Dz.U. 2026 poz. 30 t.j.; zm. po t.j.: 2026/734 (od 20.06.2026), 2026/507 — etapami: 21.04.2026 (art. 1 pkt 2 lit. a, pkt 46, pkt 53 w zakresie art. 64 ust. 2), 14.10.2026 (zasadnicza część), 1.11.2026 (art. 1 pkt 4 lit. a tiret pierwsze, pkt 43 lit. a), ⏳ 1.11.2028 (m.in. publikacja informacji o spółce cywilnej, art. 42a–42b) ✅ [VER] RZĄD 1 2026-10-15 (ELI) | `mod-prawo-przedsiebiorcow` (routing CEIDG) | ✅ aktywny; fresh gate |
| KRS | Dz.U. 2025 poz. 869 t.j. ze zm. | `mod-ustawa-KRS-rejestr-sadowy` | 🟢 B+/COV |
| UZNK | Dz.U. 2026 poz. 85 t.j. ze zm. | `mod-ustawa-UZNK-nieuczciwa-konkurencja` | ✅ aktywny |
| Prawo upadłościowe | Dz.U. 2026 poz. 913 t.j. ze zm. | `mod-PrUpad-upadlosc-restrukturyzacja` + rodzina PrUp | ✅ aktywny; fresh gate |
| PrUp — Pełny tekst PrUp, wersje czasowe, indeks artykułów i odczyt ELI | Dz.U. 2026 poz. 913; 2026/1206: zmiana art. 452 i 456 od 11.01.2027 | `mod-PrUpad-zrodla-i-wersje` | źródło pełne / workflow B; fresh gate |
| PrUp — Zgłoszenia, braki, zwrot, sprawdzanie, lista i sprzeciw | Dz.U. 2026 poz. 913; 2026/1206: zmiana art. 452 i 456 od 11.01.2027 | `mod-PrUpad-wierzytelnosci-235-266` | ✅ A / COV-ART (każdy aktywny artykuł omówiony); fresh gate |
| PrUp — Fundusze masy, kategorie, zabezpieczenia i plan podziału | Dz.U. 2026 poz. 913; 2026/1206: zmiana art. 452 i 456 od 11.01.2027 | `mod-PrUpad-podzial-335-360` | ✅ A / COV-ART (każdy aktywny artykuł omówiony); fresh gate |
| PrUp — Czynności syndyka, wynagrodzenie, sprawozdania, plan i sprzedaż | Dz.U. 2026 poz. 913; 2026/1206: zmiana art. 452 i 456 od 11.01.2027 | `mod-PrUpad-syndyk-likwidacja` | ✅ A / COV-ART (każdy aktywny artykuł omówiony); fresh gate |
| PrUp — Upadłość konsumencka osoby fizycznej (oddłużenie): tryby konsumenckie, wyłączenia części pierwszej i plan spłaty | Dz.U. 2026 poz. 913; 2026/1206: zmiana art. 452 i 456 od 11.01.2027 | `mod-PrUpad-konsument-workflow` | ✅ A / COV-ART (każdy aktywny artykuł omówiony); fresh gate |
| PrUp — układ w postępowaniu upadłościowym (art. 266a–266f) | jw. | `mod-PrUpad-uklad-likwidacja-zakonczenie` | ✅ A / COV-ART (każdy aktywny artykuł omówiony); fresh gate |
| PrUp — postępowanie międzynarodowe, po śmierci dłużnika, deweloper (art. 378–425s) | jw. | `mod-PrUpad-likwidacja-miedzynarodowe-szczegolne` | ✅ A / COV-ART (każdy aktywny artykuł omówiony); fresh gate |
| PrUp — postępowania odrębne: banki, SKOK, banki hipoteczne, instytucje EOG, ubezpieczyciele, obligacje, układ konsumencki (art. 426–491, 491²⁵–491³⁸) | jw. | `mod-PrUpad-postepowania-odrebne-426-491-38` | ✅ A / COV-ART (każdy aktywny artykuł omówiony); fresh gate |
| PrUp + PrRestr — wspólna nawigacja i status pokrycia (wszystkie moduły A) | PrUp jw. + PrRestr Dz.U. 2026 poz. 533 t.j. ze zm. | `mod-PrUp-PrRestr-uzupelnienie-pokrycia-2026` | ✅ hub nawigacyjny; fresh gate |
| Prawo restrukturyzacyjne — układ | Dz.U. 2026 poz. 533 t.j. ze zm. | `mod-PrRestr-dzial-VI-uklad` | ✅ A / COV-ART (każdy aktywny artykuł omówiony); fresh gate |
| PrRestr — układ częściowy | jw. | `mod-PrRestr-dzial-VII-uklad-czesciowy` | ✅ A / COV-ART (każdy aktywny artykuł omówiony); fresh gate |
| PrRestr — nadzorca / zarządca | jw. | `mod-PrRestr-dzial-III-nadzorca-zarzadca` | ✅ A / COV-ART (każdy aktywny artykuł omówiony); fresh gate |
| PrRestr — uczestnicy / wierzyciele | jw. | `mod-PrRestr-dzial-IV-uczestnicy-wierzyciele` | ✅ A / COV-ART (każdy aktywny artykuł omówiony); fresh gate |
| PrRestr — pomoc publiczna | jw. | `mod-PrRestr-dzial-V-pomoc-publiczna` | ✅ A / COV-ART (każdy aktywny artykuł omówiony); fresh gate |
| Pomoc publiczna na ratowanie / restrukturyzację | Dz.U. 2026 poz. 113 t.j. ze zm. | `mod-ustawa-pomoc-ratowanie-restrukturyzacja-przedsiebiorcow` | ✅ aktywny |
| PrUp i PrRestr — zmiany po t.j. (jeszcze nie w życiu) | Dz.U. 2026 poz. 1206 (od 11.01.2027: PrUp art. 452 ust. 1, 456 ust. 1; PrRestr art. 4 ust. 2 pkt 4); Dz.U. 2026 poz. 176 (od 18.02.2027: PrRestr art. 156 ust. 5 pkt 4 uchylony) | `mod-PrUpad-zrodla-i-wersje`, `mod-PrRestr-zrodla-i-wersje` | ⏳ temporal gate: przed datą wejścia stosuj brzmienie z t.j.; ELI 2026-10-07 |
| Doradca restrukturyzacyjny | Dz.U. 2022 poz. 1007 t.j. ze zm. | `mod-ustawa-doradca-restrukturyzacyjny-zawod` | ✅ aktywny |
| Ustawa o zasadach uczestnictwa przedsiębiorców zagranicznych i innych osób zagranicznych w obrocie gospodarczym na terytorium RP (oddziały, przedstawicielstwa) | Dz.U. 2026 poz. 1313 t.j. ✅ [VER: ELI DU/2026/1313 text.pdf, RZĄD 1, 2026-10-20] | `mod-ustawa-przedsiebiorcy-zagraniczni-oddzialy-przedstawicielstwa` | ✅ NOWY 2026-10-20 |

### Konsument, nieruchomości, spółdzielczość i instrumenty

| Akt / zakres | Bieżąca podstawa | Moduł / routing | Status runtime |
|---|---|---|---|
| Prawa konsumenta | Dz.U. 2026 poz. 1244 t.j. ze zm. | `mod-ustawa-prawa-konsumenta` | 🟢 B+/COV |
| UOKiK | Dz.U. 2025 poz. 1714 t.j. ze zm. (m.in. 2026/1296 art. 6 — Prezes UOKiK organem DSA, art. 29 ust. 2b, od 6.11.2026) | `mod-ustawa-UOKIK-antymonopolowe` | 🟢 B+/COV |
| Kredyt konsumencki / SKD | Dz.U. 2025 poz. 1362 t.j. ze zm. | `mod-ustawa-kredyt-konsumencki-SKD` | ✅ aktywny; fresh gate |
| Parabanki / lombardy / lichwa | KC/KK + ustawa lombardowa Dz.U. 2024 poz. 1111 t.j. ze zm. + akty szczególne | `mod-parabanki-chwilowki-lombardy-lichwa.md` | ✅ aktywny; fresh gate |
| Reklama wobec nieletnich | UPNPR Dz.U. 2023 poz. 845 t.j. + ustawa o radiofonii i telewizji Dz.U. 2022 poz. 1722 t.j. ze zm. | `mod-reklama-wobec-nieletnich` | ✅ aktywny; fresh gate |
| Ochrona praw lokatorów | Dz.U. 2023 poz. 725 t.j. ze zm. | `mod-ustawa-ochrona-praw-lokatorow-najem-eksmisja` | 🟢 B+/COV |
| Kaucja przy najmie lokalu | ustawa o ochronie praw lokatorów — aktualne brzmienie na dzień sprawy | `mod-kaucja-najem-lokalu` | ✅ aktywny; fresh gate |
| Ustawa deweloperska / ochrona nabywcy | właściwe aktualne brzmienie ustawy deweloperskiej | `mod-ustawa-deweloperska` | ✅ aktywny; fresh gate |
| Własność lokali | Dz.U. 2026 poz. 232 t.j. ze zm. | `mod-ustawa-spoldzielnie-wlasnosc-lokali` | 🟢 B+/COV |
| Księgi wieczyste i hipoteka | Dz.U. 2026 poz. 1066 t.j. ze zm. | `mod-KW-ksiega-wieczysta-zakup-nieruchomosci` | 🟢 B+/COV |
| Prawo spółdzielcze | Dz.U. 2026 poz. 521 t.j. ze zm. | `mod-prawo-spoldzielcze` | 🟢 B+/COV |
| Spółdzielnie mieszkaniowe | Dz.U. 2026 poz. 889 t.j. ze zm. | `mod-ustawa-spoldzielnie-mieszkaniowe` | 🟢 B+/COV |
| Fundacje / stowarzyszenia | właściwe aktualne ustawy | `mod-ustawa-fundacje-stowarzyszenia` | 🟢 B+/COV; fresh gate |
| Fundacja rodzinna | Dz.U. 2023 poz. 326 ze zm. | `mod-ustawa-fundacja-rodzinna` | 🟢 B+/COV |
| Prawo wekslowe + Prawo czekowe | Dz.U. 2022 poz. 282 t.j. + Dz.U. 2016 poz. 462 t.j. | `mod-prawo-wekslowe-czekowe` | 🟢 B+/COV |
| Timeshare + zastaw rejestrowy | ustawa o timeshare: Dz.U. 2011 nr 230 poz. 1370 ze zm.; zastaw: Dz.U. 2018 poz. 2017 t.j. ze zm. | `mod-ustawa-timeshare-zastaw-rejestrowy` + `mod-ustawa-zastaw-rejestrowy` | ✅ aktywny / B+/COV |
| Ubezpieczenia obowiązkowe / UFG / PBUK — OC sprawcy, odszkodowanie i zadośćuczynienie z OC, wypadek drogowy | Dz.U. 2026 poz. 783 t.j. ze zm. | `mod-ustawa-ubezpieczenia-obowiazkowe-UFG-PBUK` | 🟢 B+/COV |
| Monopole państwowe | Konstytucja + właściwe ustawy sektorowe, w tym hazard/poczta | `mod-ustawa-monopole-panstwowe` | ✅ aktywny; temporal gate |
| Transakcje handlowe / opóźnienia | Dz.U. 2023 poz. 1790 t.j. ze zm. | `mod-transakcje-handlowe-opoznienia` | 🟢 B+/COV |
| Cudzoziemcy — routing gospodarczy/cywilny | Dz.U. 2025 poz. 1079 t.j. ze zm. | `mod-ustawa-cudzoziemcy` | 🔗 routing DR-05 |
| Ustawa frankowa 2026 — procedura | Dz.U. 2026 poz. 985 | `mod-ustawa-frankowa-2026-procedura.md` | ✅ aktywny; fresh gate |

## Reguły runtime

- każdy fizyczny moduł DR-02 pozostaje jawnie rejestrowany w tej mapie zgodnie z `check_rejestracja_modulow.py`;
- mapy nie przechowują dawnych metryk, opisów napraw, `NOWY/ZAMKNIĘTE/NAPRAWIONE`, raportów pokrycia ani historii sesji;
- przy KSH, restrukturyzacji, konsumentach, instrumentach finansowych i regulacjach dynamicznych obowiązuje fresh/temporal gate;
- `COV` oznacza aktualną strukturę/routing, nie `FULL` artykuł-po-artykule.


## Pełne korpusy i procedury niewypłacalności

| Zakres | Podstawa | Moduł | Status |
|---|---|---|---|
| PrRestr — Prawo restrukturyzacyjne — pełny korpus i sposób użycia | Dz.U. 2026 poz. 533; metryka i kontrola nowelizacji w korpusie | `mod-PrRestr-zrodla-i-wersje` | pełne źródło / procedura tematyczna; fresh gate |
| PrRestr — Restrukturyzacja — kwalifikacja sprawy, plan i test zaspokojenia | Dz.U. 2026 poz. 533; metryka i kontrola nowelizacji w korpusie | `mod-PrRestr-wejscie-plan-test` | ✅ A / COV-ART (każdy aktywny artykuł omówiony); fresh gate |
| PrRestr — Postępowanie o zatwierdzenie układu — pełny przebieg | Dz.U. 2026 poz. 533; metryka i kontrola nowelizacji w korpusie | `mod-PrRestr-pzu` | ✅ A / COV-ART (każdy aktywny artykuł omówiony); fresh gate |
| PrRestr — Przyspieszone postępowanie układowe i postępowanie układowe | Dz.U. 2026 poz. 533; metryka i kontrola nowelizacji w korpusie | `mod-PrRestr-ppu-pu` | ✅ A / COV-ART (każdy aktywny artykuł omówiony); fresh gate |
| PrRestr — Sanacja — zarząd, działania sanacyjne i układ | Dz.U. 2026 poz. 533; metryka i kontrola nowelizacji w korpusie | `mod-PrRestr-sanacja` | ✅ A / COV-ART (każdy aktywny artykuł omówiony); fresh gate |
| PrRestr — Restrukturyzacja — procedura wspólna, zakończenie i upadłość | Dz.U. 2026 poz. 533; metryka i kontrola nowelizacji w korpusie | `mod-PrRestr-procedura-zakonczenie` | ✅ A / COV-ART (każdy aktywny artykuł omówiony); fresh gate |
| PrRestr — Restrukturyzacja — transgraniczne, odrębne, karne i przejściowe | Dz.U. 2026 poz. 533; metryka i kontrola nowelizacji w korpusie | `mod-PrRestr-odrebne-miedzynarodowe` | ✅ A / COV-ART (każdy aktywny artykuł omówiony); fresh gate |
| PrUp — Upadłość — przesłanki, wniosek, zabezpieczenie i pre-pack | Dz.U. 2026 poz. 913; metryka i kontrola nowelizacji w korpusie | `mod-PrUpad-wniosek-ogloszenie` | ✅ A / COV-ART (każdy aktywny art. 1–56h omówiony); fresh gate |
| PrUp — Upadłość — masa, umowy, bezskuteczność i procesy | Dz.U. 2026 poz. 913; metryka i kontrola nowelizacji w korpusie | `mod-PrUpad-skutki-masa-bezskutecznosc` | ✅ A / COV-ART (każdy aktywny artykuł omówiony); fresh gate |
| PrUp — Upadłość — organy, wierzyciele i wspólna procedura | Dz.U. 2026 poz. 913; metryka i kontrola nowelizacji w korpusie | `mod-PrUpad-organy-procedura` | ✅ A / COV-ART (każdy aktywny artykuł omówiony); fresh gate |
| PrUp — Upadłość — zakończenie, oddłużenie przedsiębiorcy, zakaz i przepisy końcowe | Dz.U. 2026 poz. 913; metryka i kontrola nowelizacji w korpusie | `mod-PrUpad-zakonczenie-zakaz-karne` | ✅ A / COV-ART (każdy aktywny artykuł omówiony); fresh gate |
