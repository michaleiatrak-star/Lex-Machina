# mod-ustawa-deweloperska

**Akt:** UDew (ustawa o ochronie praw nabywcy lokalu mieszkalnego lub domu jednorodzinnego oraz DFG) — t.j. Dz.U. 2026 poz. 880 (zm. 2026/1077 od 2026-11-11 — art. 19b ust. 1, 2a–2b).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1; poprawka: 14 dni na stanowisko dewelopera — art. 41 ust. 4, skutek milczenia — ust. 5).
**Data weryfikacji online:** 2026-06-05
**ZASADA:** Każde brzmienie przepisu przed powołaniem → isap.sejm.gov.pl

---

## FAZA 0 — INTAKE

```
□ Czy deweloper posiada mieszkaniowy rachunek powierniczy (MRP)?
□ Jaki typ rachunku: zamknięty (bezpieczniejszy) czy otwarty z gwarancją?
□ Czy sporządzono prospekt informacyjny?
□ Jaki etap: umowa deweloperska / odbiór / przeniesienie własności?
□ Czy są wady lokalu? → termin i procedura zgłoszenia
□ Czy deweloper opóźnia wydanie lokalu lub przeniesienie własności?
□ Data zawarcia umowy (ustawa nowa = od 01.07.2022 lub stara)?
```

---

## KLUCZOWE OBOWIĄZKI DEWELOPERA

> ⚠️ Weryfikuj aktualne przepisy ustawy w ELI (RZĄD 1) — nowa ustawa deweloperska obowiązuje od 01.07.2022.

```
□ Mieszkaniowy rachunek powierniczy (MRP) — obowiązkowy dla nowych inwestycji
□ Prospekt informacyjny — przed zawarciem umowy
□ Forma aktu notarialnego — umowa deweloperska i umowa przeniesienia własności
□ Deweloperski Fundusz Gwarancyjny — ochrona nabywcy przy upadłości dewelopera
```

---

## WADY LOKALU — ŚCIEŻKA

```
Odbiór lokalu → protokół odbioru (sporządzić na piśmie!)
  → wpisać wszystkie wady do protokołu
  ↓
Deweloper: 14 DNI na pisemne uznanie LUB odrzucenie zgłoszonych wad
  od podpisania protokołu — ⚠️ DODANE 2026-07-27 (FAZA 3E/ZASADA 14,
  poprzednia wersja pomijała ten termin całkowicie). Potwierdzone w
  6+ źródłach zgodnych (art. 41 ust. 4; skutek — ust. 5). BRAK ODPOWIEDZI W TYM
  TERMINIE = MILCZĄCE UZNANIE WAD (skutek dla dewelopera niekorzystny,
  warto to podnieść, jeśli deweloper spóźni się z odpowiedzią).
  ↓
Deweloper: 30 dni na usunięcie UZNANYCH wad od podpisania protokołu
  (POTWIERDZONE 2026-07-27 — art. 41 ust. 6 ustawy z 20.05.2021 r.
  o ochronie praw nabywcy lokalu mieszkalnego lub domu jednorodzinnego
  oraz Deweloperskim Funduszu Gwarancyjnym, t.j. Dz.U. 2026 poz. 880 ze zm.;
  liczone jako dni kalendarzowe, nie robocze)
  ↓ brak usunięcia
Nabywca: wyznacza dodatkowy termin ALBO
         odmawia odbioru (wada istotna) ALBO
         żąda obniżenia ceny
         
⚠️ Terminy i procedury — weryfikuj aktualne przepisy ustawy w ELI (RZĄD 1).
```

---

## WERYFIKACJA ONLINE

```
web_search: "ustawa deweloperska ochrona nabywcy isap.sejm.gov.pl Dz.U. 2026 poz. 880"
web_search: "mieszkaniowy rachunek powierniczy MRP deweloper obowiązki 2022"
web_search: "Deweloperski Fundusz Gwarancyjny UOKiK nabywca upadłość"
web_search: "wady lokalu protokół odbioru deweloper termin orzecznictwo"
```

---

## ŁĄCZ Z

| Sytuacja | Skill / Moduł |
|---|---|
| Analiza umowy deweloperskiej | `analizator-umow-v1` (moduł J2 — nieruchomości) |
| Pismo: reklamacja, wezwanie | `pisma-procesowe-v3` |
| Własność lokali | `mod-ustawa-spoldzielnie-wlasnosc-lokali` |

---

## ŹRÓDŁA ONLINE

- Ustawa deweloperska: https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20210001177
- UOKiK (DFG): https://uokik.gov.pl


---

## QUALITY GATE

- [ ] Aktualny tekst t.j. aktu zweryfikowany w ISAP?
- [ ] Stan prawny właściwy temporalnie (na dzień zdarzenia i na dzień orzekania)?
- [ ] Każda przesłanka ma przypisany dowód?
- [ ] Termin nie upłynął?
- [ ] Właściwy organ / sąd wskazany?
- [ ] Ryzyka formalne i dowodowe ocenione?
- [ ] Brzmienie przepisów pobrane ze źródeł, nie z pamięci modelu?

## OUTPUT

Wynik pracy modułu:
1. Stan faktyczny;
2. Stan prawny i źródła (Dz.U. z ISAP);
3. Kwalifikacja trybu i właściwość;
4. Terminy (obliczone, z datami granicznymi);
5. Przesłanki (spełnione / wątpliwe / niespełnione);
6. Matryca dowodowa (teza → dowód → siła → luka);
7. Zarzuty i kontrargumenty;
8. Analiza ryzyk;
9. Strategia (wariant podstawowy + ewentualny);
10. Rekomendacja + kolejne kroki;
11. Kontrola ISAP/temporalności.
