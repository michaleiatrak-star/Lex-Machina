# mod-rzeczy-znalezione-zasiedzenie

**Wersja:** 1.1 | **Dodano:** 2026-07-18 | **Aktualizacja:** 2026-10-12 (Dz.U. 2026 poz. 184)
**Rola w systemie:** odpowiedź na wskazanie użytkownika ("rzeczy
znalezione, przywłaszczenie mienia i zasiedzenie"). Stan przed tym
modułem: (1) rzeczy znalezione — CAŁKOWITA LUKA, ustawa z 2015 r. nigdzie
nieopracowana; (2) zasiedzenie — TYLKO SZKIELET (5 linijek w ANEKS D
`mod-KC-cywilne-zobowiazania-odpowiedzialnosc.md`), bez kryteriów dobrej/
złej wiary, doliczania posiadania, ograniczeń rolnych; (3) przywłaszczenie
mienia — JUŻ DOBRZE POKRYTE karnie (art. 284 KK w BLOK A/L kwalifikatora,
art. 125 KW) — potwierdzone, bez potrzeby duplikacji, patrz sekcja 3.

> ✅ **METRYKA (ELI 2026-10-12):** ustawa o rzeczach znalezionych — **Dz.U. 2023 poz. 501 t.j.**; ⏳ po t.j.: **Dz.U. 2026 poz. 184** (ustawa z 23.01.2026, ogł. 18.02.2026, w mocy od 19.05.2026 — art. 4). KC — **Dz.U. 2026 poz. 795 t.j.** (brak zmian po t.j.; art. 187 § 1–2 w brzmieniu nadanym art. 2 ustawy 2026/184). Fresh hard gate pozostaje obowiązkowy dla brzmienia konkretnego przepisu.
>
> ⛔ **PRAWO INTERTEMPORALNE (art. 3 ustawy 2026/184):** „Do rzeczy znalezionych przed dniem wejścia w życie niniejszej ustawy stosuje się przepisy dotychczasowe.” Rozstrzyga **data znalezienia**: przed 19.05.2026 — stan dawny (terminy z art. 187 KC: rok / 2 lata; właściwy wyłącznie starosta miejsca znalezienia); od 19.05.2026 — stan poniżej.

---

## CZĘŚĆ A — RZECZY ZNALEZIONE (ustawa z 20.02.2015 r., **Dz.U. 2023 poz. 501 t.j.**, zm. **Dz.U. 2026 poz. 184** od 19.05.2026, ELI 2026-10-12)

### 1. Podstawowy obowiązek znalazcy (art. 183-187 KC + ustawa szczegółowa)

```
□ Znalazca NIEZWŁOCZNIE zawiadamia osobę uprawnioną do odbioru (jeśli
  zna jej tożsamość/miejsce pobytu) LUB właściwego STAROSTĘ — art. 5
  ust. 1: „starostę właściwego ze względu na miejsce znalezienia rzeczy
  (właściwy starosta)”
□ (zm. 2026/184, od 19.05.2026) art. 5 ust. 6: zamiast właściwego
  starosty znalazca może zawiadomić starostę / oddać rzecz staroście
  „właściwemu ze względu na miejsce swojego zamieszkania”; ten przesyła
  odpis protokołu i rzecz właściwemu staroście (art. 5 ust. 7)
□ (zm. 2026/184) art. 5 ust. 3: pieniądze, papiery wartościowe,
  kosztowności, rzeczy o wartości historycznej/naukowej/artystycznej —
  ODDAJE SIĘ niezwłocznie właściwemu staroście, „chyba że znalezione
  zostały jedynie pieniądze, a ich kwota nie przekracza 5 % minimalnego
  wynagrodzenia za pracę [...] obowiązującego w dniu znalezienia
  pieniędzy” (waluta obca — równowartość wg kursu średniego NBP)
□ (zm. 2026/184) art. 12 ust. 4: starosta może odmówić przyjęcia rzeczy
  o szacunkowej wartości do 5 % minimalnego wynagrodzenia, chyba że to
  rzecz o wartości historycznej/naukowej/artystycznej lub dokument
  zawierający dane osobowe
□ Jeśli przechowanie/oddanie rzeczy jest NIEMOŻLIWE albo połączone z
  NIEBEZPIECZEŃSTWEM pogorszenia, TRUDNOŚCIAMI lub ZNACZNYMI KOSZTAMI —
  znalazca MOŻE ograniczyć się do WSKAZANIA miejsca, w którym rzecz się
  znajduje (osobie uprawnionej, staroście lub zarządcy)
□ PROCEDURA (art. 13 ust. 1–2, zm. 2026/184): protokół sporządza
  właściwy starosta, starosta miejsca zamieszkania znalazcy, jednostka
  Policji albo Żandarmerii Wojskowej — także przy samym wskazaniu
  miejsca rzeczy; w protokole dane znalazcy, opis rzeczy, czas/miejsce
  znalezienia, pouczenie o znaleźnym i zasadach nabycia własności;
  żądanie znaleźnego — wzmianka w protokole; odpis na żądanie znalazcy
□ OGŁOSZENIE (art. 15 ust. 3, zm. 2026/184): przy wartości > 5 %
  minimalnego wynagrodzenia i braku możliwości doręczenia wezwania —
  wywieszenie na tablicy przez 6 miesięcy od dnia znalezienia + BIP
  w terminie 3 dni roboczych; dane także w portalu otwartych danych
  (art. 15 ust. 5–7)
```

### 2. Kategorie szczególne wymagające odrębnego postępowania

```
□ BROŃ, AMUNICJA, MATERIAŁY WYBUCHOWE, inna rzecz wymagająca pozwolenia
  lub rzecz, której oddanie wiązałoby się z ZAGROŻENIEM życia/zdrowia —
  (zm. 2026/184) art. 6: znalazca „niezwłocznie zawiadamia o miejscu,
  w którym rzecz się znajduje, jednostkę organizacyjną Policji”, a
  Policja zawiadamia właściwego starostę. W budynku publicznym / środku
  transportu publicznego — zawiadamia się właściwego zarządcę, a Policję
  zawiadamia zarządca (art. 7 ust. 2)
□ RZECZ ZNALEZIONA W BUDYNKU PUBLICZNYM / środku transportu publicznego —
  oddaje się zarządcy (art. 7 ust. 1); (zm. 2026/184) zarządca wzywa
  znaną osobę uprawnioną albo zamieszcza ogłoszenie na swojej stronie
  (art. 7 ust. 1a), a po 30 dniach przekazuje rzecz właściwemu staroście
  (art. 7 ust. 1b)
□ SPRZĘT/EKWIPUNEK WOJSKOWY — (zm. 2026/184) art. 5 ust. 4: oddaje się
  „właściwemu staroście albo najbliższej jednostce organizacyjnej
  Żandarmerii Wojskowej”
□ DOKUMENTY WOJSKOWE (legitymacja, książeczka, zaświadczenie, karta
  powołania) — (zm. 2026/184) art. 5 ust. 4a: organowi wskazanemu
  w dokumencie, a gdy dokument tego nie wskazuje — właściwemu staroście
  albo najbliższej jednostce ŻW
□ ZABYTKI lub MATERIAŁY ARCHIWALNE — SZCZEGÓLNY reżim: jeśli nie zostaną
  odebrane, stają się własnością SKARBU PAŃSTWA (nie znalazcy!), a
  znalazcy przysługuje NAGRODA (nie znaleźne) — wysokość określa
  rozporządzenie Ministra Kultury, uwzględniając wartość historyczną/
  naukową/artystyczną/materialną
□ DOKUMENTY z danymi osobowymi (dokument w rozumieniu art. 77³ KC) —
  (zm. 2026/184) art. 5 ust. 3a: oddaje się niezwłocznie właściwemu
  staroście, chyba że dokument wskazuje inny sposób postępowania
□ DOWODY OSOBISTE, DOKUMENTY PASZPORTOWE i inne rzeczy z odrębnym trybem
  w innych ustawach — (zm. 2026/184) art. 3 pkt 3: wyłączone spod ustawy
□ DOKUMENTY z danymi osobowymi i rzeczy umożliwiające DOSTĘP do
  pomieszczeń/pojazdów (klucze, karty dostępu, piloty) — (zm. 2026/184)
  NIE przechodzą na znalazcę (art. 19 ust. 2); po upływie terminu stają
  się własnością POWIATU (art. 187 § 2 KC), a starosta niezwłocznie je
  NISZCZY z protokołem (art. 25a)
```

### 3. ⭐ ZNALEŹNE — wynagrodzenie znalazcy

```
WYSOKOŚĆ: 1/10 (JEDNA DZIESIĄTA) wartości rzeczy
WARUNEK: znalazca musi ZGŁOSIĆ roszczenie NAJPÓŹNIEJ w chwili WYDANIA
  rzeczy osobie uprawnionej — zgłoszenie PO wydaniu = utrata prawa
JEŚLI rzecz NIE jest przechowywana przez znalazcę (np. wskazał tylko
  miejsce) — może ZAWCZASU powiadomić przechowującego o zamiarze żądania
  znaleźnego → przechowujący ma wtedy obowiązek przekazać znalazcy dane
  adresowe osoby, która odebrała rzecz → znalazca zgłasza żądanie
  BEZPOŚREDNIO do tej osoby, w terminie 1 MIESIĄCA od zawiadomienia go
  o wydaniu rzeczy
WYJĄTEK: zabytki/materiały archiwalne → NAGRODA (nie znaleźne), patrz
  sekcja 2
```

### 4. ⭐⭐ NABYCIE WŁASNOŚCI PRZEZ ZNALAZCĘ (art. 187 KC) — kluczowy mechanizm

```
⛔ ZMIANA TERMINÓW (art. 2 ustawy 2026/184, rzeczy znalezione od 19.05.2026):
  art. 187 § 1 KC: „Rzecz znaleziona, która nie zostanie przez osobę
  uprawnioną odebrana w ciągu 6 miesięcy od dnia doręczenia jej wezwania
  do odbioru, a w przypadku niemożności wezwania – w ciągu roku od dnia
  jej znalezienia, staje się własnością znalazcy, jeżeli uczynił on
  zadość swoim obowiązkom. Jeżeli jednak rzecz została oddana staroście,
  znalazca staje się jej właścicielem, jeżeli rzecz odebrał
  w wyznaczonym przez starostę terminie.”
WARUNEK CZASOWY: rzecz NIE zostanie odebrana przez osobę uprawnioną:
  □ W CIĄGU 6 MIESIĘCY od dnia DORĘCZENIA jej wezwania do odbioru, ALBO
  □ W CIĄGU ROKU od dnia ZNALEZIENIA — gdy wezwanie było NIEMOŻLIWE
  □ rzecz znaleziona PRZED 19.05.2026 — terminy dawne: rok / 2 lata
    (art. 3 ustawy 2026/184)
□ (zm. 2026/184) art. 19 ust. 3: starosta wydaje znalazcy, który nabył
  własność, zaświadczenie o upływie terminów z art. 187 § 1 KC
WARUNEK DODATKOWY: znalazca musi UCZYNIĆ ZADOŚĆ swoim USTAWOWYM
  OBOWIĄZKOM (zawiadomienie, przechowanie itd. — sekcja 1) — brak
  dopełnienia obowiązków = brak nabycia własności mimo upływu terminu
WYJĄTEK: NIE dotyczy rzeczy wpisanej do KRAJOWEGO REJESTRU UTRACONYCH
  DÓBR KULTURY (art. 169 §3, 170 §2, 174 §2 KC, dodane nowelizacją 2015)
JEŚLI znalazca NIE CHCE rzeczy lub NIE dopełnił obowiązków → po
  DALSZYM wezwaniu starosty (termin NIE KRÓTSZY niż 2 TYGODNIE) →
  własność przechodzi na POWIAT
art. 187 § 2 KC (zm. 2026/184): zabytek / materiał archiwalny → SKARB
  PAŃSTWA; klucze, karty dostępu, piloty, dokumenty z danymi osobowymi →
  POWIAT (bez etapu znalazcy); inne rzeczy → POWIAT po upływie terminu
  do ich odbioru przez znalazcę
```

### 5. Koszty i prawo zatrzymania

```
□ Koszty PRZECHOWANIA + UTRZYMANIA rzeczy w należytym stanie + koszty
  POSZUKIWANIA osoby uprawnionej — OBCIĄŻAJĄ osobę uprawnioną do odbioru,
  DO WYSOKOŚCI wartości rzeczy w dniu odbioru
□ Znalazcy/przechowującemu PRZYSŁUGUJE PRAWO ZATRZYMANIA rzeczy do
  czasu rozliczenia kosztów
□ Odbiór rzeczy OD STAROSTY możliwy WYŁĄCZNIE po uregulowaniu kosztów
  przechowania
```

### 6. Checklist praktyczny — rzeczy znalezione

```
□ DATA ZNALEZIENIA: przed czy od 19.05.2026 (art. 3 ustawy 2026/184)?
□ Czy rzecz należy do kategorii SZCZEGÓLNEJ (broń → Policja, wojskowa →
  starosta/ŻW, zabytek, dokument z danymi osobowymi, klucze/karty/piloty)
  wymagającej ODMIENNEJ procedury niż zwykłe zawiadomienie starosty?
□ Czy znalazca DOPEŁNIŁ wszystkich ustawowych obowiązków — to WARUNEK
  KONIECZNY zarówno znaleźnego, jak i nabycia własności
□ Czy roszczenie o znaleźne zostało zgłoszone we WŁAŚCIWYM terminie
  (najpóźniej przy wydaniu rzeczy, lub miesiąc od zawiadomienia przy
  wskazaniu miejsca)?
□ Czy upłynął termin do nabycia własności (od 19.05.2026: 6 miesięcy od
  wezwania / rok od znalezienia; wcześniej: rok / 2 lata) — i czy znalazca w ogóle CHCE nabyć rzecz (jeśli nie,
  przechodzi na powiat)?
```

---

## CZĘŚĆ B — ZASIEDZENIE (art. 172-176 KC) — PEŁNE OPRACOWANIE (rozbudowa dotychczasowego szkieletu)

> Zastępuje/rozbudowuje skrótowy wpis w ANEKS D pliku `mod-KC-cywilne-
> zobowiazania-odpowiedzialnosc.md` — TAM pozostaje odesłanie, TU pełna treść.

### 7. Przesłanki podstawowe (art. 172 KC)

```
□ PODMIOT: posiadacz NIEBĘDĄCY właścicielem (nie można zasiedzieć
  rzeczy, której już jest się właścicielem)
□ RODZAJ POSIADANIA: WYŁĄCZNIE posiadanie SAMOISTNE (art. 336 KC —
  władanie rzeczą JAK WŁAŚCICIEL, nie jak najemca/użytkownik/dzierżawca
  — posiadanie ZALEŻNE NIGDY nie prowadzi do zasiedzenia)
□ NIEPRZERWANOŚĆ posiadania przez wymagany okres
□ UPŁYW CZASU: 20 LAT (dobra wiara) lub 30 LAT (zła wiara)
```

### 8. Terminy — tabela

| Sytuacja | Termin |
|---|---|
| Nieruchomość, DOBRA WIARA | 20 lat |
| Nieruchomość, ZŁA WIARA | 30 lat |
| Ruchomość, DOBRA WIARA | 3 lata (art. 174 KC) |
| Ruchomość, ZŁA WIARA | ⚠️ co do zasady zasiedzenie ruchomości w złej wierze NIE JEST możliwe na gruncie art. 174 — zweryfikuj na ISAP dokładne brzmienie |

### 9. Dobra wiara vs zła wiara — kryterium oceny

```
□ DOBRA WIARA: posiadacz ma OBIEKTYWNIE USPRAWIEDLIWIONE przekonanie,
  że przysługuje mu prawo własności (np. kupił nieruchomość w
  przeświadczeniu, że transakcja była ważna, mimo wady prawnej)
□ ZŁA WIARA: posiadacz WIE (lub przy dołożeniu należytej staranności
  powinien wiedzieć), że nieruchomość do niego nie należy
□ MOMENT OCENY: dobra/zła wiara ocenia się na CHWILĘ OBJĘCIA
  nieruchomości W POSIADANIE — PÓŹNIEJSZA zmiana świadomości (np.
  posiadacz w dobrej wierze dowiaduje się później o wadzie) NIE ZMIENIA
  already ustalonej kwalifikacji
□ DOMNIEMANIE (art. 7 KC): w postępowaniu o zasiedzenie PRZYJMUJE SIĘ
  na WSTĘPIE domniemanie DOBREJ WIARY — ciężar dowodu ZŁEJ wiary
  spoczywa na tym, kto ją PODNOSI (np. dotychczasowy właściciel
  kwestionujący wniosek o zasiedzenie)
```

**Orzecznictwo praktyczne:** SN, postanowienie z 28.04.1999, sygn. I CKN
430/98 — samoistny posiadacz w ZŁEJ wierze, który w trakcie biegu
zasiedzenia zwraca się do właściciela z OFERTĄ KUPNA nieruchomości, NIE
TRACI przez to cechy posiadania samoistnego (chyba że z innych
okoliczności wynika rezygnacja z samodzielnego władania).

### 10. Doliczanie posiadania poprzednika (art. 176 KC) — mechanizm

```
ZASADA OGÓLNA: obecny posiadacz MOŻE doliczyć do SWOJEGO czasu
  posiadania czas posiadania SWOJEGO POPRZEDNIKA (przy przeniesieniu
  posiadania, w tym przez SPADKOBRANIE — art. 176 §2)

OGRANICZENIE przy złej wierze poprzednika: jeśli POPRZEDNI posiadacz
  uzyskał posiadanie W ZŁEJ WIERZE, jego czas MOŻE być doliczony TYLKO
  gdy ŁĄCZNY okres (poprzednik + obecny posiadacz) wynosi CO NAJMNIEJ
  30 LAT (⚠️ jedno ze sprawdzonych źródeł w tej sesji podawało omyłkowo
  "20 lat" dla tego progu — WIĘKSZOŚĆ źródeł, w tym komentarze
  akademickie, wskazuje 30 LAT jako prawidłowy próg — zweryfikuj
  KONIECZNIE dokładne brzmienie art. 176 §1 na ISAP przed użyciem w
  piśmie, NIE polegaj na żadnym pojedynczym źródle wtórnym dla tej
  konkretnej liczby)

GRANICA MECHANIZMU (orzecznictwo SN): NIE MOŻNA doliczyć posiadania
  poprzednika, jeśli zasiedzenie JUŻ NASTĄPIŁO na jego rzecz PRZED
  przeniesieniem posiadania — po spełnieniu przesłanek zasiedzenia
  przez poprzednika, WŁASNOŚĆ przeszła już NA NIEGO z mocy prawa (patrz
  sekcja 11), więc "doliczanie" nie ma już przedmiotu
```

### 11. Charakter nabycia — Z MOCY PRAWA, orzeczenie sądu DEKLARATORYJNE

**Kluczowe dla strategii procesowej:** nabycie własności przez
zasiedzenie następuje **Z MOCY SAMEGO PRAWA** w CHWILI spełnienia
wszystkich przesłanek (upływ terminu + posiadanie samoistne
nieprzerwane) — orzeczenie sądu o STWIERDZENIU zasiedzenia ma charakter
WYŁĄCZNIE DEKLARATORYJNY (potwierdzający istniejący JUŻ stan prawny),
NIE KONSTYTUTYWNY. Oznacza to, że data zasiedzenia w postanowieniu sądu
wskazuje moment W PRZESZŁOŚCI (upływ terminu), a nie datę wydania
orzeczenia.

### 12. Ograniczenie dla nieruchomości ROLNYCH (art. 172 §3 KC)

```
Nabycie NIERUCHOMOŚCI ROLNEJ (w rozumieniu ustawy o kształtowaniu
  ustroju rolnego) przez zasiedzenie MOŻE nastąpić WYŁĄCZNIE na rzecz
  ROLNIKA INDYWIDUALNEGO (w rozumieniu tej samej ustawy)
LIMIT POWIERZCHNIOWY: powierzchnia NABYWANEJ nieruchomości rolnej
  ŁĄCZNIE z nieruchomościami rolnymi JUŻ stanowiącymi własność tej
  osoby NIE MOŻE przekroczyć 300 HA użytków rolnych
GENEZA: przepis dodany ustawą o wstrzymaniu sprzedaży nieruchomości
  Zasobu Własności Rolnej Skarbu Państwa — kontekst ochrony struktury
  agrarnej przed nadmierną koncentracją ziemi
```

### 13. Współwłasność — pułapka praktyczna

**SN, postanowienie z 20.09.2012, sygn. IV CSK 117/12:** NIEWYKONYWANIE
prawa posiadania przez JEDNEGO współwłaściciela NIE UPRAWNIA do wniosku,
że współwłaściciel FAKTYCZNIE posiadający przejął rzecz w SAMOISTNE
posiadanie w zakresie uprawnień tego, kto nie wykonuje swojego prawa —
sam fakt bierności jednego współwłaściciela NIE prowadzi automatycznie
do zasiedzenia jego udziału przez drugiego.

### 14. Procedura sądowa

```
□ WNIOSEK o STWIERDZENIE ZASIEDZENIA — do SĄDU REJONOWEGO właściwego
  dla miejsca położenia nieruchomości
□ TRYB: postępowanie NIEPROCESOWE (art. 609-610 KPC)
□ Po prawomocnym postanowieniu — ODRĘBNY wniosek do KSIĘGI WIECZYSTEJ
  o wykreślenie dotychczasowego wpisu własności i innych obciążeń
  (hipotek), oraz wpisanie nowego właściciela
□ Warto sprawdzić RÓWNIEŻ z przeciwnej strony: czy wobec NALEŻĄCEJ do
  klienta nieruchomości NIE BIEGNIE aktualnie zasiedzenie na rzecz innej
  osoby — bierność właściciela przez wiele lat może działać na jego
  NIEKORZYŚĆ (przerwanie biegu wymaga aktywnego działania — np. pozew
  windykacyjny, patrz `mod-KC-cywilne-zobowiazania-odpowiedzialnosc.md`
  ANEKS D, art. 222 KC)
```

### 15. Checklist praktyczny — zasiedzenie

```
□ Czy posiadanie było SAMOISTNE (władanie JAK właściciel) przez CAŁY
  wymagany okres — nie zależne (najem/dzierżawa/użyczenie)?
□ Jaka była dobra/zła wiara NA CHWILĘ OBJĘCIA w posiadanie (nie później)?
□ Czy doliczano posiadanie poprzednika — jeśli tak, sprawdź czy
  poprzednik był w dobrej czy złej wierze i czy łączny okres spełnia
  odpowiedni próg (patrz ostrzeżenie sekcja 10 — zweryfikuj dokładną
  liczbę lat na ISAP)
□ Czy przedmiotem jest NIERUCHOMOŚĆ ROLNA — jeśli tak, sprawdź czy
  wnioskodawca jest rolnikiem indywidualnym i czy nie przekracza
  limitu 300 ha łącznie
□ Czy nieruchomość jest przedmiotem WSPÓŁWŁASNOŚCI — jeśli tak, samo
  niewykonywanie prawa przez innego współwłaściciela NIE WYSTARCZA
□ Czy upłynął już termin (licząc od faktycznego objęcia w posiadanie,
  nie od złożenia wniosku do sądu) — pamiętaj, że nabycie nastąpiło
  Z MOCY PRAWA wcześniej, orzeczenie tylko to POTWIERDZA
```

---

## CZĘŚĆ C — PRZYWŁASZCZENIE MIENIA — POTWIERDZENIE POKRYCIA (bez duplikacji)

### 16. Status w systemie

Przywłaszczenie mienia jest JUŻ dobrze pokryte w warstwie KARNEJ:
```
□ Art. 284 KK (przywłaszczenie, powyżej progu 800 zł) →
  `mod-KK-kwalifikator-karnomaterialny.md` BLOK A/L
□ Art. 125 KW (przywłaszczenie rzeczy znalezionej, wykroczenie) →
  `mod-KW-art119-131-przeciwko-mieniu.md`
```

**Powiązanie z Częścią A tego modułu:** art. 125 KW dotyczy WŁAŚNIE
sytuacji, gdy ZNALAZCA (Część A) NIE dopełnia obowiązków ustawowych z
zamiarem zatrzymania rzeczy dla siebie z pominięciem procedury — to
BEZPOŚREDNIE połączenie tematyczne: nieprawidłowe postępowanie ze
znalezioną rzeczą (Część A) MOŻE przerodzić się w wykroczenie/
przestępstwo przywłaszczenia (art. 125 KW / art. 284 KK), jeśli znalazca
działa z ZAMIAREM zatrzymania rzeczy dla siebie zamiast wypełnienia
obowiązków ustawowych.

**Warstwa CYWILNA (uzupełnienie, krótkie):** poza karą, właściciel
rzeczy przywłaszczonej ma też ROSZCZENIE WINDYKACYJNE (art. 222 KC —
już opisane w `mod-KC-cywilne-zobowiazania-odpowiedzialnosc.md` ANEKS D)
o WYDANIE rzeczy, niezależnie od odpowiedzialności karnej — te dwie
ścieżki (karna i cywilna) są NIEZALEŻNE i mogą być prowadzone
RÓWNOLEGLE.

---

## 17. INTEGRACJA Z SYSTEMEM

- **`mod-KC-cywilne-zobowiazania-odpowiedzialnosc.md`** ANEKS D —
  zawiera SKRÓCONY wpis o zasiedzeniu (5 linijek) — ten moduł go
  ZASTĘPUJE merytorycznie (rozważ przy przyszłym audycie usunięcie
  duplikatu z ANEKS D na rzecz odesłania tutaj) oraz roszczenie
  windykacyjne (art. 222 KC), z którym Część C się łączy.
- **`mod-KW-art119-131-przeciwko-mieniu.md`** (DR-03) — art. 125 KW,
  bezpośrednie połączenie z Częścią A (nieprawidłowe postępowanie ze
  znalezioną rzeczą jako wykroczenie).
- **`mod-KK-kwalifikator-karnomaterialny.md`** BLOK A/L (DR-03) — art.
  284 KK, przywłaszczenie powyżej progu.
- **`mod-UGN-gospodarka-nieruchomosciami.md`** (DR-09) — zasiedzenie
  nieruchomości w kontekście gospodarki nieruchomościami/deweloperskim
  — odsyła tutaj po pełną treść zamiast duplikować.
- **`pisma-procesowe-v3`** — wniosek o stwierdzenie zasiedzenia, wniosek
  o wpis do KW po prawomocnym postanowieniu.

---

## 18. LITERATURA I ŹRÓDŁA (zweryfikowane online 2026-07-18)

- ora.poznan.pl, infor.pl, lexlege.pl, przepisy.gofin.pl,
  standardyprawa.pl, warszawa19115.pl — ustawa z 20.02.2015 o rzeczach
  znalezionych, pełna treść art. 187 KC po nowelizacji, procedura,
  znaleźne, kategorie szczególne (zabytki, broń, wojskowe).
- topagrar.pl, prawoity.pl, weredynski.pl, pwrz.pl, infor.pl (gmina/
  nieruchomości), dziurkiewicz.eu, zasiedzenie.net — pełna treść art.
  172-176 KC, kryteria dobrej/złej wiary, doliczanie posiadania,
  ograniczenie rolne (art. 172 §3), orzecznictwo SN (I CKN 430/98,
  IV CSK 117/12).
- ⚠️ Odnotowana rozbieżność źródeł co do progu przy doliczaniu
  posiadania poprzednika w złej wierze (20 vs 30 lat) — wymaga
  ostatecznej weryfikacji w ELI (RZĄD 1).
