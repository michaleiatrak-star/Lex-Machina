# mod-KSH-spolki-handlowe

**Status:** moduł klasy kancelaryjnej — poziom DR-03

**Źródło weryfikacji:** KSH — Dz.U. 2024 poz. 18 t.j. ze zm. | PrUp — Dz.U. 2025 poz. 614 t.j. | Prawo przedsiębiorców — Dz.U. 2025 poz. 1480 t.j. | KC (spółka cywilna) — Dz.U. 2025 poz. 1071 ze zm.
**Data weryfikacji online:** 2026-06-05 (KSH/PrUp) · 2026-06-15 (Prawo przedsiębiorców, formy działalności, dokumenty założycielskie)
**ZASADA:** Każde brzmienie przepisu przed powołaniem → isap.sejm.gov.pl
**⚠️ KSH był wielokrotnie nowelizowany — przed każdą sprawą weryfikuj aktualny t.j. w ISAP.**

---

## FAZA 0 — INTAKE

```
□ Jaki typ spółki: sp. z o.o. / S.A. / spółka osobowa / inna?
□ Problem: rejestracja / zmiana umowy / odpowiedzialność zarządu /
  uchwała / representacja / przekształcenie / fuzja / podział?
□ Czy jest kwestia odpowiedzialności art. 299 KSH (sp. z o.o.)?
□ Czy spółka jest niewypłacalna? → rozważ upadłość/restrukturyzację
□ Jaka forma wymagana do czynności? (akt notarialny / forma pisemna / wpis do KRS)
□ Jakie terminy obowiązują (zgłoszenie do KRS, wniosek o upadłość)?
```

---

## TYPY SPÓŁEK — KWALIFIKATOR ODPOWIEDZIALNOŚCI

| Typ spółki | Odpowiedzialność wspólników/akcjonariuszy | Kluczowy przepis |
|---|---|---|
| Spółka jawna | Nieograniczona całym majątkiem (subsydiarnie) | art. 22, 31 KSH |
| Spółka partnerska | Partner odpowiada za własne działania, nie partnerów | art. 95 KSH |
| Spółka komandytowa | Komplementariusz: nieograniczona; komandytariusz: do sumy komandytowej | art. 111 KSH |
| Spółka komandytowo-akcyjna (S.K.A.) | Komplementariusz: nieograniczona; akcjonariusz: brak odpowiedzialności osobistej | art. 125, 135 KSH |
| Sp. z o.o. | Brak odpowiedzialności wspólników; zarząd: art. 299 KSH | art. 151 §4, 299 KSH |
| Prosta spółka akcyjna (PSA) | Brak odpowiedzialności akcjonariuszy | art. 300¹ i n. KSH |
| S.A. | Brak odpowiedzialności akcjonariuszy | art. 301 §5 KSH |

> ℹ️ S.K.A. i PSA dodane do tabeli 2026-06-15 dla kompletności (S.K.A. —
> obecna w KSH od 2000; PSA — wprowadzona nowelizacją z 2019, w życie od
> 1.07.2021, Dział Ia KSH art. 300¹–300¹³⁴).

---

## ODPOWIEDZIALNOŚĆ ZARZĄDU SP. Z O.O. (art. 299 KSH)

> ⚠️ Brzmienie art. 299 KSH — weryfikuj w aktualnym tekście KSH w ISAP.

```
ZASADA: Członek zarządu odpowiada osobiście za zobowiązania sp. z o.o.
  gdy egzekucja z majątku spółki okazała się bezskuteczna.

PRZESŁANKA UWOLNIENIA SIĘ (ciężar na zarządzie):
  □ We właściwym czasie złożono wniosek o upadłość, LUB
  □ Otwarto postępowanie restrukturyzacyjne / zatwierdzono układ, LUB
  □ Niezgłoszenie wniosku o upadłość nastąpiło nie z winy członka zarządu, LUB
  □ Wierzyciel nie poniósł szkody

TERMIN ZŁOŻENIA WNIOSKU O UPADŁOŚĆ:
  30 dni od dnia zaistnienia podstawy upadłości (art. 21 PrUp — Dz.U. 2025 poz. 614)
  ⚠️ Termin — weryfikuj aktualny art. 21 PrUp w ISAP.

PRZEDAWNIENIE roszczenia z art. 299 KSH: 3 lata — weryfikuj orzecznictwo SN.
```

---

## REPREZENTACJA SPÓŁKI

```
Sp. z o.o. / S.A.:
  Domyślnie: każdy członek zarządu samodzielnie
  CHYBA ŻE: umowa/statut zastrzega reprezentację łączną
  Prokura: prokurenci wpisani do KRS

⚠️ Zawsze weryfikuj aktualny sposób reprezentacji w KRS (dane publiczne):
  https://ekrs.ms.gov.pl lub https://rejestr.io
```

---

## UCHWAŁY ZGROMADZENIA WSPÓLNIKÓW / WALNEGO ZGROMADZENIA

```
Forma:
  Zmiana umowy spółki → AKT NOTARIALNY
  Zbycie nieruchomości spółki → AKT NOTARIALNY
  Uchwały zwykłe → protokół pisemny (sp. z o.o.) lub notarialny (S.A.)
  Brak formy = bezwzględna nieważność (art. 17 KSH)

Zaskarżenie uchwały (sp. z o.o.):
  Powództwo o stwierdzenie nieważności: 6 miesięcy od powzięcia wiadomości o uchwale,
  max 3 lata od podjęcia (art. 252 §3 KSH)
  Powództwo o uchylenie: 1 miesiąc od otrzymania wiadomości, max 6 miesięcy od podjęcia
  (art. 251 KSH)
  ⚠️ Terminy — weryfikuj aktualne brzmienie w ISAP.
```

---

## SCHEMAT: SPÓŁKA W TRUDNOŚCIACH

```
Trudności finansowe
  ↓
  [TEST NIEWYPŁACALNOŚCI — art. 11 PrUp — Dz.U. 2025 poz. 614]
  Dłużnik utracił zdolność do wykonywania wymagalnych zobowiązań pieniężnych
  (opóźnienie > 3 miesiące — domniemanie)
  Zobowiązania pieniężne > majątek przez > 24 miesiące (osoby prawne)
  ↓
Restrukturyzacja (zachowanie przedsiębiorstwa)     Upadłość (likwidacja)
  → postępowanie o zatwierdzenie układu (PZU)         → wniosek do sądu upadłościowego
  → przyspieszone postępowanie układowe               → syndyk + masa upadłości
  → postępowanie układowe                             → zgłoszenie wierzytelności
  → postępowanie sanacyjne                            → plan spłaty (konsument)
  ↓
⚠️ Złóż wniosek o upadłość w terminie 30 dni! → inaczej odpowiedzialność z art. 299 KSH
```

---

## FORMY DZIAŁALNOŚCI GOSPODARCZEJ — PEŁNY PRZEGLĄD (NOWA SEKCJA 2026-06-15)

> **Status:** sekcja NOWA — domyka pokrycie form prowadzenia działalności
> w Polsce poza KSH (działalność nierejestrowana, JDG, spółka cywilna),
> łącznie z kapitałami minimalnymi spółek KSH (poprzednia treść tej sekcji).
> ✅ VER online 2026-06-15.

### 0. Działalność nierejestrowana (Prawo przedsiębiorców, art. 5)

```
Podstawa: Prawo przedsiębiorców — t.j. Dz.U. 2025 poz. 1480 (obwieszczenie
20.10.2025), art. 5 w brzmieniu OD 1.01.2026 wg nowelizacji Dz.U. 2025
poz. 769 (ustawa z 25.07.2025 o uproszczeniach administracyjnych i wsparciu
przedsiębiorczości, podpisana przez Prezydenta 21.08.2025)
✅ VER: 2026-06-15

WARUNKI (art. 5 ust. 1):
□ osoba fizyczna
□ przychód należny ≤ 225% minimalnego wynagrodzenia za pracę W ŻADNYM
  KWARTALE (od 1.01.2026 — limit KWARTALNY, wcześniej był miesięczny 75%)
  → 2026: ok. 10 813,50 zł/kwartał — WERYFIKUJ aktualną kwotę minimalnego
    wynagrodzenia online, bo limit "podąża" za nią
□ brak prowadzenia działalności gospodarczej w ostatnich 60 miesiącach
□ działalność NIE wymaga koncesji/zezwolenia/wpisu do rejestru
  działalności regulowanej

PRZEKROCZENIE LIMITU (art. 5 ust. 3–4):
→ działalność staje się działalnością gospodarczą OD DNIA przekroczenia
→ obowiązek wpisu do CEIDG w terminie 7 dni od przekroczenia

PRZYCHÓD NALEŻNY (art. 5 ust. 6): kwoty należne, NIEZALEŻNIE od faktycznego
wpływu na rachunek, po wyłączeniu zwrotów/bonifikat/rabatów — liczy się
data wymagalności (np. termin płatności faktury), nie data zapłaty.

SKUTKI:
- brak ZUS, brak zaliczek PIT w trakcie roku
- obowiązek ewidencji sprzedaży + rozliczenie w PIT-36 (rubryka
  "działalność nierejestrowana"), zasady ogólne (skala 12%/32%)
- VAT: możliwe zwolnienie podmiotowe (limit obrotów, art. 113 ustawy o VAT
  — weryfikuj aktualny próg) — przy zwolnieniu: faktura bez VAT + uproszczony
  rejestr sprzedaży (art. 109 ust. 1 ustawy o VAT)
- BRAK dokumentu założycielskiego — co najwyżej umowy cywilnoprawne
  z klientami (zlecenie/dzieło) i regulamin świadczenia usług (jeśli online)
```

### 1. Jednoosobowa działalność gospodarcza (JDG / CEIDG)

```
Podstawa: Prawo przedsiębiorców (Dz.U. 2025 poz. 1480 t.j.)
- rejestracja w CEIDG (Centralna Ewidencja i Informacja o Działalności
  Gospodarczej) — bezpłatna, online (Profil Zaufany / e-dowód / podpis
  kwalifikowany)
- BRAK osobowości prawnej; przedsiębiorca = osoba fizyczna
- odpowiedzialność: CAŁYM majątkiem, BEZ rozdzielenia od majątku
  prywatnego (brak separacji jak w spółkach kapitałowych)
- opodatkowanie: PIT (skala / podatek liniowy 19% / ryczałt ewidencjonowany
  — wybór formy przy rejestracji lub do 20. dnia miesiąca następującego po
  pierwszym przychodzie) + składki ZUS (weryfikuj aktualne stawki — Mały
  ZUS Plus, ulga na start — online)
- BRAK dokumentu założycielskiego w sensie korporacyjnym; opcjonalnie:
  regulamin świadczenia usług / sprzedaży (jeśli działalność online, B2C
  → patrz DR-02/mod-ustawa-prawa-konsumenta i analizator-umow-v1/J8)
```

### 2. Spółka cywilna

```
Podstawa: Kodeks cywilny art. 860–875 (Dz.U. 2025 poz. 1071 ze zm.) — NIE
KSH. Spółka cywilna NIE jest spółką handlową (KSH art. 1 §2 — katalog
zamknięty: jawna, partnerska, komandytowa, komandytowo-akcyjna, sp. z o.o.,
PSA, S.A. — spółki cywilnej tam NIE MA).

- BRAK osobowości prawnej i BRAK zdolności prawnej samej spółki —
  podmiotami praw i obowiązków są WSPÓLNICY (każdy wspólnik jest odrębnym
  przedsiębiorcą wpisanym do CEIDG)
- odpowiedzialność: SOLIDARNA, całym majątkiem wspólników (art. 864 KC)
- DOKUMENT ZAŁOŻYCIELSKI: umowa spółki cywilnej — forma pisemna dla celów
  dowodowych (ad probationem, art. 860 §2 KC), NIE wymaga aktu notarialnego
- NIE wpisuje się do KRS — każdy wspólnik wpisany do CEIDG, spółka ma
  własny NIP/REGON dla celów rozliczeniowych (VAT, ZUS pracowników)
- typowe zastosowanie: mała działalność dwóch+ wspólników, niski próg
  formalności — często etap PRZEJŚCIOWY przed przekształceniem w spółkę
  handlową (np. sp. jawną) gdy biznes rośnie
```

### 3. Spółki handlowe (KSH) — kapitały minimalne (orientacyjne)

> ⚠️ Kwoty minimalne — weryfikuj aktualne przepisy KSH w ISAP przed każdą sprawą.

| Forma | Minimalny kapitał zakładowy |
|---|---|
| Spółki osobowe (jawna, partnerska, komandytowa, S.K.A. — wkład komplementariusza) | brak wymogu kapitałowego |
| Sp. z o.o. | 5 000 zł (art. 154 §1 KSH — weryfikuj w ISAP) |
| Prosta spółka akcyjna (PSA) | 1 zł (kapitał akcyjny, art. 300² §2 KSH — weryfikuj w ISAP; brak tradycyjnego "kapitału zakładowego") |
| S.A. (i S.K.A. — kapitał zakładowy akcjonariuszy) | 100 000 zł (art. 308 §1 KSH — weryfikuj w ISAP) |

### PODSUMOWANIE — DROGA "OD NAJPROSTSZEJ DO NAJBARDZIEJ ZŁOŻONEJ"

```
Działalność nierejestrowana → JDG → spółka cywilna → spółka osobowa
(jawna/partnerska/komandytowa/S.K.A.) → spółka kapitałowa (sp. z o.o./PSA/S.A.)

Kluczowe osie różnic:
1. Odpowiedzialność: osobista nieograniczona (nierejestrowana, JDG, cywilna,
   jawna) → ograniczona/mieszana (komandytowa, S.K.A.) → brak odpow.
   osobistej wspólników/akcjonariuszy (sp. z o.o., PSA, S.A. — ale art. 299
   KSH dla zarządu sp. z o.o.)
2. Rejestracja: brak (nierejestrowana) → CEIDG (JDG, wspólnicy spółki
   cywilnej) → KRS (spółki handlowe)
3. Opodatkowanie: PIT/ryczałt transparentny (nierejestrowana, JDG, cywilna,
   spółki osobowe poza komandytową/S.K.A.) → CIT (sp. z o.o., PSA, S.A.,
   komandytowa, S.K.A. — od 2021/2022 są podatnikami CIT, weryfikuj aktualny
   stan w DR-06)
4. Formalności: minimalne (nierejestrowana) → księgowość uproszczona
   możliwa (JDG, cywilna na starcie) → pełna księgowość + sprawozdania
   finansowe (spółki kapitałowe)
5. Dokument założycielski: brak → brak → umowa spółki cywilnej → umowa
   spółki (osobowe) → umowa spółki / statut (kapitałowe) — patrz sekcja
   "DOKUMENTY ZAŁOŻYCIELSKIE I WEWNĘTRZNE" poniżej
```

---

## DOKUMENTY ZAŁOŻYCIELSKIE I WEWNĘTRZNE (NOWA SEKCJA 2026-06-15)

> Dla ANALIZY/REDAKCJI tych dokumentów → `analizator-umow-v1`, nowy moduł
> `references/mod-FA-founders-dokumenty-zalozycielskie.md` (J.20). Tu:
> przegląd typów dokumentów i kiedy który jest właściwy/wymagany.

### Tabela dokumentów wg formy

| Forma | Dokument "konstytucyjny" | Forma prawna | Dokumenty wewnętrzne (fakultatywne/obowiązkowe wg KSH) |
|---|---|---|---|
| Działalność nierejestrowana | brak | — | brak |
| JDG | brak | — | regulamin sprzedaży/usług (jeśli B2C online) |
| Spółka cywilna | umowa spółki cywilnej | pisemna ad probationem (art. 860 §2 KC) | brak organów — wspólnicy prowadzą sprawy spółki |
| Sp. jawna | umowa spółki jawnej | pisemna (forma elektroniczna dopuszczalna; S24 — wzorzec) | brak organów obligatoryjnych |
| Sp. partnerska | umowa spółki partnerskiej | pisemna pod rygorem nieważności | regulamin wykonywania wolnego zawodu (jeśli wymaga ustawa zawodowa) |
| Sp. komandytowa | umowa spółki komandytowej | akt notarialny (lub S24) | — |
| S.K.A. | statut | akt notarialny | regulamin rady nadzorczej (obligatoryjna w S.K.A. przy >25 akcjonariuszach — weryfikuj art. 142 KSH) |
| Sp. z o.o. | umowa spółki | akt notarialny (lub S24 — wzorzec uproszczony) | regulamin zarządu, regulamin rady nadzorczej/komisji rewizyjnej (jeśli powołane) |
| PSA | umowa spółki | akt notarialny (lub S24) | regulamin zarządu / rady dyrektorów (system monistyczny — art. 300⁷³ i n. KSH), regulamin rady nadzorczej (jeśli system dualistyczny) |
| S.A. | statut | akt notarialny | regulamin zarządu, regulamin rady nadzorczej, regulamin walnego zgromadzenia |

> ℹ️ TERMINOLOGIA "umowa spółki" vs "statut": dla spółek osobowych i sp.
> z o.o. dokument nazywa się "umową spółki"; dla S.A., PSA i S.K.A. —
> "statutem". Różnica głównie terminologiczna/formalna, ale statut bywa
> bardziej "instytucjonalny" (mniej zależny od tożsamości konkretnych
> wspólników, łatwiej zbywalne akcje).

### Founders' Agreement (umowa założycielska) — dokument NIEZALEŻNY od formy

```
✅ VER online 2026-06-15 (Legal Geek, RPMS, Creativa Legal i inne — zgodne
źródła branżowe; brak regulacji ustawowej — dokument oparty na art. 353¹ KC,
swoboda umów)

CHARAKTER:
- NIE jest tym samym co umowa spółki/statut — NIE tworzy odrębnego podmiotu,
  NIE jest obligatoryjny
- może istnieć RÓWNOLEGLE z umową spółki, regulując kwestie, których
  wspólnicy nie chcą umieszczać w (publicznym, jawnym w KRS) dokumencie
  spółki

ETAPY ZASTOSOWANIA:
1. PRZED rejestracją spółki (pre-formation) — substytut/zarys przyszłej
   umowy spółki, gdy founderzy mają już plan, ale spółka jeszcze nie istnieje
2. PRZY rejestracji — jako dokument UZUPEŁNIAJĄCY umowę spółki (szczególnie
   przy S24, gdzie umowa spółki ma formę uproszczonego wzorca)
3. W TRAKCIE działania spółki — doprecyzowanie/zmiana relacji między
   wspólnikami (nowi wspólnicy, zmiana ról)
4. PRZY ZAKOŃCZENIU współpracy — rozliczenie wypracowanych korzyści/praw

TYPOWA TREŚĆ (minimum 9 elementów wg branżowych wzorców):
□ podział udziałów/akcji (w tym zasady zmiany podziału)
□ wkłady wspólników (pieniężne, niepieniężne, praca/usługi — PSA dopuszcza
  wkład w postaci pracy/usług na kapitał akcyjny)
□ role i obowiązki founderów (kto za co odpowiada operacyjnie)
□ VESTING i REVERSE VESTING:
  - vesting: prawo do udziałów "nabywane" w czasie (typowo 4 lata, 1 rok
    cliff = brak nabycia przed upływem roku)
  - reverse vesting: jeśli founder odchodzi przed końcem vestingu, spółka/
    pozostali wspólnicy mogą odkupić jego NIEnabytą część
□ własność intelektualna: przeniesienie praw IP wytworzonych przez
  founderów na spółkę (kluczowe — bez tego spółka może NIE mieć praw do
  własnego produktu! → patrz analizator-umow-v1/J9)
□ wynagrodzenia founderów (czy i kiedy zaczynają, z jakiego budżetu)
□ procedury decyzyjne (większości głosów, weto, sprawy wymagające zgody
  wszystkich)
□ zakaz konkurencji po odejściu (okres, zakres, ekwiwalent — patrz
  analizator-umow-v1/zakaz-konkurencji.md)
□ poufność (NDA) — zakres, okres, sankcje
□ mechanizmy wyjścia/rozstania:
  - lock-up (zakaz sprzedaży udziałów przez określony czas)
  - prawo odkupu (od odchodzącego founder'a)
  - shotgun clause (jedna strona proponuje cenę, druga musi sprzedać LUB
    kupić po tej cenie)
  - procedura przy sytuacji patowej (deadlock): rozmowy → mediacja →
    arbitraż/sąd

⚠️ PUŁAPKA PRAWNA: jeśli founders' agreement zawierany jest PRZED rejestracją
spółki handlowej i strony dążą do wspólnego celu gospodarczego przez wkłady
— może zostać zakwalifikowany jako UMOWA SPÓŁKI CYWILNEJ (art. 860 KC) ze
wszystkimi tego skutkami (solidarna odpowiedzialność!), nawet jeśli strony
tego nie chciały. REKOMENDACJA: zawrzeć w founders' agreement WYRAŹNE
zastrzeżenie wyłączające zastosowanie przepisów o spółce cywilnej, jeśli
strony nie chcą takiego skutku.

KOLEJNOŚĆ DOKUMENTÓW PRZY WEJŚCIU INWESTORA (osobny etap, nie część FA):
Founders' Agreement → (gdy pojawia się inwestor) → Term Sheet / LOI →
Umowa inwestycyjna (reguluje m.in. powoływanie zarządu, prawa nadzorcze
inwestora, exit plan) → SHA (umowa wspólników/akcjonariuszy, post-investment)
→ patrz analizator-umow-v1/mod-MA-transakcje.md (MA.2 — LOI/Term Sheet,
MA.4 — SHA)
```

### Regulaminy organów spółek kapitałowych — kiedy wymagane / fakultatywne

```
ZARZĄD (sp. z o.o., PSA, S.A.):
- regulamin zarządu zwykle FAKULTATYWNY (chyba że umowa/statut wymaga) —
  ustala podział kompetencji, kworum, sposób podejmowania uchwał zarządu,
  reprezentację
- weryfikuj: czy umowa spółki/statut PRZEWIDUJE obowiązek uchwalenia
  regulaminu i KTO go uchwala (zarząd sam / zgromadzenie wspólników / RN)

RADA NADZORCZA / RADA DYREKTORÓW:
- sp. z o.o.: RN fakultatywna (poza wyjątkami ustawowymi — np. spółki
  powyżej określonych progów, weryfikuj art. 213 KSH)
- S.A.: RN OBLIGATORYJNA (art. 381 i n. KSH)
- S.K.A.: RN obligatoryjna przy >25 akcjonariuszach (weryfikuj art. 142 KSH)
- PSA: SYSTEM DUALISTYCZNY (zarząd + RN, jak w sp. z o.o./S.A.) ALBO
  SYSTEM MONISTYCZNY (rada dyrektorów łącząca funkcje zarządcze i nadzorcze
  — art. 300⁷³ i n. KSH) — wybór systemu w umowie spółki
- regulamin RN/rady dyrektorów: tryb posiedzeń, kworum, kompetencje
  nadzorcze, ew. delegowanie członków do indywidualnego nadzoru

WALNE ZGROMADZENIE (S.A., PSA w wariancie z walnym):
- regulamin walnego zgromadzenia: zwykle fakultatywny, reguluje organizację
  obrad, sposób głosowania, prowadzenie protokołu

⚠️ HIERARCHIA: statut/umowa spółki > regulamin organu. Regulamin NIE może
być sprzeczny ze statutem/umową — w razie kolizji statut/umowa ma
pierwszeństwo. Zmiana regulaminu zwykle wymaga niższego kworum/formy niż
zmiana statutu (która wymaga aktu notarialnego — art. 255 §3, 430 §1 KSH —
weryfikuj).
```

---

## WERYFIKACJA ONLINE

```
web_search: "KSH kodeks spółek handlowych isap.sejm.gov.pl Dz.U. 2024 poz. 18 tekst jednolity"
web_search: "art 299 KSH odpowiedzialność zarządu orzecznictwo SN przesłanki"
web_search: "wniosek o upadłość termin 30 dni art 21 PrUp orzecznictwo"
web_search: "zaskarżenie uchwały sp z o.o. termin art 251 252 KSH"
web_search: "Prawo przedsiębiorców tekst jednolity isap działalność nierejestrowana limit aktualny"
web_search: "minimalne wynagrodzenie za pracę 2026 kwota działalność nierejestrowana limit kwartalny"
web_search: "kapitał minimalny prosta spółka akcyjna art 300(2) KSH aktualne brzmienie"
```

---

## ŁĄCZ Z

| Sytuacja | Skill / Moduł |
|---|---|
| Upadłość / restrukturyzacja | `mod-PrUpad-upadlosc-restrukturyzacja` |
| Status syndyka/nadzorcy/zarządcy (zawód) | `mod-ustawa-doradca-restrukturyzacyjny-zawod` |
| Analiza umowy (B2B, spółka) | `analizator-umow-v1` |
| Redakcja/analiza: umowa spółki, statut, regulamin organu, founders' agreement | `analizator-umow-v1` → `mod-FA-founders-dokumenty-zalozycielskie.md` (J.20) |
| M&A — SPA/SHA/LOI (etap post-formation / inwestycja) | `analizator-umow-v1` → `mod-MA-transakcje.md` |
| Pismo: wniosek o upadłość, zgłoszenie wierzytelności | `pisma-procesowe-v3` |
| Rejestracja JDG / działalność nierejestrowana — pisma do CEIDG | `pisma-proste-v2` (jeśli dotyczy prostego wniosku) |
| Orzecznictwo SN gospodarcze | `orzeczenia-sadowe-v2` |
| KRS (rejestr spółki) | `mod-ustawa-KRS-rejestr-sadowy` |
| UZNK (nieuczciwa konkurencja) | `mod-ustawa-UZNK-nieuczciwa-konkurencja` |
| Opodatkowanie form działalności (PIT/CIT/ryczałt) | DR-06 → `mod-PIT-podatek-dochodowy-fizyczne`, `mod-CIT-podatek-dochodowy-prawne`, `mod-ustawa-ryczalt-przychody` |

---

## ŹRÓDŁA ONLINE

- KSH: https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20240000018
- PrUp: https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20250000614
- Prawo przedsiębiorców (t.j. 2025/1480): https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20250001480
- Nowelizacja art. 5 (działalność nierejestrowana, Dz.U. 2025/769): https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20250000769
- KC (spółka cywilna, art. 860–875): https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20250001071
- KRS online: https://ekrs.ms.gov.pl
- CEIDG online: https://www.biznes.gov.pl/pl/firma/ceidg

---

## UMOWY B2B — KLUCZOWE ELEMENTY

```
□ Strony: NIP, REGON, KRS / CEIDG — ZAWSZE weryfikuj w rejestrze przed podpisaniem
□ Przedmiot: precyzyjny opis + parametry jakościowe / ilościowe
□ Wynagrodzenie: stałe / zmienne + VAT / netto + termin płatności
□ Kara umowna: TYLKO za zobowiązania NIEPIENIĘŻNE (art. 483 KC)
□ Zakaz konkurencji: ograniczony terytorialnie + zakres + ekwiwalent
□ Poufność (NDA): czas trwania + zakres + sankcja umowna
□ Prawo właściwe + sąd właściwy (klauzula jurysdykcyjna)
□ Rozwiązanie: tryb + wypowiedzenie + skutki
□ Siła wyższa (force majeure): definicja + skutki
```

---

## PROKURA (art. 109¹ i n. KC)

```
Prokura = pełnomocnictwo handlowe udzielane przez zarząd spółki
Zakres: wszystkie czynności związane z prowadzeniem przedsiębiorstwa
  WYJĄTKI (wymagają pełnomocnictwa szczególnego):
  → Zbycie lub obciążenie nieruchomości
  → Ustanowienie prokury (nie może subprokurent)

Formy prokury:
  → Samoistna: prokurent działa samodzielnie
  → Łączna: kilku prokurentów musi działać razem (LUB z członkiem zarządu)
  → Oddziałowa: ograniczona do oddziału spółki

Wpis prokury do KRS jest OBOWIĄZKOWY — sprawdzaj KRS przed zawarciem umowy.
```


---

## QUALITY GATE

- [ ] Aktualny tekst t.j. aktu zweryfikowany w ISAP?
- [ ] Stan prawny właściwy temporalnie (na dzień zdarzenia i na dzień orzekania)?
- [ ] Każda przesłanka ma przypisany dowód?
- [ ] Termin nie upłynął?
- [ ] Właściwy organ / sąd wskazany?
- [ ] Ryzyka formalne i dowodowe ocenione?
- [ ] Brzmienie przepisów pobrane ze źródeł, nie z pamięci modelu?
- [ ] Jeśli sprawa dotyczy WYBORU FORMY DZIAŁALNOŚCI — czy rozważono pełną
      drogę (nierejestrowana → JDG → cywilna → osobowa → kapitałowa) i
      kluczowe osie różnic (odpowiedzialność, rejestracja, opodatkowanie)?
- [ ] Jeśli sprawa dotyczy DOKUMENTU ZAŁOŻYCIELSKIEGO/WEWNĘTRZNEGO (umowa
      spółki, statut, regulamin organu, founders' agreement) — czy
      rozróżniono dokument "konstytucyjny" (umowa/statut) od dokumentów
      pomocniczych (regulaminy, founders' agreement) i sprawdzono hierarchię
      (statut/umowa > regulamin)?
- [ ] Jeśli founders' agreement zawierany PRZED rejestracją spółki — czy
      sprawdzono ryzyko niezamierzonej kwalifikacji jako spółka cywilna
      (art. 860 KC) i potrzebę zastrzeżenia wyłączającego?
- [ ] Przy działalności nierejestrowanej — czy zweryfikowano AKTUALNĄ kwotę
      minimalnego wynagrodzenia (limit = 225% tej kwoty, kwartalnie)?

## OUTPUT

Wynik pracy modułu:
1. Stan faktyczny;
2. Stan prawny i źródła (Dz.U. z ISAP);
3. Kwalifikacja trybu i właściwość;
4. Terminy (obliczone, z datami granicznymi);
5. Przesłanki (spełnione / wątpliwe / niespełnione);
6. Matryca dowodowa (teza → dowód → siła → luka);
7. Zarzuty i kontrargumenty;
8. Analiza ryzyk;
9. Strategia (wariant podstawowy + ewentualny);
10. Rekomendacja + kolejne kroki;
11. Kontrola ISAP/temporalności.

---

## STRATEGIA

### Perspektywa wierzyciela spółki z o.o.

1. Sprawdź KRS — aktualny skład zarządu (ekrs.ms.gov.pl).
2. Jeśli egzekucja bezskuteczna → pozew przeciwko członkom zarządu (art. 299 KSH).
3. Sprawdź czy złożono wniosek o upadłość w terminie 30 dni — jeśli nie → podstawa roszczenia.
4. Oceń czynności bezskuteczne (przesunięcia majątkowe przed upadłością) → skarga pauliańska.

### Perspektywa zarządu zagrożonej spółki

1. Monitoruj test niewypłacalności (art. 11 PrUp) — termin 30 dni biegnie od jego zaistnienia.
2. Złóż wniosek o restrukturyzację przed złożeniem wniosku o upadłość — ochrona przed egzekucją.
3. Dokumentuj przesłanki uwolnienia się od odpowiedzialności (art. 299 §2 KSH).
4. Uchwały ważne formalnie → zachowaj wymagane kworum, formę i głosowanie.

### Ryzyka

| Ryzyko | Opis | Działanie zaradcze |
|---|---|---|
| Termin 30 dni na wniosek o upadłość | Przekroczenie = odpow. osobista zarządu | Monitoring kondycji finansowej spółki |
| Nieważna uchwała (brak formy) | Art. 17 KSH — nieważność bezwzgl. | Akt notarialny przy zmianach umowy/statutu |
| Zaskarżenie uchwały | Termin 1/6 m-cy od powzięcia / doręczenia | Prawidłowe doręczenie uchwał wszystkim wspólnikom |
| Prokurent przekracza umocowanie | Brak skutku wobec spółki | Sprawdzaj wpisy prokury w KRS |
