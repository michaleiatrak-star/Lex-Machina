# KC — część 1: przedawnienie, kara umowna, wady oświadczenia woli, bezpodstawne wzbogacenie, odsetki

> Część modułu `mod-KC-cywilne-zobowiazania-odpowiedzialnosc.md`
> (podział 2026-08-20, naprawa F-78 — plik źródłowy przekroczył 1300
> linii). Pełny indeks i zasady użycia: zobacz plik nadrzędny w katalogu
> `modules/`. To NIE jest samodzielny skill — ładowany WYŁĄCZNIE przez
> indeks nadrzędny na żądanie konkretnej części.

---

## 4. TERMINY PRZEDAWNIENIA — TABELA (art. 118 i n. KC)

> ⚠️ Weryfikuj aktualne brzmienie w ELI (RZĄD 1). Od 2018 r. sąd bada przedawnienie Z URZĘDU gdy dłużnikiem jest konsument.

| Roszczenie | Termin | Art. KC | Uwagi |
|---|---|---|---|
| Ogólny | 6 lat | art. 118 | Koniec: ostatni dzień roku kalendarzowego |
| Z działalności gospodarczej | 3 lata | art. 118 | Między przedsiębiorcami |
| Delikt — od wiedzy | 3 lata | art. 442¹ § 1 | Od dowiedzenia się o szkodzie i sprawcy |
| Delikt — max | 10 lat | art. 442¹ § 1 | Od zdarzenia |
| Delikt — zbrodnia/występek | 20 lat | art. 442¹ § 2 | Od popełnienia |
| Sprzedaż w zakresie działalności przedsiębiorstwa sprzedawcy (także rzemieślnik, płody rolne) | 2 lata | art. 554 | Inna sprzedaż — art. 118 |
| Dzieło | 2 lata | art. 646 | Od oddania dzieła |
| Zachowek | 5 lat | art. 1007 | § 1: od ogłoszenia testamentu; § 2–4 (uzupełnienie od obdarowanego, zapisobiercy windykacyjnego, fundacji rodzinnej): od otwarcia spadku |
| Wyrok / ugoda sądowa | 6 lat | art. 125 | Od uprawomocnienia |
| Skarga pauliańska | 5 lat | art. 534 | Od daty pokrzywdzającej czynności |

**Zawezwanie do próby ugodowej:** przerywa bieg przedawnienia WYŁĄCZNIE gdy złożone w dobrej wierze — weryfikuj aktualną linię orzeczniczą SN.

---


---

## 5. KARA UMOWNA (art. 483–484 KC)

```
Zastrzeżenie możliwe: WYŁĄCZNIE przy zobowiązaniach NIEPIENIĘŻNYCH
  → za zobowiązania pieniężne: odsetki, nie kara umowna

MIARKOWANIE (art. 484 §2) — dwie samoistne podstawy:
  □ Zobowiązanie zostało w znacznej części wykonane
  □ Kara jest rażąco wygórowana
    (mierniki: stosunek kary do wartości całej umowy,
     stosunek kary do poniesionej szkody — choćby zerowej,
     stopień winy dłużnika, charakter naruszenia)

Charakter procesowy: miarkowanie = wniosek strony (sąd NIE działa z urzędu)
Skutek miarkowania: zmniejszenie kary, nie jej uchylenie
```

---


---

## 6. WADY OŚWIADCZENIA WOLI — KWALIFIKATOR

> ⚠️ Brzmienie każdego artykułu — weryfikuj w aktualnym KC w ELI (RZĄD 1).

| Wada | Art. KC | Skutek | Termin uprawnienia |
|---|---|---|---|
| Brak świadomości lub swobody | art. 82 | Bezwzględna nieważność | Brak — nieważne z mocy prawa |
| Pozorność | art. 83 | Bezwzględna nieważność | Brak — nieważne z mocy prawa |
| Błąd co do treści | art. 84 | Wzruszalność | 1 rok od wykrycia (art. 88 § 2) |
| Podstęp | art. 86 | Wzruszalność | 1 rok od wykrycia błędu (art. 88 § 2) |
| Groźba | art. 87 | Wzruszalność | 1 rok od ustania obawy (art. 88 § 2); oświadczenie na piśmie (art. 88 § 1) |
| Wyzysk | art. 388 | Zmiana lub unieważnienie | 3 lata od zawarcia umowy (6 lat — konsument), art. 388 § 2 |

**Art. 388 §1¹ KC (domniemanie wyzysku):** jeżeli wartość świadczenia jednej strony przewyższa co najmniej dwukrotnie wartość świadczenia wzajemnej — domniemywa się rażącą dysproporcję.

---


---

## 7. BEZPODSTAWNE WZBOGACENIE (art. 405–414 KC)

```
Cztery przesłanki łącznie:
  □ Wzbogacenie po stronie pozwanego
  □ Zubożenie po stronie powoda
  □ Związek między wzbogaceniem a zubożeniem (kosztem zubożonego)
  □ Brak podstawy prawnej (causa)

Nie wymaga winy ani bezprawności.
Granica roszczenia: aktualne wzbogacenie (art. 409 KC) — może zmaleć lub zniknąć.
Przedawnienie: 6 lat ogólne / 3 lata przy działalności gosp. (art. 118 KC).
```

---


---

## 9. ODSETKI ZA OPÓŹNIENIE (art. 481 KC)

> ⚠️ Aktualna stopa referencyjna NBP zmienia się decyzją RPP — weryfikuj przed każdą sprawą: nbp.pl

```
Odsetki ustawowe za opóźnienie (art. 481 §2):
  stopa referencyjna NBP + 5,5 pkt proc.

Odsetki maksymalne za opóźnienie (art. 481 §2¹):
  dwukrotność odsetek ustawowych za opóźnienie

Odsetki w transakcjach handlowych:
  → view modules/mod-transakcje-handlowe-opoznienia.md
  Kwalifikacja, terminy, stawki i rekompensata wyłącznie w tym module.
  Nie przenoś poniższej reguły wezwania z KC do art. 6 ustawy handlowej.

Od kiedy liczyć:
  → dzień po upływie terminu płatności z umowy / faktury
  → dzień po wezwaniu (świadczenie bezterminowe — art. 455 KC)
```

---
