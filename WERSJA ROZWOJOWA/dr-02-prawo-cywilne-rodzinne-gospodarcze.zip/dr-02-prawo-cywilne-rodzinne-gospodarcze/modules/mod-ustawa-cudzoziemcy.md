# mod-ustawa-cudzoziemcy [PERSPEKTYWA PRAWA PRYWATNEGO — zatrudnienie, umowy, sankcje pracodawcy]

**Akt:** UCudz (ustawa o cudzoziemcach) — t.j. Dz.U. 2025 poz. 1079 (zm. 2025/1794 od 2026-01-01 — m.in. art. 2, 3, 7, 13, 24, 58–58b, 64a, 99, 104–105, 144–144a; 2026/203 od 2026-03-05 — m.in. art. 25–25a, 60, 77c–77d, 87–87a, 113b–113c, 120b–120c, 207a–207b, 223–223a, 299, 334, 449–451).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1; poprawka: pobyt stały — przesłanki z art. 195 ust. 1, brak ogólnej ścieżki „5 lat pobytu”).

**Zakres modułu (DR-02):** Uprawnienia do pracy cudzoziemców, typy zezwoleń, kary dla pracodawcy, ścieżka odwoławcza od decyzji UW → SZUSC → WSA. Koncentracja na relacji pracodawca–cudzoziemiec i legalizacji zatrudnienia.
**Wersja kanoniczna (pełna) — prawo administracyjne, wydalenie, procedura, pełna taksonomia tytułów pobytowych:** `dr-05` → `mod-ustawa-cudzoziemcy.md`
**Świadome utrzymanie dwóch wersji:** TAK — DR-02 = zakres cywilno-pracowniczy (pobyt + praca), DR-05 = pełny moduł administracyjny (ścieżka procesowa, wydalenie, ochrona międzynarodowa, pełne matrycy). Przy sprawach wielowątkowych ładuj DR-05.

**Źródło weryfikacji:** Ustawa o cudzoziemcach — Dz.U. 2025 poz. 1079 t.j. ze zm. (zm.: Dz.U. 2026 poz. 203) | Ustawa o warunkach dopuszczalności powierzania pracy cudzoziemcom — Dz.U. 2025 poz. 621 (w życie 01.06.2025)
**Data weryfikacji online:** 2026-06-05
**ZASADA:** Każde brzmienie przepisu przed powołaniem → isap.sejm.gov.pl
**⚠️ Przepisy imigracyjne są BARDZO często nowelizowane — weryfikuj ZAWSZE aktualne brzmienie.**

---

## FAZA 0 — INTAKE

```
□ Jaki problem: karta pobytu / praca / wydalenie / ochrona międzynarodowa / obywatelstwo?
□ Jaka podstawa pobytu: Karta Polaka / UE / małżeństwo / praca / nauka / inne?
□ Czy wniosek złożono przed upływem legalnego pobytu? (KRYTYCZNE!)
□ Jakie decyzje organu I instancji? Kiedy doręczona?
□ Termin na odwołanie: 14 dni od doręczenia decyzji UW
□ Czy pracodawca zatrudnił cudzoziemca bez zezwolenia? → ryzyko kary od 3 000 zł
□ Status postępowania: gdzie jest sprawa — UW / SZUSC / WSA?
```

---

## TYPY ZEZWOLEŃ NA POBYT (Dz.U. 2025 poz. 1079 — weryfikuj przesłanki w ELI (RZĄD 1))

| Typ | Okres | Praca | Podstawowe warunki (orientacyjne) |
|---|---|---|---|
| Wiza Schengen (C) | max 90 dni / 180 dni | NIE | Cel: turystyka, biznes, odwiedziny — zakaz pracy |
| Wiza krajowa (D) | do 1 roku | Zależy od celu (pkt 5, 5a, 6, 9 = TAK; pkt 1, 2, 11, 14, 20, 23 = NIE) | 25 celów; studia/badania/praca/łączenie rodzin; weryfikuj art. 60 u.c. |
| Pobyt czasowy — praca (jednolite) | do 3 lat | TAK (u wskazanego pracodawcy) | Pracodawca składa wniosek; nowa ustawa Dz.U. 2025 poz. 621 |
| Pobyt czasowy — nauka | do 1 roku (przedłuż.) | TAK (studenci dzienni bez limitu) | Zaświadczenie z uczelni; reforma Dz.U. 2025 poz. 622 |
| Pobyt czasowy — Niebieska Karta UE (art. 127) | do 3 lat (art. 98 ust. 2) | TAK (pełny dostęp rynku od 01.06.2025) | Studia wyższe LUB 5 lat dośw.; wynagrodz. ≥ 150% przeciętnego |
| Pobyt czasowy — ICT | do 3 lat | TAK (jednostka przyjmująca) | Przeniesienie wewnątrz przedsięb. z kraju poza UE; art. 139a u.c. |
| Pobyt czasowy — łączenie rodzin | do 3 lat | TAK | Sponsor z tytułem pobytowym; dochód; ubezpieczenie |
| Pobyt stały | Bezterminowy | TAK (pełny dostęp) | art. 195 ust. 1 u.c. — m.in.: dziecko obywatela PL (pkt 2); polskie pochodzenie (pkt 3); małżonek obywatela PL: ≥ 3 lata małżeństwa **i** ≥ 2 lata nieprzerwanego pobytu na zezwoleniu z tego tytułu (pkt 4); 5 lat ze statusem uchodźcy/ochroną uzupełniającą/zgodą humanitarną, 10 lat zgody tolerowanej, 4 lata z art. 114 ust. 1a (pkt 6); Karta Polaka (pkt 9). Brak ogólnej ścieżki „5 lat pobytu” — to rezydent UE (art. 211) |
| Rezydent długoterminowy UE | Bezterminowy | TAK (pełny dostęp + mobilność UE) | 5 lat ciągłego pobytu; dochód; ubezpieczenie; j. polski; art. 211 u.c. |
| Status uchodźcy / ochron. uzupeł. | do 2 lat (przedłuż.) | TAK bez zezwoleń | Konwencja Genewska / ryzyko krzywdy |
| PESEL UKR (ochrona tymczasowa) | do 4.03.2027 (dotychczasowi beneficjenci) | TAK (powiadomienie PUP w 7 dni, praca.gov.pl) | ⛔ POPRAWKA 2026-07-02 (WARN-27): OD 5.03.2026 reżim przeniesiony do ustawy o udzielaniu cudzoziemcom ochrony na terytorium RP + ustawy o warunkach dopuszczalności powierzania pracy cudzoziemcom (Dz.U. 2025 poz. 621) — dawna specustawa 2022.583 w istotnym zakresie wygaszona ustawą z 23.01.2026 (Dz.U. 2026 poz. 203). Pełny opis: DR-05/mod-ustawa-cudzoziemcy.md ANEKS A |

> ⚠️ Warunki orientacyjne — weryfikuj dokładne przesłanki w aktualnej ustawie w ELI (RZĄD 1).
> Pełny wykaz celów wizy D (art. 60 u.c.) i matryca dokument → uprawnienie do pracy:
> ```
> view dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-ustawa-cudzoziemcy.md
> ```

---

## PRACA CUDZOZIEMCÓW — NOWA USTAWA OD 01.06.2025

> **Podstawa:** Ustawa o warunkach dopuszczalności powierzania pracy cudzoziemcom — Dz.U. 2025 poz. 621

```
KLUCZOWE ZMIANY od 01.06.2025:
  → Wnioski i oświadczenia o powierzeniu pracy: WYŁĄCZNIE ELEKTRONICZNIE przez praca.gov.pl
  → Zastępuje przepisy o zezwoleniach z ustawy o promocji zatrudnienia

KARY DLA PRACODAWCY za nielegalne zatrudnienie:
  → NIE mniej niż 3 000 zł za każdego nielegalnie zatrudnionego cudzoziemca
  → MAX 50 000 zł (łącznie)
  → Inspektorzy pracy: mandat do 10 000 zł

Zwolnienie z zezwolenia na pracę:
  → Obywatele UE/EOG/Szwajcarii
  → Absolwenci polskich uczelni (dziennych studiów)
  → Posiadacze Karty Polaka
  → inne zwolnienia — weryfikuj aktualny art. 3 ustawy Dz.U. 2025 poz. 621 w ELI (RZĄD 1)
```

---

## ŚCIEŻKA ODWOŁAWCZA

```
Decyzja Urzędu Wojewódzkiego (UW)
  ↓ Odwołanie — TERMIN: 14 dni od doręczenia (art. 129 §2 KPA)
    → Za pośrednictwem Wojewody do SZUSC
    ⚠️ Złożone w terminie → POBYT LEGALNY do decyzji SZUSC (stempel/zaświadczenie)
    ⚠️ Niepodjęta przesyłka: doręczenie z upływem 14. dnia od I awizo → termin biegnie!

Szef Urzędu ds. Cudzoziemców (SZUSC)
  ↓ Skarga do WSA — TERMIN: 30 dni od doręczenia decyzji SZUSC
    → Art. 54 §1 PPSA (Dz.U. 2026 poz. 143 t.j.)
    → Za pośrednictwem SZUSC

WSA → ewentualnie NSA (skarga kasacyjna)
```

---

## OCHRONA MIĘDZYNARODOWA (uchodźcy)

```
Podstawa: art. 1A Konwencji Genewskiej 1951 + ustawa o udzielaniu cudzoziemcom ochrony
Organ: Szef Urzędu ds. Cudzoziemców (SZUSC)

Formy ochrony:
  → Status uchodźcy (prześladowanie ze względu na rasę, religię, narodowość, poglądy, przynależność do grupy)
  → Ochrona uzupełniająca (ryzyko poważnej krzywdy — nie spełnia warunków uchodźcy)
  → Pobyt tolerowany (wydalenie byłoby sprzeczne z zobowiązaniami RP)
  → Azyl (szczególne okoliczności — przepis krajowy)
```

---

## WERYFIKACJA ONLINE

```
web_search: "ustawa cudzoziemcy isap.sejm.gov.pl Dz.U. 2025 poz. 1079 tekst jednolity"
web_search: "ustawa praca cudzoziemcy Dz.U. 2025 poz. 621 isap.sejm.gov.pl"
web_search: "karta pobytu stały rezydent UE przesłanki 2025 2026 procedura"
web_search: "kara pracodawca nielegalne zatrudnienie cudzoziemiec PIP 2025"
```

---

## ŁĄCZ Z

| Sytuacja | Skill / Moduł |
|---|---|
| Pismo: odwołanie od decyzji UW, skarga do WSA | `pisma-procesowe-v3` |
| Prawo administracyjne / WSA / NSA | `dr-05` |
| Prawo pracy cudzoziemców | `dr-04` |
| Orzecznictwo NSA (cudzoziemcy) | `orzeczenia-sadowe-v2` |

---

## ŹRÓDŁA ONLINE

- Ustawa o cudzoziemcach: https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20250001079
- Ustawa o pracy cudzoziemców: https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20250000621
- Urząd ds. Cudzoziemców: https://udsc.gov.pl
- praca.gov.pl (wnioski elektroniczne): https://praca.gov.pl


---

## QUALITY GATE

- [ ] Aktualny tekst t.j. aktu zweryfikowany w ISAP?
- [ ] Stan prawny właściwy temporalnie (na dzień zdarzenia i na dzień orzekania)?
- [ ] Każda przesłanka ma przypisany dowód?
- [ ] Termin nie upłynął?
- [ ] Właściwy organ / sąd wskazany?
- [ ] Ryzyka formalne i dowodowe ocenione?
- [ ] Brzmienie przepisów pobrane ze źródeł, nie z pamięci modelu?

## OUTPUT

Wynik pracy modułu:
1. Stan faktyczny;
2. Stan prawny i źródła (Dz.U. z ISAP);
3. Kwalifikacja trybu i właściwość;
4. Terminy (obliczone, z datami granicznymi);
5. Przesłanki (spełnione / wątpliwe / niespełnione);
6. Matryca dowodowa (teza → dowód → siła → luka);
7. Zarzuty i kontrargumenty;
8. Analiza ryzyk;
9. Strategia (wariant podstawowy + ewentualny);
10. Rekomendacja + kolejne kroki;
11. Kontrola ISAP/temporalności.

---

## STRATEGIA

### Perspektywa cudzoziemca

1. Złóż wniosek o zezwolenie na pobyt PRZED upływem dotychczasowego tytułu pobytu — złożony w terminie = legalny pobyt do decyzji.
2. Niepodjęcie przesyłki (awizo): doręczenie z mocy prawa po 14 dniach — śledź korespondencję!
3. Odwołanie złożone w terminie (14 dni od doręczenia) = pobyt legalny do decyzji SZUSC.
4. Przy wydaleniu: natychmiast złóż wniosek o wstrzymanie wykonania decyzji do WSA.
5. Elektroniczna obsługa od 01.06.2025 — wszystkie wnioski przez praca.gov.pl.

### Perspektywa pracodawcy

1. Sprawdź status pobytu cudzoziemca PRZED zatrudnieniem.
2. Weryfikuj zezwolenie na pracę / oświadczenie — czy aktualne i czy obejmuje dany rodzaj pracy.
3. Zatrudnienie bez zezwolenia: kara min. 3 000 zł za każdą osobę, max 50 000 zł łącznie.
4. Prowadź dokumentację zatrudnienia cudzoziemców (kopie dokumentów w aktach).

### Ryzyka

| Ryzyko | Opis | Działanie zaradcze |
|---|---|---|
| Upływ tytułu pobytu bez złożenia wniosku | Pobyt nielegalny | Złóż wniosek z wyprzedzeniem |
| Awizo niepodjęte | Decyzja prawomocna — utrata prawa do odwołania | Śledzenie korespondencji / pełnomocnik |
| Praca bez zezwolenia | Kara dla pracodawcy; wydalenie cudzoziemca | Weryfikacja przed zatrudnieniem |
| Cofnięcie zezwolenia | Zmiana okoliczności (pracodawca, stanowisko) | Monitoring warunków zezwolenia |
