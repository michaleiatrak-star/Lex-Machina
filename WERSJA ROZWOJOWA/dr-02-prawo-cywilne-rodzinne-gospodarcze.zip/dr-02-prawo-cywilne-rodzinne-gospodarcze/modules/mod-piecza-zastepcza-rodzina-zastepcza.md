# mod-piecza-zastepcza-rodzina-zastepcza

**Akt:** UWRPZ (ustawa o wspieraniu rodziny i systemie pieczy zastępczej) — t.j. Dz.U. 2026 poz. 980 (stan 2026-07-15; zm. 2026/187 [OD 2028-05-19: 2026/187] — art. 26, 98 (psycholog)).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1; art. 61 ust. 1–2 — limit 8 osób w RDD potwierdzony; art. 85 ust. 1 — kwota bazowa 4 100 zł, waloryzowana kwota oznaczona jako niezweryfikowana).

**Wersja:** 1.0 | **Dodano:** 2026-07-19
**Rola w systemie:** odpowiedź na pytanie użytkownika o "opiekę
zastępczą" — dotąd CAŁKOWITA LUKA w całym systemie, mimo że to
INSTYTUCJA ODRĘBNA od przysposobienia (`mod-KRO-przysposobienie-
adopcja-miedzynarodowa.md`), często z nią mylona.

> ✅ **METRYKA RZĄD 1, VER 2026-08-28:** ustawa z 9.06.2011 o wspieraniu rodziny i systemie pieczy zastępczej — **Dz.U. 2026 poz. 980 t.j.**. Ze względu na częste nowelizacje przed cytowaniem konkretnej jednostki wykonaj fresh hard gate ELI.

---

## 1. ⭐ ROZGRANICZENIE PODSTAWOWE — PIECZA ZASTĘPCZA vs PRZYSPOSOBIENIE

```
PIECZA ZASTĘPCZA (ten moduł) — CZASOWA forma opieki nad dzieckiem, gdy
  rodzice biologiczni NIE MOGĄ (przejściowo lub trwale) sprawować opieki
  — WIĘŹ PRAWNA z rodziną biologiczną NIE USTAJE, władza rodzicielska
  rodziców biologicznych MOŻE być tylko OGRANICZONA (nie zawsze
  odebrana), rodzina zastępcza NIE STAJE SIĘ prawną rodziną dziecka

PRZYSPOSOBIENIE (adopcja, `mod-KRO-przysposobienie-adopcja-
  miedzynarodowa.md`) — TRWAŁA, docelowo NIEODWRACALNA (przy formie
  całkowitej) zmiana STATUSU PRAWNEGO dziecka — przysposabiający
  STAJE SIĘ prawnym rodzicem, więzi z rodziną biologiczną CO DO ZASADY
  USTAJĄ

CEL USTAWOWY POWIĄZANIA: ustawa o wspieraniu rodziny WPROST wskazuje,
  że jednym z CELÓW pieczy zastępczej jest — gdy realizacja planu pracy
  z rodziną biologiczną okazuje się NIEMOŻLIWA — DĄŻENIE do
  PRZYSPOSOBIENIA dziecka. Piecza zastępcza bywa więc PRZEJŚCIOWYM
  ETAPEM prowadzącym docelowo do adopcji, ale to NIE JEST regułą — wiele
  dzieci pozostaje w pieczy zastępczej bez przechodzenia do adopcji
  (np. gdy rodzice biologiczni zachowują ograniczoną władzę rodzicielską
  i utrzymują kontakt).
```

---

## 2. PODSTAWA PRAWNA I ZASADA OGÓLNA

```
□ Ustawa z 9.06.2011 o wspieraniu rodziny i systemie pieczy zastępczej
□ ZASADA: piecza zastępcza JEST SPRAWOWANA w PRZYPADKU NIEMOŻNOŚCI
  zapewnienia dziecku opieki i wychowania PRZEZ RODZICÓW (biologicznych)
□ CELE: zaspokojenie potrzeb EMOCJONALNYCH, BYTOWYCH, ZDROWOTNYCH,
  EDUKACYJNYCH i KULTURALNO-REKREACYJNYCH dziecka; NAWIĄZYWANIE i
  PODTRZYMYWANIE bliskich, osobistych i społecznie akceptowanych
  kontaktów z rodziną i rówieśnikami (łagodzenie skutków doświadczenia
  straty/separacji, zdobywanie umiejętności społecznych)
□ UMIESZCZENIE dziecka w pieczy zastępczej następuje CO DO ZASADY na
  podstawie ORZECZENIA SĄDU (z wyjątkami dla sytuacji nagłych/
  kryzysowych — ⚠️ dokładne wyjątki nie zweryfikowane w pełni w tej
  sesji)
```

---

## 3. DWIE FORMY PIECZY ZASTĘPCZEJ

```
FORMA RODZINNA (preferowana ustawowo, ma mieć "szczególne miejsce"):
  □ RODZINA ZASTĘPCZA SPOKREWNIONA — tworzona przez OSOBY BLISKO
    SPOKREWNIONE z dzieckiem (⭐ TO JEST "ADOPCJA PRZEZ RODZINĘ" w
    potocznym rozumieniu użytkownika — precyzyjniej: OPIEKA, nie
    adopcja, sprawowana przez np. DZIADKÓW, WUJOSTWO, DOROSŁE RODZEŃSTWO
    dziecka — NAJCZĘSTSZY, najbardziej "naturalny" wariant pieczy
    zastępczej)
  □ RODZINA ZASTĘPCZA NIEZAWODOWA — osoby NIESPOKREWNIONE, pełniące
    funkcję bez statusu zawodowego (zwykle 1-3 dzieci)
  □ RODZINA ZASTĘPCZA ZAWODOWA — profesjonalny status, w tym:
    - ZWYKŁA zawodowa
    - PEŁNIĄCA FUNKCJĘ POGOTOWIA RODZINNEGO (dzieci w sytuacjach
      NAGŁYCH/kryzysowych, pobyt zwykle KRÓTKOTRWAŁY)
    - SPECJALISTYCZNA (dzieci z ORZECZENIEM O NIEPEŁNOSPRAWNOŚCI lub
      w stopniu ZNACZNYM/UMIARKOWANYM, oraz — od nowelizacji z 2022 r.
      — dzieci na podstawie ustawy o wspieraniu i resocjalizacji
      nieletnich)
  □ RODZINNY DOM DZIECKA — forma zbliżona do rodziny zastępczej
    zawodowej. ✅ LIMIT ZWERYFIKOWANY 2026-08-13c (art. 61 ustawy,
    t.j. Dz.U. 2026 poz. 980 — 3+ zgodne źródła): **NIE WIĘCEJ NIŻ 8**
    dzieci w tym samym czasie (łącznie z osobami pełnoletnimi
    kontynuującymi pobyt na zasadach art. 37 ust. 2-4/6). WYJĄTEK
    (art. 61 ust. 2): przy konieczności umieszczenia RODZEŃSTWA — za
    zgodą prowadzącego + POZYTYWNĄ opinią koordynatora rodzinnej
    pieczy — dopuszczalne umieszczenie WIĘKSZEJ liczby (⭐ zasada
    NIEROZDZIELANIA rodzeństwa, już wspomniana wyżej w tym module,
    ma tu KONKRETNY mechanizm przełamania limitu).
    ⭐ PRZEKSZTAŁCENIE z rodziny zastępczej zawodowej (art. 61a):
    OBLIGATORYJNE gdy rodzina wychowuje już CO NAJMNIEJ 6 dzieci i ma
    min. 3-letnie doświadczenie — starosta MUSI zawrzeć umowę o
    prowadzenie rodzinnego domu dziecka na wniosek tej rodziny.
  □ RODZINA POMOCOWA — WSPARCIE dla powyższych, na czas np. WYPOCZYNKU
    rodziny zastępczej lub CZASOWEJ niemożności sprawowania opieki

FORMA INSTYTUCJONALNA — ✅ CZĘŚCIOWO UZUPEŁNIONE 2026-08-13c (Rząd 3,
  1 źródło branżowe — domydziecka.org — NIE potwierdzone krzyżowo w
  źródle Rządu 1/2, ⚠️ przed użyciem w piśmie zweryfikować limit
  liczbowy bezpośrednio w art. 95/105 ustawy):
  □ Placówki OPIEKUŃCZO-WYCHOWAWCZE (socjalizacyjne, specjalistyczno-
    terapeutyczne, interwencyjne — art. 93 i nast.) — limit liczby
    dzieci: **max 14** w placówkach utworzonych PO 2011 r., max 30 w
    placówkach STARSZYCH (trwa stopniowe przekształcanie 30-osobowych
    w mniejsze jednostki); od 2.01.2021 r. w nowo tworzonej/
    przekształcanej placówce nie może przebywać więcej niż 14 dzieci.
    Wojewoda MOŻE, w uzasadnionych przypadkach, wyrazić zgodę na
    zwiększenie limitu. Prowadzi POWIAT lub podmiot zlecony (NGO,
    instytucja kościelna).
  □ Regionalne placówki opiekuńczo-terapeutyczne — dla dzieci
    wymagających szczególnej opieki (niepełnosprawność, choroba) —
    ⚠️ szczegółowy limit i procedura NIE zweryfikowane w tej sesji,
    pozostaje punkt startowy.
  □ Interwencyjne ośrodki preadopcyjne — ⚠️ szczegóły NIE zweryfikowane
    w tej sesji, pozostaje punkt startowy (niski priorytet — rzadka
    forma).
```

### Wynagrodzenie (przykład orientacyjny, ⚠️ ZAWSZE zweryfikuj aktualne stawki — ustalane lokalnie przez rady powiatów/miast, WALORYZOWANE)

```
Orientacyjne kwoty miesięczne — ⚠️ UZUPEŁNIONE 2026-07-27 (FAZA 3E/
ZASADA 14): to NIE są stawki ogólnokrajowe sztywne, tylko WYNIK
lokalnych uchwał POSZCZEGÓLNYCH POWIATÓW, każdy powyżej ustawowego
MINIMUM. Art. 85 ust. 1 t.j. 2026/980: wynagrodzenie zawodowej rodziny
zastępczej/RDD nie niższe niż **4 100 zł** (kwota z ustawy); ust. 2 —
pogotowie rodzinne nie mniej niż 124% tej kwoty. Kwota po waloryzacji
(w module: 4 902 zł / ok. 6 079 zł) ⚠️ [NIEWERYFIKOWANE] — sprawdź aktualne
obwieszczenie waloryzacyjne przed powołaniem. POTWIERDZONY REALNY ZAKRES między powiatami
(2026 r.): od ustawowego minimum do znacznie wyższych stawek lokalnych
(np. Świebodzin: pogotowie 9 136 zł, RDD 9 136 zł; Puławy: pogotowie
6 079 zł, zawodowa 4 902 zł; Szczecinek: pogotowie 124%×6000 zł=7 440
zł) — RÓŻNICE SIĘGAJĄ KILKU TYSIĘCY ZŁOTYCH między powiatami. ZAWSZE
sprawdź uchwałę KONKRETNEGO powiatu, którego dotyczy sprawa — nie ma
jednej "krajowej" kwoty do zacytowania.
  □ Rodzina zastępcza — pogotowie rodzinne: min. ustawowe ok. 6 079 zł,
    lokalnie może być WYŻSZE (potwierdzony przykład: 9 136 zł)
  □ Zawodowa rodzina zastępcza: min. ustawowe ok. 4 902 zł, lokalnie
    może być wyższe
  □ Prowadzący rodzinny dom dziecka: min. ustawowe jak zawodowa
    (4 902 zł), lokalnie może być znacznie wyższe (potwierdzony
    przykład: 9 136 zł)
Rodzina zastępcza SPOKREWNIONA i NIEZAWODOWA — inny, zwykle NIŻSZY
  poziom wsparcia finansowego (⚠️ zweryfikuj dokładne zasady i kwoty)
```

---

## 4. PROCEDURA UMIESZCZENIA DZIECKA

```
□ Zawiadomienie SĄDU (np. przez szkołę, ośrodek pomocy społecznej,
  policję, sąsiadów) o sytuacji dziecka
□ POWIATOWE CENTRUM POMOCY RODZINIE (PCPR) informuje sąd o DOSTĘPNYCH
  rodzinach zastępczych/rodzinnych domach dziecka/placówkach
  odpowiednich dla danego dziecka
□ SĄD orzeka o umieszczeniu (co do zasady) — z uwzględnieniem
  PIERWSZEŃSTWA form RODZINNYCH nad instytucjonalnymi oraz
  PIERWSZEŃSTWA rodziny SPOKREWNIONEJ, jeśli to możliwe i zgodne z
  dobrem dziecka
□ PRZENIESIENIE dziecka między rodzinami zastępczymi — dotychczasowa
  rodzina PRZEKAZUJE dokumentację NOWEJ rodzinie (za pośrednictwem
  organizatora rodzinnej pieczy zastępczej), NIE PÓŹNIEJ niż w dniu
  przeniesienia
□ MOŻLIWOŚĆ TRANSGRANICZNA: piecza zastępcza MOŻE być czasowo
  powierzona przez sąd rodzinie zastępczej NIEZAMIESZKUJĄCEJ w Polsce
  — WYJĄTKOWO, gdy ta rodzina SPRAWUJE JUŻ pieczę nad RODZEŃSTWEM tego
  dziecka (zasada NIEROZDZIELANIA rodzeństwa) — przed takim
  rozstrzygnięciem sąd ZASIĘGA OPINII właściwego STAROSTY
```

---

## 5. WSPÓŁPRACA Z OŚRODKIEM ADOPCYJNYM

Rodzina zastępcza oraz prowadzący rodzinny dom dziecka WSPÓŁPRACUJĄ z:
OŚRODKIEM ADOPCYJNYM, KOORDYNATOREM rodzinnej pieczy zastępczej,
ORGANIZATOREM rodzinnej pieczy zastępczej — to POTWIERDZA bezpośrednie
POWIĄZANIE proceduralne między pieczą zastępczą a systemem adopcyjnym
(patrz sekcja 1 — piecza jako możliwy etap przejściowy do adopcji).

---

## 6. CHECKLIST PRAKTYCZNY

```
□ Czy klient (np. dziadkowie) chce PRZEJĄĆ OPIEKĘ nad wnukiem/wnuczką,
  gdy rodzice NIE MOGĄ się nim zajmować — WYJAŚNIJ różnicę: RODZINA
  ZASTĘPCZA SPOKREWNIONA (opieka, więź prawna z rodzicami TRWA,
  możliwy powrót dziecka) vs PRZYSPOSOBIENIE (trwała zmiana statusu
  prawnego, patrz odrębny moduł)
□ Czy sytuacja dziecka jest NAGŁA/kryzysowa — sprawdź czy właściwa jest
  forma "pogotowia rodzinnego" (krótkotrwała) czy zwykła rodzina
  zastępcza (długoterminowa)
□ Czy dziecko ma NIEPEŁNOSPRAWNOŚĆ lub INNE szczególne potrzeby —
  sprawdź czy kwalifikuje się do rodziny zastępczej SPECJALISTYCZNEJ
□ Czy dziecko ma RODZEŃSTWO już umieszczone w innej rodzinie
  zastępczej — dąż do NIEROZDZIELANIA (zasada ustawowa)
□ Czy KANDYDACI NA rodzinę zastępczą spełniają wymogi formalne (⚠️
  szczegółowe kryteria kwalifikacyjne NIE zweryfikowane w pełni w tej
  sesji — sprawdź w ELI (RZĄD 1)/u organizatora rodzinnej pieczy zastępczej
  przy konkretnej sprawie)
□ Czy celem docelowym jest POWRÓT dziecka do rodziny biologicznej,
  UTRZYMANIE w pieczy zastępczej, czy DOCELOWA adopcja — to WPŁYWA na
  strategię i wybór właściwej instytucji od samego początku
```

---

## 7. INTEGRACJA Z SYSTEMEM

- **`mod-KRO-przysposobienie-adopcja-miedzynarodowa.md`** (DR-02) —
  przysposobienie jako MOŻLIWY, ale NIE JEDYNY, dalszy etap po pieczy
  zastępczej — NIE MYLIĆ tych dwóch instytucji, patrz sekcja 1.
- **`mod-KRO-rodzinne.md`** (DR-02) — władza rodzicielska (ograniczenie/
  pozbawienie rodziców biologicznych jako PRZESŁANKA umieszczenia
  dziecka w pieczy zastępczej).
- **DR-08 (Samorząd Terytorialny)** — PCPR (Powiatowe Centrum Pomocy
  Rodzinie), organizator rodzinnej pieczy zastępczej — organy o
  charakterze SAMORZĄDOWYM, sprawdź powiązany moduł JST.

---

## 8. LITERATURA I ŹRÓDŁA (zweryfikowane online 2026-07-19)

- isap.sejm.gov.pl, orka.sejm.gov.pl, przepisy.gofin.pl, lexlege.pl —
  pełna treść ustawy z 9.06.2011 o wspieraniu rodziny i systemie pieczy
  zastępczej (w tym Rozdział 2 — Rodzinna piecza zastępcza).
- mcpr.zamosc.pl — przykładowe, LOKALNE stawki wynagrodzeń rodzin
  zastępczych (2026) — WYŁĄCZNIE jako ilustracja rzędu wielkości, nie
  ogólnokrajowa stawka sztywna.
- infor.pl — praktyczny przegląd rodzajów rodzin zastępczych, historia
  reformy 2012.
