# mod-KPC-prawomocnosc-granice-apelacji

**Wersja:** 1.0.0 | **Dodano:** 2026-08-14 (NAPRAWA — F-65: raport
zewnętrzny KPC wskazał prawomocność orzeczeń [art. 365-366] i granice
apelacji [art. 378, 382-386] jako krytyczne luki — bez podstawy
prawnej mimo że engine `appellate-v8` [DR-16, `pisma-procesowe-v3`]
DZIAŁA operacyjnie na tych instytucjach, WYKORZYSTUJĄC je bez
posiadania własnego pokrycia merytorycznego w żadnym module DR-.)

> ⛔ HARDGATE — zweryfikuj aktualny t.j. na ISAP przed użyciem w piśmie.
> Akt bazowy: KPC, t.j. Dz.U. 2026 poz. 468.
> **Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1; poprawka: nieważność z urzędu — art. 378 § 1 zd. 2, nie § 2). **Zmiany KPC po t.j. 2026/468 (ELI 2026-11-13, wszystkie w mocy):** 2026/473 — art. 63¹–63², 398² § 2 pkt 4, 460 § 1, 461 § 1¹–1², 2³–2⁴, 465 § 1², 476 § 1 pkt 12–13, 477¹ᶜ–477¹ᵈ, 477⁷ᵇ–477⁷ʲ, 755⁶ (w brzmieniu od 2026-07-08; przejściowy art. 15: sprawy z powództwa PIP wszczęte wcześniej — dotychczasowe); 2026/830 — art. 4¹ zd. 2 (w brzmieniu od 2026-07-08; art. 19: w sprawach w toku do czynności po tej dacie); 2026/1003 — dział IVfa, art. 479⁸⁸ᵃ i n. (od 2026-10-28); 2026/1046 — art. 47 § 2 pkt 1 lit. d, 461 § 1¹, 477⁶ᵃ (w brzmieniu od 2026-11-05; art. 5: sprawy w toku — dotychczasowe); 2026/1296 — art. 17 pkt 4⁶ (od 2026-11-06). Brzmienie po zmianie: tekst nowelizacji w ELI.

**Rola w systemie:** KPC jest używany w DR-02, DR-05, DR-12, DR-16 bez
JEDNEGO, kanonicznego miejsca dla podstawowych instytucji procesowych
— ten moduł (obok `mod-KPC-egzekucja-windykacja.md`) zaczyna wypełniać
tę lukę dla dwóch najpilniejszych tematów.

---

## 1. PRAWOMOCNOŚĆ ORZECZEŃ (Dział IV, Rozdział 3, art. 363-366)

```
⭐⭐⭐ ART. 363 §1 — DEFINICJA: orzeczenie STAJE SIĘ prawomocne, JEŻELI
  NIE PRZYSŁUGUJE co do niego ŚRODEK ODWOŁAWCZY LUB inny środek
  zaskarżenia (⭐ prawomocność = WYCZERPANIE zwykłej drogi zaskarżenia,
  NIE to samo co "orzeczenie ostateczne" w innych systemach)

⭐⭐⭐ DWA RODZAJE PRAWOMOCNOŚCI (⭐ rozróżnienie DOKTRYNALNE, nie
  wprost nazwane w ustawie tymi terminami, ale kluczowe dla zrozumienia
  art. 363 vs 365):
  - PRAWOMOCNOŚĆ FORMALNA (art. 363 §1) — orzeczenie NIE MOŻE być już
    zaskarżone zwykłym środkiem — dotyczy SAMEGO orzeczenia
  - PRAWOMOCNOŚĆ MATERIALNA (art. 365 §1) — WYKLUCZENIE możliwości
    PONOWNEGO wystąpienia z POWÓDZTWEM w TEJ SAMEJ sprawie, jeśli
    została już prawomocnie rozstrzygnięta CO DO ISTOTY — UTOŻSAMIANA
    w doktrynie z POWAGĄ RZECZY OSĄDZONEJ (res iudicata, art. 366)

⭐⭐⭐ ART. 364 — TRYB STWIERDZENIA prawomocności (⭐ praktyczne: KIEDY i
  JAK uzyskać formalne potwierdzenie):
  §1: prawomocność orzeczenia STWIERDZA — NA WNIOSEK strony — SĄD I
    INSTANCJI na POSIEDZENIU NIEJAWNYM, A DOPÓKI akta znajdują się w
    sądzie II instancji — TEN sąd. Stwierdzenia dokonuje sąd
    JEDNOOSOBOWO (⭐ nie skład kolegialny, nawet jeśli orzeczenie
    merytoryczne było wydane w składzie 3-osobowym)
  §2: postanowienie w tej sprawie MOŻE wydać TAKŻE REFERENDARZ sądowy
    (⭐ nie tylko sędzia — czynność techniczna, nie merytoryczna)

⭐⭐⭐ ART. 365 §1 — MOC WIĄŻĄCA orzeczenia prawomocnego (⭐ zasięg
  PODMIOTOWY — KOGO wiąże, szerszy niż tylko strony postępowania):
  wiąże NIE TYLKO strony i sąd, który je wydał, LECZ RÓWNIEŻ: INNE
  sądy, INNE organy PAŃSTWOWE i organy administracji PUBLICZNEJ, A W
  WYPADKACH przewidzianych w ustawie — TAKŻE inne OSOBY (⭐ efekt
  "erga omnes" ograniczony do przypadków ustawowych, poza zwykłym
  "inter partes")
  §2: KPK OKREŚLA, w jakim zakresie orzeczenia sądu CYWILNEGO NIE
    WIĄŻĄ sądu w postępowaniu KARNYM (⭐ odesłanie do KPK — moc
    wiążąca NIE jest absolutna między gałęziami prawa)

⭐⭐⭐ ART. 366 — POWAGA RZECZY OSĄDZONEJ (res iudicata) — ⭐⭐⭐ NAJWAŻNIEJSZY
  przepis praktyczny tego modułu, DWA OGRANICZENIA zasięgu (⭐ oba
  MUSZĄ być spełnione, żeby powaga rzeczy osądzonej zablokowała nowe
  powództwo):
  1) OGRANICZENIE PRZEDMIOTOWE: TYLKO co do tego, co W ZWIĄZKU z
     PODSTAWĄ SPORU stanowiło PRZEDMIOT ROZSTRZYGNIĘCIA (⭐ powaga
     rzeczy osądzonej obejmuje SENTENCJĘ wyroku, NIE motywy/
     uzasadnienie — doktryna: motywy pełnią rolę WYŁĄCZNIE pomocniczą;
     ⚠️ jeśli sąd orzekł PONAD żądanie [plus] albo o CZYMŚ INNYM
     [aliud] — powagą objęte jest to, o CZYM RZECZYWIŚCIE
     rozstrzygnięto, nie to, o czym sąd POWINIEN był rozstrzygnąć —
     kwestia sporna w doktrynie, ale dominujące stanowisko orzecznicze
     SN [np. post. V CSK 673/14])
  2) OGRANICZENIE PODMIOTOWE: TYLKO MIĘDZY TYMI SAMYMI STRONAMI (⭐
     nowe powództwo z UDZIAŁEM innej osoby — nawet w tej samej
     sprawie faktycznej — NIE JEST zablokowane powagą rzeczy
     osądzonej z wcześniejszego wyroku)

⭐⭐ ZWIĄZANIE SĄDU WŁASNYM ORZECZENIEM vs POWAGA RZECZY OSĄDZONEJ (⭐
  rozróżnienie doktrynalne, orzecznictwo SN): "moc wiążąca" (art. 365)
  dotyczy ZWIĄZANIA faktem PRAWOMOCNEGO rozstrzygnięcia W INNYCH
  sprawach (np. kwestia PREJUDYCJALNA), podczas gdy "powaga rzeczy
  osądzonej" (art. 366) dotyczy NIEDOPUSZCZALNOŚCI ponownego
  ROZPOZNANIA TEJ SAMEJ sprawy — ⭐ dwa RÓŻNE mechanizmy ochronne,
  często mylone w praktyce
```

---

## 2. GRANICE APELACJI (Dział V, Rozdział 1, art. 378, 380-386)

```
⭐⭐⭐ ART. 378 §1 — ZASADA ZWIĄZANIA GRANICAMI ZASKARŻENIA: sąd
  II instancji ROZPOZNAJE sprawę W GRANICACH apelacji — ⭐⭐⭐
  PRAKTYCZNA KONSEKWENCJA (⭐ NAJCZĘSTSZY punkt formalny do
  sprawdzenia PRZED złożeniem apelacji): apelacja MUSI wprost wskazać,
  czy wyrok I instancji jest zaskarżony W CAŁOŚCI czy W CZĘŚCI —
  CZĘŚĆ wyroku NIEWSKAZANA jako zaskarżona STAJE SIĘ prawomocna I NIE
  MOŻE być objęta kontrolą sądu odwoławczego (⭐ powiązanie z sekcją 1
  wyżej — częściowe zaskarżenie = częściowa prawomocność pozostałej
  części, NATYCHMIAST po upływie terminu apelacji dla tej części)
  §1 zd. 2 — w granicach ZASKARŻENIA sąd II instancji BIERZE z urzędu pod
    uwagę NIEWAŻNOŚĆ postępowania (art. 379) — niezależnie od zarzutów
    apelacji, ale tylko w części zaskarżonej
  §2 — w granicach zaskarżenia sąd może z urzędu rozpoznać sprawę także na
    rzecz WSPÓŁUCZESTNIKÓW, którzy wyroku nie zaskarżyli, gdy prawa lub
    obowiązki są dla nich wspólne (wymaga zawiadomienia ich o terminie)

⭐⭐ ART. 380 — ROZSZERZENIE ZAKRESU ROZPOZNANIA: sąd II instancji NA
  WNIOSEK strony — MOŻE rozpoznać RÓWNIEŻ postanowienia sądu I
  instancji, które nie podlegały ZASKARŻENIU w drodze ZAŻALENIA, a
  MIAŁY WPŁYW na rozstrzygnięcie sprawy (⭐ mechanizm "wciągnięcia" do
  kontroli apelacyjnej postanowień WPADKOWYCH, np. dowodowych, które
  same nie były zaskarżalne osobno)

⭐⭐ ART. 381 — PREKLUZJA DOWODOWA w postępowaniu apelacyjnym: sąd
  II instancji MOŻE POMINĄĆ nowe fakty i dowody, JEŻELI STRONA MOGŁA
  je POWOŁAĆ w postępowaniu PRZED sądem I instancji, CHYBA że
  POTRZEBA powołania wynikła PÓŹNIEJ (⭐⭐ zasada CO DO ZASADY
  RESTRYKCYJNA wobec "nowości" na etapie apelacji — ale NIE jest to
  zakaz BEZWZGLĘDNY, tylko UPRAWNIENIE sądu do pominięcia, ocena
  ad casum)

⭐⭐⭐ ART. 382 — PODSTAWA ORZECZENIA sądu II instancji: sąd II instancji
  ORZEKA na PODSTAWIE materiału zebranego W POSTĘPOWANIU W I
  INSTANCJI ORAZ W POSTĘPOWANIU APELACYJNYM (⭐ tzw. "APELACJA PEŁNA"
  — sąd II instancji nie jest ograniczony wyłącznie do kontroli błędów
  I instancji, lecz KONTYNUUJE merytoryczne rozpoznanie sprawy na
  całości zebranego materiału — fundamentalna cecha polskiego modelu
  apelacyjnego)

⭐⭐ ART. 383 — ZAKAZ PRZEKSZTAŁCEŃ PODMIOTOWYCH I PRZEDMIOTOWYCH
  ŻĄDANIA: w postępowaniu apelacyjnym NIE MOŻNA rozszerzyć żądania
  pozwu ANI wystąpić z NOWYMI roszczeniami — ⚠️ WYJĄTEK: w RAZIE
  zmiany OKOLICZNOŚCI można żądać, ZAMIAST pierwotnego przedmiotu
  sporu, JEGO WARTOŚCI lub INNEGO przedmiotu; w sprawach o świadczenie
  powtarzające się można rozszerzyć żądanie o świadczenia za dalsze
  okresy (brzmienie z t.j. 2026/468)

⭐⭐⭐ ART. 384 — ZAKAZ REFORMATIONIS IN PEIUS (⭐⭐⭐ jeden z
  najważniejszych mechanizmów ochronnych całego postępowania
  apelacyjnego): sąd NIE MOŻE uchylić LUB zmienić wyroku NA NIEKORZYŚĆ
  strony WNOSZĄCEJ apelację, CHYBA że strona PRZECIWNA RÓWNIEŻ wniosła
  apelację (⭐⭐ konsekwencja praktyczna: strona wnosząca JEDYNĄ
  apelację w sprawie ma GWARANCJĘ, że wynik NIE będzie dla niej GORSZY
  niż wyrok I instancji — "nie ma nic do stracenia" składając apelację
  samodzielnie). ⚠️ NIUANSE z orzecznictwa SN (zweryfikowane
  pośrednio): zakaz MOŻE być WYŁĄCZONY wobec rozstrzygnięć
  NIEORZEKAJĄCYCH co do ISTOTY sprawy oraz wobec ROZSTRZYGNIĘĆ O
  KOSZTACH procesu; W POSTĘPOWANIU NIEPROCESOWYM stosowanie zakazu NIE
  PODLEGA generalizacji — zależy od RODZAJU sprawy (np. sprawy
  działowe, zasiedzenie, stwierdzenie nabycia spadku mają odrębne,
  ustalone linie orzecznicze) — ⚠️ punkt startowy do pogłębienia przy
  konkretnej sprawie nieprocesowej

⭐⭐ ART. 385 — ODDALENIE APELACJI: gdy apelacja jest BEZZASADNA — sąd
  ODDALA (art. 385); uwzględnienie apelacji → ZMIANA wyroku i orzeczenie
  co do istoty (art. 386 § 1)

⭐⭐⭐ ART. 386 — POZOSTAŁE ROZSTRZYGNIĘCIA sądu II instancji (⭐
  katalog rozstrzygnięć POZA samym oddaleniem/uwzględnieniem —
  KLUCZOWY dla zrozumienia co może zrobić sąd odwoławczy):
  §2 — NIEWAŻNOŚĆ postępowania → uchylenie, zniesienie postępowania w
    zakresie nią dotkniętym i przekazanie sprawy I instancji
  §3 — pozew podlega odrzuceniu albo zachodzi podstawa umorzenia →
    uchylenie wyroku oraz odrzucenie pozwu lub umorzenie
  §4 — poza §2 i §3 uchylenie i PRZEKAZANIE do ponownego rozpoznania
    (rozstrzygnięcie KASATORYJNE) TYLKO w razie NIEROZPOZNANIA ISTOTY
    SPRAWY przez sąd I instancji albo gdy wydanie wyroku WYMAGA
    przeprowadzenia POSTĘPOWANIA DOWODOWEGO W CAŁOŚCI — orzecznictwo
    SN: WYJŚCIE przez sąd II instancji, W TOKU formułowania sentencji
    na podstawie art. 386 §4, POZA granice apelacji I granice
    zaskarżenia (np. uchylenie CAŁOŚCI wyroku, gdy zaskarżono TYLKO
    część) — STANOWI NARUSZENIE zasad z art. 378 (przykład z praktyki
    orzeczniczej SN, III PZ 2/18)

⚠️ ART. 387 (Uzasadnienie) — poza zakresem tej naprawy, punkt startowy.
```

---

## 3. ROZGRANICZENIE

| Temat | Gdzie |
|---|---|
| Egzekucja i windykacja (KPC cz. III) | `mod-KPC-egzekucja-windykacja.md` — NIE duplikować |
| Arbitraż i mediacja (KPC cz. V) | `mod-KPC-arbitraz-mediacja-ADR.md` (DR-02/DR-12) |
| Skarga kasacyjna do SN (KPC Dział Va, art. 398¹-398²¹) | ⚠️ POZA zakresem tej naprawy — nadal bez podstawy prawnej, punkt startowy |
| Skarga na orzeczenie referendarza (KPC Dział Vb, art. 398²²-398²⁴) | Treść ISTNIEJE, ale w `prawo-polskie-v2/krajowe/pisma-proste-v2/references/SPH-inne.md` (moduł DRAFTOWANIA pism), NIE w kanonicznym module DR- — ✅ ZWERYFIKOWANE 2026-08-14: to NIE jest realna luka merytoryczna, tylko rozproszenie lokalizacji (patrz F-65, punkt zamknięty jako "fałszywy alarm") |
| Zażalenie (KPC Dział V, Rozdział 2) | ⚠️ POZA zakresem tej naprawy, punkt startowy |
| Wznowienie postępowania CYWILNEGO (KPC Dział VI) | ⚠️ POZA zakresem tej naprawy, punkt startowy — NIE mylić z wznowieniem postępowania ADMINISTRACYJNEGO (DR-05, `mod-KPA-tryby-nadzwyczajne-i-strategia.md`) |

## ŁĄCZ Z

| Sytuacja | Skill / Moduł |
|---|---|
| Pismo: apelacja, wniosek o stwierdzenie prawomocności | `pisma-procesowe-v3` (w tym engine `appellate-v8`, KTÓRY TERAZ ma podstawę merytoryczną dla granic apelacji) |
| Orzecznictwo dot. prawomocności i apelacji | `orzeczenia-sadowe-v2` |

---

## ⚠️ POZOSTAJE DO POGŁĘBIENIA (jawnie oznaczone, poza zakresem tej naprawy)
- Skarga kasacyjna do SN (art. 398¹-398²¹) — całkowicie poza zakresem
  tej naprawy, wciąż bez podstawy prawnej w żadnym module DR-.
- Zażalenie (art. 394 i n.) — poza zakresem.
- Wznowienie postępowania cywilnego (art. 399-416¹) — poza zakresem.
- Dokładne przesłanki wyboru między rozstrzygnięciem merytorycznym a
  kasatoryjnym przez sąd II instancji (art. 386 §2-4 w pełnym
  brzmieniu).
- Wyjątek z art. 383 (zmiana okoliczności — żądanie wartości/innego
  przedmiotu) — dokładne brzmienie niezweryfikowane.
- Zastosowanie zakazu reformationis in peius w postępowaniu
  NIEPROCESOWYM — zależne od typu sprawy, wymaga odrębnej analizy
  przy konkretnym stanie faktycznym.

## Środki odwoławcze w praktyce — apelacja i zażalenie (dodano 2026-11-19)

> Praktyka ze źródeł (2026-11-19): każda reguła ma źródło (Pn). Orzeczenia przytoczone przez źródła wtórne oznaczone `[ORZ-DO-WERYFIKACJI]` — przed powołaniem `weryfikator-orzeczen`. Tezy źródeł starszych niż t.j. sprawdzone z t.j.; rozbieżność = KOREKTA.

### Wybór środka (KPC, t.j. 2026/468)

| Orzeczenie / akt | Środek | Do kogo / za pośrednictwem | Termin | Kwalifikator |
|---|---|---|---|---|
| wyrok sądu I instancji (cywilny) | apelacja | sąd II instancji, wnoszona do sądu, który wydał wyrok | 2 tygodnie od doręczenia wyroku z uzasadnieniem; 3 tygodnie przy przedłużonym terminie uzasadnienia | KPC art. 367 § 1–2, art. 369 § 1–1¹; art. 369 § 3 — termin zachowany także przy wniesieniu wprost do sądu II instancji |
| postanowienie kończące postępowanie i katalog art. 394 § 1 | zażalenie (pionowe) | sąd II instancji | tydzień od doręczenia postanowienia z uzasadnieniem | KPC art. 394 § 1–3 |
| postanowienia z katalogu art. 394¹a § 1 (m.in. koszty, zwolnienie od kosztów, grzywna, wyłączenie sędziego, rygor natychmiastowej wykonalności) | zażalenie poziome | inny skład sądu I instancji (3 sędziów) | jak art. 394 § 2 (odesłanie w art. 394¹a § 2) | KPC art. 394¹a § 1, § 1², § 2, § 3 |
| przepis szczególny daje zażalenie, nie wskazując sądu | zażalenie | sąd II instancji | art. 394 § 2 | KPC art. 394 § 4 |

### SO-1 — Apelacja cywilna

#### Wymogi treści (KPC art. 368)
- § 1 pkt 1–5: oznaczenie wyroku i zakresu zaskarżenia (całość albo część), zwięzłe zarzuty, uzasadnienie zarzutów, w razie potrzeby nowe fakty i dowody, wniosek o zmianę albo uchylenie z zakresem.
- § 1¹: zarzut co do podstawy faktycznej wskazuje fakty ustalone niezgodnie z rzeczywistością albo istotne fakty nieustalone.
- § 1²: nowe fakty i dowody — uprawdopodobnienie, że nie mogły być powołane w I instancji albo potrzeba wynikła później.
- § 1³: fakt z nagrania — wskazać część zapisu.
- § 2: sprawy majątkowe — wartość przedmiotu zaskarżenia.

#### Granice i skutki
- art. 378 § 1: sąd II instancji rozpoznaje sprawę w granicach apelacji; z urzędu tylko nieważność w granicach zaskarżenia. Wniosek praktyczny: czego nie zarzucono, tego sąd zwykle nie bada (źródło P1).
- art. 380: na wniosek sąd bada niezaskarżalne zażaleniem postanowienia, które miały wpływ na rozstrzygnięcie — wniosek trzeba zgłosić w apelacji.
- art. 381–382: nowe fakty i dowody mogą być pominięte, gdy strona mogła je powołać wcześniej; orzekanie na materiale z obu instancji.
- art. 384: zakaz reformationis in peius, chyba że apelację wniosła także strona przeciwna.
- art. 386 § 4: uchylenie i przekazanie poza nieważnością i odrzuceniem pozwu/umorzeniem tylko przy nierozpoznaniu istoty sprawy albo konieczności przeprowadzenia postępowania dowodowego w całości — wniosek o uchylenie bez tych przesłanek jest słaby; domyślnie wnoś o zmianę.
- art. 373 § 1: odrzucenie apelacji spóźnionej, nieopłaconej, niedopuszczalnej albo z nieusuniętymi brakami.

#### Praktyka formułowania zarzutów (ze źródeł)
1. **Zarzut z konkretu sprawy, nie z szablonu.** Każdy zarzut na podstawie konkretnego stanu faktycznego i skali naruszenia (P1). Kopiowanie zarzutów art. 233 § 1 bez odniesienia do sprawy to typowy problem (P4 — omówienie Wolters Kluwer w wynikach wyszukiwania; pełny tekst niedostępny).
2. **Art. 233 § 1 KPC — nie alternatywny stan faktyczny.** Zarzut nie może polegać na przedstawieniu własnej wersji faktów; trzeba wykazać rażącą wadliwość oceny i wskazać przekroczone kryterium (logika, doświadczenie życiowe, wszechstronność) (P1). Sąd może dać wiarę jednemu z dwóch sprzecznych źródeł — sama sprzeczność z jednym z nich nie jest błędem (P1).
3. **Matryca zarzutu dowodowego:** dowód → ocena sądu (strona uzasadnienia) → naruszone kryterium → jaki fakt powinien zostać ustalony → wpływ na rozstrzygnięcie. Bez ostatniego ogniwa zarzut proceduralny jest bezskuteczny — wzór zarzutu zawiera „mających istotny wpływ na treść rozstrzygnięcia” (P1).
4. **Rozdziel błąd subsumcji od błędu ustaleń.** Przed zarzutem prawa materialnego sprawdź, czy sąd nie zastosował prawa poprawnie do błędnie ustalonych faktów — wtedy właściwy jest zarzut ustaleń (art. 368 § 1¹), a zarzut materialny jest wtórny (P1, P3).
5. **Zarzut prawa materialnego wskazuje skutek dla rozstrzygnięcia** (jaki wynik przy prawidłowej wykładni/zastosowaniu) (P1).
6. **Typowe błędy (P1):** nieważność bez podstaw (np. powaga rzeczy osądzonej bez wskazania sprawy i sygnatury); zarzut pominięcia dowodu bez wykazania jego istotności; błędne przypisanie przyznania faktu (art. 229); błędne przytoczenie treści zeznań lub dokumentu; zarzut wobec opinii biegłego bez wskazania wewnętrznej sprzeczności i bez wniosku o opinię uzupełniającą.
7. **Nowe dowody w apelacji (P2):** apelacja nie służy powtórzeniu postępowania; dopuszczenie nowego dowodu zależy od uznania sądu `[ORZ-DO-WERYFIKACJI: SN I PKN 28/00, 12.09.2000]`; brak adwokata w I instancji nie jest samodzielną podstawą powołania nowych faktów `[ORZ-DO-WERYFIKACJI: SN V CKN 1269/00, 16.05.2002]`. Uprawdopodobnienie z art. 368 § 1² w samej apelacji, z dowodem na brak winy.
8. **Postanowienia niezaskarżalne:** gdy wpływały na wynik (np. oddalenie wniosku dowodowego), wniosek z art. 380 w apelacji; bez niego sąd ich nie bada.

### SO-2 — Zażalenie cywilne (pionowe i poziome)

- **Dobór drogi (P5, P6):** reguła — zażalenie dewolutywne; poziome tylko w katalogu art. 394¹a § 1 (I instancja) albo art. 394² § 1–1¹ (II instancja). Zażalenia „osierocone” (przepis szczególny nie mówi, kto rozpoznaje) były najczęstszym problemem pełnomocników (P6); od nowelizacji z 2023 r. rozstrzyga je art. 394 § 4 — sąd II instancji (P5, potwierdzone t.j. 2026/468).
- **Uzasadnienie jako warunek (P6):** postanowienia z posiedzenia niejawnego sąd uzasadnia tylko na żądanie zgłoszone w tygodniu od doręczenia (art. 357 § 2¹); termin na zażalenie biegnie od doręczenia postanowienia z uzasadnieniem (art. 394 § 2). Wyjątek: gdy sąd z urzędu doręczył postanowienie z uzasadnieniem, wniosek odpada (art. 357 § 2⁴); gdy sąd odstąpił od uzasadnienia — termin od ogłoszenia/doręczenia (art. 394 § 2 zd. 2).
- **„Zasadnicze powody rozstrzygnięcia” to nie uzasadnienie (P6)** — nie otwierają biegu terminu ani drogi zażalenia; częsty błąd stron (P5).
- **Skład i odrzucenie:** zażalenie poziome — 3 sędziów (art. 394¹a § 1²); odrzucenie spóźnionego/niedopuszczalnego — 1 sędzia sądu, który wydał postanowienie (§ 1¹). Wątpliwości składu przy rozstrzygnięciach niemerytorycznych mogą prowadzić do nieważności (P6) — w zażaleniu na odrzucenie sprawdź skład.
- **Autokontrola:** zarzut nieważności albo oczywista zasadność — sąd, który wydał postanowienie, może sam je uchylić (art. 395 § 2); formułuj taki zarzut wprost na początku.
- **Treść (art. 394 § 3):** wskazanie postanowienia, wniosek o zmianę albo uchylenie, zwięzłe uzasadnienie, w miarę potrzeby nowe fakty i dowody. Do postępowania zażaleniowego odpowiednio przepisy o apelacji (art. 397 § 3).
- **Odpowiedź na zażalenie:** tydzień od doręczenia (art. 395 § 1¹).

#### Źródła praktyki (odczyt 2026-11-19)

- P1 — Najczęstsze zarzuty w apelacjach cywilnych i sposób ich formułowania, poradnikprzedsiebiorcy.pl (10.12.2024): https://poradnikprzedsiebiorcy.pl/-najczestsze-zarzuty-w-apelacjach-cywilnych-i-sposob-ich-formulowania
- P2 — Ł. Nysztal, Zgłoszenie nowych dowodów w apelacji cywilnej, infor.pl (10.10.2010; przepisy sprawdzone z t.j. 2026/468): https://www.infor.pl/prawo/w-sadzie/postepowanie-sadowe/256496,Zgloszenie-nowych-dowodow-w-apelacji-cywilnej.html
- P3 — Zarzuty — materiał dydaktyczny, Wydział Prawa UWr: https://prawo.uwr.edu.pl/wp-content/uploads/sites/210/2022/07/Zarzuty-uproszcz-apelacja.pdf (z wyników wyszukiwania; nie odczytany w całości)
- P4 — Art. 233 KPC — dobór orzecznictwa w apelacji, Wolters Kluwer Expert Insights (24.06.2026): https://www.wolterskluwer.com/pl-pl/expert-insights/art-233-kpc-dobor-orzecznictwa-apelacja (pełny tekst niedostępny — HTTP 403; teza z omówienia)
- P5 — Postępowanie zażaleniowe — trzy nowelizacje w pięć lat, prawo.pl: https://www.prawo.pl/prawnicy-sady/zmiany-w-postepowaniu-zazaleniowym-od-2019-r,527235.html
- P6 — Zażalenia poziome: luki w przepisach utrudniają pracę sądom i pełnomocnikom, prawo.pl: https://www.prawo.pl/prawnicy-sady/zazalenia-poziome-luki-w-przepisach-utrudniaja-prace-sadom-i,504054.html
