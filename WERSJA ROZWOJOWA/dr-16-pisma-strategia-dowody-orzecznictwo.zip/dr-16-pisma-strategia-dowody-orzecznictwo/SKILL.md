---
name: dr-16-pisma-strategia-dowody-orzecznictwo
version: "3.15"
description: "Pisma, strategia, dowody i orzecznictwo: routing narzędzi procesowych, analiza dowodowa, research orzeczeń, kalkulatory i wsparcie budowy strategii sprawy."
dependencies:
  requires:
    - shared
  # 2026-09-27e: jawna zależność (każdy skill systemu korzysta z `shared`); pole czytane przy imporcie z marketplace
---

> **Universal runtime:** przed wykonaniem zastosuj kanoniczny `shared/UNIVERSAL-RUNTIME-ADAPTER.md` z osobnego skilla `shared`. Lokalna sekcja adaptera poniżej jedynie go doprecyzowuje.


## ADAPTER RUNTIME — PORTABILITY (ChatGPT / Claude / inne hosty)

Ta sekcja zmienia wyłącznie wykonanie operacji technicznych. Merytoryka dziedzinowa, mapy aktów, hard gate’y, kolejność modułów i kryteria jakości tego DR-skilla pozostają bez zmian.

1. `view dr-16-pisma-strategia-dowody-orzecznictwo/<plik>` oraz `view modules/...` / `view references/...` oznaczają świeży odczyt odpowiedniego lokalnego pliku tego skilla. Literalna ścieżka `/mnt/skills/user` nie jest wymagana.
2. `view shared/<plik>` oznacza świeży odczyt z osobnego, kanonicznego skilla `shared`. NIE kopiuj `shared` do tej paczki. Brak obowiązkowego zasobu shared = fail-closed, nie substytucja pamięcią modelu.
3. `view <inny-skill>/<plik>` oznacza aktywację/odczyt wskazanego osobnego skilla. Nie vendoryzuj innych skilli do tego ZIP-a.
4. `web_search` / `web_fetch` i podobne nazwy oznaczają świeże wyszukanie/odczyt online przez równoważną funkcję hosta. Zachowaj wymagane źródła oficjalne, statusy weryfikacji i zakaz cytowania prawa z pamięci.
5. `show_widget`, `visualize:read_me`, `present_files`, `create_file`, shell/Python i podobne operacje są nazwami semantycznymi. Jeśli host nie ma literalnego narzędzia, użyj równoważnej funkcji natywnej bez omijania bramek jakości.
6. `/mnt/user-data/...` oznacza rzeczywiste załączniki użytkownika dostępne w bieżącym hoście; wymagany ponowny odczyt ma być faktycznym odczytem źródła.

**Zasada nadrzędna:** instrukcje, które są już zrozumiałe i wykonalne w bieżącym hoście, wykonuj bez konwersji. Adapter działa wyłącznie na granicy runtime.


# DR-16 — Pisma, Strategia, Dowody, Orzecznictwo

## ⛔ HARD GATE — ZAKAZ CYTOWANIA Z PAMIĘCI

**PRZED każdym powołaniem przepisu, artykułu, terminu lub sygnatury:**
1. Zweryfikuj brzmienie i Dz.U. w `ELI (RZĄD 1)`
2. Zweryfikuj orzeczenie w `orzeczenia.ms.gov.pl` / `nsa.gov.pl` / `sn.pl`
3. Przy TSUE/ETPC — weryfikuj w `curia.europa.eu` / `hudoc.echr.coe.int`
4. **NIGDY** nie podawaj artykułu, terminu procesowego ani sygnatury wyłącznie z pamięci modelu.

**Obszar procesowy był nowelizowany w 2024–2026:**
- KPC — tekst jednolity Dz.U. 2026 poz. 468 — weryfikuj aktualność przed każdym użyciem.
- E-doręczenia i portal sądowy — przepisy wdrażane etapami; sprawdź aktualny stan w ELI (RZĄD 1).
- Prawo prasowe — ustawa z 1984 r. wielokrotnie nowelizowana; weryfikuj Dz.U. ze zm.
- Ustawa o archiwach — sprawdź aktualny tekst jednolity w ELI (RZĄD 1).


> ⛔ **SELF-CHECK ANTY-FASADA — obowiązkowy przed wysłaniem odpowiedzi/pisma**
> (podłączone 2026-08-24, flaga F-115 P3 — zamknięcie zakresu 16 skilli DR):
>
> ```
> view shared/SELF-CHECK-ANTY-FASADA.md
> ```
>
> Sprawdza dwie rzeczy: (1) czy w tekście stoi „zweryfikowano", data weryfikacji
> albo URL przy przepisie, dla którego NIE wywołano narzędzia W TEJ ODPOWIEDZI;
> (2) czy znacznik statusu nie został nadany treści WYGENEROWANEJ w tej odpowiedzi
> (AF-6). Treść listy jest w module, nie tutaj — celowo, żeby nie powstało kolejne
> miejsce dryfu (7 wcześniejszych kopii rozjechało się ze źródłem przy pierwszej
> zmianie brzmienia).
>
> ⛔ Wyzwalaczem jest BRAK WYWOŁANIA NARZĘDZIA dla danego twierdzenia w danej
> odpowiedzi — nie brak narzędzi w sesji. Niedostępność ELI (oba kanały) nie zwalnia z
> oznaczenia, tylko je wymusza; niedostępność ISAP to stan normalny.

---

## Zasada architektoniczna
- Jeden moduł = jeden akt prawny (tekst jednolity Dz.U.) lub wydzielony obszar procesowy
- Wyjątek: wydzielone rozdziały jednej ustawy mogą mieć osobny moduł (z adnotacją)
- Ten sam akt NIE może pokrywać dwóch różnych DR-skills
- **Zakaz cytowania przepisów z pamięci — każde brzmienie weryfikuj w ELI (RZĄD 1)**
- **Terminy procesowe są terminami zawitymi — błąd daty może skutkować prekluzją**

---

## DEFINICJE — prawo-polskie-v2/krajowe/shared/definicje/ (bezpośrednie, lazy loading per temat)

- `prawo-polskie-v2/krajowe/shared/definicje/DEF-ODPOWIEDZIALNOSC-SZKODA.md` — szkoda/damnum emergens/lucrum
  cessans — precyzja żądania pozwu; ⚠️ NOWE: siła wyższa + rebus sic stantibus
  (art. 357¹ KC) — przy pismach dot. niewykonania zobowiązań w nadzwyczajnych
  okolicznościach (wojna, inflacja, embargo)
- `prawo-polskie-v2/krajowe/shared/definicje/DEF-PROCEDURA.md` — termin zawity vs przedawnienie vs instrukcyjny
  — KRYTYCZNE dla każdego pisma z terminem

- `prawo-polskie-v2/krajowe/shared/definicje/DEF-INTERES-WLASNY-WYLACZENIA.md` — ⚠️ NOWE: interes
  prawny/faktyczny (strategia legitymacji procesowej), wyłączenie sędziego/
  biegłego, ocena wiarygodności świadka z interesem własnym, czynność prawna
  ukryta/pozorna (art. 83 KC) — przy zarzutach pozorności w pismach

## ORKA-BAS — Definicje wspomagające (shared/ORKA-BAS-LEKSYKON.md)

Przy redagowaniu pism rozważ doładowanie (`view`) definicji:
- BAS-103 Uprawdopodobnienie vs udowodnienie (ORKA-REG-02 — argumentacja dowodowa)
- BAS-W26 Szkoda / damnum emergens / lucrum cessans — precyzja żądania
- BAS-W27 Termin zawity vs przedawnienie vs instrukcyjny — KRYTYCZNE dla pism
- BAS-W28 Nadużycie prawa (art. 5 KC / art. 8 KP) — "ostatni bastion" argumentacji
- BAS-W30 Moc dowodowa dokumentu urzędowego vs prywatnego — strategia dowodowa
- BAS-W33/W34 Kara umowna i odsetki — precyzja żądań pozwu
- BAS-W35 Nakaz zapłaty: terminologia "sprzeciw" vs "zarzuty"

<!-- lex:wykonuje-aplikacja: REJESTR-MODULOW -->
## Moduły (11 łącznie — ✓ 11 OK, ☐ 0 STUB; 1 przeniesiony do shared/)

```
KPC — PROCEDURY SZCZEGÓLNE I NARZĘDZIA PROCESOWE:

> **Przeniesiony do shared/ (2026-07-12):** `mod-KPC-przesluchanie-swiadkow`
> (Dz.U. 2026 poz. 468 ze zm. — art. 258–305 KPC; typologia świadków, 10 technik
> procesowych, cross-examination, impeachment, sekwencje pytań; KPK art. 171,
> 272, 391; KPC art. 259, 261 — WYMAGA WERYFIKACJI RZĄD 1) był bajt-w-bajt
> kanoniczna warstwa KPC jest w `prawo-polskie-v2/krajowe/shared/PRZESLUCHANIE-SWIADKOW-KPC.md`; router zawiera wyłącznie bridge, nie kopię prawa materialnego
> (wykryte przez `ci_check_shared.py`). Scalony pod jedną kanoniczną lokalizacją:
> `view prawo-polskie-v2/krajowe/shared/PRZESLUCHANIE-SWIADKOW-KPC.md`. Dla zaawansowanej
> strategii przesłuchania (przygotowanie pytań, kontrprzesłuchanie, scoring
> dowodowy) → osobny skill `przesluchanie-swiadkow-v2-min90`, różny zakres.
> Pełny opis: `audyt-systemu-v4/references/CHECKLIST-DEDUP.md` NOTA-13.

  [✓] OK    mod-KPC-e-doreczenia-portal-sadowy
  [✓] OK    mod-KPC-odtworzenie-akt-zaginionych-zniszczonych
              (dodany 2026-07-18: Księga IV KPC art. 716-729 — terminy
               zawite 3/10 lat, trzyetapowa procedura [odpisy →
               oświadczenia → dochodzenie z urzędu], sankcja grzywny,
               zbieg z przedawnieniem roszczenia. Odpowiedź na pytanie
               o "odtwarzanie dokumentów")
              (Dz.U. 2026 poz. 468 ze zm.; ustawa o ustroju sądów powszechnych;
               regulamin urzędowania sądów; ustawa o skardze na przewlekłość;
               portal informacyjny, fikcja doręczenia, skargi administracyjne do prezesa,
               odróżnienie czynności orzeczniczych od administracyjnych)

  [✓] OK    mod-KPC-procedury-UE-TSUE-ETPC
              (KPC + Rozp. UE; Traktaty UE; EKPC i regulamin ETPC;
               pytania prejudycjalne TSUE, bezpośredni skutek i pierwszeństwo prawa UE,
               skargi do ETPC — status ofiary, wyczerpanie środków, termin 4 m-cy;
               odpowiedzialność odszkodowawcza za naruszenie prawa UE;
               weryfikacja: curia.europa.eu | hudoc.echr.coe.int | eur-lex.europa.eu)

  [✓] OK    mod-KPC-arbitraz-sportowy-dyscyplinarny
              (Dz.U. 2026 poz. 468 cz. V — arbitraż; ustawa o sporcie;
               bezpieczeństwo imprez masowych; regulaminy polskich związków sportowych;
               POLADA — przepisy antydopingowe; dyscyplinarki sportowe, transfery,
               licencje, odpowiedzialność klubów, arbitraż sportowy)

  [✓] OK    mod-KPC-wzory-pism-procesowych
              (Dz.U. 2026 poz. 468 t.j. — art. 126–130² KPC;
               wymogi formalne pisma procesowego, pozew o zapłatę art. 187 KPC,
               sprzeciw od nakazu zapłaty art. 505 § 1 KPC (termin: art. 480² § 2 KPC), zasady absolutne:
               podpis, adres, opłata, pełnomocnictwo, odpisy)

PRAWO MATERIALNE I USTROJOWE — ZASTOSOWANIE PROCESOWE:
  [✓] OK    mod-Konstytucja-prawa-i-wolnosci-procesowe
              (Konstytucja RP art. 45, 47, 51, 77; ustawa o TK; ustawa o RPO;
               KPC/KPA/PPSA/KPK w ścieżkach ochrony praw;
               skarga konstytucyjna, proporcjonalność, równość, prawo do sądu,
               wolność słowa, dostęp do informacji publicznej, RPO)

  [✓] OK    mod-ustawa-prawo-prasowe-media
              (Prawo prasowe — Dz.U. 2018 poz. 1914 ze zm.;
               ustawa o radiofonii i telewizji; KC/KPC; prawo autorskie;
               sprostowanie prasowe, odpowiedzialność redaktora naczelnego,
               ochrona źródeł, dobra osobiste, KRRiT)

  [✓] OK    mod-ustawa-archiwa-dokumentacja
              (Ustawa o narodowym zasobie archiwalnym i archiwach — Dz.U. 2020 poz. 164 ze zm.;
               KPA; ustawa o dostępie do informacji publicznej; RODO;
               retencja akt, udostępnienie dokumentacji, brakowanie,
               archiwizacja elektroniczna, akta osobowe, dowodzenie dokumentem archiwalnym)

  [✓] OK    mod-ustawa-obywatelstwo-paszporty-ewidencja
              (Ustawa o obywatelstwie polskim — Dz.U. 2024 poz. 80 ze zm.;
               ustawa o dokumentach paszportowych; ustawa o ewidencji ludności;
               ustawa o dowodach osobistych; Prawo o aktach stanu cywilnego;
               KPA/PPSA i przepisy konsularne;
               organy: Wojewoda, minister, konsul, kierownik USC, WSA/NSA)

NARZĘDZIA PRZEKROJOWE:
  [✓] OK    mod-narzedzie-kalkulatory
              (Kalkulator terminów procesowych, zachowku, nadgodzin, emerytury;
               tabela terminów zawitych z podstawami KPA/KPC/KP/KC/PPSA/KPSW;
               OSTRZEŻENIA: termin < 5 dni / termin minął — wywołaj automatycznie
               gdy sprawa wymaga obliczeń)

  [✓] OK    mod-narzedzie-kontroler-kompletnosci
              (Moduł nadrzędny dla prawo-polskie-v2; 10-punktowa checklista
               obowiązkowa przed każdą odpowiedzią z zakresu prawa polskiego;
               tabela decyzyjna: typ sprawy → moduł podstawowy → moduły wspierające;
               finalny quality gate 7 pytań kontrolnych)
```

---

## Jak wywołać

```
view dr-16-pisma-strategia-dowody-orzecznictwo/modules/[nazwa-modulu].md
```

## Lokalna mapa aktów prawnych

```
view dr-16-pisma-strategia-dowody-orzecznictwo/MAPA-AKTOW.md
```

## Mapa pokrycia treściowego (planowanie rozwoju skilla)

Rejestr informacyjny — NIE krok obowiązkowy przy obsłudze konkretnej sprawy.
Jedyne bieżące źródło statusu pokrycia DR-16 (por. `prawny-router-v3/references/pokrycie-dziedzinowe.md`):

```
view dr-16-pisma-strategia-dowody-orzecznictwo/MAPA-POKRYCIA.md
```

---

## Powiązania zewnętrzne
- Wchodzi z: `prawo-polskie-v2` → `ROUTING-MAP.md` → ten skill
- Pisma procesowe kompleksowe → `pisma-procesowe-v3`
- Pisma proste / jednoinstancyjne → `pisma-proste-v2`
- Przesłuchanie świadków (zaawansowane) → `przesluchanie-swiadkow-v2-min90`
- Analiza dowodów → `analizator-dowodow-v3`
- Analiza akt / szanse sprawy → `analiza-sadowa-v6`
- Orzecznictwo (wyszukiwanie i weryfikacja) → `orzeczenia-sadowe-v2`
- Prawo UE / ETPC materialne → `dr-14`
- Koszty sądowe (KSCU) → `dr-12` → `mod-KSCU-koszty-sadowe-i-pomoc-prawna`
- Wychodzi do: `pisma-procesowe-v3` / `analiza-sadowa-v6` / `orzeczenia-sadowe-v2`
- Weryfikacja: ELI (RZĄD 1) | orzeczenia.ms.gov.pl | sn.pl | nsa.gov.pl | curia.europa.eu | hudoc.echr.coe.int

## ⚖️ DISCLAIMER (obowiązkowy)

Po zakończeniu analizy lub przed oddaniem odpowiedzi zawierającej ocenę prawną:

```text
view shared/DISCLAIMER.md
```

Wybierz wariant odpowiedni do trybu:
- **PRAWNIK / kancelaria** → wariant techniczny (art. 4 Prawa o adwokaturze / art. 6 u.r.p.)
- **LAIK / pro se** → wariant uproszczony (informacja ≠ porada prawna)

Disclaimer musi być **ostatnim elementem** każdej odpowiedzi zawierającej analizę prawną,
ocenę szans, kwalifikację prawną lub interpretację przepisu.
