# W3-WERYFIKACJA — Weryfikacja przepisów, orzeczeń i walidacja (W3.1–W3.7)

> Wydzielono z pisma-procesowe-v3/SKILL.md (v5.5) — redukcja NOTA-4
> Wywołanie: `view pisma-procesowe-v3/references/W3-WERYFIKACJA.md`
> Zawiera: W3.1 (ISAP), W3.2 (orzeczenia + ZAKRES-STOSOWANIA), W3.3 (MOD-FAKTY),
>   W3.4 (MOD-WALIDACJA bloki A–J + moduły warunkowe), W3.5 (HYBRID-VALIDATION),
>   W3.6 (raport W3 + pismo finalne), W3.6a (AUDYT-KOŃCOWY), W3.7 (PEER-REVIEW + PV).

---

### W3.1 — Weryfikacja przepisów (ISAP)

**W Claude Code** (dostępny subagent `shared:weryfikator-isap`, narzędzie Agent): deleguj ⚠️Pn w paczkach po 1–4 akty, kilka
instancji równolegle (zgł. #110). Zlecenie: lista powołań z datą zdarzenia i tezą + ścieżki
`JUR:weryfikacja-przepisow-kanon`, tego pliku i `JUR:format-cytowania`. Do głównego kontekstu wraca tylko tabela
(t.j., zmiany po t.j., brzmienie dosłowne, zapis do pisma, URL) — wpisz ją jako raport bloku P.
**Gdzie indziej** (claude.ai, API, Codex, aplikacja Lex Machina) albo gdy subagent niedostępny: kroki poniżej, bez zmian.

Dla każdego ⚠️Pn z listy W2.3:

```
  KROK 1: web_fetch → https://isap.sejm.gov.pl (szukaj aktu po nazwie / Dz.U.)
  KROK 2: Potwierdź: tytuł aktu, numer Dz.U., data tekstu jednolitego
  KROK 3: Odczytaj brzmienie artykułu ze źródła — nie parafrazuj z pamięci
  KROK 4: Sprawdź: czy artykuł nie był nowelizowany po dacie zdarzenia?
  KROK 5: Zapisz zapis do pisma wg JUR:format-cytowania:
          "art. [X] ustawy z dnia [...] r. o [...] (Dz. U. z [rok] r. poz. [nr])"
          URL i metryka ELI → tylko raport bloku P (część robocza), nie treść pisma

FORMAT RAPORTU bloku P (część robocza):
  ✅ P1: zapis do pisma: art. [X] [ustawa] (Dz. U. z [rok] r. poz. [nr]) — ELI: DU/[rok]/[nr] — URL: [...]
  ✅ P2: zapis do pisma: art. [X] [ustawa] (Dz. U. z [rok] r. poz. [nr]) — ELI: DU/[rok]/[nr] — URL: [...]
  ⛔ P3: [opis] — BRAK DOSTĘPU / NIE ZNALEZIONO
          → pozostaw ⚠️ w piśmie z adnotacją [WYMAGA RĘCZNEJ WERYFIKACJI]
```

---

### W3.2 — Weryfikacja orzeczeń

> ⚠️ **Naprawa po NSA I FZ 104/26 (2026-07-05b):** postanowienie NSA
> skrytykowało pełnomocnika, który powołał w zażaleniu postanowienia
> wydane w INNYCH DATACH niż podane i niedotyczące w ogóle powoływanej
> instytucji procesowej — sygnały "bezrefleksyjnego" AI. KROK 2 poniżej
> rozszerzono o obowiązkową weryfikację DOKŁADNEJ DATY (nie tylko sygnatury
> i tezy) — dotąd tylko domyślnie zakładana, teraz jawna.

**W Claude Code** (dostępny subagent `shared:weryfikator-orzeczen`, narzędzie Agent): deleguj ⚠️On w paczkach po 3–5 sygnatur, równolegle.
Zlecenie: sygnatura, data i teza z projektu, teza pisma + ścieżki tego pliku i `JUR:sygnatury-repertoria`.
Wraca tabela FOUND/NOT_FOUND/AMBIGUOUS/OUT_OF_SCOPE z dokładną datą, tezą ze źródła i ZAKRESEM.
**Gdzie indziej** (claude.ai, API, Codex, aplikacja Lex Machina) albo gdy subagent niedostępny: kroki poniżej, bez zmian.

Dla każdego ⚠️On z listy W2.3:

```
  KROK 1: kanał strukturalny NAJPIERW (PRAWO-HARDGATE POZIOM A/B) — sygnatura znana →
           od razu baza urzędowa po repertorium (orzeczenia-sadowe-v2 Faza 1-0 A; JUR:sygnatury-repertoria ROUTING BAZ):
           MCP: sn_sprawdz_sygnature / cbosa_sprawdz_sygnature / kio_sprawdz_sygnature, portal SP (Lex Machina —
           shared/MCP-INTEGRACJA.md; konektory obce: verify_signature);
           SAOS (saos_search z `sygnatura` / API caseNumber) tylko zastępczo i w zasięgu
           (SP bieżąco, SN do 2016, TK do 2015, KIO do 2018; bez NSA/WSA),
           fallback: web_search → "[opis orzeczenia] sygnatura site:orzeczenia.ms.gov.pl"
           lub: web_search → "[opis orzeczenia] sygnatura site:sn.pl"
           Klasyfikuj wynik wg kontraktu FOUND/NOT_FOUND/AMBIGUOUS/OUT_OF_SCOPE
           (JUR:sygnatury-repertoria) — patrz również V-SYG w orzeczenia-sadowe-v2.
  KROK 2: web_fetch → URL z wyników → potwierdź TRZY elementy niezależnie:
           (a) sygnaturę, (b) DATĘ WYDANIA orzeczenia — dokładną, dzień-miesiąc-rok,
           porównaną znak-po-znak z datą podaną w projekcie pisma (nie samym rokiem
           z sygnatury), (c) tezę/sentencję.
           ⛔ Rozbieżność na (b) — nawet przy zgodnej sygnaturze — traktuj jak
           NOT_FOUND dla tej pary sygnatura+data (K-SYG-2, JUR:sygnatury-repertoria) i USUŃ
           datę z pisma albo skoryguj na rzeczywistą, ze wskazaniem źródła.
  KROK 3: Odczytaj tezę ze źródła — nie parafrazuj z pamięci

  KROK 3a — ZAKRES-STOSOWANIA (obowiązkowy):
    Odczytaj stan faktyczny orzeczenia ze źródła.
    Odpowiedz: czy stan faktyczny orzeczenia jest analogiczny do stanu w piśmie?
    Pytania kontrolne:
      □ Czy orzeczenie dotyczy tego samego typu podmiotu?
      □ Czy orzeczenie dotyczy tego samego przepisu w tym samym kontekście?
      □ Czy orzeczenie dotyczy w ogóle TEJ SAMEJ INSTYTUCJI PROCESOWEJ, którą
        pismo powołuje na poparcie (np. "wstrzymanie wykonania" vs "przywrócenie
        terminu" — różne instytucje mimo tej samej gałęzi prawa) — to jest
        odrębne pytanie od "ten sam przepis": błąd I FZ 104/26 polegał na
        powołaniu orzeczeń z INNEJ instytucji niż ta, o którą toczył się spór.
      □ Czy orzeczenie nie ma ograniczonego zakresu (np. wyłącznie prywatyzacja,
        wyłącznie art. 47 KP, wyłącznie określony typ umowy)?
      □ Czy doktryna orzeczenia jest utrwalona czy odosobniona?

    Klasyfikacja (odpowiednik gradientu shared/WERYFIKACJA-SLAD.md GRAD-3b —
    patrz tam mapowanie statusów dla spójności z tabelą śladu/audit-bundle):
      ✅ ZAKRES-OK:      stan faktyczny analogiczny → dopuszcz
      ⚠️ WARN-ZAKRES:   orzeczenie z ograniczonym zakresem stosowania →
                        wskaż ograniczenie w piśmie, szukaj orzeczenia
                        o szerszym zakresie jako wsparcie lub zamiennik
      ⛔ ZAKAZ-ZAKRES:  stan faktyczny orzeczenia NIE obejmuje pisma, LUB
                        orzeczenie dotyczy innej instytucji procesowej →
                        orzeczenia NIE wolno użyć; wstaw ⬛ [UZUPEŁNIJ]

  KROK 4: Sprawdź datę — czy linia orzecznicza aktualna po ewentualnych zmianach prawa?
  KROK 5: Zapisz: "wyrok [sąd] z [data], sygn. [nr], teza: [dosłownie ze źródła]"
           URL źródłowy obowiązkowy

  KROK 6 — "ugruntowana linia orzecznicza" (jeśli pismo używa takiego zwrotu):
    Sformułowania "zgodnie z ugruntowaną/utrwaloną linią orzeczniczą",
    "jednolicie przyjmuje się" to twierdzenie o STANIE CAŁEJ LINII, nie
    o pojedynczym wyroku. Uruchom Zasadę 10 (BILANS) z `orzeczenia-sadowe-v2`
    (Faza 1-D) PRZED W3.6a — sprawdź linię przeciwną, nie tylko przykłady
    zgodne. 🔴 BILANS NIEKORZYSTNY → usuń zwrot "ugruntowana"/"utrwalona",
    zastąp opisem rzeczywistego rozkładu (np. "przeważająca, choć nie
    jednolita, linia orzecznicza").

FORMAT RAPORTU bloku O:
  ✅ O1: wyrok SN z [data], sygn. [nr] — URL: [...] — teza: [...]
         ZAKRES: ✅ analogiczny
  ✅ O2: wyrok SA [miasto] z [data], sygn. [nr] — URL: [...] — teza: [...]
         ZAKRES: ⚠️ WARN — orzeczenie z kontekstu prywatyzacji (III PZP 2/06);
                 użyto pomocniczo — mocniejsze wsparcie: I PK 311/07 + I PK 179/14
  ⛔ O3: [opis orzeczenia] — NIE ZNALEZIONO w oficjalnej bazie
          → ZAKAZ użycia w piśmie. Wstaw ⬛ [UZUPEŁNIJ: orzeczenie potwierdzające X]
```

⛔ ZAKAZ-6: Nie używaj orzeczenia gdy ZAKRES-STOSOWANIA = ZAKAZ-ZAKRES.
Nie cytuj orzeczeń na podstawie samej tezy bez weryfikacji stanu faktycznego.
Orzeczenia z ograniczonym zakresem (WARN-ZAKRES) można użyć tylko pomocniczo,
z jawnym wskazaniem ograniczenia i równoległym silniejszym orzeczeniem.

`view orzeczenia-sadowe-v2/SKILL.md`  (gdy potrzebne szerokie wyszukiwanie)

---

### W3.3 — MOD-FAKTY (gdy pismo z dostarczonych materiałów)

```
Czy użytkownik dostarczył materiały źródłowe?
  TAK → view shared/FAKTY_v2.md
        Procedura F1/F2/F3 — weryfikacja każdego faktu w piśmie
        ⛔ FIKCJA lub ⛔ BRAK ŹRÓDŁA → BLOKADA finalizacji
  NIE → pomiń W3.3
```

---

### W3.4 — MOD-WALIDACJA (zawsze)

```
view shared/MOD-WALIDACJA_v2.md
```

Wykonaj wszystkie bloki A–J. Raport walidacyjny obowiązkowy:

```
BLOK A — wymogi proceduralne (właściwość, strony, opłata, podpis)
BLOK B — spójność wewnętrzna (fakty ↔ dowody, kwoty, daty)
BLOK C — styl procesowy (oceny moralne, ogólne negacje, precyzja wniosków)
         Po Bloku C zawsze: view shared/MOD-KONCENTRACJA.md
         → raport długości per typ pisma (WARN/ALERT gdy za długie)
         → view shared/QUALITY-CHECK.md (kontrola redakcyjna + logiczna)
         → QUALITY-CHECK §5: view shared/MOD-INTRO.md (executive summary)
BLOK D — terminy i prekluzja
         view JUR:liczenie-terminow (zawsze gdy termin zawity lub
         środek zaskarżenia lub przedawnienie)
BLOK E — logika prawna (przepis + fakt + dowód dla każdego roszczenia)
         view shared/ROSZCZENIA.md (gdy ≥2 roszczenia lub żądanie ewentualne)
BLOK F — ryzyka procesowe (co można zaatakować, przyznania niekorzystne)
         view shared/RISK-ASSESSMENT.md (zawsze)
BLOK G — intertemporalność (brzmienie na datę zdarzenia)
         view shared/ISAP-AUDIT-PROTOCOL.md (gdy akty mogły być
         nowelizowane między datą zdarzenia a datą pisma)
BLOK H — zgodność z materiałem źródłowym (zakaz fabrykowania faktów)
BLOK I — skrzyżowanie pismo ↔ dostarczone dowody
         view shared/DOWODY-METODOLOGIA.md (gdy ≥3 dowody lub
         dowód pośredni/ryzykowny)
         view JUR:prekluzja-dowodowa (gdy pismo w toku
         postępowania lub sprawa gospodarcza)
         view shared/EXPERT-OPINION-AUDIT.md (gdy w aktach jest
         opinia biegłego lub pismo kwestionuje biegłego)
BLOK J — weryfikacja statusu prawnego aktów (FSL/LSL) — nowość v2.0:
          przed Blokiem J wywołaj:
          view shared/FACT-SOURCE-LOCK.md
          view shared/LEGAL-STATUS-LOCK.md
```

Moduły proceduralne shared (wczytaj zawsze przed blokami):
```text
view JUR:tryby-procesowe
view JUR:wymogi-formalne-pism
view JUR:braki-formalne
view shared/WARUNKI-SKUTECZNOSCI.md
view shared/RISK-ASSESSMENT.md
view shared/QUALITY-CHECK.md
```

Moduły jakości prawnej (zawsze po BLOK E):
```text
view shared/LEGAL-QUALITY-GATE.md   (bramka: PASS/PASS-WITH-WARNING/FAIL
                                                       — blokuje .docx gdy FAIL)
view JUR:orzecznictwo-hierarchia (gdy pismo powołuje orzecznictwo)
```

Moduły warunkowe (triggery obowiązkowe — NIE "zależnie od sprawy"):
```text
view JUR:liczenie-terminow            → ZAWSZE gdy: termin zawity / środek
                                                        zaskarżenia / przedawnienie roszczenia
view JUR:prekluzja-dowodowa   → ZAWSZE gdy: pismo po pierwszym /
                                                        sprawa gospodarcza / twierdzenia nowe
view shared/DOWODY-METODOLOGIA.md   → ZAWSZE gdy: ≥3 dowody w sprawie /
                                                        dowód pośredni lub kontekstowy
view shared/ROSZCZENIA.md           → ZAWSZE gdy: ≥2 roszczenia /
                                                        żądanie ewentualne / alternatywne
view shared/STRATEGIA-PROCESOWA.md  → ZAWSZE gdy: pismo kończące etap /
                                                        ryzyko procesowe WYSOKIE lub KRYTYCZNE
view shared/ISAP-AUDIT-PROTOCOL.md  → ZAWSZE gdy: akty mogły być nowelizowane
                                                        między datą zdarzenia a datą pisma
view shared/EXPERT-OPINION-AUDIT.md → ZAWSZE gdy: opinia biegłego w aktach /
                                                        pismo kwestionuje biegłego
```

---

### W3.5 — HYBRID-VALIDATION (zawsze po walidacji)

```
view shared/HYBRID-VALIDATION.md
```

FAZA 1: auto-raport braków 🔴/🟡/🔵 bez pytania o zgodę
FAZA 2: użytkownik podaje dane per numer → precyzyjne wstawienie
FAZA 3: licznik ⬛ + docx gdy kompletne

---

### W3.6 — Pismo finalne

Po zamknięciu wszystkich ⚠️ — wydaj wersję finalną. Zapis powołań w treści: `JUR:format-cytowania`
(F1–F9; gdy jest narzędzie: `walidator_cytowan.py --document PISMO --format`, kod 3 = popraw). Raport W3,
metryki ELI i URL-e idą pod nagłówek `CZĘŚĆ ROBOCZA` albo do osobnego pliku, nigdy do treści pisma.

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RAPORT W3
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PRZEPISY:   ✅ [n] zweryfikowane | ⛔ [n] brak dostępu
ORZECZENIA: ✅ [n] zweryfikowane | ⛔ [n] nie znaleziono
WALIDACJA:  [GOTOWE DO ZŁOŻENIA / WYMAGA POPRAWEK / BLOKADA]
POLA ⬛:    [n] do uzupełnienia
ZAPIS F1–F9: [0 naruszeń / lista kodów]

STATUS PISMA: [GOTOWE / PROJEKT — uzupełnij przed złożeniem]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

### W3.6a — AUDYT-KOŃCOWY (gate przed .docx)

> Wywołaj: `view shared/AUDYT-KONCOWY.md`

Wykonuj zawsze, niezależnie od typu pisma — bez warunku aktywacji.

**Krok 1 — COURT-SIMULATION (przed punktową oceną):**
```
view pisma-procesowe-v3/references/engines/court-simulation-engine.md
```
Wykonaj 10 pytań symulacji sądu. Wyniki zasilają bezpośrednio kategorię
"Realizm sądowy" w AUDYT-KONCOWY (nie wykonuj obu niezależnie).

**Krok 2 — LEGAL-QUALITY-GATE (bramka jakości prawa):**
```
view shared/LEGAL-QUALITY-GATE.md
```
Wynik: PASS → kontynuuj; PASS-WITH-WARNING → zaznacz w raporcie;
FAIL → ⛔ BLOKADA .docx — wróć do W3.1 dla problematycznych przepisów.

**Krok 3 — AUDYT-KOŃCOWY (6 kategorii 0–10):**
Oceń pismo finalne w 6 kategoriach (0–10, z uzasadnieniem). Jeśli
KTÓRAKOLWIEK kategoria <7/10 — STATUS = 🔴 BLOKADA: NIE generuj .docx,
wskaż poprawkę, wykonaj ją, powtórz ocenę tej kategorii.

---

### W3.7 — PEER REVIEW + POST-VALIDATION (krok kancelaryjny przed .docx)

> Wykonuj po AUDYT-KOŃCOWY ze statusem ✅ ZAMKNIĘTE.
> To jest ostatni jakościowy checkpoint przed finalną prezentacją — symuluje
> "drugiego adwokata" i pełną walidację spójności.

**Krok 1 — MOD-PEER-REVIEW (gdy warunek aktywacji spełniony):**
```
Aktywuj gdy CHOĆBY JEDNO jest prawdą:
  □ wartość przedmiotu sporu > 50 000 zł
  □ pismo zawiera ≥3 żądania
  □ pismo jest apelacją / zażaleniem do SN/SA
  □ użytkownik użył zwrotu "peer review" / "adwokat diabła" / "sprawdź jeszcze raz"

Jeśli aktywny:
W Claude Code (subagent shared:recenzent-niezalezny): przekaż WYŁĄCZNIE ścieżkę pliku pisma
  i ścieżki akt — bez rozumowania autora, bez list W2/W3, bez raportu W3 (zgł. #110).
  Wynik subagenta (tabela ATAK/UWAGA-SĄDU/INTERES-KLIENTA/SPÓJNOŚĆ + PEER-OK/UWAGI/STOP)
  zastępuje 4 role poniżej. Izolacja: BLIND.
W aplikacji Lex Machina (narzędzie independent_review dostępne): wywołaj je z samym tekstem
  pisma (bez CZĘŚCI ROBOCZEJ, bez ocen i listy mocnych tez); akta dobiera aplikacja.
  Wynik zastępuje 4 role poniżej; zapisz izolację z wyniku (BLIND / NON_BLIND).
Gdzie indziej albo bez subagenta i narzędzia: 4 role jak niżej, izolacja NON_BLIND —
  w raporcie „przegląd własny (red team), nie niezależna ocena” (MOD-PEER-REVIEW §1).
view shared/MOD-PEER-REVIEW.md

Wykonaj 4 role: Adwokat diabła (ATAK-n), Sędzia (UWAGA-SĄDU-n),
Klient (INTERES-KLIENTA-n), Audyt spójności (SPÓJNOŚĆ-n).
Wynik: PEER-OK / PEER-UWAGI / PEER-STOP.
PEER-STOP = ⛔ BLOKADA .docx — wykonaj wskazaną korektę, powtórz ocenę.
Powtórna ocena = nowy kontekst (nowy subagent / nowe independent_review), najwyżej 2 rundy,
  tylko po zmianie materialnej; po niej ponów W3.5 HYBRID-VALIDATION (kontrola regresji).
```

**Krok 2 — POST-VALIDATION (zawsze):**
```
view shared/POST-VALIDATION.md

FAZA 1: automatyczny raport braków 🔴/🟡/🔵 (bez pytania o zgodę)
FAZA 2: wstaw dane użytkownika per numer → jeśli brak → ⬛
Braki 🔴 blokują finalizację.
```

**Krok 3 — UWAGI-REDAKCYJNE DLA PRAWNIKA/KLIENTA (zawsze, wbudowane w plik):**
```
⛔ OBOWIĄZKOWE przy każdym piśmie — analogicznie jak sekcja "Uwagi dla prawnika"
   w systemach konkurencyjnych. Wbuduj do pliku .docx jako ostatnią sekcję
   przed podpisem, wyróżnioną kursywą i kolorem szarym (rozmiar czcionki 18pt).

FORMAT:
  ⚖️ UWAGI REDAKCYJNE PRZED ZŁOŻENIEM:
  🔴 [n] KWESTIE DO BEZWZGLĘDNEGO SPRAWDZENIA:
    1. [konkretna kwestia]
    2. [...]
  🟡 [n] KWESTIE ZALECANE:
    1. [...]
  📌 PRZYJĘTE ZAŁOŻENIA KALKULACYJNE:
    - Wynagrodzenie: [stawka] — źródło: [umowa z dnia]
    - Metodologia odsetek: od 11. dnia każdego miesiąca
    - Premia: [kwota]/mies. — źródło: zeznania [świadek] + dane SUDOP

TRIGGER: ZAWSZE — nie ma warunku aktywacji. Brak sekcji = błąd pipeline.
Zawartość: generuj dynamicznie per sprawę na podstawie:
  → braków 🔴🟡 z POST-VALIDATION FAZA 1
  → anomalii Klasy II z DA-REJ (MOD-DOKUMENT-ANOMALIE)
  → ryzyk RD/RP/RPC z MOD-ATAK-NA-DRAFT RAPORT D
  → założeń kalkulacyjnych z W1.4b
```

---

### Po W3.7 — generowanie .docx i finalizacja

```
⛔ STRIP-VER-GATE → view shared/WERYFIKACJA-SLAD.md § STRIP-VER-GATE
  Wykonaj SVG-1 → SVG-2 → SVG-3 przed generowaniem pliku.
  Blokada: nie wywołuj docx/SKILL.md dopóki SVG-1–SVG-3 niezamknięte.

view HOST_CAPABILITY[document_generation] → generuj .docx

⛔ HARD GATE STEP-DISCLOSURE → wykonaj ST-FINAL (REJESTR KROKÓW).
  Jeśli ≥1 krok wymagany ma status ⚠️ POMINIĘTY lub ○ OCZEKUJE →
  uruchom INFORMACJĘ WARUNKOWĄ, oznacz plik DRAFT — NIEZWERYFIKOWANY
  i ZATRZYMAJ się na decyzję a/b PRZED present_files. (ZAKAZ-14)

present_files (dopiero gdy ST-FINAL = FINAL, albo po świadomej zgodzie „a")

view shared/raport-sytuacyjny-integracja.md → propozycja Raportu Sytuacyjnego
```
