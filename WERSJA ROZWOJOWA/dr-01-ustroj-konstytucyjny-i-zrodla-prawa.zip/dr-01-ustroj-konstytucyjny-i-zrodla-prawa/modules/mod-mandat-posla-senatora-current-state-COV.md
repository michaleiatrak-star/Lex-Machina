# Wykonywanie mandatu posła i senatora — current-state COV

**Akt:** UMPS (ustawa o wykonywaniu mandatu posła i senatora) — t.j. Dz.U. 2026 poz. 1282.
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1).

**Stan operacyjny:** 2026-08-28  
**Status:** B+ / COV  
**Źródło kanoniczne:** ELI, Dz.U. 2026 poz. 1282 t.j. ✅ [VER] RZĄD 1 2026-10-09 (ELI); poprzedni t.j. Dz.U. 2024 poz. 907 — wygaśnięcie aktu.

## Struktura

| Rozdział | Zakres | Status |
|---|---|---|
| 1 | przepisy ogólne | B+/COV |
| 2 | immunitet parlamentarny | B+/COV |
| 3 | prawa i obowiązki posłów i senatorów w Sejmie i Senacie | B+/COV |
| 4 | inne prawa i obowiązki posłów i senatorów | B+/COV |
| 5 | warunki wykonywania mandatu | B+/COV |
| 6 | zmiany, przepisy przejściowe i końcowe | temporal gate |
| załącznik | wzór oświadczenia o stanie majątkowym | fresh gate |

## Runtime

Przy sprawie ustal, czy dotyczy immunitetu, wykonywania mandatu, praw informacyjnych/interwencyjnych, incompatibilitas, warunków pracy lub obowiązków majątkowych. Równolegle sprawdź Konstytucję, regulamin właściwej izby oraz przepisy szczególne.

Immunitet materialny i formalny wymagają odrębnej kwalifikacji; nie traktuj ich jako jednego mechanizmu.

## Fresh gate
ELI wskazuje późniejsze akty zmieniające. Przed zastosowaniem konkretnego uprawnienia, obowiązku lub procedury wyrażenia zgody sprawdź aktualne brzmienie ustawy i regulamin Sejmu/Senatu.

## Quality gate
- [ ] ustalono Sejm/Senat i status osoby;
- [ ] rozróżniono immunitet materialny i formalny;
- [ ] odczytano właściwy rozdział ustawy;
- [ ] sprawdzono Konstytucję i regulamin izby;
- [ ] nie nadano statusu FULL bez audytu artykuł-po-artykule.
