# MOD-STANY-KRYZYSOWE — Stany Nadzwyczajne i Sytuacje Kryzysowe (klęski żywiołowe, katastrofy, epidemie)

**Hasła spraw:** stan wyjątkowy, stan wojenny, stan klęski żywiołowej, ograniczenie wolności i praw w stanie nadzwyczajnym, wolność zgromadzeń, sytuacja kryzysowa, epidemia

**Akt:** Konstytucja RP — Dz.U. 1997 nr 78 poz. 483 (art. 228–234).
**Akt:** USKZ (ustawa o stanie klęski żywiołowej) — t.j. Dz.U. 2025 poz. 112.
**Akt:** USW (ustawa o stanie wyjątkowym) — t.j. Dz.U. 2017 poz. 1928.
**Akt:** USWoj (ustawa o stanie wojennym) — t.j. Dz.U. 2025 poz. 504 (zm. 2026/252 od 2026-04-03 — art. 12a (cyberbezpieczeństwo)).
**Akt:** UZK (ustawa o zarządzaniu kryzysowym) — t.j. Dz.U. 2026 poz. 574 (zm. 2026/815 od 2026-07-04 — m.in. art. 3, uchylone art. 5–6d, nowe rozdziały (odporność podmiotów krytycznych); 2026/1206 [OD 2027-01-11: 2026/1206] — załącznik, sektor bankowy).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1; art. 228–232 Konstytucji odczytane z tekstu ogłoszonego).
**Wersja:** 1.0 | **Dodano:** 2026-07-17
**Rola w systemie:** czwarty moduł w rodzinie DR-01 poświęconej prawu
międzyczasowemu/kolizyjnemu, obok `mod-ZTP-przepisy-przejsciowe-doktryna.md`
i `mod-specustawy-lex-specialis-graf-zaleznosci.md`. Tamte moduły odpowiadają
na pytania "co ze starym prawem gdy wchodzi nowe" i "który z dwóch aktów
stosować". Ten moduł odpowiada na osobne pytanie: **jaki reżim prawny
uruchamia się, gdy państwo reaguje na klęskę żywiołową, katastrofę lub
epidemię** — i jak te reżimy (konstytucyjny i ustawowe) mają się do siebie.

> ⛔ NIE DUBLUJ: katalog specustaw doraźnych (np. specustawa koronawirusowa)
> → `mod-specustawy-lex-specialis-graf-zaleznosci.md` sekcja 3 (już tam
> jest, nie powielaj). Ten moduł dostarcza WARSTWĘ WYŻSZĄ — konstytucyjną
> i ustrojową architekturę, w którą te specustawy się wpisują.

**Zasada:** `view prawo-polskie-v2/krajowe/shared/PRAWO-HARDGATE.md` przed każdym
przepisem/aktem z tego modułu.

---

## 1. CZTERY POZIOMY REŻIMU PRAWNEGO — NIE JEDNA DRABINA, DWIE OSOBNE OSIE

Kluczowe ustalenie doktrynalne: sytuacje kryzysowe w Polsce NIE są regulowane
jedną hierarchiczną drabiną "coraz poważniejszych" stanów. Istnieją **dwie
osobne, częściowo niezależne osie**:

**OŚ A — Konstytucyjne stany nadzwyczajne (Rozdział XI Konstytucji, art. 228-234)**
Wymagają formalnego aktu wprowadzenia (rozporządzenie + kontrola Sejmu),
uruchamiają szczególny reżim ograniczeń praw i wolności oraz zakazy
ustrojowe (brak zmian Konstytucji, ordynacji wyborczych, wyborów).

**OŚ B — Ustawowe reżimy zarządzania zagrożeniem (poniżej progu konstytucyjnego)**
Ustawa o zarządzaniu kryzysowym (2007), ustawa o ochronie ludności i obronie
cywilnej (2024), oraz odrębnie — ustawa o zapobieganiu chorobom zakaźnym
(2008) ze swoimi WŁASNYMI "stanami" (stan zagrożenia epidemicznego, stan
epidemii), które **nie są stanami nadzwyczajnymi z Rozdziału XI Konstytucji**,
mimo mylącej nazwy i podobnej wagi społecznej.

**To rozróżnienie było źródłem największej kontrowersji konstytucyjnej
ostatnich lat w Polsce (COVID-19) — patrz sekcja 4.**

---

## 2. OŚ A — PODSTAWA KONSTYTUCYJNA (Rozdział XI, art. 228-234)

**Art. 228 ust. 1:** w sytuacjach szczególnych zagrożeń, jeżeli zwykłe środki
konstytucyjne są niewystarczające, może zostać wprowadzony odpowiedni stan
nadzwyczajny: **stan wojenny, stan wyjątkowy lub stan klęski żywiołowej**.

**Art. 228 ust. 2-5** — wymogi wspólne dla wszystkich trzech: wprowadzenie
tylko na podstawie ustawy, w drodze rozporządzenia podawanego dodatkowo do
publicznej wiadomości; ustawa określa zasady działania organów i zakres
ograniczeń praw/wolności; działania muszą być proporcjonalne do zagrożenia
i zmierzać do jak najszybszego przywrócenia normalnego funkcjonowania państwa.

**Art. 232 (najistotniejszy dla klęsk żywiołowych/katastrof):** w celu
zapobieżenia skutkom katastrof naturalnych lub awarii technicznych
noszących znamiona klęski żywiołowej oraz w celu ich usunięcia, **Rada
Ministrów** może wprowadzić na czas oznaczony, **nie dłuższy niż 30 dni**,
stan klęski żywiołowej na części albo całym terytorium państwa. Przedłużenie
wymaga zgody Sejmu. (Dla porównania: stan wojenny/wyjątkowy wprowadza
**Prezydent RP** na wniosek Rady Ministrów, z obowiązkiem przedstawienia
Sejmowi w ciągu 48 godzin — art. 229-231.)

**Zakazy wspólne w czasie stanu nadzwyczajnego (niezależnie od jego rodzaju):**
zakaz zmiany Konstytucji, ordynacji wyborczych do Sejmu/Senatu/samorządu,
ustawy o wyborze Prezydenta oraz ustaw o stanach nadzwyczajnych; zakaz
skrócenia kadencji Sejmu, przeprowadzania referendum ogólnokrajowego i
wyborów (Sejm, Senat, samorząd, Prezydent) — także przez 90 dni po
zakończeniu stanu — z odpowiednim przedłużeniem kadencji tych organów.

**Ustawy wykonawcze do art. 228-234 (jedna ustawa na każdy z trzech stanów):**

| Stan | Ustawa | Kto wprowadza |
|---|---|---|
| Stan klęski żywiołowej | Ustawa z 18.04.2002 o stanie klęski żywiołowej (t.j. Dz.U. 2025 poz. 112) | Rada Ministrów, rozporządzenie, max 30 dni |
| Stan wyjątkowy | Ustawa z 21.06.2002 o stanie wyjątkowym (t.j. Dz.U. 2017 poz. 1928) | Prezydent RP na wniosek RM, najwyżej 90 dni, jedno przedłużenie za zgodą Sejmu do 60 dni (art. 230); rozporządzenie Sejmowi w 48 h (art. 231) |
| Stan wojenny | Ustawa z 29.08.2002 o stanie wojennym oraz o kompetencjach Naczelnego Dowódcy Sił Zbrojnych... (t.j. Dz.U. 2025 poz. 504) | Prezydent RP na wniosek RM, bez konstytucyjnego limitu czasu (art. 229); rozporządzenie Sejmowi w 48 h, Sejm może uchylić bezwzględną większością (art. 231) |

✅ VER 2026-08-14 (F-77): numery Dz.U. tabeli zweryfikowane u źródła — stan
klęski żywiołowej i stan wojenny potwierdzone bezpośrednio (Kancelaria Sejmu,
isap.sejm.gov.pl); stan wyjątkowy potwierdzony pośrednio (2017.1928 wciąż
cytowany jako aktualny w dokumencie źródłowym datowanym 2026-07-07 — 9 lat
bez nowego t.j. jest wiarygodne dla rzadko używanej ustawy, ale ⚠️
zweryfikuj ponownie na ISAP przed użyciem w piśmie, gdyby w międzyczasie
doszło do nowelizacji). Stan wojenny miał NAJWIĘKSZĄ rozbieżność — poprzedni
zapis modułu podawał wyłącznie datę uchwalenia bez numeru Dz.U., podczas gdy
istnieje t.j. z 10.04.2025 (Dz.U. 2025 poz. 504), nowszy niż poprzedni
t.j. 2022.2091.

⚠️ Mimo pełnej weryfikacji 2026-08-14 (F-77), przed użyciem którejkolwiek
z tych ustaw w piśmie procesowym ponownie zweryfikuj aktualny t.j. na ISAP —
zwłaszcza stan wyjątkowy, gdzie brak nowszego t.j. od 2017 r. jest wiarygodny,
ale niepotwierdzony z absolutną pewnością wobec częstych nowelizacji innych
aktów tej rodziny.

---

## 3. OŚ B — REŻIMY USTAWOWE PONIŻEJ PROGU KONSTYTUCYJNEGO

### 3.1 Ustawa o zarządzaniu kryzysowym (26.04.2007)

Reguluje **"sytuację kryzysową"** — kategorię ustawową ODRĘBNĄ od
konstytucyjnego "stanu nadzwyczajnego". Od 4.07.2026 art. 1 ust. 1 stanowi:
"Ustawa określa: 1) organy właściwe w sprawach zarządzania kryzysowego oraz
zadania i zasady działania tych organów; 2) organy właściwe w sprawach
identyfikacji infrastruktury krytycznej oraz ich zadania; 3) zadania
i obowiązki operatorów infrastruktury krytycznej; 4) usługi kluczowe oraz
zadania i obowiązki podmiotów krytycznych; 5) organy do spraw podmiotów
krytycznych oraz ich zadania; 6) zasady sprawowania nadzoru nad podmiotami
krytycznymi oraz ich kontroli; 7) zasady finansowania zadań, o których mowa
w pkt 1–6." (zm. Dz.U. 2026 poz. 815, od 4.07.2026). Definicja "sytuacji
kryzysowej" (art. 3 pkt 1) w nowym brzmieniu: "sytuację wpływającą
negatywnie na poziom bezpieczeństwa ludzi, mienia w znacznych rozmiarach,
środowiska lub dziedzictwa kulturowego, wywołującą znaczne ograniczenia
w działaniu właściwych organów administracji publicznej ze względu na
nieadekwatność posiadanych sił i środków lub zakłócenia w obsłudze tych
organów" (zm. Dz.U. 2026 poz. 815, od 4.07.2026). Może działać
**RÓWNOLEGLE** do normalnego funkcjonowania państwa, bez uruchamiania
Rozdziału XI Konstytucji — to jest właśnie różnica jakościowa, nie tylko
stopnia. Aktualny t.j.: **Dz.U. 2026 poz. 574** (obwieszczenie Marszałka
Sejmu z 21.04.2026, stan prawny na 16.04.2026), ze zmianą **Dz.U. 2026 poz.
815** (ustawa z 29.05.2026 wdrażająca dyrektywę UE 2022/2557 o odporności
podmiotów krytycznych; w życie 4.07.2026 — art. 73: 14 dni od ogłoszenia
19.06.2026; uchyla art. 5–6d i dodaje rozdziały 2–16, m.in. Krajowa Ocena
Ryzyka — art. 6e; "planach zarządzania kryzysowego – należy przez to rozumieć
plany zarządzania ryzykiem oraz plany reagowania kryzysowego" — art. 3 pkt 16;
przepisy przejściowe: art. 28–35 ustawy zmieniającej); ⏳ dalsza zmiana po
t.j.: Dz.U. 2026 poz. 1206 (w zakresie tej ustawy od 11.01.2027, ELI
2026-10-12). ✅ VER: isap.sejm.gov.pl (WDU20260000574,
api.sejm.gov.pl/eli/acts/DU/2026/574/text.pdf), samorzad.pap.pl,
zamowieniapubliczne doradca.pl — 2026-08-14 (F-77). ⚠️ poprzedni zapis
modułu nie podawał żadnego numeru ("dokładny numer pozycji do potwierdzenia
przy najbliższym audycie") — ustawa nowelizowana bardzo często, weryfikuj
ponownie przed każdym użyciem w piśmie.

### 3.2 Ustawa o ochronie ludności i obronie cywilnej (5.12.2024, Dz.U. 2024 poz. 1907)

⏳ Brak t.j.; zm.: Dz.U. 2025 poz. 1705, Dz.U. 2026 poz. 646, Dz.U. 2026
poz. 815 (od 4.07.2026 — art. 27: art. 5 ust. 2, art. 15 ust. 1 pkt 6,
art. 38, art. 40, art. 44; art. 5 ust. 1 bez zmian). ✅ ELI 2026-10-12.

**Nowy element architektury** — weszła w życie od 1.01.2025 r., po latach
prac legislacyjnych (poprzednie projekty z l. 2022-2023 nosiły roboczy tytuł
"o ochronie ludności i stanie klęski żywiołowej", co sugerowało zastąpienie
dotychczasowej ustawy o stanie klęski żywiołowej — **finalna wersja tego NIE
zrobiła**: art. 5 ust. 1 tej ustawy wprost odsyła do WSPÓŁISTNIEJĄCEJ ustawy
o stanie klęski żywiołowej, ustawy o zarządzaniu kryzysowym, o stanie
wyjątkowym, o stanie wojennym i o obronie Ojczyzny — jako odrębnych,
równoległych podstaw działania organów ochrony ludności. **To jest przykład
z tej samej rodziny zagadnień co MOD-SPECUSTAWY sekcja 5 (graf zależności)
— nowy akt nie deroguje starych, tylko się z nimi splata.**

### 3.3 Stan zagrożenia epidemicznego / stan epidemii (ustawa z 5.12.2008)

Ustawa o zapobieganiu oraz zwalczaniu zakażeń i chorób zakaźnych u ludzi —
art. 46, 46a, 46b (dodane nowelizacją z 8.03.2020) — wprowadza WŁASNE
"stany": **stan zagrożenia epidemicznego** i **stan epidemii**, ogłaszane
rozporządzeniem Ministra Zdrowia (na podstawie upoważnienia ustawowego) lub
Rady Ministrów co do dalszych nakazów/zakazów.

**⚠️ KLUCZOWE ROZRÓŻNIENIE (najczęstszy błąd w analizie):** stan epidemii z
tej ustawy **nie ma nic wspólnego z konstytucyjnym katalogiem stanów
nadzwyczajnych z art. 228 Konstytucji**. To osobna kategoria ustawowa, z
osobnym reżimem ograniczeń — i to właśnie ta różnica wywołała główny spór
doktrynalny lat 2020-2022 (sekcja 4).

---

## 4. DOKTRYNALNA KONTROWERSJA COVID-19 — DLACZEGO TO MA ZNACZENIE PRAKTYCZNE

W marcu 2020 r. rząd RP wybrał **stan epidemii** (ustawa z 2008 r.) zamiast
konstytucyjnego **stanu klęski żywiołowej** (art. 232 Konstytucji), mimo że
w doktrynie i orzecznictwie wskazywano, iż choroba zakaźna ludzi mieści się
w ustawowej definicji "katastrofy naturalnej" uzasadniającej stan klęski
żywiołowej.

**Argumentacja doktrynalna przeciw wyborowi rządu** (Palestra 9/2020, Palestra
6/2020, Radca Prawny — Zeszyty Naukowe 3/2021): skoro przesłanki
konstytucyjne stanu klęski żywiołowej były spełnione, ograniczenia praw i
wolności wprowadzane wyłącznie ROZPORZĄDZENIAMI (a nie ustawą) naruszały
art. 31 ust. 3 Konstytucji — który wymaga, by ograniczenia konstytucyjnych
wolności i praw były ustanawiane **tylko w ustawie**, samodzielnie
określającej podstawowe elementy ograniczenia (utrwalone orzecznictwo TK).
W doktrynie ukuto określenia: **"materialny stan klęski żywiołowej bez
formy"**, **"hybrydowy stan nadzwyczajny"** — sytuacja, w której faktycznie
spełnione są konstytucyjne przesłanki stanu nadzwyczajnego, ale formalnie
go nie wprowadzono, co pozbawia obywateli gwarancji proceduralnych
przewidzianych właśnie NA WYPADEK takiej sytuacji (kontrola sejmowa,
czasowe ograniczenie, odszkodowania za straty majątkowe z art. 228 ust. 4).

**Kontrargument (potwierdzony orzecznictwem):** Sąd Najwyższy wskazał, że
Rada Ministrów **nie miała obowiązku** wprowadzać stanu klęski żywiołowej,
skoro istniała alternatywna podstawa ustawowa (stan epidemii) — przesłanki
wprowadzenia stanu nadzwyczajnego są na tyle ogólne, że ich ocena mieści się
w sferze uznania administracyjnego rządu, a nie jest obowiązkiem prawnym o
określonej treści. **Konsekwencja tej dyskrecjonalności:** skoro RM
zrezygnowała ze stanu klęski żywiołowej, uznała tym samym, że zwykłe środki
konstytucyjne są wystarczające — co oznacza, że **wszystkie zwykłe zasady
konstytucyjne i legislacyjne** (w tym art. 31 ust. 3 — wymóg formy ustawowej
dla ograniczeń praw) **musiały być w pełni przestrzegane**, bez możliwości
powoływania się na nadzwyczajność sytuacji jako usprawiedliwienie dla
rozporządzeń wykraczających poza delegację ustawową.

⚠️ Powyższy pogląd o dyskrecjonalności RM (za: S. Czarnow, Radca Prawny —
Zeszyty Naukowe 3/2021) referuje "jedno z orzeczeń SN" bez podania w
dostępnym fragmencie źródła dokładnej sygnatury tej konkretnej tezy — nie
myl go z konkretnymi, w pełni zweryfikowanymi sygnaturami z tabeli w
sekcji 4.1 poniżej (II KK 74/21 i linia towarzysząca), które dotyczą
ODRĘBNEJ, choć powiązanej kwestii: nie dyskrecji co do WYBORU reżimu, lecz
wadliwości KONKRETNYCH sankcji nałożonych na podstawie rozporządzeń
przekraczających delegację ustawową. Przed powołaniem tezy o dyskrecji RM
w piśmie — dodatkowa weryfikacja sygnatury na sn.pl.

**Znaczenie praktyczne dla analizy spraw:** jeżeli klient kwestionuje
konkretne ograniczenie praw wprowadzone w okresie COVID rozporządzeniem
(a nie ustawą) — argument "brak podstawy ustawowej, bo nie wprowadzono
stanu nadzwyczajnego, więc obowiązywały zwykłe rygory art. 31 ust. 3
Konstytucji" ma silne oparcie w doktrynie i był wielokrotnie uwzględniany
przez sądy administracyjne kontrolujące akty wykonawcze z tego okresu.

### 4.1 ORZECZNICTWO WPIĘTE — brak podstawy ustawowej ograniczeń covidowych

Zweryfikowane online 2026-07-17 (punkt startowy, nie zamknięty katalog;
linia jednolita i bogata — poniżej wybrane, najczęściej cytowane orzeczenia):

| Orzeczenie | Teza |
|---|---|
| SN, wyrok z 16.03.2021, sygn. II KK 74/21 (potwierdzone: sn.pl — baza orzeczeń, inforlex.pl, kbpp.pl, adwokat.suszynski.com.pl) | Kasacja RPO uwzględniona, uniewinnienie. SN wskazał wprost: ustawa z 2008 r. o zapobieganiu oraz zwalczaniu zakażeń i chorób zakaźnych u ludzi NIE zawiera unormowań określających możliwość i warunki ograniczenia konstytucyjnej wolności poruszania się — akty rangi niższej niż ustawa (rozporządzenie z 31.03.2020) nie mogą limitować tej wolności |
| SN, wyroki z 16.03.2021, sygn. II KK 64/21 i II KK 97/21 (potwierdzone: sn.pl, adwokat.suszynski.com.pl) — wydane tego samego dnia, ta sama linia | Analogiczna argumentacja — brak podstawy ustawowej dla zakazu przemieszczania się z rozporządzenia z 31.03.2020 |
| SN, wyrok z 14.04.2021, sygn. II KK 122/21 (potwierdzone: bip.brpo.gov.pl — pełny tekst orzeczenia) | Kontynuacja linii z 16.03.2021 — powołuje się wprost na II KK 74/21, II KK 64/21, II KK 97/21 jako ugruntowaną linię |

**Wniosek praktyczny:** to jest linia JEDNOLITA (nie ma tu poważnej linii
przeciwnej co do zasady braku podstawy ustawowej) — SN konsekwentnie
stwierdzał wadliwość sankcji nakładanych na podstawie rozporządzeń
covidowych przekraczających delegację ustawową. Linia przeciwna dotyczy
raczej DYSKRECJI RM co do WYBORU reżimu (stan epidemii vs stan klęski
żywiołowej) — to jest odrębna kwestia od WYKONANIA tego reżimu, co do
którego SN był krytyczny.

⛔ Każde KOLEJNE powołanie orzeczenia covidowego spoza tej tabeli wymaga
odrębnej weryfikacji online — HARDGATE, linia orzecznicza w tym obszarze
jest bardzo bogata (dziesiątki wyroków WSA/NSA), powyższe to tylko punkt
startowy z linii SN.

---

## 5. GRAF ZALEŻNOŚCI — ARCHITEKTURA REŻIMÓW KRYZYSOWYCH

Zgodnie ze schematem węzeł/krawędź z `mod-specustawy...` sekcja 5.2, ale
zastosowanym do relacji między REŻIMAMI (nie pojedynczymi przepisami):

```
[Konstytucja RP, Rozdział XI, art. 228-234]
        │
        ├──(wykonuje)──> [Ustawa o stanie klęski żywiołowej 2002]
        │                        │
        │                        └──(współpracuje z, NIE zastępuje)──>
        │                           [Ustawa o ochronie ludności i obronie
        │                            cywilnej 2024 — art. 5 ust. 1: odesłanie
        │                            wprost do współistnienia]
        │
        ├──(wykonuje)──> [Ustawa o stanie wyjątkowym 2002]
        ├──(wykonuje)──> [Ustawa o stanie wojennym 2002]
        │
        └──(NIE wykonuje — oś odrębna)──> [Ustawa o zarządzaniu kryzysowym
                                            2007 — działa PONIŻEJ progu
                                            konstytucyjnego, równolegle]
                                                    │
                                                    └──(nakłada się na)──>
                                                       [Ustawa o ochronie
                                                        ludności i obronie
                                                        cywilnej 2024]

[Ustawa o zapobieganiu chorobom zakaźnym 2008 — art. 46/46a/46b]
        │
        └──(stan epidemii/zagrożenia epidemicznego — WŁASNA kategoria,
            BRAK krawędzi do Rozdziału XI Konstytucji — to jest właśnie
            źródło kontrowersji z sekcji 4)
                │
                └──(uruchamia w praktyce)──> [specustawa koronawirusowa
                                               2020 — patrz mod-specustawy
                                               sekcja 3, katalog]
```

**Wniosek praktyczny z grafu:** oś "stan epidemii" wisi w powietrzu
względem konstytucyjnej architektury stanów nadzwyczajnych — nie ma do niej
krawędzi. To nie jest usterka grafu, to jest DOKŁADNIE ten sam brak, który
opisuje doktryna jako źródło problemu konstytucyjnego. Graf sam w sobie
jest więc narzędziem diagnostycznym: brakująca krawędź = potencjalny zarzut
konstytucyjny do wykorzystania w piśmie.

---

## 6. ALGORYTM — KTÓRY REŻIM ZASTOSOWAĆ DO KONKRETNEJ SYTUACJI KRYZYSOWEJ

```
KROK 1 — Czy zagrożenie ma charakter katastrofy naturalnej lub awarii
         technicznej noszącej znamiona klęski żywiołowej (art. 232
         Konstytucji + definicja ustawowa z ustawy o stanie klęski
         żywiołowej)?
  TAK → możliwe wprowadzenie stanu klęski żywiołowej (Rada Ministrów,
        max 30 dni + przedłużenie za zgodą Sejmu) → OŚ A.
        Ale: wprowadzenie NIE jest obowiązkiem automatycznym (dyskrecja
        RM, potwierdzona orzeczeniem SN — sekcja 4) → sprawdź KROK 2.
  NIE → KROK 3.

KROK 2 — Czy rząd FAKTYCZNIE wprowadził stan klęski żywiołowej?
  TAK → stosuj reżim art. 228 ust. 3-5 Konstytucji + ustawę o stanie
        klęski żywiołowej wprost.
  NIE → zagrożenie jest zarządzane na OSI B (zarządzanie kryzysowe /
        ochrona ludności) — ALE sprawdź, czy ograniczenia praw i wolności
        wprowadzone w tym trybie mają podstawę USTAWOWĄ (art. 31 ust. 3
        Konstytucji), nie tylko w rozporządzeniu — jeśli nie, możliwy
        zarzut konstytucyjny analogiczny do kontrowersji COVID (sekcja 4).

KROK 3 — Czy zagrożenie ma charakter epidemiologiczny (choroba zakaźna)?
  TAK → stosuje się ustawa z 2008 r. (stan zagrożenia epidemicznego / stan
        epidemii) — pamiętaj: to NIE jest stan nadzwyczajny z Rozdziału XI,
        mimo że w praktyce bywa równie dotkliwy dla praw i wolności.
        Sprawdź, czy konkretne ograniczenie ma podstawę ustawową (art. 46a/
        46b) czy tylko w samym rozporządzeniu wykonawczym — braki
        delegacji ustawowej były wielokrotnie stwierdzane przez sądy
        administracyjne w sprawach covidowych.
  NIE → KROK 4.

KROK 4 — Czy zagrożenie ma charakter wojenny lub godzi w porządek
         konstytucyjny/bezpieczeństwo wewnętrzne (nie naturalne/techniczne/
         epidemiologiczne)?
  TAK → możliwy stan wojenny lub stan wyjątkowy (Prezydent RP na wniosek RM,
        kontrola Sejmu w 48h) → OŚ A, inna procedura wprowadzenia niż stan
        klęski żywiołowej.
  NIE → zwykłe środki konstytucyjne i ustawowe, brak podstaw do sięgania po
        którykolwiek z powyższych reżimów nadzwyczajnych.
```

---

## 7. LITERATURA EKSPERCKA (zweryfikowana online 2026-07-17)

- **S. Czarnow**, *Między stanem epidemii a stanem klęski żywiołowej —
  COVID-19 a niektóre prawa człowieka*, Radca Prawny. Zeszyty Naukowe
  3(28)/2021 — najbardziej szczegółowe zestawienie argumentów za i przeciw
  wyborowi reżimu ustawowego przez rząd, z powołaniem stanowiska RPO i
  orzecznictwa SN/sądów administracyjnych.
- **Palestra 9/2020**, *Pandemia COVID-19 a konstytucyjne stany nadzwyczajne*
  — analiza dyskrecjonalności Rady Ministrów przy stosowaniu art. 232
  Konstytucji i wykładni słowa "może" w prawie publicznym.
- **Palestra 6/2020**, *Konstytucyjne podstawy rozstrzygania kolizji
  obowiązków i konfliktów dóbr w czasie epidemii* — cztery konkurencyjne
  modele kwalifikacji sytuacji faktycznej (m.in. "materialny stan klęski
  żywiołowej bez formy", "hybrydowy stan nadzwyczajny").
- **Temidium**, *Jawność postępowań sądowych podczas pandemii COVID-19 —
  między konstytucyjnym standardem a rzeczywistością* — zastosowanie tej
  kontrowersji do konkretnego prawa (jawność rozpraw).
- **K. Prokop**, *Stany nadzwyczajne w Rzeczypospolitej Polskiej* —
  cytowana w literaturze jako podstawowa monografia teoretyczna dot.
  dyskrecjonalności organów przy wprowadzaniu stanów nadzwyczajnych.

---

## 8. INTEGRACJA Z SYSTEMEM

- **`mod-specustawy-lex-specialis-graf-zaleznosci.md`** — specustawa
  koronawirusowa (już skatalogowana tam w sekcji 3) jest NARZĘDZIEM
  WYKONAWCZYM w ramach reżimu "stan epidemii" opisanego tutaj. Przy
  pytaniu łączonym — wywołaj oba moduły.
- **`mod-ZTP-przepisy-przejsciowe-doktryna.md`** — ustawa o ochronie
  ludności i obronie cywilnej (2024) jako świeży przykład koegzystencji
  nowego i starych aktów bez pełnej derogacji — ilustracja techniki C
  (zachowanie uprawnień + okres przejściowy) z tamtego modułu.
- **DR-09 (Budownictwo/Środowisko/Energia/Transport)** — klęski żywiołowe o
  podłożu środowiskowym (powodzie, pożary) — ten moduł dostarcza ramy
  konstytucyjnej, DR-09 ustala szczegółowe przepisy sektorowe.
- **DR-10 (Zdrowie)** — stan epidemii/zagrożenia epidemicznego jako
  zagadnienie zdrowia publicznego — ten moduł dostarcza ramy konstytucyjnej
  kontrowersji, DR-10 ustala aktualne szczegóły sanitarno-epidemiologiczne.
- **DR-13 (Służby/Bezpieczeństwo)** — stan wojenny/wyjątkowy, obrona cywilna.
- **`orzeczenia-sadowe-v2`** — źródło do weryfikacji konkretnych wyroków
  sądów administracyjnych stwierdzających brak podstawy ustawowej dla
  ograniczeń covidowych (liczne, nie cytuj sygnatur z pamięci).
- **`pisma-procesowe-v3`** — argument "brak stanu nadzwyczajnego → zwykłe
  rygory art. 31 ust. 3 Konstytucji w pełni obowiązywały" jako gotowa
  podstawa zarzutu przy kwestionowaniu aktów wykonawczych z okresów
  kryzysowych (nie tylko COVID — mechanizm jest uniwersalny).
