# CHANGELOG — dr-01-ustroj-konstytucyjny-i-zrodla-prawa

- 3.21 (2026-11-06): migracja prawa polskiego E3: ścieżki odwołań do modułów przeniesionych z shared i skilli wykonawczych do prawo-polskie-v2/krajowe/ (treść bez zmian)
- 3.20 (2026-10-20, AUDYT-2026-10-20g): SKILL.md: znacznik `lex:wykonuje-aplikacja: REJESTR-MODULOW` nad rejestrem modułów — w trybie mechanicznym aplikacja podaje modelowi indeks nazw (moduły aktów dobiera z MAPA-AKTOW), w AUTO rejestr w całości
- 3.19 (2026-10-12b, AUDYT-2026-10-12b): mod-stany-nadzwyczajne-sytuacje-kryzysowe: ustawa o zarządzaniu kryzysowym po zm. Dz.U. 2026 poz. 815 (od 4.07.2026) — nowy art. 1 ust. 1, definicja sytuacji kryzysowej i planów zarządzania kryzysowego dosłownie; ⏳ 2026/1206 (od 11.01.2027); ochrona ludności — zm. 2025/1705, 2026/646, 815. ELI 2026-10-12.

- 3.18 (2026-10-09f, AUDYT-2026-10-09f): mod-mandat-posla-senatora: źródło kanoniczne t.j. Dz.U. 2026 poz. 1282 (było wygasłe 2024/907; ELI 2026-10-09).

- 3.17 (2026-10-09, AUDYT-2026-10-09): mandat posła i senatora — t.j. Dz.U. 2026 poz. 1282 (ELI 2026-10-09; poprzedni 2024/907 wygasł).

- 3.16 (2026-10-05l, AUDYT-2026-10-05l): mod-stany-nadzwyczajne: linia „Hasła spraw” (słowa, którymi klient opisuje sprawę; aplikacja dobiera po nich moduł). Treść prawna bez zmian.

- 3.15 (2026-10-04n, AUDYT-2026-10-04n): Historia zmian SKILL.md i modułów przeniesiona z plików roboczych do `references/HISTORIA-ZMIAN-PLIKOW.md` (plik historyczny, niewczytywany przez model). Treść robocza bez zmian.

- 3.14 (2026-10-04c, AUDYT-2026-10-04c): **F-227 (zamknięta).** SKILL.md nie wczytywał `MAPA-POKRYCIA.md`, choć `prawny-router-v3/references/pokrycie-dziedzinowe.md` nazywa lokalną mapę jedynym bieżącym źródłem statusu pokrycia — dodana sekcja „Mapa pokrycia treściowego” z `view`, wzorem DR-02…DR-06 i DR-16. Treść prawa bez zmian. Pełny opis: `audyt-systemu-v4/references/AUDIT-JOURNAL.md`, AUDYT-2026-10-04c.

- 3.13 (2026-09-27e, AUDYT-2026-09-27e): claude.ai po dodaniu marketplace instalował wyłącznie 4 z 32 pluginów (shared, prawny-router-v3, analizator-dowodow-v3, przesluchanie-swiadkow-v2-min90); jedyna cecha wspólna tych 4, nieobecna w żadnym z 28 pozostałych, to klucz `dependencies` we frontmatterze SKILL.md. Dodano go (`requires: [shared]` — zgodnie ze stanem faktycznym) oraz jawny manifest pluginu (name, description = description z SKILL.md, author, repository, license) — host nie musi niczego wnioskować z SKILL.md. `version` w manifeście = `version:` z SKILL.md (pilnuje T38 w audyt-systemu-v4) — host rozpoznaje aktualizację po podbiciu wersji. Treść skilla bez zmian.
- 3.12 (2026-09-23, AUDYT-2026-09-23c): SKILL.md: „Źródło podstawowe” — LEX/Legalis → ArsLege gdy aktu nie da się pobrać z RZĘDU 1 (awaria serwera, timeout, blokada); korekta użytkownika do warunku E-3.
- 3.11 (2026-09-23, AUDYT-2026-09-23b): kanon E-1…E-5 (`shared/HIERARCHIA-ZRODEL.md` 1.10): instrukcje weryfikacji „w ISAP” / „isap.sejm.gov.pl →” zamienione na „w ELI (RZĄD 1)” (4 plików); ISAP pozostaje adresem dla człowieka; wpisy historyczne („zweryfikowano w ISAP …”) bez zmian.
- 3.10 (2026-09-16, F-189): mod-ustawa-KRS-i-ustroj-wladzy — ustawa o Radzie Ministrów: `2022/2032` (obwieszczenie MSWiA o rozporządzeniu — podmiana aktu, wygasłe) → t.j. `2025/780` (RZĄD 1; T27).
- 3.9 (2026-08-27): F-108/50 — dodano dedykowany moduł ustawy o Sądzie Najwyższym (poziom B), oparty na RZĄD 1 ELI; oddzielono zmianę prospektywną z Dz.U. 2026 poz. 1123 od prawa obowiązującego.

- 3.8 (2026-08-26): zsynchronizowano metryki tekstów jednolitych w mapie aktów
  oraz modułach ZTP, specustaw, partii politycznych i referendum.

> Lokalizacja kanoniczna historii wersji (ZASADA 15, `audyt-systemu-v4/SKILL.md`).
> Plik założony 2026-08-24 w ramach flagi **F-126** — do tej daty jedyny wpis
> historii tego skilla mieszkał w sekcji `## CHANGELOG` w korpusie `SKILL.md`,
> co T12 zgłaszał jako ⛔.

- 3.7 (2026-08-24, sesja audytowa audyt-systemu-v4, flagi F-115 P3 + F-126):
  (a) podłączenie self-checku ANTY-FASADA jako WYWOŁANIA modułu kanonicznego
  `shared/SELF-CHECK-ANTY-FASADA.md` — domknięcie zakresu P3 flagi F-115
  (16 skilli DR); (b) historia wersji przeniesiona 1:1 z korpusu SKILL.md do
  tego pliku. Pełny opis: `audyt-systemu-v4/references/AUDIT-JOURNAL.md`,
  wpis AUDYT-2026-08-24.

⛔ **LUKA HISTORII 3.4 – 3.6 — ŚWIADOMIE NIEODTWORZONA.** Numery 3.4, 3.5 i 3.6
nie mają wpisu ani tutaj, ani w korpusie SKILL.md, ani w polu `changelog:` YAML.
Zgodnie z zakazem z wiersza flagi F-126 (precedens F-102: groziło dopisanie
pięciu zmyślonych wpisów) **nie zostały odtworzone z pamięci**. Ślad tych zmian —
o ile istnieje — należy szukać w `audyt-systemu-v4/references/AUDIT-JOURNAL.md`
po dacie sesji, nie w tym pliku.

---

## Wpisy przeniesione z korpusu SKILL.md (F-126, 2026-08-24)

> Tekst poniżej przeniesiony 1:1 z sekcji `## CHANGELOG` w `SKILL.md`.
> Nic nie przeredagowano ani nie odtworzono z pamięci.

> **3.3 (2026-07-25, CRIT-TREŚĆ — audyt adresatów zażalenia w sprawach
> wyłączenia sędziego/neosędziów):** `modules/mod-USP-ustroj-sadow-
> powszechnych.md`, sekcja "Procedura wyłączenia" — poprzednia wersja
> kończyła się ogólnikiem "odmowa → zażalenie" bez wskazania adresata.
> Dodano tabelę rozróżniającą: (1) zażalenie poziome do innego składu tego
> samego sądu przy oddaleniu wniosku strony (art. 394¹ᵃ §1 pkt 10 KPC dla
> I instancji, art. 394² §1 KPC dla II instancji); (2) brak zaskarżalności,
> gdy to sam sędzia zgłosił i uzyskał oddalenie własnego żądania wyłączenia
> (uchwała SN III CZP 33/69). Doprecyzowano konsekwencję praktyczną dla
> spraw neosędziowskich: kontrola odwoławcza zwykle zostaje w tym samym
> sądzie, nie trafia automatycznie do instancji wyższej. Zweryfikowano
> online (SN, Palestra, gofin.pl, saos.org.pl). Ten sam wzorzec braku
> (brak adresata zażalenia) wykryto i naprawiono równolegle w
> pisma-proste-v2 (v2.4) i pisma-procesowe-v3 (v5.14). Pełny opis:
> audyt-systemu-v4/references/AUDIT-JOURNAL.md, wpis 2026-07-25.
