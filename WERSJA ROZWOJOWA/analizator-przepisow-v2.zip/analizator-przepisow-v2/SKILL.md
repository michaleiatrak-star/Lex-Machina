---
name: analizator-przepisow-v2
version: "2.11"
type: executive-analiza
status: production
compatibility: "live_web_lookup, file_read, optional_interactive_ui"
description: "Analiza przepisów prawa polskiego: brzmienie aktualne i historyczne, przesłanki, wykładnia, orzecznictwo, zbieg norm, nowelizacje i vacatio legis."
dependencies:
  requires:
    - shared
  # 2026-09-27e: jawna zależność (każdy skill systemu korzysta z `shared`); pole czytane przy imporcie z marketplace
---

> **Universal runtime:** przed wykonaniem zastosuj kanoniczny `shared/UNIVERSAL-RUNTIME-ADAPTER.md` z osobnego skilla `shared`. Lokalna sekcja adaptera poniżej jedynie go doprecyzowuje.


## ADAPTER RUNTIME — PORTABILITY (ChatGPT / Claude / inne hosty)

Ta sekcja zmienia wyłącznie sposób wykonania operacji technicznych. Nie zmienia hard gate’ów, hierarchii źródeł, analizy przesłanek, logiki orzeczniczej, historii zmian ani modelu vacatio legis.

1. `view`, `web_search`, `web_fetch`, `show_widget`, `sendPrompt` i podobne nazwy traktuj jako nazwy operacji semantycznych, jeżeli bieżący host nie udostępnia literalnie narzędzia o tej nazwie. Użyj równoważnej funkcji hosta.
2. `view analizator-przepisow-v2/...` oznacza świeży odczyt odpowiedniego pliku lokalnego tego skilla, przede wszystkim `references/...`. Nie wymagaj literalnego katalogu `/mnt/skills`.
3. `view shared/<plik>` oznacza świeży odczyt z osobnego, kanonicznego skilla `shared`. NIE kopiuj `shared` do tej paczki. Jeżeli obowiązkowy zasób shared jest niedostępny, zastosuj fail-closed zamiast zastępować go pamięcią modelu.
4. `web_search` / `web_fetch` oznaczają świeże wyszukanie i odczyt zewnętrznego źródła. Dla przepisów i sygnatur zachowaj istniejący wymóg źródeł oficjalnych/urzędowych i zakaz cytowania z pamięci.
5. `show_widget` oznacza interaktywny widok, jeśli host go obsługuje. Jeżeli nie, zachowaj ten sam model danych, zakładki, drzewo przesłanek i funkcje jako ustrukturyzowany raport, HTML lub natywny artefakt hosta. Brak renderera nie może blokować analizy merytorycznej.
6. `sendPrompt(...)` w opisie widgetu oznacza przekazanie wybranych przez użytkownika parametrów z UI z powrotem do bieżącej rozmowy/zadania. Jeśli host nie ma takiego callbacku, pokaż gotowe polecenie lub użyj natywnego mechanizmu interakcji hosta.
7. Odwołania do innych skilli są integracjami między-skillowymi. Nie kopiuj ich do tej paczki; jeśli integracja nie jest dostępna, wykonaj lokalną część możliwą do wykonania i jawnie oznacz pominięty krok bez wymyślania wyniku.

**Zasada nadrzędna adaptera:** jeżeli istniejąca instrukcja jest zrozumiała i wykonalna przez bieżący host, wykonaj ją bez konwersji. Adapter działa tylko na rzeczywistej granicy runtime.
# Analizator Przepisów Prawnych v2

> ⛔ HARD GATE — ZAKAZ CYTOWANIA PRAWA I ORZECZEŃ Z PAMIĘCI
> Przed podaniem jakiegokolwiek przepisu, artykułu, numeru Dz.U. lub sygnatury orzeczenia:
> `view shared/PRAWO-HARDGATE.md`

> ⛔ **SELF-CHECK ANTY-FASADA — obowiązkowy przed wysłaniem odpowiedzi/pisma**
> (podłączone 2026-08-23i, flaga F-115 — ten skill cytuje prawo, a bramki nie miał):
>
> ```
> view shared/SELF-CHECK-ANTY-FASADA.md
> ```
>
> Sprawdza dwie rzeczy: (1) czy w tekście stoi „zweryfikowano", data weryfikacji
> albo URL przy przepisie, dla którego NIE wywołano narzędzia W TEJ ODPOWIEDZI;
> (2) czy znacznik statusu nie został nadany treści WYGENEROWANEJ w tej odpowiedzi
> (AF-6). Treść listy jest w module, nie tutaj — celowo, żeby nie powstało kolejne
> miejsce dryfu (7 wcześniejszych kopii rozjechało się ze źródłem przy pierwszej
> zmianie brzmienia).

Profesjonalne narzędzie do analizy przepisów prawnych z widgetem wizualnym, automatycznym orzecznictwem (MOD-ORZECZ-PRZEPIS), mapą powiązań norm, historią zmian z obsługą vacatio legis, interaktywnym drzewem przesłanek i kontekstem praktycznym dla laika. (v2)

---

## ZASADA NACZELNA

> ⛔ HARDGATE — Nigdy nie cytuj przepisów z pamięci. Każdy przepis MUSI być pobrany według kanonu E-1…E-5 (`shared/HIERARCHIA-ZRODEL.md`): najpierw ELI (RZĄD 1), ISAP wyłącznie jako adres dla człowieka, LEX/Legalis → ArsLege, gdy aktu nie da się pobrać z RZĘDU 1 — procedura w `shared/PRAWO-HARDGATE.md`. Jeśli wszystkie źródła niedostępne — oznacz `⚠️ [NIEWERYFIKOWANE]` i kontynuuj bez treści przepisu.

---

## MODUŁ 0 — INTAKE I ROUTING

### Krok 0.1 — Zbierz dane wejściowe

| Element                | Przykład                             | Wymagany? |
|------------------------|--------------------------------------|-----------|
| Identyfikator przepisu | art. 415 KC / § 3 ust. 2 pkt 1 uVAT | TAK       |
| Data analizy           | dziś / 1.01.2020 / przed nowelizacją | TAK       |
| Typ sprawy             | cywilna / karna / admin / pracownicza| TAK       |
| Stan faktyczny         | opis sytuacji, dokumenty, fakty      | TAK       |
| Strona analizująca     | powód / pozwany / oskarżony / organ  | zalecane  |
| Cel analizy            | obrona / atak / zgodność / wykładnia | zalecane  |

### Krok 0.2 — Wybierz ścieżkę analizy

```
A) Jeden przepis + stan faktyczny   → Moduł 1 → 2 → 3 → 7A → 7C → 4 → WIDGET
B) Wiele przepisów / zbieg norm     → Moduł 1 → 2 → 3 → 7A → 7B → 7C → 4 → 5 → WIDGET
C) Stan prawny na datę historyczną  → Moduł 1H → 2 → 7C → 4 → WIDGET
D) Linia orzecznicza przepisu       → Moduł 1 → 7 → 7A
E) Tylko wyjaśnienie przepisu       → Moduł 1 → 2 → 7D → Raport uproszczony
F) Brak danych od użytkownika       → WIDGET WYBORU PRZEPISU → potem A–E
G) Użytkownik-laik (wykryty)        → +7D (kontekst praktyczny) do każdej ścieżki
H) Przepis z odesłaniem do innych   → +7B (mapa powiązań) do każdej ścieżki
```

### Krok 0.3 — WIDGET WYBORU PRZEPISU

Uruchom gdy: użytkownik nie podał przepisu, pyta o "widget wyboru", "wyszukaj przepis" lub wpisał tylko kodeks bez artykułu.

#### Szablon gotowy (host z `show_widget` czytającym plik korpusu)

`show_widget(path="analizator-przepisow-v2/assets/widget-wybor-przepisu.html")` — formularz bez danych sprawy, spełnia specyfikację niżej; przycisk wysyła polecenie analizy przez `sendPrompt`.

<!-- lex:wykonuje-aplikacja: WIDGET-DANE -->
#### Specyfikacja do samodzielnego wygenerowania (host bez szablonu)

Wygeneruj interaktywny widget HTML (CSS i JS inline) z następującymi elementami:

NAGŁÓWEK: ikona ⚖️, tytuł "Analizator Przepisów Prawnych v2"

SEKCJA 1 — IDENTYFIKACJA PRZEPISU:
- SELECT "Kodeks / Akt prawny" z grupami optgroup:
  - Prawo cywilne: KC, KPC, KRO, KSH
  - Prawo karne: KK, KPK, KKW, KW, KPW
  - Prawo administracyjne: KPA, PPSA, OP
  - Prawo pracy: KP
  - Inne ustawy: uVAT, uPIT, uCIT, PrBud, RODO, UODO, inne (pole tekstowe)
- INPUT TEXT "Numer artykułu" z podglądem na żywo obok pola (np. "art. 415 KC")
  - Obsługuje: zwykły numer (415), indeks (23¹), paragraf (§ 3 ust. 2 pkt 1)
  - Placeholder: "np. 415 lub 23 ust. 1 pkt 2"
- Szybkie przyciski-badge z popularnymi artykułami per kodeks:
  - KC: 415, 471, 448, 23, 446
  - KPC: 840, 843, 189, 193, 730
  - KK: 278, 286, 190, 193, 177
  - KP: 52, 55, 183a, 94
  - KRO: 56, 58, 61¹

SEKCJA 2 — PARAMETRY (dwie kolumny):
- SELECT "Cel analizy": czy stosuje się / wykładnia przesłanek / linia orzecznicza / stan historyczny / zbieg norm / tryb karny / tryb administracyjny / pełna analiza
- SELECT "Typ sprawy": cywilna / karna / administracyjna / pracownicza / podatkowa / gospodarcza

SEKCJA 3 — DATA STANU PRAWNEGO:
- Checkbox "Data historyczna" → odkrywa date picker
- Tekst: "Stan prawny: aktualny (dziś)" lub "Stan prawny: historyczny [data]"

SEKCJA 4 — STAN FAKTYCZNY:
- TEXTAREA opcjonalne, placeholder "Opisz swoją sytuację..."

PRZYCISK "🔍 Analizuj przepis":
- Disabled gdy brak kodeksu lub artykułu
- onClick → sendPrompt("Analizuj [kodeks] art. [artykuł]. Cel: [cel]. Typ sprawy: [typ]. Stan prawny na: [data]. Stan faktyczny: [treść lub brak]")
- Fallback gdy brak sendPrompt → alert z gotowym promptem

Paleta: --primary #1B3A6B, --accent #C8960C, --bg #F8F7F4, --success #16a34a, --danger #dc2626, --warn #d97706. Czcionka: Segoe UI lub system-ui. Responsywny, min-width 320px.

---

## MODUŁ 1 — WERYFIKACJA I POBRANIE PRZEPISU

### Hierarchia źródeł (RZĄD 1 / RZĄD 2 / RZĄD 3)

> ⛔ **KANONICZNA LOKALIZACJA (od 2026-07-15):** pełna treść tej hierarchii
> (definicje RZĄD 1/2A/2B/3, listy domen, zakaz mieszania rzędów, znaczniki
> obowiązkowe, procedura H-1→H-4) przeniesiona do
> `view shared/HIERARCHIA-ZRODEL.md` — plik jest teraz
> współdzielony przez `shared/PRAWO-HARDGATE.md`, `shared/WERYFIKACJA-SLAD.md`
> i każdy inny skill podający linki źródłowe, nie tylko ten moduł.
> Wczytaj ten plik PRZED podaniem jakiegokolwiek linku/URL w analizie
> przepisu — kategoryzacja RZĄD jest OBOWIĄZKOWA dla każdego źródła,
> nie tylko dla brzmienia przepisu.
>
> Powód wydzielenia: kategoryzacja obowiązywała dotąd wyłącznie lokalnie
> w tym skillu i nie była wymuszana przy linkach/kotwicach generowanych
> poza kontekstem analizy przepisu (np. w odpowiedziach opartych na
> `shared/WERYFIKACJA-SLAD.md` bez wczytania tego modułu) — zgłoszone przez
> użytkownika i naprawione przeniesieniem do `shared/`.

### Procedura weryfikacji (OBOWIĄZKOWA)

```
1. E-1 ELI: api.sejm.gov.pl/eli/acts/search?title=[nazwa aktu] → aktualny t.j.
   (rok/poz.), metryka /eli/acts/DU/{rok}/{poz} — kanałem kodu (curl/skrypt);
   host bez kanału kodu → B-1 web_search „eli.gov.pl DU {rok} {poz}” → B-2 web_fetch
2. Odczyt treści: /eli/acts/DU/{rok}/{poz}/text.pdf (t.j.; pułapka /text.html
   — B-T1…B-T3 PRAWO-HARDGATE). Link ISAP dopisz dla czytelnika (E-2).
   Aktu nie da się pobrać z RZĘDU 1 (ELI ani ISAP — awaria serwera, timeout,
   blokada; zapisz próby) → obowiązkowo E-3 LEX/Legalis → E-4 ArsLege.
3. Zlokalizuj dokładny przepis (artykuł / paragraf / ustęp / punkt)
4. Z treści obwieszczenia o t.j. wypisz nowelizacje JUŻ UWZGLĘDNIONE
   (obwieszczenia standardowo wymieniają: „uwzględnia zmiany wprowadzone
   ustawami z dnia..."). To jest punkt wyjścia — te zmiany są już wliczone,
   nie trzeba ich szukać ponownie w kroku 4A.
4A. ⛔ KROK 2C shared/PRAWO-HARDGATE.md — OSOBNE zapytanie o WSZYSTKIE
    akty zmieniające OPUBLIKOWANE PO dacie t.j. z kroku 1-2 (skorygowano
    2026-08-23f, po pytaniu użytkownika — NIE zatrzymuj się na pierwszej
    znalezionej nowelizacji; między t.j. a dziś mogło wejść w życie
    kilka kolejnych zmian tego samego przepisu). To NIE jest to samo
    zapytanie co krok 1 — krok 1 szuka t.j., krok 4A szuka WSZYSTKICH
    nowelizacji OGŁOSZONYCH PO nim, w całym przedziale od daty t.j. do
    dziś. Zapisz PEŁNĄ LISTĘ chronologiczną wyników zawsze, także gdy
    pusta (pole „Sprawdzono po t.j." w Karcie Przepisu niżej). Gdy
    nowelizacji więcej niż jedna — ustal, które brzmienie obowiązuje
    NA DATĘ ANALIZY (kolejność wejścia w życie, ewentualne vacatio
    legis), nie zakładaj że najnowsza znaleziona = aktualna. Obowiązkowe
    dla przepisów NIOSĄCYCH ROZSTRZYGNIĘCIE, opcjonalne dla przywołań
    kontekstowych.
5. Sprawdź czy przepis nie został uchylony lub zmieniony
6. Zapisz DOSŁOWNĄ treść z oficjalnego źródła
```

### Karta Przepisu

```
KARTA PRZEPISU
Akt prawny:         [pełna nazwa + rok + Dz.U.]
Numer przepisu:     [art./§/ust./pkt]
Tekst jednolity z:  [Dz.U. RRRR poz. NNN — z metryki ELI]
Nowelizacje w t.j.: [lista ustaw zmieniających już uwzględnionych w t.j.,
                     z treści obwieszczenia]
Nowelizacje po t.j.:[TAK: pełna lista chronologiczna / brak — patrz KROK
                     2C — / NIE sprawdzono]
Status:             Obowiązuje / Zmieniony / Uchylony
Data analizy:       [data stanu prawnego]
Źródło URL:         [link ELI (odczyt) + link ISAP (dla człowieka); inne źródło tylko wg E-3/E-4]

PEŁNA TREŚĆ PRZEPISU:
[tekst dosłownie z oficjalnego źródła]
```

---

## MODUŁ 1H — STAN PRAWNY NA WYBRANĄ DATĘ

Stosuj gdy użytkownik chce zbadać przepis w stanie na konkretną datę przeszłą.

```
1. Ustal datę docelową: [DD.MM.RRRR]
2. W ELI ustal historię aktu: /eli/acts/DU/{rok}/{poz}/references (zmiany,
   teksty jednolite) — ISAP tylko jako link dla czytelnika
3. Zidentyfikuj tekst jednolity obowiązujący W DNIU docelowym
4. Pobierz historyczną wersję przepisu
5. Oznacz wyraźnie: "STAN NA [data]" we wszystkich wynikach
```

### Raport historyczny

```
ANALIZA ZMIAN PRZEPISU W CZASIE
Przepis:          [identyfikator]
Data docelowa:    [DD.MM.RRRR]

Chronologia zmian:
┌──────────────┬─────────────────────┬────────────────────────┐
│ Data zmiany  │ Nowelizacja (Dz.U.) │ Co się zmieniło        │
├──────────────┼─────────────────────┼────────────────────────┤
│ [data]       │ Dz.U. [rok] poz.[n] │ [opis zmiany]          │
└──────────────┴─────────────────────┴────────────────────────┘

Wersja na [datę docelową]: [treść — dosłownie]
Wersja aktualna:           [treść dziś — dosłownie]
Różnice procesowo istotne: [co się zmieniło i jak wpływa]
```

---

## MODUŁ 2 — DEKOMPOZYCJA PRZESŁANEK

### Klasyfikacja struktury logicznej

| Typ         | Symbol        | Opis                          |
|-------------|---------------|-------------------------------|
| Koniunkcja  | A i B i C     | Wszystkie przesłanki łącznie  |
| Alternatywa | A lub B lub C | Wystarczy jedna               |
| Warunkowa   | A → B         | Warunek konieczny             |
| Mieszana    | (A i B) lub C | Grupy przesłanek              |

### Drzewo Przesłanek

> ⚠️ **DRZEWO-LIMIT — przeczytaj przed wygenerowaniem:**
> Drzewo przesłanek jest modelem analitycznym opartym na tekście przepisu pobranego
> z ELI (RZĄD 1). NIE jest oficjalną wykładnią prawa ani opinią prawną.
> Struktura logiczna (koniunkcja / alternatywa) wynika z literalnej analizy językowej
> przepisu — może odbiegać od wykładni przyjętej w orzecznictwie.
>
> **ZAKAZ-DRZEWO:** Nie prezentuj wyniku drzewa jako definitywnego rozstrzygnięcia
> bez weryfikacji w Module 7A (orzecznictwo). Jeśli linia orzecznicza jest niejednolita
> lub pojęcia są nieostre — wynik drzewa jest ZAWSZE `?` (niejednoznaczny), niezależnie
> od literalnej struktury logicznej przepisu. Dla laika: dodaj obligatoryjnie sekcję
> 7D z zaznaczeniem ograniczeń analizy.

```
DRZEWO PRZESŁANEK — [numer przepisu]
Skutek prawny: [co wynika z przepisu]
Typ logiczny:  [koniunkcja / alternatywa / mieszany]

P1: [nazwa przesłanki]
    Definicja ustawowa: [jeśli istnieje]
    Treść: [opis]
    Charakter: Konieczna / Alternatywna
    Pojęcia nieostre: [jeśli są → Krok 2.3]

P2: [j.w.]
Pn: [j.w.]

LOGIKA: Wszystkie P1–Pn lacznie / Wystarczy jedna / Wystarczy: [opis]
```

### Weryfikacja pojęć nieostrych

```
POJĘCIE: "[słowo/fraza]"
Definicja ustawowa (ten sam akt): [artykuł + treść]
Definicja ustawowa (inny akt):    [akt + artykuł + treść]
Pojęcie nieostre → wykładnia orzecznicza (Moduł 7)
Pojęcie techniczne → znaczenie branżowe: [źródło]
```

### Wykładnia orzecznicza pojęć nieostrych

Przeszukaj w kolejności:
1. https://www.sn.pl/orzecznictwo — Sąd Najwyższy
2. https://orzeczenia.nsa.gov.pl — NSA / WSA
3. https://orzeczenia.ms.gov.pl — sądy powszechne
4. https://www.trybunal.gov.pl/orzeczenia — Trybunał Konstytucyjny
5. https://saos.org.pl — agregator orzeczeń

Uzupełniająco (POMOCNICZO, nie zamiast powyższego): sprawdź też komentarze
doktrynalne na dużych, uznanych portalach RZĘDU 3 (prawo.pl, LEX, Legalis,
rp.pl, gofin.pl i pozostałe duże portale — patrz "Hierarchia źródeł" w
Module 1) i oznacz je znacznikiem 📚 [ŹRÓDŁO POMOCNICZE — RZĄD 2: ...].
Strony indywidualnych prawników/kancelarii/blogów (Rząd 3) traktuj z
dodatkową ostrożnością wg zasad Rzędu 3. Gdy komentarz i orzecznictwo się różnią —
priorytet ma orzecznictwo, odnotuj rozbieżność.

---

## MODUŁ 3 — ANALIZA SPEŁNIENIA PRZESŁANEK

### Matryca oceny

```
MATRYCA OCENY PRZESŁANEK
Przepis:             [identyfikator]
Stan prawny na:      [data analizy]
Materiały wejściowe: [lista dokumentów / faktów]

┌─────┬──────────────────────┬────────┬──────────────────────┬─────────┐
│ Nr  │ Przesłanka           │ Status │ Uzasadnienie          │ Pewność │
├─────┼──────────────────────┼────────┼──────────────────────┼─────────┤
│ P1  │ [nazwa]              │ T/N/?  │ [dowód / brak]       │ 85%     │
│ P2  │ [nazwa]              │ T/N/?  │ [dowód / brak]       │ 60%     │
└─────┴──────────────────────┴────────┴──────────────────────┴─────────┘
Legenda: T = Spełniona  N = Niespełniona  ? = Wątpliwa
```

### Analiza szczegółowa przesłanki N lub ?

```
PRZESŁANKA [Pn] — SZCZEGÓŁOWO
Treść:                [cytat z przepisu]
Co musi być wykazane: [fakty 1, 2...]
Na spełnienie (+):    [dokument/fakt → powiązanie]
Przeciw spełnieniu(-): [dokument/fakt → powiązanie]
Braki dowodowe (?):   [czego brak]
Ocena:    spełniona / niespełniona / wątpliwa
Pewność:  [%] — wysoka 80+ / średnia 50-79 / niska <50
```

### Wynik logiczny

```
WYNIK LOGICZNY
Koniunkcja: P1(T) i P2(N) i P3(T) = N — NIE STOSUJE SIĘ
  Blokuje: P2 — [wyjaśnienie]

Alternatywa: P1(N) lub P2(T) = T — STOSUJE SIĘ
  Podstawa: P2 — [wyjaśnienie]

KONKLUZJA:
  T — PRZEPIS STOSUJE SIĘ
  N — PRZEPIS NIE STOSUJE SIĘ
  ? — WYNIK NIEJEDNOZNACZNY — [co go warunkuje]
```

---

## MODUŁ 4 — RAPORT KOŃCOWY

```
RAPORT ANALIZY — [identyfikator przepisu]
Stan prawny na: [data] | Typ sprawy: [typ] | Wygenerowano: [dziś]

1. PRZEPIS (źródło: [URL ELI] · ISAP: [URL dla czytelnika])
   [pełna treść]

2. STRUKTURA PRZESŁANEK
   Typ logiczny: [koniunkcja / alternatywa / mieszany]
   Przesłanek: [n] łącznie, koniecznych: [k], alternatywnych: [a]

3. WYNIK: T STOSUJE SIĘ / N NIE STOSUJE / ? NIEJEDNOZNACZNY
   Pewność ogólna: [%]

4. PRZESŁANKI — PODSUMOWANIE
   Spełnione: [lista]
   Niespełnione: [lista + przyczyna]
   Wątpliwe: [lista + co warunkuje]

5. UZASADNIENIE MERYTORYCZNE
   [zwięzłe uzasadnienie — język profesjonalny]

6. LINIA ORZECZNICZA (skrót)
   Dominujące stanowisko: [opis]
   Orzeczenia kluczowe: [sygnatury — tylko zweryfikowane online]

7. RYZYKA I ZASTRZEŻENIA
   [lista ryzyk procesowych, wątpliwości dowodowych]
   ⚠️ DRZEWO-LIMIT (obowiązkowe): Drzewo przesłanek jest modelem analitycznym
   opartym na wykładni literalnej. Wynik może odbiegać od wykładni orzeczniczej.
   Wskaż konkretnie: czy pojęcia nieostre zostały rozstrzygnięte orzecznictwem
   (M7A), czy linia jest jednolita. Jeśli nie — wynik analizy ma charakter
   orientacyjny i wymaga konsultacji z prawnikiem przed podjęciem działań.

8. REKOMENDACJE
   [co zrobić, jakie dowody zebrać, jakie czynności]

9. POWIĄZANE PRZEPISY
   [przepisy powiązane, wyjątki, lex specialis]

10. ŹRÓDŁA
    Normatywne i orzecznicze (zweryfikowane, ✅ [VER: ...]): [lista URL]
    Pomocnicze — duże portale RZĄD 2 (📚 [ŹRÓDŁO POMOCNICZE — RZĄD 2: ...], o ile użyto): [lista URL]
    Pomocnicze — Rząd 3, wysokie ryzyko dezaktualizacji (⚠️📚 [... RZĄD 3: ...], o ile użyto): [lista URL]
```

---

## MODUŁ 5 — ZBIEG NORM

```
PORÓWNANIE PRZEPISÓW
┌──────────────┬──────────┬────────┬──────────┬────────────────┐
│ Przepis      │ P1       │ P2     │ Wynik    │ Uwagi          │
├──────────────┼──────────┼────────┼──────────┼────────────────┤
│ art. X ust.Y │ T        │ N      │ N        │                │
│ art. Z §1    │ T        │ T      │ T        │ Lex specialis  │
└──────────────┴──────────┴────────┴──────────┴────────────────┘

ZBIEG NORM:
Typ: kumulatywny / eliminacyjny / pozorny
Przepis właściwy: [który i dlaczego]
Zasada: lex specialis / lex posterior / lex superior / [inna]
```

---

## MODUŁ 6 — TRYBY SPECJALNE

### Tryb A — Przepis karny

```
STRONA PODMIOTOWA:
Forma winy: Umyślna (dolus) / Nieumyślna (culpa) / Obie
  Umyślna: Zamiar bezpośredni / Zamiar ewentualny
Analiza zamiaru w stanie faktycznym: [ocena]

STRONA PRZEDMIOTOWA:
Skutek: Wymagany (materialne) / Niewymagany (formalne)
Związek przyczynowy: [ocena adekwatności]
Przedmiot ochrony: [dobro prawne]
```

### Tryb B — Przepis administracyjny

```
Organ właściwy:        [kto stosuje przepis]
Tryb postępowania:     KPA / Ordynacja podatkowa / inne
Terminy:               [terminy wynikające z przepisu]
Forma rozstrzygnięcia: Decyzja / Postanowienie / inne
```

### Tryb C — Przepis proceduralny (KPC/KPK/PPSA)

```
Etap postępowania:         [kiedy stosuje się]
Inicjatywa:                Z urzędu / Na wniosek
Termin zawity/prekluzyjny: [jeśli dotyczy — KRYTYCZNE]
Skutek niespełnienia:      [konsekwencje procesowe]
```

---

## MODUŁY 7–8 — ORZECZNICTWO, MAPA POWIĄZAŃ, HISTORIA ZMIAN, KONTEKST DLA LAIKA, WIDGET WYNIKÓW

Wyodrębnione do osobnego pliku referencyjnego (refaktoryzacja 2026-06-14 — eliminacja monolitu 794 linii):

```
view analizator-przepisow-v2/references/MOD-ORZECZ-POWIAZANIA-HISTORIA.md
```

Zawiera:
- **Moduł 7** — Linia orzecznicza (wyszukiwanie i analiza stanowisk SN/NSA/TK/SA/WSA)
- **Moduł 7A** — MOD-ORZECZ-PRZEPIS (automatyczne pobranie 3 orzeczeń do przepisu)
- **Moduł 7B** — MOD-ZBIEZNOSC (mapa powiązań norm)
- **Moduł 7C** — MOD-HISTORIA-ZMIAN + MOD-VACATIO-LEGIS (nowelizacje, vacatio legis — odsyła dalej do `references/MOD-VACATIO-LEGIS.md`)
- **Moduł 7D** — MOD-KONTEKST-PRAKTYCZNY (wyjaśnienie dla laika)
- **Moduł 8** — Widget wyników HTML (7 zakładek)

Wczytaj ten plik na etapie 5–9 i 13 sekwencji obowiązkowej (patrz INSTRUKCJE OPERACYJNE poniżej).

---

---

## MODUŁ 9 — INTEGRACJA Z SYSTEMEM SKILLÓW

| Wynik analizy                           | Proponowany skill       |
|-----------------------------------------|-------------------------|
| Przepis stosuje się → chcę pismo        | pisma-procesowe-v3      |
| Brak dowodów na przesłanki              | analizator-dowodow-v3   |
| Pojęcia nieostre, linia niejednoznaczna | orzeczenia-sadowe-v2    |
| Złożona sprawa, wiele przepisów         | analiza-sadowa-v6       |
| Użytkownik zagubiony w wynikach         | przewodnik-prawny-v2    |
| Linia niejednolita ⚠️ — chcę więcej    | orzeczenia-sadowe-v2    |
| Zbieg norm — chcę mapę powiązań         | analiza-sadowa-v6       |

---

## INSTRUKCJE OPERACYJNE

### Sekwencja obowiązkowa

```
1. Moduł 0 → intake + routing
   Jeśli brak przepisu → Widget wyboru przepisu (Moduł 0.3)
2. Moduł 1 → pobierz przepis z ELI — kanon E-1…E-5 (ZAWSZE, BEZ WYJĄTKU)
   Lub Moduł 1H → tryb historyczny
3. Moduł 2 → dekompozycja przesłanek
4. Moduł 3 → analiza spełnienia (jeśli jest stan faktyczny)
5. Moduł 7 → linia orzecznicza (pojęcia nieostre lub żądanie)
6. Moduł 7A → MOD-ORZECZ-PRZEPIS (AUTOMATYCZNIE — 3 orzeczenia + alert rozbieżności)
7. Moduł 7B → MOD-ZBIEZNOSC (jeśli przepis odsyła lub ścieżka B)
8. Moduł 7C → MOD-HISTORIA-ZMIAN (AUTOMATYCZNIE — w tle, wynik w zakładce widgetu)
   8a. Jeśli wykryto vacatio legis lub nowelizację wieloetapową → MOD-VACATIO-LEGIS
       `view analizator-przepisow-v2/references/MOD-VACATIO-LEGIS.md`
9. Moduł 7D → MOD-KONTEKST-PRAKTYCZNY (gdy laik lub żądanie wyjaśnienia)
10. Moduł 4 → raport końcowy
11. Moduł 5 → zbieg norm (jeśli wiele przepisów)
12. Moduł 6 → tryb specjalny (karny / admin / proceduralny)
13. Moduł 8 → Widget wyników z 7 zakładkami (zawsze po analizie) — wykonanie: „Moduł 8 — wykonanie widgetu” niżej
14. Moduł 9 → propozycja kolejnych skillów
```

#### Moduł 8 — wykonanie widgetu: szablon zasilany danymi (host z `show_widget` przyjmującym `data`)

`show_widget(path="analizator-przepisow-v2/assets/widget-wyniki.html", data=DANE)` — bez kodu; host wstawia dane i dokłada pasek eksportu/importu. Zakładki i funkcje jak w `references/MOD-ORZECZ-POWIAZANIA-HISTORIA.md` § MODUŁ 8. DANE (pola opcjonalne można pominąć):
```
przepis: {oznaczenie, akt, tresc, status: obowiazuje|zmieniony|uchylony, stan_na, url, w_praktyce, os_czasu: [{data, opis}]}
przeslanki: {logika: AND|OR|MIXED, lista: [{id, nazwa, status: T|N|?, pewnosc 0–100, uzasadnienie, braki}]}
wynik: {ocena: stosuje|nie_stosuje|watpliwe, opis}
orzeczenia: {jednolita: true|false, rozbieznosc: {a, b, przyczyna, rekomendacja},
             lista: [{sygnatura, sad, rok, teza, url, trafnosc 0–100, tier: 1|2|3}]}
powiazania: [{artykul, akt, relacja: odeslanie|wyjatek|lex_specialis|uzupelnienie|definicja, opis}]
historia: [{data, akt_zmieniajacy, opis, istotnosc: wysoka|niska}]; porownanie: {poprzednia, aktualna}
raport: {konkluzja, kolor: zielony|czerwony|pomaranczowy, pewnosc 0–100, ryzyka: [], rekomendacje: [], dla_ciebie}
```
Zasady treści bez zmian: brzmienie z ELI, statusy źródeł, sygnatury wyłącznie zweryfikowane.

<!-- lex:wykonuje-aplikacja: WIDGET-DANE -->
#### Moduł 8 — wykonanie widgetu: kod HTML i pasek IO (host bez pola `data`)

Wygeneruj widget wg `references/MOD-ORZECZ-POWIAZANIA-HISTORIA.md` § MODUŁ 8. Przed `show_widget`:
```
⛔ MOD-WIDGET-IO (OBOWIĄZKOWE przed show_widget):
view shared/MOD-WIDGET-IO.md
→ wbuduj pasek IO w nagłówek widgetu
→ IO_SKILL_ID='analizator-przepisow-v2', IO_CASE_ID=sygnatura_lub_przepis
→ matryca: Export JSON ✅ MD ✅ | Import JSON ✅
```

### Poziomy pewności

| Poziom | %     | Kryterium                                           |
|--------|-------|-----------------------------------------------------|
| Wysoka | 80–100| Materiały jednoznacznie i bezpośrednio potwierdzają |
| Średnia| 50–79 | Pośrednie wskazanie, możliwa inna interpretacja     |
| Niska  | <50   | Brak materiałów lub wzajemna sprzeczność            |

### Cytowanie orzeczeń

- Nigdy sygnatur z pamięci AI
- Format: [Sąd], [data], sygn. [sygnatura], [teza skrócona]
- Link do źródła oficjalnego obowiązkowy

### Postępowanie przy braku dostępu do źródeł (kanon E-1…E-5)

```
Brak dostępu do ISAP = stan normalny (kanał maszynowy martwy) — NIE przerywa
pracy i NIE uruchamia źródeł zastępczych; brzmienie bierzesz z ELI.
ELI niedostępny → sprawdź kształt żądania (DOSTEP-MASZYNOWY-API §1), drugi
kanał (web_fetch/B-1→B-2 ↔ kanał kodu), ISAP / dziennikustaw.gov.pl; zapisz
wynik prób. Aktu nie da się pobrać z RZĘDU 1 → obowiązkowo kolejno: E-3 LEX/Legalis (przy licencji) → E-4 ArsLege
(🟨 na warunkach K-1…K-4). Prawo UE → EUR-Lex; akty organu → BIP / dziennik
urzędowy.
Jeśli wszystkie niedostępne (E-5):
  ZATRZYMAJ analizę
  Poinformuj użytkownika
  Zaproponuj dostarczenie tekstu przez użytkownika
  NIE analizuj z pamięci AI
```

---

## PRZYKŁAD

Zapytanie: "Czy art. 415 KC stosuje się do mojej sprawy? Stan na 1.01.2020."

```
[M0]  Ścieżka C — historyczna
[M1H] Pobrano ELI DU/2019/1145 (text.pdf), stan na 01.01.2020
[M2]  Koniunkcja: P1 Szkoda | P2 Wina | P3 Związek przyczynowy
[M3]  P1 T 90% | P2 ? 55% (brak protokołu) | P3 T 80%
[M7]  SN: "wina" — wykładnia obiektywna (sygn. zweryfikowana)
[M7A] 3 orzeczenia pobrane z saos.org.pl + sn.pl — LINIA NIEJEDNOLITA ⚠️
      Stanowisko A (dominujące SN): subiektywna miara staranności
      Stanowisko B (mniejszościowe SA): obiektywny wzorzec "dobrego gospodarza"
      Przyczyna: różna wykładnia pojęcia "wina" przed uchwałą SN z 2018
[M7C] Przepis bez zmian w ostatnich 3 latach ✅
[M4]  KONKLUZJA: ? NIEJEDNOZNACZNY — blokuje P2, ryzyko linii niejednolitej
[M7D] Dla laika: "Przepis mówi, że kto wyrządził komuś szkodę przez własną winę,
      musi ją naprawić. Tu kwestią sporną jest, czy winę oceniamy przez Twoje
      zamierzenia czy przez to, co zrobiłby 'rozsądny człowiek' na Twoim miejscu."
[M8]  Widget wyników z 7 zakładkami.
```

---

## Integracja z kancelaryjnym jądrem shared

Jeżeli wynik tego skilla ma służyć do pisma, strategii procesowej, oceny ryzyka albo decyzji terminowej, wczytaj właściwe moduły shared:

```text
view shared/TRYBY-PROCESOWE.md
view shared/RISK-ASSESSMENT.md
view shared/TERM-CALC.md
view shared/DOWODY-METODOLOGIA.md
view shared/PREKLUZJA-DOWODOWA.md
view shared/STRATEGIA-PROCESOWA.md
view shared/QUALITY-CHECK.md
```

Nie dubluj logiki shared w lokalnych plikach. Lokalne moduły mogą tylko doprecyzować analizę dziedzinową.
