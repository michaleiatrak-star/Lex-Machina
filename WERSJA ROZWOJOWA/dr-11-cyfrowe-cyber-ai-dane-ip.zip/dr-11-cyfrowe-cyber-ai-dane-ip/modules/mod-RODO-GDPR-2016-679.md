# Moduł [P] — RODO i Ochrona Danych Osobowych

**Akt:** UODO (ustawa o ochronie danych osobowych) — t.j. Dz.U. 2019 poz. 1781 (zm. po t.j.: 2026/252 od 2026-04-03 — art. 104; 2026/548 od 2026-07-23 — art. 34; 2026/1003 od 2026-10-28 — art. 59, 59a).
**Akt:** PrAut (ustawa o prawie autorskim i prawach pokrewnych) — t.j. Dz.U. 2025 poz. 24 (zm. po t.j.: 2026/1296 od 2026-11-06 — art. 22; 2026/1477 od 2026-11-10 — art. 5, 35, 127).
**Akt:** KP (Kodeks pracy) — t.j. Dz.U. 2026 poz. 1245.
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

**Zakres:** RODO (GDPR), UODO, naruszenia przetwarzania, skargi do UODO, prawo do bycia zapomnianym,
zgody marketingowe, monitoring pracowników, administrator vs. podmiot przetwarzający.

---

## ZASADY ABSOLUTNE

1. **UODO.GOV.PL** → organ nadzorczy w Polsce = Prezes UODO (nie sąd administracyjny w pierwszej kolejności).
2. **Skarga do UODO** → bezpłatna, nie wymaga pełnomocnika, termin ograniczony tylko przedawnieniem.
3. **Prawo do usunięcia danych ("bycia zapomnianym")** → art. 17 RODO — nie jest bezwzględne
   (wyjątki: interes publiczny, obowiązki prawne, roszczenia).
4. **Monitoring pracowników** → wymaga: podstawy prawnej + poinformowania pracownika + proporcjonalności.
5. **Zgoda marketingowa** → musi być dobrowolna, konkretna, świadoma i jednoznaczna (art. 7 RODO).
6. **Naruszenie ochrony danych** → administrator zgłasza bez zbędnej zwłoki, w miarę możliwości nie później niż w 72 h **po stwierdzeniu** naruszenia (art. 33 ust. 1 RODO); bez zgłoszenia, gdy ryzyko mało prawdopodobne. ✅ [VER] RZĄD 1 2026-09-17q — EUR-Lex, tekst skonsolidowany 02016R0679

---

## KLUCZOWE AKTY PRAWNE — WERYFIKUJ W ISAP / EUR-LEX PRZED POWOŁANIEM

- Rozporządzenie RODO (UE) 2016/679 → eur-lex.europa.eu
- Ustawa o ochronie danych osobowych (UODO) → isap.sejm.gov.pl
- Kodeks pracy — monitoring (art. 22²–22³ KP) → isap.sejm.gov.pl

⚠️ RODO to rozporządzenie UE — tekst weryfikuj w EUR-LEX, nie tylko ISAP.

---

## INTAKE — PYTANIA WSTĘPNE

```
□ Kto jest administratorem danych (firma, organ, osoba)?
□ Jakie dane są przetwarzane i w jakim celu?
□ Co konkretnie naruszono? (brak zgody, bezprawne udostępnienie, odmowa usunięcia, wyciek)
□ Czy jest podmiot przetwarzający (procesor) — np. firma IT, call center?
□ Czy naruszenie dotyczy pracownika (monitoring) czy klienta/osoby trzeciej?
□ Jakiego efektu oczekuje klient? (usunięcie danych, odszkodowanie, decyzja UODO)
```

---

## ŚCIEŻKI DZIAŁANIA

```
A. Skarga do Prezesa UODO (uodo.gov.pl)
   → Bezpłatna, pisemna lub elektroniczna
   → Prezes UODO wydaje decyzję administracyjną
   → Od decyzji → skarga do WSA (nie SO!)

B. Pozew cywilny o odszkodowanie (art. 82 RODO)
   → Sąd powszechny (SO lub SR zależnie od WPS)
   → Niezależnie od postępowania przed UODO

C. Oba równocześnie (A + B)
   → Dozwolone — różne tryby, różne organy
```

---

## SZCZEGÓŁOWY FRAMEWORK

Dla pogłębionej analizy, INTAKE, map postępowań, kalkulatorów i predykcji → wczytaj
odpowiednie moduły wspólne (lazy loading — tylko właściwy do sprawy):

```
view shared/INTAKE-GAP.md
view shared/ROSZCZENIA.md
view prawo-polskie-v2/krajowe/shared/TERM-CALC.md
view shared/STRATEGIA-PROCESOWA.md
```

Dla BENCHMARKINGU orzeczniczego i predykcji wyniku wywołaj skill `orzeczenia-sadowe-v2`.

---

## ŁĄCZ Z

| Sytuacja | Skill / Moduł |
|---|---|
| Pozew o odszkodowanie RODO | `pisma-procesowe-v3` |
| Skarga do UODO | `pisma-proste-v2` |
| Naruszenie wizerunku + IP | `dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-PrAut-wlasnosc-intelektualna-IP.md` |
| Monitoring w miejscu pracy | `dr-04-prawo-pracy-zus-swiadczenia/modules/mod-KP-prawo-pracy.md` |
| Analiza szans procesowych | `analiza-sadowa-v6` |
| Redakcja/audyt: polityka prywatności, RCP/RCO, PBI, upoważnienia, IOD, procedura naruszeń, archiwizacja/retencja, regulamin pracy/wynagradzania/ZFŚS | `analizator-umow-v1` → `prawo-polskie-v2/krajowe/analizator-umow-v1/references/mod-J21-rodo-archiwizacja-regulaminy.md` (J21) |
| Klauzule RODO/DPA w umowie z kontrahentem | `analizator-umow-v1` → `prawo-polskie-v2/krajowe/analizator-umow-v1/references/mod-shared-rodo.md` |

*⚠️ Moduł strategiczny — wszystkie przepisy i orzecznictwo wymagają weryfikacji online przed powołaniem.*

---

## AKTUALIZACJA ISAP / UODO — 2026-05-28

Sprawy administracyjne przed Prezesem UODO prowadź przez moduł:

```text
view dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-UODO-postepowanie-ochrona-danych.md
```

Nie mieszaj: skarga do UODO, skarga do WSA na decyzję UODO i powództwo cywilne o odszkodowanie z art. 82 RODO to trzy różne warstwy ochrony.
---

## AKTUALIZACJA ISAP / UODO — 2026-05-28

Sprawy administracyjne przed Prezesem UODO prowadź przez moduł:

```text
view dr-11-cyfrowe-cyber-ai-dane-ip/modules/mod-UODO-postepowanie-ochrona-danych.md
```

Nie mieszaj: skarga do UODO, skarga do WSA na decyzję UODO i powództwo cywilne o odszkodowanie z art. 82 RODO to trzy różne warstwy ochrony.
