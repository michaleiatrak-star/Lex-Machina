# mod-PrAut-wlasnosc-intelektualna-IP

**Akt:** PrAut (ustawa o prawie autorskim i prawach pokrewnych) — t.j. Dz.U. 2025 poz. 24 (zm. po t.j.: 2026/1296 od 2026-11-06 — art. 22; 2026/1477 od 2026-11-10 — art. 5, 35, 127).
**Akt:** PWP (Prawo własności przemysłowej) — t.j. Dz.U. 2023 poz. 1170 (zm. po t.j.: 2026/1296 od 2026-11-06 — art. 296).
**Akt:** KC (Kodeks cywilny) — t.j. Dz.U. 2026 poz. 795.
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

**Hasła spraw:** naruszenie praw autorskich, skopiowanie zdjęć, plagiat, licencja, utwór, autorskie prawa majątkowe, kopiowanie treści

**Stan operacyjny:** 2026-08-28  
**Źródło kanoniczne:** ELI — ustawa z 4.02.1994 r. o prawie autorskim i prawach pokrewnych, tekst jednolity Dz.U. 2025 poz. 24.

## Zakres

Moduł obejmuje prawo autorskie i prawa pokrewne w zakresie: przedmiotu i podmiotu ochrony, praw osobistych i majątkowych, dozwolonego użytku, czasu ochrony, umów/licencji, programów komputerowych, roszczeń cywilnych, praw pokrewnych oraz odpowiedzialności karnej.

Prawo własności przemysłowej, znaki towarowe i patenty są obsługiwane przez dedykowany moduł PWP. Nie mieszaj obu reżimów.

## Mapa ustawy

| Zakres | Status operacyjny |
|---|---|
| Rozdział 1 — przedmiot prawa autorskiego | 🟢 B+ / COV |
| Rozdział 2 — podmiot prawa autorskiego | 🟢 B+ / COV |
| Rozdział 3 — treść prawa autorskiego: prawa osobiste, majątkowe, dozwolony użytek | 🟢 B+ / COV |
| Rozdział 4 — czas trwania autorskich praw majątkowych | 🟢 B+ / COV |
| Rozdział 5 — przejście autorskich praw majątkowych, umowy i licencje | 🟢 B+ / COV |
| przepisy szczególne dotyczące utworów audiowizualnych / programów komputerowych | 🟢 B+ / COV |
| Rozdział 8 — ochrona autorskich praw osobistych | 🟢 B+ / COV |
| Rozdział 9 — ochrona autorskich praw majątkowych | 🟢 B+ / COV |
| prawa pokrewne | 🟡 B+ |
| Rozdział 14 — odpowiedzialność karna | 🟡 B+; przy kwalifikacji karnej łącz z DR-03 |

## Kwalifikator utworu

Przed analizą naruszenia odpowiedz kolejno:

```text
1. Czy istnieje rezultat działalności twórczej o indywidualnym charakterze?
2. Czy został ustalony w jakiejkolwiek postaci?
3. Co jest chronionym sposobem wyrażenia, a co tylko ideą, metodą, procedurą lub zasadą działania?
4. Kto jest twórcą albo innym pierwotnym/uprawnionym podmiotem?
5. Czy prawa majątkowe zostały przeniesione albo udzielono licencji?
6. Jakie pola eksploatacji obejmuje umowa?
7. Czy korzystanie mieści się w dozwolonym użytku albo innym ustawowym wyjątku?
8. Czy ochrona majątkowa nadal trwa?
```

## Prawa osobiste i majątkowe

- Prawa osobiste z art. 16 chronią więź twórcy z utworem i co do zasady nie podlegają zrzeczeniu ani zbyciu.
- Prawa majątkowe z art. 17 obejmują wyłączne korzystanie i rozporządzanie utworem na polach eksploatacji oraz wynagrodzenie, z wyjątkami ustawowymi.
- Nie utożsamiaj posiadania egzemplarza/pliku z nabyciem autorskich praw majątkowych.

## Umowy i licencje

Twarde reguły wejścia:

1. Ustal, czy mamy przeniesienie praw, licencję wyłączną czy niewyłączną.
2. Umowa/licencja obejmuje pola eksploatacji wyraźnie w niej wymienione; nie zakładaj automatycznego przeniesienia „wszystkich praw”.
   - **Klauzula ogólna („na wszelkie / wszystkie pola eksploatacji”)**: punkt wyjścia — nie spełnia art. 41 ust. 2 PA, pola trzeba wymienić.
     Ale **konkluzja warunkowa, nie kategoryczna**: zakres przeniesienia ustala się także w drodze **wykładni umowy (art. 65 § 2 KC —
     zgodny zamiar stron i cel umowy)**, więc w sporze sąd może odczytać, jakie pola strony faktycznie objęły (np. z opisu zlecenia,
     przeznaczenia materiałów). Pisz: „sama klauzula ogólna nie wystarcza; zakres może jednak wynikać z wykładni całej umowy —
     dla pewności wymień pola”. Orzecznictwo SN w tej kwestii — tylko po weryfikacji narzędziami.
   - **Skutek prawny wyłącznie z brzmienia przepisu**: art. 41 ust. 3 mówi o **nieważności** (umowa co do wszystkich przyszłych utworów
     twórcy), a art. 41 ust. 4 tylko, że umowa **„może dotyczyć tylko pól eksploatacji znanych w chwili jej zawarcia”** — nie nazywaj tego
     nieważnością ani bezskutecznością, napisz, że pól nieznanych umowa nie obejmuje.
   ✅ [VER: ELI DU/2025/24 (PA t.j.), art. 41 ust. 2–4; DU/2026/795 (KC t.j.), art. 65 — odczyt 2026-10-31, RZĄD 1]
3. Kontroluj formę wymaganą ustawą dla danego rodzaju czynności.
4. Aktualny tekst ustawy zawiera obowiązki dotyczące godziwego i odpowiedniego wynagrodzenia oraz mechanizmy korekty niewspółmiernie niskiego wynagrodzenia; przed zastosowaniem konkretnego roszczenia pobierz aktualne brzmienie właściwych artykułów z ELI.
5. Przy długotrwałej eksploatacji kontroluj ustawowe obowiązki informacyjne nabywcy/licencjobiorcy wobec twórcy, jeżeli znajdują zastosowanie.

## Dozwolony użytek

Nie stosuj ogólnej etykiety „fair use”. W prawie polskim ustal konkretną podstawę ustawową dozwolonego użytku, jej przesłanki, zakres korzystania, obowiązek oznaczenia autorstwa/źródła oraz test z art. 35. Cytat, edukacja, biblioteki, parodia, eksploracja tekstów i danych lub inne wyjątki mają odrębne warunki.

## Programy komputerowe

Programy komputerowe mają szczególny reżim ustawowy. Nie przenoś automatycznie wszystkich reguł dozwolonego użytku z innych kategorii utworów. Przed analizą kopii zapasowej, dekompilacji, interoperacyjności, modyfikacji lub reverse engineeringu sprawdź bezpośrednio właściwe przepisy działu dotyczącego programów komputerowych.

## Naruszenie i roszczenia

### Prawa osobiste

W przypadku zagrożenia lub naruszenia praw osobistych ustal roszczenia z aktualnego art. 78, charakter naruszenia, winę oraz sposób usunięcia skutków.

### Prawa majątkowe

Przy naruszeniu praw majątkowych pobierz aktualny art. 79 z ELI. Nie rekonstruuj z pamięci katalogu ani wysokości świadczeń; przepis zawiera historię częściowej utraty mocy niektórych wariantów roszczeń, więc analiza musi opierać się na aktualnym tekście ujednoliconym i ewentualnym orzeczeniu stanowiącym podstawę utraty mocy.

## Odpowiedzialność karna

Rozdział 14 obejmuje przestępstwa związane m.in. z przywłaszczeniem autorstwa, bezprawnym rozpowszechnianiem i innymi naruszeniami określonymi ustawą. Każdą kwalifikację karną wykonuj wspólnie z DR-03 i aktualnym KPK; nie wyprowadzaj znamion ani sankcji wyłącznie z niniejszego modułu.

## Matryca dowodowa

| Teza | Typowy dowód |
|---|---|
| autorstwo / data ustalenia | pliki źródłowe, repozytorium, metadane, korespondencja, wersje robocze |
| zakres nabytych praw | umowa, aneksy, licencja, regulamin |
| konkretne pole eksploatacji | treść umowy + sposób faktycznego wykorzystania |
| naruszenie | kopie publikacji, zrzuty, pliki, logi, egzemplarze, protokół zabezpieczenia |
| skala korzystania | sprzedaż, wyświetlenia, dystrybucja, raporty platformy, faktury |
| szkoda / korzyści | dokumentacja finansowa, cenniki licencyjne, umowy porównawcze |

## Fresh gate

Przed powołaniem konkretnego artykułu, wyjątku, terminu ochrony, roszczenia lub sankcji pobierz aktualny tekst ujednolicony ELI/ISAP dla Dz.U. 2025 poz. 24 i sprawdź późniejsze nowelizacje. Prawo UE dotyczące prawa autorskiego weryfikuj w EUR-Lex.
