# Modul - DSA - Digital Services Act (Akt o Uslugach Cyfrowych)

**Akt:** USUDE (ustawa o świadczeniu usług drogą elektroniczną) — t.j. Dz.U. 2024 poz. 1513 (zm. po t.j.: 2026/1296 od 2026-11-06 — art. 1, 2, 2a, 3, 4, 7, 9, 11, 12, 13, 14, 15, 15a, 16, 17, 18, 20, 21, 22, 22zj).
**Akt:** URTV (ustawa o radiofonii i telewizji) — t.j. Dz.U. 2022 poz. 1722 (zm. po t.j.: 2024/96 od 2024-01-26 — zakres: tekst nowelizacji w ELI; 2024/1222 od 2024-11-10 — art. 4, 26, 37, 38a, 38b, 40; 2026/1003 od 2026-10-28 — art. 6; 2026/1296 od 2026-11-06 — art. 10, 10a, 47t).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

**Hasła spraw:** platforma internetowa, usuwanie nielegalnych treści, zgłoszenie treści, moderacja treści, hosting, portal społecznościowy, marketplace, blokada konta

## Akt prawny
**Rozporządzenie (UE) 2022/2065 z 19.10.2022 r. o jednolitym rynku uslug cyfrowych (DSA)**
- Dz.Urz. UE L 277/1 z 27.10.2022
  VER: eur-lex.europa.eu/legal-content/PL/TXT/?uri=CELEX:32022R2065 [2026-05-31]
- Stosowanie: od **17.02.2024** (dla wszystkich podmiotow)

⚡ **STATUS POLSKIEJ IMPLEMENTACJI — POPRAWKA PILNA 2026-07-27
(FAZA 3E/ZASADA 14):** moduł znacząco nie doszacowywał burzliwości
procesu. Aktualny, potwierdzony przebieg (6 źródeł: rp.pl [17.07.2026],
bankier.pl, uke.gov.pl, dlahandlu.pl, wnp.pl, portalsamorzadowy.pl):

```
Maj 2024 — TERMIN WDROŻENIA DSA MINĄŁ (Polska go NIE dotrzymała)
Wiosna 2025 — KE POZWAŁA POLSKĘ do TSUE za brak wdrożenia (koordynator
              niewyznaczony) — ryzyko kary 35-40 mln zł
13.05.2025 — uchwałą Rady Ministrów Prezesowi UKE TYMCZASOWO powierzono
             funkcję Koordynatora ds. usług cyfrowych (rozwiązanie
             PRZEJŚCIOWE, ograniczony zakres zadań — wymiana informacji
             z KE, udział w ERUC — NIE PEŁNE uprawnienia kontrolne/
             sankcyjne, te wymagają ustawy)
Styczeń 2026 — PREZYDENT KAROL NAWROCKI ZAWETOWAŁ nowelizację ustawy o
             świadczeniu usług drogą elektroniczną (tzw. "ustawa
             cyfrowa"), która miała wdrożyć DSA W CAŁOŚCI — powód weta:
             zarzut wprowadzenia "administracyjnej cenzury" (dotyczyło
             to części o blokowaniu treści przez policję/prokuraturę/KAS)
Luty 2026 — Rząd PODZIELIŁ projekt na DWA ODRĘBNE: (1) czysta
             implementacja DSA (UKE jako koordynator, nadzór, kary —
             BEZ kontrowersyjnych uprawnień blokujących), (2) osobny
             projekt o uprawnieniach policji/prokuratury/KAS do
             wnioskowania o blokowanie treści w internecie
Ok. czerwca 2026 — Rząd przyjął projekt (1) — implementację DSA bez
             spornej części
4.09.2026 — USTAWA UCHWALONA: ustawa o zmianie ustawy o świadczeniu usług
             drogą elektroniczną oraz niektórych innych ustaw
6.10.2026 — ogłoszona: Dz.U. 2026 poz. 1296; W MOCY OD 6.11.2026
             ✅ [VER: ELI DU/2026/1296 text.pdf + metadane, RZĄD 1, 2026-10-20]

Nadzór (ustawa 1296):
  Koordynator ds. usług cyfrowych: PREZES UKE (art. 15b u.ś.u.d.e.)
  Właściwe organy: Prezes UOKiK (sekcja 4 rozdz. III DSA + naruszenia interesów
    konsumentów), Przewodniczący KRRiT (platformy udostępniania wideo, bez sekcji 4),
    Prezes UKE w pozostałym zakresie
  Skarga usługobiorcy do koordynatora (art. 22zh); kary do 6% światowego obrotu
    (art. 22zzn); roszczenia z art. 54 DSA przed SĄDEM OKRĘGOWYM (art. 22zzi; KPC
    art. 17 pkt 4⁶)
  Szczegóły: `mod-ustawa-uslugi-elektroniczne`
  ⛔ Blokowanie treści na wniosek policji/prokuratury/KAS — poza tą ustawą
```
**Weryfikacja eur-lex przed kazdy cytowaniem.**

## Adresaci i kategorie
```
Posrednicy (hosting, cache, access): Podstawowe zasady "safe harbour"
Platformy internetowe:               Powiadomienie o nielegalnych tresciach + usuniecie
Duze platformy (VLOP):               > 45 mln uzytkownikow/mies. w UE - dodatkowe obowiazki
  - Ocena ryzyka systemowego (co roku)
  - Audyt niezalezny
  - Dostep do danych dla badaczy
Bardzo duze wyszukiwarki (VLOSE):    Analogicznie

Nadzor nad VLOP/VLOSE: KE (Komisja Europejska) - bezposrednio
```

## Kluczowe obowiazki
```
Notice-and-action: System zglaszan nielegalnych tresci + szybka reakcja
Przejrzystosc reklam: Oznaczenie reklam + baza reklam (VLOP)
Zakaz targetowania: Dzieci, dane wrazliwe - zakaz targetowanej reklamy
Mechanizm skargi:   Wewnetrzny + zewnetrzny do DSC
Srodki przymusu:    Do 6% globalnego obrotu (VLOP niezastosowanie sie do KE)
```

## Weryfikacja online
```
web_search: "DSA Digital Services Act Rozp. UE 2022/2065 wymagania VLOP 2025"
Polska implementacja: ELI DU/2026/1296
```
