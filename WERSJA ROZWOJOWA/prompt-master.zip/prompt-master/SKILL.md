---
name: prompt-master
description: |
  Framework do tworzenia, oceny i iteracyjnego ulepszania promptów aż do uzyskania odpowiedzi 10/10.
  
  Używaj tego skilla ZAWSZE gdy użytkownik:
  - pyta jak napisać dobry prompt lub jak poprawić prompt
  - mówi "popraw mój prompt", "ulepsz zapytanie", "zrób lepszy prompt"
  - podaje słaby, ogólny prompt i prosi o wykonanie zadania ("jak pozyskać klientów", "jak schudnąć", "jak nauczyć się programować")
  - pyta o "prompt engineering", "skuteczny prompt", "prompt 10/10"
  - chce żeby Claude zadał pytania doprecyzowujące przed odpowiedzią
  - mówi "chcę lepszą odpowiedź" lub jest niezadowolony z ogólnikowej odpowiedzi
  
  Skill implementuje 7-warstwowy framework (Rola → Zadanie → Kontekst → Format → Przykłady → Myślenie → Ewaluacja) i prowadzi użytkownika przez iteracyjne doprecyzowanie za pomocą celowanych pytań, aż prompt osiągnie poziom 10/10.
---

# Prompt Master — framework 10/10

## Cel skilla

Przekształcić każdy słaby, ogólny prompt w precyzyjną instrukcję, która generuje odpowiedź wartą 10/10. Robi to przez:
1. Ocenę oryginalnego prompta (transparentnie, z punktacją)
2. Zadanie celowanych pytań doprecyzowujących (max 3 rundy po 3 pytania)
3. Zbudowanie poprawionego prompta wg 7-warstwowego frameworka
4. Wykonanie zadania na podstawie poprawionego prompta
5. Szczerą samoocenę odpowiedzi

---

## Krok 1 — Oceń oryginalny prompt

Zanim cokolwiek poprawisz, pokaż użytkownikowi co było nie tak. Używaj skali 1–10 i oceniaj każdą z 7 warstw osobno:

| Warstwa | Pytanie kontrolne | Brak = ile punktów tracisz |
|---|---|---|
| Rola | Czy model wie kim jest w tej rozmowie? | −1 |
| Zadanie | Czy jest konkretny czasownik akcji + cel? | −2 |
| Kontekst | Czy model zna sytuację, odbiorcę, ograniczenia? | −2 |
| Format | Czy wiadomo jak ma wyglądać output? | −1 |
| Przykłady | Czy jest choć jeden przykład dobrego/złego outputu? | −2 |
| Myślenie | Czy złożone zadania mają aktywację CoT? | −1 |
| Ewaluacja | Czy są kryteria sukcesu / samoocena? | −1 |

Jeśli prompt jest bardzo krótki (< 10 słów), od razu napisz: "Oceniam ten prompt na X/10. Żeby dać Ci odpowiedź 10/10, potrzebuję kilku informacji."

---

## Krok 2 — Zadaj pytania doprecyzowujące

Używaj narzędzia `ask_user_input_v0` do zadawania pytań jako interaktywne widgety. Zasady:

- **Max 3 rundy pytań**, po max 3 pytania na rundę
- **Runda 1** — pytania krytyczne (status, cel, budżet/ograniczenia)
- **Runda 2** — pytania kontekstowe (odbiorca, usługi/produkt, co już próbowano)
- **Runda 3** — pytania różnicujące (co wyróżnia, jakie wyniki są akceptowalne, format preferowany)

**Kiedy NIE pytać dalej:** jeśli po 2 rundach masz wystarczająco kontekstu — wykonaj zadanie. Nie przeciągaj w nieskończoność.

**Typy pytań do użycia:**
- `single_select` — gdy jest jedna najlepsza odpowiedź
- `multi_select` — gdy użytkownik może mieć wiele odpowiedzi naraz
- `rank_priorities` — gdy trzeba ustalić kolejność ważności

**Zawsze po widgecie dodaj otwarte pytanie tekstowe** dla informacji, których nie da się zamknąć w opcjach (np. lokalizacja, wyróżnik produktu, opis sytuacji).

### Priorytety pytań wg dziedziny

**Biznes / marketing:**
- Status (nowy / istniejący biznes)
- Budżet miesięczny
- Główne usługi/produkty
- Odbiorca (kim jest klient)
- Największa bolączka teraz

**Osobisty rozwój / nauka:**
- Obecny poziom (beginner / intermediate / advanced)
- Dostępny czas tygodniowo
- Cel końcowy i deadline
- Co już próbowano i dlaczego nie działało

**Technologia / kod:**
- Stack technologiczny
- Skala projektu
- Istniejące ograniczenia / zależności
- Doświadczenie zespołu

**Twórczość / content:**
- Ton i styl (przymiotniki)
- Odbiorca treści
- Kanał dystrybucji
- Przykład treści którą admirer

---

## Krok 3 — Zbuduj poprawiony prompt (7 warstw)

Na podstawie zebranych odpowiedzi zbuduj prompt wg poniższego wzoru. **Zawsze pokaż poprawiony prompt użytkownikowi przed wykonaniem zadania.**

```
# === WARSTWA 1: ROLA ===
Jesteś [stanowisko + dziedzina] z [X lat] doświadczenia w [branża/nisza].
Wiesz, że [jedna kluczowa prawda branżowa, której laicy nie znają].

# === WARSTWA 2: ZADANIE I CEL ===
Zadanie: [jeden konkretny czasownik akcji] [co dokładnie].
Cel: [końcowy efekt] dla [kto/co].

# === WARSTWA 3: KONTEKST ===
<kontekst>
  Produkt/Sytuacja: [opis]
  Odbiorca: [persona — demografia, ból, motywacja]
  Ton/Styl: [przymiotniki]
  Ograniczenia: [co nie może / co musi]
  Dodatkowy kontekst: [z pytań doprecyzowujących]
</kontekst>

# === WARSTWA 4: FORMAT ===
Format odpowiedzi: [lista / proza / JSON / tabela / podział na fazy]
Długość: [maks. X słów / X punktów]
Nie rób: [konkretne zakazy]

# === WARSTWA 5: PRZYKŁADY ===
<przykład-dobry>
  [Wejście]: [przykładowy input]
  [Wyjście]: [przykładowy idealny output]
</przykład-dobry>
<przykład-zły>
  [To jest złe:] [przykład]
  [Powód:] [dlaczego to nie działa]
</przykład-zły>

# === WARSTWA 6: MYŚLENIE ===
Zanim zaczniesz pisać, w tagach <thinking> przemyśl:
  1. Co jest najważniejszym wyzwaniem w tym zadaniu?
  2. Jakie ryzyko błędu jest największe?
  3. Jak podejdę krok po kroku?
Finalną odpowiedź umieść w <output>.

# === WARSTWA 7: EWALUACJA ===
Kryteria sukcesu:
  ✓ [Kryterium A]
  ✓ [Kryterium B]
  ✓ [Kryterium C]
Po napisaniu oceń odpowiedź wg powyższych. Jeśli nie spełnia ≥2 — ulepsz przed zwróceniem.

# === INPUT ===
[Konkretne pytanie / materiał]
```

**Warstwy opcjonalne (dodaj tylko gdy potrzebne):**
- Warstwa 5 (przykłady) — pomiń przy kreatywnych, swobodnych zadaniach gdzie przykład ogranicza
- Warstwa 6 (myślenie) — pomiń przy prostych, faktycznych pytaniach bez wielokrokowego rozumowania
- Warstwa 7 (ewaluacja) — zawsze, nawet skrócona do 2 kryteriów

---

## Krok 4 — Wykonaj zadanie

Wykonaj zadanie na podstawie poprawionego prompta. Używaj narzędzia `visualize:show_widget` do prezentacji wyników gdy wynik jest:
- planem działania (fazy, budżety, priorytety)
- porównaniem opcji
- strukturą z wieloma sekcjami
- czymś co użytkownik będzie wracał i przeglądał

---

## Krok 5 — Samoocena i transparentność

Po wykonaniu zadania **zawsze** napisz krótką samoocenę:

```
Oceniam tę odpowiedź na X/10.

Co działa dobrze: [1–2 zdania]
Co brakuje do 10/10: [konkretny brak, np. "nie znam Twojej lokalizacji / wyróżnika / budżetu"]
Żeby osiągnąć 10/10: [co użytkownik może dodać]
```

Zasady samooceny:
- Bądź szczery — jeśli brakuje kontekstu, powiedz to wprost
- Nigdy nie przyznaj 10/10 jeśli brakuje personalizacji
- Zawsze zaproponuj konkretny następny krok do poprawy

---

## Obsługa brzegowych przypadków

**Użytkownik nie odpowiada na pytania / odpowiada "nie wiem":**
Nie blokuj się. Przyjmij rozsądne założenia, napisz je explicite ("Zakładam że X — jeśli jest inaczej, powiedz mi") i wykonaj zadanie.

**Sprzeczne odpowiedzi użytkownika:**
Wskaż sprzeczność bezpośrednio i zaproponuj klaryfikację: "Zaznaczyłeś/aś X i Y — to wyklucza się, które lepiej opisuje Twoją sytuację?"

**Prompt już jest dobry (7+/10):**
Powiedz to. Nie ulepszaj dla samego ulepszania. Zaproponuj 1–2 konkretne ulepszenia i zapytaj czy wdrożyć.

**Temat wrażliwy / niejasny etycznie:**
Zadaj pytanie o intencję zanim zaczniesz iterować prompt.

**Brak wystarczającego kontekstu po 2 rundach pytań:**
Wykonaj zadanie z założeniami i oznacz je wyraźnie w odpowiedzi jako "[ZAŁOŻENIE — uzupełnij jeśli inne]".

---

## Przykłady promptów uruchamiających skill

Skill powinien się uruchomić dla:
- "jak pozyskać klientów do salonu"
- "popraw mój prompt: [prompt]"
- "jak napisać skuteczny prompt"
- "zrób mi prompt do [zadanie]"
- "ulepsz to zapytanie: [tekst]"
- "chcę lepszą odpowiedź na to pytanie"
- "jak powinienem zapytać Claude o [temat]"
- "[krótkie, ogólne pytanie] + prośba o plan/strategię/porady"

Skill NIE powinien się uruchamiać dla:
- konkretnych pytań faktycznych z wystarczającym kontekstem
- prostych próśb o kod / tłumaczenie / edycję tekstu
- zadań gdzie prompt jest już szczegółowy (>50 słów z kontekstem)
