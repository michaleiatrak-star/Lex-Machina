# Framework 7 warstw — szczegółowy przewodnik

## Warstwa 1 — Rola i tożsamość

### Cel
Nadać modelowi konkretną tożsamość eksperta z doświadczeniem, perspektywą i "wewnętrzną wiedzą branżową".

### Wzór
```
Jesteś [stanowisko] z [X lat] doświadczenia w [nisza].
Wiesz, że [jedna prawda branżowa której laicy nie znają].
```

### Przykłady dobra vs złe
✓ "Jesteś senior copywriterem z 12-letnim doświadczeniem w B2B SaaS, specjalizującym się w email marketingu. Wiesz, że 80% kampanii upada przez słaby subject line, nie przez treść emaila."

✗ "Jesteś ekspertem od marketingu."

### Wpływ na jakość: wysoki
### Trudność wdrożenia: niska

---

## Warstwa 2 — Zadanie i cel

### Cel
Powiedzieć modelowi CO zrobić (konkretny czasownik akcji) i PO CO (cel końcowy). Cel pozwala modelowi podejmować inteligentne decyzje przy lukach w specyfikacji.

### Wzór
```
Zadanie: [czasownik] [co dokładnie].
Cel: [końcowy efekt] dla [kto/co].
```

### Przykłady dobra vs złe
✓ "Zadanie: Napisz sekwencję 3 emaili onboardingowych. Cel: doprowadzić nowych użytkowników do pierwszego kluczowego działania (AHA moment) w ciągu 7 dni od rejestracji."

✗ "Napisz emaile onboardingowe."

### Wpływ na jakość: krytyczny
### Trudność wdrożenia: niska

---

## Warstwa 3 — Kontekst i materiały

### Cel
Dostarczyć wszystkich informacji których model nie może zgadnąć. Brak kontekstu = generyczne odpowiedzi.

### Elementy kontekstu (wybierz relevantne)
- Produkt / usługa / sytuacja: opis
- Odbiorca: demografia, ból, motywacja, poziom wiedzy
- Ton marki / styl komunikacji: przymiotniki opisujące głos
- Ograniczenia: co nie może / co musi się pojawić
- Poprzednie próby: co testowano i dlaczego nie działało
- Dodatkowy kontekst: liczby, daty, nazwy własne, zależności

### Technika XML tagów
Zawijaj sekcje kontekstu w tagi XML — model lepiej separuje różne typy informacji:
```xml
<kontekst>
  <produkt>...</produkt>
  <odbiorca>...</odbiorca>
  <ton>...</ton>
</kontekst>
```

### Czego NIE dawać w kontekście
- Nierelevantnych informacji (dilute focus)
- Sprzecznych instrukcji
- Długich dokumentów bez wskazania kluczowych fragmentów

### Wpływ na jakość: bardzo wysoki
### Trudność wdrożenia: średnia

---

## Warstwa 4 — Format i ograniczenia

### Cel
Precyzować strukturę, długość, format i czego unikać. Negatywne instrukcje ("nie rób X") eliminują najczęstsze błędy skuteczniej niż dodatkowy opis pozytywny.

### Elementy formatu
- Struktura: lista / proza / JSON / tabela / podział na fazy / markdown
- Długość: maks. X słów / X punktów / X akapity
- Zakazy ("nie rób"): konkretne, nie ogólne

### Przykłady zakazy dobra vs złe
✓ "Nie używaj frazesów marketingowych jak 'przełomowy' lub 'rewolucyjny'. Nie zaczynaj od pytania retorycznego. Nie używaj bullet pointów — pisz w zdaniach."

✗ "Pisz naturalnie."

### Wpływ na jakość: wysoki
### Trudność wdrożenia: bardzo niska

---

## Warstwa 5 — Przykłady (few-shot)

### Cel
Kształtować styl, ton i strukturę outputu. Jeden dobry przykład = dziesięć zdań opisu.

### Kiedy używać
- Gdy format jest niestandardowy
- Gdy ton jest bardzo specyficzny
- Gdy poprzednie odpowiedzi były "obok"

### Kiedy pominąć
- Proste, faktyczne pytania
- Kreatywne zadania gdzie przykład ogranicza
- Gdy format jest oczywisty (np. "przetłumacz to zdanie")

### Wzór
```
<przykład-dobry>
  [Wejście]: [przykładowy input]
  [Wyjście]: [przykładowy idealny output]
</przykład-dobry>
<przykład-zły>
  [To jest złe]: [przykład]
  [Powód]: [dlaczego nie działa]
</przykład-zły>
```

### Pro tip: Przykład negatywny > przykład pozytywny
Ludzie lepiej uczą się przez unikanie błędów niż naśladowanie wzoru. Przykład złego outputu z wyjaśnieniem DLACZEGO jest zły często daje lepsze rezultaty.

### Wpływ na jakość: krytyczny
### Trudność wdrożenia: średnia-wysoka

---

## Warstwa 6 — Myślenie krok po kroku (Chain-of-Thought)

### Cel
Aktywować rozumowanie wieloetapowe przed wygenerowaniem odpowiedzi. Dramatycznie zwiększa jakość przy analizie, kodowaniu i decyzjach złożonych.

### Kiedy używać
- Złożone analizy
- Kod z logiką wieloetapową
- Decyzje z wieloma ograniczeniami
- Zadania gdzie "pierwszy instynkt" modelu bywa błędny

### Kiedy pominąć
- Proste, faktyczne pytania
- Tłumaczenia
- Streszczenia prostych tekstów

### Wzory aktywacji CoT
```
Zanim zaczniesz pisać, w tagach <thinking> przemyśl:
  1. Co jest najważniejszym wyzwaniem?
  2. Jakie ryzyko błędu jest największe?
  3. Jak podejdę krok po kroku?
```

Lub krócej:
```
Myśl krok po kroku zanim odpiszesz.
```

Lub z separacją outputu:
```
Swoje rozumowanie zapisz w <thinking>.
Finalną odpowiedź umieść w <output>.
```

### Wpływ na jakość: wysoki (dla złożonych zadań)
### Trudność wdrożenia: minimalna

---

## Warstwa 7 — Ewaluacja i samoocena

### Cel
Wbudować mechanizm QA w sam prompt. Model ocenia własny output przed zwróceniem — jak wewnętrzny recenzent.

### Wzór
```
Kryteria sukcesu:
  ✓ [Kryterium A — jak je sprawdzić]
  ✓ [Kryterium B — jak je sprawdzić]
  ✓ [Kryterium C — jak je sprawdzić]
Po napisaniu odpowiedzi oceń ją wg powyższych. 
Jeśli nie spełnia ≥2 — ulepsz przed zwróceniem.
```

### Typy kryteriów sukcesu
- **Funkcjonalne**: "Odpowiedź zawiera konkretne działania z datami"
- **Tonalne**: "Żadne zdanie nie brzmi jak reklama"
- **Strukturalne**: "Plan jest podzielony na fazy z budżetem"
- **Personalizacyjne**: "Odpowiedź uwzględnia specyfikę małego miasta"

### Warianty (alternatywne)
Zamiast samooceny, można poprosić o warianty:
```
Zaproponuj 3 wersje: konserwatywną, odważną i eksperymentalną.
```

### Wpływ na jakość: wysoki
### Trudność wdrożenia: niska-średnia

---

## Mapa priorytetów — co poprawiać najpierw

Gdy masz ograniczony czas i musisz wybrać co ulepszyć:

1. **Warstwa 2 (Zadanie + cel)** — najczęstszy powód ogólnych odpowiedzi
2. **Warstwa 5 (Przykłady)** — najszybszy sposób na dopasowanie tonu i stylu
3. **Warstwa 3 (Kontekst)** — personalizacja odpowiedzi pod konkretną sytuację
4. **Warstwa 4 (Format)** — eliminacja najczęstszych błędów przez zakazy
5. **Warstwa 1 (Rola)** — podniesienie głębokości i perspektywy
6. **Warstwa 7 (Ewaluacja)** — weryfikacja że output spełnia kryteria
7. **Warstwa 6 (Myślenie)** — aktywuj tylko przy złożonych zadaniach

---

## Pytania doprecyzowujące wg dziedziny

### Marketing / pozyskiwanie klientów
Runda 1: status biznesu, budżet miesięczny, główna bolączka
Runda 2: usługi/produkty, profil klienta, co już testowano
Runda 3: lokalizacja, wyróżnik, preferowany kanał

### Nauka / rozwój osobisty
Runda 1: obecny poziom, cel końcowy, dostępny czas
Runda 2: co już próbowano, styl uczenia się, deadline
Runda 3: zasoby dostępne, wsparcie zewnętrzne, motywacja

### Tworzenie treści
Runda 1: kanał dystrybucji, odbiorca, cel treści
Runda 2: ton marki, co inspiruje, co odpycha
Runda 3: długość, format, CTA

### Programowanie / technologia
Runda 1: stack, doświadczenie, skala projektu
Runda 2: istniejące ograniczenia, zależności
Runda 3: wymagania wydajnościowe, deadline, team

### HR / zarządzanie
Runda 1: rozmiar zespołu, branża, problem do rozwiązania
Runda 2: kultura firmy, historia problemu
Runda 3: zasoby, timeline, akceptowalne kompromisy
