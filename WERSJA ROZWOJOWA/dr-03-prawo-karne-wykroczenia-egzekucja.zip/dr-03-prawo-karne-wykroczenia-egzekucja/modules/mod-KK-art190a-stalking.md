# Moduł [J] — Stalking i Nękanie

**Zakres:** Art. 190a §1 KK (stalking), §2 (podszywanie pod osobę), §3 (kwalifikowany
— skutek samobójstwo), cyberstalking, zabezpieczenie dowodów, zawiadomienie
o przestępstwie, zakaz zbliżania (środek zapobiegawczy i nakazowy).

---

## ZASADY ABSOLUTNE

1. **STALKING — ŚCIGANIE NA WNIOSEK** (art. 190a §4 KK) — bez wniosku pokrzywdzonego
   Policja i prokurator NIE MOGĄ wszcząć postępowania z urzędu dla §1 i §2.
   **Wyjątek:** §3 (gdy skutkiem jest targnięcie się pokrzywdzonego na własne życie) → z urzędu.

2. **UWAGA: GROŹBA KARALNA (art. 190 KK) — ODRĘBNY PRZEPIS**
   - Art. 190 §1 KK (Dz.U.2025.383): kara do **3 lat** pozbawienia wolności
   - Art. 190 §2 KK: „Ściganie następuje na wniosek pokrzywdzonego"
   - **Wyjątek procesowy — art. 12 §4 KPK (od 01.10.2023):** można wszcząć BEZ wniosku
     jeżeli zachodzi duże prawdopodobieństwo, że niezłożenie wniosku wynika z **obawy przed
     odwetem** albo przemawia za tym **interes społeczny**. Postępowanie do prawomocnego
     zakończenia toczy się wtedy z urzędu.
   - ⚠️ Art. 190 KK POZOSTAJE przepisem wnioskowym — art. 12 §4 KPK to wyjątek procesowy,
     nie zmiana trybu materialnego.

3. **TRZY ZNAMIONA STALKINGU ŁĄCZNIE (art. 190a §1 KK):**
   - Uporczywość (wielokrotność, długotrwałość)
   - Skutek: wzbudzenie uzasadnionego poczucia zagrożenia / istotne naruszenie prywatności
   - Obiektywna ocena (nie tylko subiektywne odczucie pokrzywdzonego)

4. **NOWELIZACJA 2023:** Art. 190a §1 i §2 — zagrożenie karą 6 miesięcy – 8 lat pozbawienia
   wolności (przed nowelizacją: do 3 lat).

5. **Pełna tabela trybów ścigania:**
   ```
   view /mnt/skills/user/prawny-router-v3/references/tryby-scigania.md
   ```

---

## KLUCZOWE AKTY PRAWNE

- KK art. 190a → isap.sejm.gov.pl (**Dz.U. 2025 poz. 383; sprawdź zmiany Dz.U. 2025 poz. 1818 i 1872** t.j.) — **weryfikuj online**
- KPK → isap.sejm.gov.pl (**Dz.U. 2026 poz. 490; sprawdź Dz.U. 2026 poz. 638 i przepisy przejściowe** t.j.) — **weryfikuj online**

---

## SZCZEGÓŁOWY FRAMEWORK

```
view /mnt/skills/user/shared/STALKING-NEKANIE.md
```

Zawiera: znamiona art. 190a §1, §2, §3 (omówienie z przykładami), cyberstalking
i naruszenie wizerunku (art. 190a §2), strategię zabezpieczania dowodów (logi,
zrzuty ekranu, bilingi, zeznania świadków), zawiadomienie o przestępstwie —
wymogi i tryb, zakaz zbliżania jako środek zapobiegawczy (art. 275a KPK) i środek
nakazowy po wyroku, ochrona cywilna (art. 24 KC — naruszenie dóbr osobistych).

---

## ŁĄCZ Z

| Sytuacja | Skill / Moduł |
|---|---|
| Zawiadomienie o przestępstwie (stalking) | `pisma-procesowe-v3` |
| Analiza i wycena dowodów (logi, SMS) | `analizator-dowodow-v3` |
| Stalking w miejscu pracy / mobbing | `mod-B-mobbing.md` |
| Sprawa karna — obrona / szanse | `analiza-sadowa-v6` |
| Naruszenie dóbr osobistych — pozew cywilny | `mod-E-cywilne.md` |
