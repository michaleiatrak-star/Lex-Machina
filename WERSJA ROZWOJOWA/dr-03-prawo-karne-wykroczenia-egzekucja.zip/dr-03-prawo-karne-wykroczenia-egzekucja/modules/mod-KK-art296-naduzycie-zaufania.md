# Nadużycie zaufania — działanie na szkodę majątkową (art. 296 KK) v1.0.0 (dodany 2026-07-16)

**Akt:** KK — t.j. Dz.U. 2026 poz. 1342 (zm. 2026/1466 [OD 2026-11-21: 2026/1466] — art. 42, 84).
**Akt:** KPK — t.j. Dz.U. 2026 poz. 490 (zm. po t.j., w mocy: 2026/421 od 2026-04-14 i 2026/760 od 2026-06-12 — art. 21h, 74, 213, 332, 336; 2026/638 od 2026-05-28 — art. 25; 2026/882 od 2026-07-16 — art. 607k–607zb; 2026/901 od 2026-07-21 — art. 87).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: zagrożenia karą i terminy porównane z t.j.).

> ⛔ Kandydat zidentyfikowany w sesji AUDYT-2026-07-16d (sąsiaduje z
> art. 296a), naprawiony teraz. Wcześniej istniały tylko 2 luźne wzmianki
> (bez drzewa) w `mod-KK-KPK-framework-karne.md`.
> ⚠️ Zweryfikowane 2026-07-16 — do potwierdzenia na isap.sejm.gov.pl.

---

## DRZEWO N.1 — NADUŻYCIE ZAUFANIA (art. 296 KK)

```
START: Czy sprawca jest OBOWIĄZANY na podstawie przepisu prawa, decyzji
właściwego organu, umowy do zajmowania się SPRAWAMI MAJĄTKOWYMI lub
DZIAŁALNOŚCIĄ GOSPODARCZĄ innej osoby fizycznej, prawnej albo jednostki
organizacyjnej niemającej osobowości prawnej?
│
├─ NIE → art. 296 NIE MA ZASTOSOWANIA — brak wymaganego statusu
│  "zarządzającego cudzymi sprawami majątkowymi"
│
└─ TAK → czy PRZEZ NADUŻYCIE UPRAWNIEŃ lub NIEDOPEŁNIENIE OBOWIĄZKU
   wyrządził tej jednostce ZNACZNĄ SZKODĘ MAJĄTKOWĄ?
   │
   ├─ Typ podstawowy, umyślny (art. 296 §1) → 3 m-ce – 5 lat
   │
   ├─ Działanie W CELU OSIĄGNIĘCIA KORZYŚCI MAJĄTKOWEJ (art. 296 §2)
   │  → 6 m-cy – 8 lat (typ kwalifikowany podmiotowo — motyw korzyści)
   │
   ├─ Szkoda WIELKIEJ WARTOŚCI (art. 296 §3, w zw. z art. 115 §6) →
   │  1-10 lat
   │
   ├─ Typ NIEUMYŚLNY — sprawca nieumyślnie wyrządza znaczną szkodę
   │  majątkową (art. 296 §4) → do 3 lat
   │
   └─ ⚠️ ESKALACJA ZBRODNIOWA (art. 306b KK — dodane 2026-07-26, FAZA 3E/
      ZASADA 14, weryfikacja odłożona z poprzedniej transzy, teraz
      potwierdzona) — jeśli czyn z art. 296 §1 LUB §2 (NIE §3!) dotyczy
      mienia o wartości LUB szkody w rozmiarach:
        > 5 mln zł (pięciokrotność mienia wielkiej wartości)
          → art. 306b §1 → 3-20 lat (ZBRODNIA)
        > 10 mln zł (dziesięciokrotność mienia wielkiej wartości)
          → art. 306b §2 → 5-25 lat (ZBRODNIA)
      Wprowadzone nowelizacją z 2022 r. (w życie 1.10.2023), obejmuje
      RÓWNIEŻ art. 296a §1/§4 (korupcja menadżerska), art. 299 §1/2/5/6
      (pranie pieniędzy), art. 303 §1 (dokumentacja działalności
      gospodarczej) — WYŁĄCZNIE bierne łapownictwo menadżerskie z 296a,
      nie czynne. Potwierdzone w 6+ źródłach: arslege.pl (t.j. Dz.U.
      2025.383), kairp.pl, adwokatdulniak.pl, kancelarierp.pl,
      chmielniak.com.pl, russellbedford.pl. ⚠️ UWAGA: art. 306b NIE
      obejmuje art. 296 §3 (już samodzielnie do 10 lat) — dotyczy
      wyłącznie eskalacji z §1/§2, tworząc TRZYSTOPNIOWĄ, nie
      dwustopniową drabinę zagrożenia dla tego samego czynu bazowego.
```

⚠️ **Ściganie na wniosek pokrzywdzonego (art. 296 §4a KK)** — analogicznie
do art. 296a: jeśli pokrzywdzonym jest podmiot inny niż Skarb Państwa/
JST, ściganie następuje NA WNIOSEK pokrzywdzonego (nie z urzędu) —
sprawdź aktualne brzmienie i czy dotyczy wszystkich typów czy tylko
niektórych paragrafów.

⚠️ **Różnica od art. 296a (korupcja menadżerska):** art. 296 NIE WYMAGA
elementu korzyści od OSOBY TRZECIEJ (łapówki) — obejmuje SAMO
nadużycie uprawnień/zaniedbanie ze szkodą, niezależnie od tego, czy
sprawca dostał za to jakąkolwiek korzyść od kogokolwiek. Jeśli
zarządzający przyjął korzyść OD OSOBY TRZECIEJ w zamian za działanie
na szkodę zarządzanego podmiotu — możliwy ZBIEG kumulatywny art. 296 +
art. 296a (dwa różne dobra chronione: majątek zarządzanego podmiotu
ORAZ uczciwość obrotu gospodarczego).

⚠️ **"Znaczna szkoda" — próg kwotowy** (art. 115 §7 w zw. z §5 KK) —
sprawdzaj aktualną wartość progową (indeksowaną), nie zakładaj z
pamięci — częsty błąd w kwalifikacji, bo próg bywa zmieniany.

---

## 2. TABELA SZYBKIEGO ODCZYTU

| Typ | Przepis | Zagrożenie | Tryb |
|---|---|---|---|
| Nadużycie zaufania (umyślne, znaczna szkoda) | art. 296 §1 | 3 m-ce – 5 lat | na wniosek (wyjątek: Skarb Państwa/JST) |
| Dla korzyści majątkowej | art. 296 §2 | 6 m-cy – 8 lat | j.w. |
| Szkoda wielkiej wartości | art. 296 §3 | 1-10 lat | j.w. |
| Nieumyślne | art. 296 §4 | do 3 lat | j.w. |

⚠️ Zagrożenia i progi kwotowe do potwierdzenia na isap.sejm.gov.pl
przed użyciem w piśmie (PRAWO-HARDGATE).

---

## CROSS-REFERENCJE

- Korupcja menadżerska — gdy szkoda wynika z przyjęcia korzyści od
  osoby trzeciej (możliwy zbieg kumulatywny) → `mod-KK-art296a-korupcja-sektor-prywatny.md`.
- Odpowiedzialność podmiotów zbiorowych, gdy szkodę wyrządzono na rzecz/
  w interesie podmiotu zbiorowego → `mod-ustawa-odpowiedzialnosc-podmiotow-zbiorowych.md`.
- Ogólne przestępstwa gospodarcze (kontekst szerszy) —
  `mod-KK-KPK-framework-karne.md` (tam tylko wzmianka, TU pełne drzewo —
  nie dubluj).
