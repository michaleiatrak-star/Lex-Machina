# Prawo Karne — Szczegółowy Framework

**Akt:** KK — t.j. Dz.U. 2026 poz. 1342 (zm. 2026/1466 [OD 2026-11-21: 2026/1466] — art. 42, 84).
**Akt:** KPK — t.j. Dz.U. 2026 poz. 490 (zm. po t.j., w mocy: 2026/421 od 2026-04-14 i 2026/760 od 2026-06-12 — art. 21h, 74, 213, 332, 336; 2026/638 od 2026-05-28 — art. 25; 2026/882 od 2026-07-16 — art. 607k–607zb; 2026/901 od 2026-07-21 — art. 87).
**Akt:** KW — t.j. Dz.U. 2026 poz. 1372 (po t.j. bez zmian, ELI 2026-11-14).
**Akt:** KKW — t.j. Dz.U. 2026 poz. 1307 (po t.j. bez zmian, ELI 2026-11-14).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: zagrożenia karą i terminy porównane z t.j.).

## PRAWA ZATRZYMANEGO — ABSOLUTNY PRIORYTET
```
OD CHWILI ZATRZYMANIA — ŻĄDAJ NATYCHMIAST:
  □ Prawo do kontaktu z adwokatem (art. 245 §1 KPK) — ZANIM zeznasz
  □ Prawo do informacji o przyczynie zatrzymania (art. 244 §2 KPK)
  □ Prawo do milczenia (art. 175 §1 KPK) — na każde pytanie
  □ Prawo do powiadomienia osoby bliskiej lub pracodawcy (art. 245 §2 KPK)
  □ Prawo do tłumacza (art. 72 KPK) — gdy nie władasz językiem polskim
  □ Prawo do lekarza (gdy stan zdrowia wymaga)

CZEGO NIE ROBIĆ:
  → NIE składaj wyjaśnień bez adwokata — nawet „niewinne" słowa szkodzą
  → NIE podpisuj protokołów, których treści nie rozumiesz
  → NIE wyrażaj zgody na przeszukanie bez nakazu (chyba że i tak nastąpi)
```

## FAZA 0 — INTAKE
```
□ Etap postępowania: zatrzymanie / podejrzany / oskarżony / sąd / wyrok?
□ Zarzut: jaki przepis KK? → sprawdź zagrożenie karą + tryb ścigania
□ Tryb ścigania: z urzędu / na wniosek / z oskarżenia prywatnego?
□ Czy złożono już wyjaśnienia? → co powiedziano? → możliwość odwołania
□ Czy są dowody rzeczowe / nagrania / świadkowie?
□ Czy możliwe warunkowe umorzenie / mediacja karna?
□ Termin przedawnienia: sprawdź art. 101 KK natychmiast
```

## ETAPY POSTĘPOWANIA KARNEGO
```
POSTĘPOWANIE PRZYGOTOWAWCZE:
  Dochodzenie (Policja) lub Śledztwo (Prokuratura)
      ↓
  Akt oskarżenia → Sąd Rejonowy / Okręgowy
      ↓
POSTĘPOWANIE SĄDOWE:
  Rozprawa główna
      ↓ [14 dni od wyroku] APELACJA → Sąd Okręgowy / Apelacyjny
      ↓ [30 dni od SA] KASACJA do SN (przymus adwokacki)
```

## TRYBY ŚCIGANIA
| Tryb | Przykłady | Jak wszcząć |
|---|---|---|
| Z urzędu | Zabójstwo, rozbój, przemoc domowa | Policja/Prokuratura działa sama |
| Na wniosek | Stalking, gwałt, zniszczenie mienia | Wniosek pokrzywdzonego |
| Prywatnoskargowy | Zniesławienie, naruszenie NTN | Prywatny akt oskarżenia |

## WARUNKOWE UMORZENIE (art. 66–68 KK) — STRATEGIA OBRONY
```
WARUNKI ŁĄCZNIE (wszystkie muszą być spełnione):
  □ Wina i społeczna szkodliwość czynu nieznaczne
  □ Sprawca niekarany za przestępstwo umyślne
  □ Postawa, właściwości i warunki osobiste sprawcy rokują przestrzeganie prawa
  □ Zagrożenie do 5 lat pozbawienia wolności

OKRES PRÓBY: 1–3 lata
OBOWIĄZKI MOGĄ OBEJMOWAĆ: naprawienie szkody, zakaz prowadzenia pojazdów,
  zakaz kontaktu z pokrzywdzonym, świadczenie pieniężne na cel społeczny

STRATEGIA:
  → Napraw szkodę przed wnioskiem (zwiększa szanse)
  → Wyraź skruchę (protokół) + zaświadczenia o niekaralności
  → Wniosek do prokuratora (etap przygotowawczy) lub do sądu
```

## MEDIACJA KARNA (art. 23a KPK)
```
KIEDY: Na każdym etapie postępowania (prokuratura + sąd)
KTO: Mediator wpisany na listę Prezesa SO
SKUTKI:
  → Porozumienie z pokrzywdzonym → podstawa warunkowego umorzenia
  → Naprawienie szkody → nadzwyczajne złagodzenie kary
  → Możliwe umorzenie postępowania (za zgodą prokuratora)
WNIOSEK: pisemny do prokuratora / sądu — złóż jak najwcześniej
```

## PRZEDAWNIENIE KARALNOŚCI (art. 101 KK) — Dz.U. 2026 poz. 1342
```
Zbrodnia zabójstwa:                40 lat od popełnienia  ⚠️ (nie 30!)
Inna zbrodnia (≥3 lat PW):        20 lat
Występek zagroż. > 5 lat PW:      15 lat                 ⚠️ (dodany próg)
Występek zagroż. > 3 lat PW:      10 lat
Pozostałe występki:                 5 lat
Prywatnoskargowe (§2):             1 rok od wiedzy / max 3 lata od czynu
Wykroczenia:                        1 rok (2 lata gdy wszczęto)

Przedłużenie po wszczęciu (art. 102 KK): +10 lat dla przestępstw z §1 / +5 lat dla pozostałych
```

## TYPOWE PRZESTĘPSTWA — ZAGROŻENIA
| Art. KK | Czyn | Zagrożenie |
|---|---|---|
| art. 156 | Ciężki uszczerbek na zdrowiu | 3–20 lat |
| art. 157 §1 | Średni uszczerbek | 3 mies.–5 lat |
| art. 178a §1 | Jazda po alkoholu (>0,5‰) — §1 (pierwszy raz) | **pozbawienie wolności do lat 3** — sankcja JEDNORODNA, bez grzywny i ograniczenia wolności jako kar samoistnych (od 1.10.2023) ✅ [VER 2026-08-25] |
| art. 178a §4 | Jazda po alkoholu — RECYDYWA (skazany uprzednio) | 3 m-ce – 5 lat PW ⚠️ |
| art. 190a | Stalking (§1) | 6 m-cy – 8 lat |
| art. 207 | Znęcanie się | 3 m-ce – 5 lat |
| art. 278 §1 | Kradzież (powyżej progu z art. 119 KW) | 3 mies.–5 lat |
| art. 286 §1 | Oszustwo | 6 mies.–8 lat |
| art. 288 §1 | Zniszczenie mienia | 3 mies.–5 lat |
| art. 190 §1 | Groźba karalna | do 3 lat PW ⚠️ |

## ART. 178a KK — JAZDA PO ALKOHOLU / NARKOTYKACH — SZCZEGÓŁY (nowelizacja 14.03.2024)
⚠️ Weryfikuj każdorazowo w ELI (RZĄD 1) (Dz.U. 2026 poz. 1342 t.j.)

### §1 — Typ podstawowy (pierwsza jazda w stanie nietrzeźwości >0,5‰ lub pod wpływem narkotyków)
- Kara ustawowa: **pozbawienie wolności do lat 3** — sankcja jednorodna
  od 1.10.2023 r. Grzywna lub ograniczenie wolności mogą wynikać z
  odrębnych podstaw części ogólnej (np. art. 37a/58 KK), nie z sankcji
  wpisanej w art. 178a §1 KK.
- Zakaz prowadzenia pojazdów: obowiązkowy, min. 3 lata
- Świadczenie na Fundusz Pomocy Pokrzywdzonym: min. 5 000 zł (sąd może do 60 000 zł)
- Przepadek pojazdu (art. 44b KK): fakultatywny (§1); OBOWIĄZKOWY gdy stężenie ≥ 1,5‰
  (0,75 mg/dm³ powietrza) — §1a, chyba że wyjątkowy wypadek uzasadniony szczególnymi
  okolicznościami; pojazd nie wyłącznie sprawcy → nawiązka 5 000–500 000 zł (§5–§6)

### §4 — Typ kwalifikowany
Sprawca czynu z §1, który był wcześniej prawomocnie skazany za prowadzenie pojazdu
mechanicznego w stanie nietrzeźwości / pod wpływem środka odurzającego albo za art. 173,
174, 177 lub 355 §2 popełnione w takim stanie, LUB który dopuścił się czynu z §1 w okresie
zakazu prowadzenia pojazdów mechanicznych orzeczonego w związku ze skazaniem za przestępstwo.
- Kara: 3 miesiące – 5 lat PW
- Świadczenie na Fundusz: min. 10 000 zł (art. 43a §3)
- Zakaz prowadzenia wszelkich pojazdów mechanicznych DOŻYWOTNIO (art. 42 §3), chyba że
  wyjątkowy wypadek; przy ponownym skazaniu w warunkach §3 — bez wyjątku (art. 42 §4)
- Przepadek pojazdu — art. 44b §1 / §1a jak przy §1
✅ [VER: ELI DU/2026/1342 text.pdf (t.j. KK), art. 42, 43a, 44b, 178a, RZĄD 1, 2026-10-20]

### STRATEGIA OBRONY art. 178a
```
□ Weryfikuj stężenie alkoholu — błąd pomiaru (urządzenie, kalibracja, choroba)
□ Sprawdź czy to droga publiczna / strefa ruchu / teren zabudowany
□ Warunkowe umorzenie: MOŻLIWE przy §1, niekaralność, niska szkodliwość
  → wymaga: wina i szkodliwość nieznaczne + zagrożenie ≤ 5 lat ✓ + brak skazania za umyślne
□ Blokada alkoholowa (art. 182a KKW) — wniosek po ½ zakazu prowadzenia
□ Przepadek pojazdu: skarżyć wartość, żądać wyceny rynkowej
```

### GRANICA WYKROCZENIE / PRZESTĘPSTWO (art. 87 KW vs art. 178a KK)
```
0,2–0,5‰ we krwi (lub 0,1–0,25 mg/dm³ w powietrzu) → art. 87 §1 KW (WYKROCZENIE)
  Kara: ARESZT 5–30 DNI (art. 19 KW) albo GRZYWNA NIE NIŻSZA NIŻ
        2 500 zł (dolna granica z art. 87 §1 KW),
        górna granica 30 000 zł (art. 87 §1 w katalogu art. 24 §1a KW)
        ⛔ nie podawaj samej górnej granicy bez dolnej — opis byłby niepełny
  + zakaz prowadzenia pojazdów OBLIGATORYJNY (art. 87 §3 KW)
> 0,5‰ we krwi (lub > 0,25 mg/dm³ w powietrzu) → art. 178a §1 KK (PRZESTĘPSTWO)
  Kara: POZBAWIENIE WOLNOŚCI DO LAT 3 (sankcja jednorodna, od 1.10.2023)
        + zakaz prowadzenia min. 3 lata (art. 42 §2 KK)
  ⛔ Znaczenie procesowe: 3 lata < 8 lat → art. 258 §2 KPK nie działa;
     3 lata > 1 rok → art. 259 §3 KPK też nie działa
✅ [VER: ELI — Dz.U. 2025 poz. 734, art. 19, 24 §1a i 87 §1 (re-ver t.j. Dz.U. 2026 poz. 1372, 2026-10-31: bez zmian w tym zakresie);
   Dz.U. 2025 poz. 383 (obecny t.j. Dz.U. 2026 poz. 1342), art. 178a §1 — odczyt 2026-08-25]
```

## ART. 190 KK — GROŹBA KARALNA — SZCZEGÓŁY
⚠️ Weryfikuj w ELI (RZĄD 1) (Dz.U. 2026 poz. 1342 t.j.)

### §1 — Znamiona
- Grożenie popełnieniem PRZESTĘPSTWA (nie wykroczenia!) na szkodę pokrzywdzonego lub osoby mu najbliższej
- Groźba WZBUDZA uzasadnioną obawę spełnienia (ocena obiektywna — test przeciętnej osoby)
- Forma dowolna: słowna, pisemna, przez gest, przez osobę trzecią
- Kara: do 3 lat PW (po nowelizacji z 07.07.2022, obowiązuje od 01.10.2023)
  ⚠️ UWAGA: do 01.10.2023 zagrożenie wynosiło 2 lata — stosuj prawo względniejsze (art. 4 §1 KK)

### §2 — Tryb ścigania: NA WNIOSEK pokrzywdzonego
- Brak wniosku = Policja nie wszczyna postępowania z urzędu
- Wyjątek: prokurator może wszcząć bez wniosku gdy: duże prawdopodobieństwo że brak wniosku wynika z obawy przed odwetem LUB przemawia interes społeczny
- Wycofanie wniosku: za zgodą prokuratora (etap przygotowawczy) lub sądu (do zamknięcia przewodu)

## 5 LINII OBRONY OSKARŻONEGO
```
1. Brak znamion: czyn nie wyczerpuje definicji przestępstwa
2. Kontratypy: obrona konieczna (art. 25 KK), stan wyższej konieczności (art. 26)
3. Niepoczytalność / poczytalność ograniczona (art. 31 KK) → biegły psychiatra
4. Błąd co do faktu (art. 28 KK) lub bezprawności (art. 30 KK)
5. Atypowy przebieg przyczynowości → brak związku z wynikiem
```

## ZABEZPIECZENIE DOWODÓW — STRONA POKRZYWDZONA
```
□ Zawiadomienie na piśmie (zalecane) — z wnioskiem o ściganie gdy wymagany
□ Zdjęcia obrażeń ciała niezwłocznie + dokumentacja medyczna
□ Zabezpieczenie nagrań z kamer (72h — potem nadpisane!)
□ Screenshoty wiadomości / maili z datą i nadawcą
□ Lista świadków z danymi kontaktowymi
□ Dziennik zdarzeń (data, opis, reakcja)
```

## PREDYKCJA WYNIKU — SZABLON
```
Szanse na uniewinnienie / WU: [0–100%]
IN PLUS: słabe dowody, brak świadków, kontratyp, niekaralność, mediacja
IN MINUS: nagranie, przyznanie, wielu świadków, recydywa
BENCHMARKING: → wywołaj orzeczenia-sadowe-v2 z frazą:
  "obrona konieczna granice SN"
  (⛔ SPRAWDZONE 2026-08-18: sygnatura SN V KK 412/21 NIE ISTNIEJE w tym
  kontekście — pod tym oznaczeniem nic nie figuruje w wynikach wyszukiwania;
  najbliższe pod względem numeru sprawy niepowiązane: V KK 412/12 [dowody
  z podsłuchu], V KK 412/24 [art. 286 KK oszustwo], III KK 412/21 [zabójstwo
  na zlecenie, inna izba]. NIE POWOŁYWAĆ tej sygnatury. Do znalezienia
  właściwego orzeczenia o obronie koniecznej uruchomić `orzeczenia-sadowe-v2`
  od zera, bez zakładania że chodzi o literówkę powyższej.)
REKOMENDACJA: □ Warunkowe umorzenie  □ Mediacja  □ Obrona na rozprawie  □ Ugoda
```

## ŁĄCZ Z
| Sytuacja | Skill |
|---|---|
| Zawiadomienie o przestępstwie | `pisma-procesowe-v3` |
| Analiza akt karnych / szanse | `analiza-sadowa-v6` |
| Ocena dowodów / nagrań | `analizator-dowodow-v3` |
| Orzecznictwo SN karne | `orzeczenia-sadowe-v2` |
| Przesłuchanie na rozprawie | `prawo-polskie-v2/krajowe/shared/PRZESLUCHANIE-SWIADKOW-KPC.md` + skill `przesluchanie-swiadkow-v2-min90` |
| Stalking / nękanie jako przestępstwo | `dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art190a-stalking.md` |

*KK (Dz.U. 2026 poz. 1342 t.j.) + KPK (Dz.U. 2026 poz. 490) + KKW (Dz.U. 2026 poz. 1307 t.j.)*
*Weryfikacja art. 178a i 190 KK: ELI (RZĄD 1) — zmiany nowelizacja 07.07.2022 (w życie 01.10.2023) i 14.03.2024*
*Audyt: 21.05.2026 — błędy zagrożeń art. 178a §1 (2→3 lata) i art. 190 §1 (2→3 lata) NAPRAWIONE*
*Weryfikacja: orzeczenia.ms.gov.pl, sn.pl*
