# Przestępstwa przeciwko wymiarowi sprawiedliwości — fałszywe zeznania, fałszywe oskarżenie, poplecznictwo/ukrywanie przestępcy (art. 233-244b KK) v1.0.0 (dodany 2026-07-16)

**Akt:** KK — t.j. Dz.U. 2026 poz. 1342 (zm. 2026/1466 [OD 2026-11-21: 2026/1466] — art. 42, 84).
**Akt:** KPK — t.j. Dz.U. 2026 poz. 490 (zm. po t.j., w mocy: 2026/421 od 2026-04-14 i 2026/760 od 2026-06-12 — art. 21h, 74, 213, 332, 336; 2026/638 od 2026-05-28 — art. 25; 2026/882 od 2026-07-16 — art. 607k–607zb; 2026/901 od 2026-07-21 — art. 87).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: zagrożenia karą i terminy porównane z t.j.).

> ⛔ Do 2026-07-16 brak dedykowanego modułu (0 wystąpień "art. 233" w
> całym dr-03). Ten moduł naprawia lukę, ze szczególnym uwzględnieniem
> POPLECZNICTWA (art. 239) — potocznie "ukrywanie przestępcy" — na
> wyraźne żądanie użytkownika.
> ⚠️ Zweryfikowane 2026-07-16 — do potwierdzenia na isap.sejm.gov.pl
> przed użyciem w piśmie (PRAWO-HARDGATE).

---

## DRZEWO S.1 — FAŁSZYWE ZEZNANIA (art. 233 KK)

```
START: Kto składał oświadczenie i w jakiej roli procesowej?
│
├─ Świadek / biegły / tłumacz / oskarżyciel posiłkowy zeznający pod
│  rygorem odpowiedzialności karnej (uprzedzony o art. 233 przed
│  przesłuchaniem — WARUNEK FORMALNY, brak pouczenia = brak przestępstwa)
│  │
│  ├─ Zeznał NIEPRAWDĘ lub ZATAIŁ PRAWDĘ → art. 233 §1 KK
│  │  (6 m-cy – 8 lat, po nowelizacji 2022; sprawdź datę czynu)
│  │
│  └─ To samo, ale dotyczy okoliczności MOGĄCYCH MIEĆ WPŁYW na
│     rozstrzygnięcie w sprawie o odpowiedzialność karną, grożąc
│     sprawcy karą pozbawienia wolności ≥8 lat → art. 233 §1a
│     (zaostrzone zagrożenie)
│
├─ Oskarżony/podejrzany kłamiący we własnej sprawie → ⛔ CO DO ZASADY
│  BEZKARNE (prawo do obrony, nemo se ipsum accusare tenetur) —
│  WYJĄTEK: fałszywe pomówienie współoskarżonego może wypełniać inne
│  przepisy (art. 234, patrz DRZEWO S.2), ale samo kłamstwo w obronie
│  własnej nie jest art. 233
│
└─ Fałszywa opinia biegłego / fałszywy przekład tłumacza → art. 233 §4a KK
   (odrębny typ, surowsze zagrożenie niż zwykły świadek)
```

⚠️ **Czynny żal (art. 233 §5 KK)** — niekaralność, jeśli sprawca
sprostuje fałszywe zeznanie, zanim orzeczenie (nawet nieprawomocne)
zostało wydane w oparciu o nie, oraz dobrowolnie i zgodnie z prawdą
wyjaśni okoliczności sprawy.

---

## DRZEWO S.2 — FAŁSZYWE OSKARŻENIE (art. 234 KK)

```
START: Czy sprawca przed organem powołanym do ścigania/orzekania
FAŁSZYWIE OSKARŻYŁ inną osobę o popełnienie przestępstwa, wykroczenia
lub przewinienia dyscyplinarnego?
│
├─ TAK, wiedząc że osoba ta jest niewinna → art. 234 KK
│  (do 2 lat pozbawienia wolności)
│
└─ Odmiana: SFAŁSZOWANIE/PODRZUCENIE DOWODU w celu skierowania
   przeciwko innej osobie ścigania → art. 235 KK (odrębny przepis,
   nie myl — 234 dotyczy samego OSKARŻENIA, 235 TWORZENIA FAŁSZYWYCH
   DOWODÓW)
```

---

## DRZEWO S.3 — POPLECZNICTWO / UKRYWANIE PRZESTĘPCY (art. 239 KK)

**To jest przepis odpowiadający potocznemu pojęciu "ukrywanie
przestępcy" — najważniejsza część tego modułu.**

```
START: Czy sprawca UTRUDNIAŁ lub UDAREMNIAŁ postępowanie karne, pomagając
sprawcy przestępstwa uniknąć odpowiedzialności?
│
├─ Formy działania (katalog przykładowy, nie zamknięty — art. 239 §1):
│  ├─ UKRYWANIE sprawcy (fizyczne, np. użyczenie lokalu)
│  ├─ ZACIERANIE ŚLADÓW przestępstwa
│  ├─ POMOC w uniknięciu wykrycia / ujęcia / osądzenia / wykonania kary
│  │   lub środka zabezpieczającego
│  └─ Udzielenie innej pomocy do uniknięcia odpowiedzialności
│
├─ Zagrożenie podstawowe (art. 239 §1) → 3 m-ce – 5 lat
│
└─ ⛔ NIEKARALNOŚĆ — art. 239 §2 KK: nie podlega karze sprawca, który
   UKRYWA osobę najbliższą (art. 115 §11 KK). Przy innej pomocy osobie
   najbliższej albo działaniu z obawy przed własną odpowiedzialnością —
   art. 239 §3: sąd MOŻE nadzwyczajnie złagodzić karę lub odstąpić od jej
   wymierzenia. Ustal relację sprawcy z ukrywanym i rodzaj pomocy.
```

⚠️ **ODNOTOWANA ROZBIEŻNOŚĆ NUMERACJI PARAGRAFÓW (dodane 2026-07-21):**
źródła zewnętrzne (arslege.pl) wskazują NA ODWRÓCONĄ kolejność względem
powyższego drzewa — §2 jako BEZWZGLĘDNY brak podlegania karze za
ukrywanie osoby najbliższej, §3 jako FAKULTATYWNE (sąd MOŻE, nie MUSI)
nadzwyczajne złagodzenie/odstąpienie od kary dla osoby najbliższej LUB
działającego z OBAWY przed odpowiedzialnością grożącą jemu/najbliższym
— TA WERSJA różni się od numeracji w drzewie wyżej. NIE ROZSTRZYGNIĘTO
tej rozbieżności arbitralnie — ZWERYFIKUJ DOKŁADNE, AKTUALNE brzmienie
art. 239 §2-3 KK na ISAP PRZED cytowaniem konkretnego numeru paragrafu
w piśmie procesowym — możliwe, że numeracja była PRZEDMIOTEM
nowelizacji między momentem opracowania drzewa (2026-07-16) a
weryfikacją źródeł zewnętrznych (2026-07-21).

## ⭐⭐⭐ WYMÓG UMYŚLNOŚCI — CO GDY UKRYWAJĄCY NIE WIE, KOGO UKRYWA (dodane 2026-07-21)

> Bezpośrednia odpowiedź na najczęstsze pytanie praktyczne: "czy
> odpowiadam, jeśli NIE WIEDZIAŁEM, że osoba, którą przenocowałem/
> którą podwiozłem, jest poszukiwana?"

```
⭐⭐ POPLECZNICTWO JEST PRZESTĘPSTWEM WYŁĄCZNIE UMYŚLNYM — art. 239 KK
NIE PRZEWIDUJE formy nieumyślnej. BRAK ŚWIADOMOŚCI, że pomaga się
osobie ŚCIGANEJ/podejrzanej o przestępstwo, CAŁKOWICIE WYKLUCZA
ODPOWIEDZIALNOŚĆ KARNĄ — nie jest to kontratyp ani okoliczność
łagodząca, lecz BRAK ZNAMION przestępstwa W OGÓLE (brak winy umyślnej
= czyn nie wypełnia znamion czynu zabronionego z art. 239)

□ FORMA umyślności: WYSTARCZY zamiar EWENTUALNY (sprawca PRZEWIDUJE
  MOŻLIWOŚĆ, że dana osoba dopuściła się czynu zagrożonego
  odpowiedzialnością karną, i GODZI SIĘ na udzielenie jej pomocy w
  uniknięciu tej odpowiedzialności) — NIE jest wymagany zamiar
  BEZPOŚREDNI ani PEWNOŚĆ (orzecznictwo SN: wyrok z 5.02.1973 r., I KR
  340/72; wyrok z 4.12.2007 r., IV KK 276/07)
□ ⭐ Świadomość NIE MUSI mieć charakteru DOKŁADNEJ wiedzy o RODZAJU i
  OKOLICZNOŚCIACH popełnionego przestępstwa — WYSTARCZY samo
  PRZEWIDYWANIE, że KONKRETNA osoba dopuściła się JAKIEGOŚ czynu
  zagrożonego odpowiedzialnością karną

⭐⭐ NIEOCZYWISTY, PRAKTYCZNY PRZYKŁAD z orzecznictwa: osoba, która
UKRYWAŁA kogoś ŚCIGANEGO listem gończym, będąc PRZEKONANA, że pomaga
RZECZYWISTEMU sprawcy przestępstwa — JEŚLI osoba ukrywana ZOSTAŁA
NASTĘPNIE UNIEWINNIONA od zarzutu, w związku z którym była poszukiwana
— UKRYWAJĄCY NIE ODPOWIADA z art. 239 §1 KK. Uzasadnienie: bez
OBIEKTYWNEGO ustalenia, że osoba, KTÓREJ pomagano, BYŁA rzeczywiście
sprawcą przestępstwa, NIE MOŻNA skazać pomagającego — SAMO
przewidywanie i godzenie się (subiektywna strona) NIE WYSTARCZA bez
SPEŁNIENIA warunku OBIEKTYWNEGO (osoba ukrywana FAKTYCZNIE była
sprawcą) — TO KLUCZOWE, dwustronne (podmiotowo-przedmiotowe)
zastrzeżenie, rzadko dostrzegane w praktyce

⭐ AUTOPOPLECZNICTWO (samopoplecznictwo): osoba, KTÓRA sama UKRYWA
SIEBIE przed organami ścigania, NIE PONOSI odpowiedzialności z art.
239 — przepis dotyczy WYŁĄCZNIE pomocy UDZIELANEJ INNEJ osobie

⭐⭐ ROZGRANICZENIE od CZYSTEGO MILCZENIA (BRAK obowiązku denuncjacji w
większości przypadków): SAMO niepowiadomienie organów ścigania o tym,
że wie się o czyimś przestępstwie (bierne "nieinformowanie"), CO DO
ZASADY NIE JEST poplecznictwem — art. 239 WYMAGA DZIAŁANIA AKTYWNEGO
(ukrywanie, zacieranie śladów, pomoc w ucieczce, itd.) — WYJĄTEK od
tej zasady opisuje ODRĘBNY przepis, art. 240 KK (obowiązek zawiadomienia
o NIEKTÓRYCH, najcięższych przestępstwach) — patrz NOWA sekcja niżej w
tym module, NIE MYLIĆ obu instytucji: poplecznictwo (działanie aktywne,
świadomość co do KONKRETNEJ osoby) vs niezawiadomienie (bierne
zaniechanie, wąski katalog zamknięty najcięższych zbrodni)

Checklist praktyczny:
□ Czy klient WIEDZIAŁ (choćby w formie przewidywania i godzenia się),
  że pomaga OSOBIE ŚCIGANEJ/podejrzanej — jeśli NIE, brak przestępstwa
  W OGÓLE, nie tylko okoliczność łagodząca
□ Czy istnieją DOWODY na stan wiedzy klienta w MOMENCIE udzielania
  pomocy (nie z perspektywy PÓŹNIEJSZEJ) — kluczowe dla obrony
□ Czy osoba UKRYWANA została OSTATECZNIE UNIEWINNIONA od zarzutu, w
  związku z którym była poszukiwana — rozważ argument BRAKU
  OBIEKTYWNEGO warunku (nie była "sprawcą przestępstwa")
□ Czy klient jedynie MILCZAŁ (nie informował), BEZ aktywnego działania
  — sprawdź, czy w OGÓLE zachodzi przestępstwo (art. 239 wymaga
  aktywności), oraz CZY nie zachodzi ODRĘBNY obowiązek z art. 240 KK
  (wąski katalog najcięższych zbrodni)
```

⚠️ **Poplecznictwo a współsprawstwo/pomocnictwo do przestępstwa
bazowego** — kluczowe rozróżnienie czasowe: pomocnictwo (art. 18 §3 KK,
patrz osobny moduł o formach popełnienia) dotyczy pomocy PRZED lub W
TRAKCIE popełniania czynu bazowego; poplecznictwo (art. 239) dotyczy
działań PO popełnieniu czynu, mających ułatwić uniknięcie
odpowiedzialności. Jeśli osoba obiecała pomoc w ukryciu PRZED
popełnieniem czynu bazowego (a nie dopiero po fakcie) — to może
wypełniać znamiona pomocnictwa do czynu głównego, nie (lub nie tylko)
poplecznictwa — orzecznictwo SN wymaga oceny, czy obietnica pomocy
"po fakcie" wzmacniała zamiar sprawcy głównego już w momencie czynu.

⚠️ **Poplecznik nie odpowiada surowiej niż na to pozwala art. 239** —
niezależnie od wagi przestępstwa bazowego (np. ukrywanie sprawcy
zabójstwa nadal kwalifikuje się z art. 239, a nie z art. 148 w
jakiejkolwiek formie sprawstwa) — to odrębne, samodzielne przestępstwo,
NIE forma współudziału w czynie bazowym.

---

## DRZEWO S.4 — PRZESTĘPSTWA POKREWNE (skrót)

| Czyn | Przepis | Zagrożenie |
|---|---|---|
| Fałszywe oskarżenie | art. 234 KK | 3 mies.–5 lat |
| Tworzenie/podrzucanie fałszywych dowodów | art. 235 KK | 3 mies.–5 lat |
| Zatajenie dowodu niewinności | art. 236 §1 KK | grzywna, ogr. wolności albo do 2 lat |
| Niekaralność zatajenia z obawy przed odpowiedzialnością własną lub najbliższych | art. 236 §2 KK | nie podlega karze |
| Rozpowszechnianie wiadomości z rozprawy z wyłączeniem jawności / z postępowania w sprawach nieletnich | art. 241 §2/§3 KK | grzywna, ogr. wolności albo do 2 lat |
| Rozpowszechnianie bez zezwolenia wiadomości z postępowania przygotowawczego przed ujawnieniem w sądzie | art. 241 §1 KK | grzywna, ogr. wolności albo do 2 lat |
| Bezprawne uwolnienie się (przez osobę pozbawioną wolności) | art. 242 §1 KK | grzywna, ogr. wolności albo do 2 lat |
| Uwolnienie lub ułatwienie ucieczki osoby pozbawionej wolności | art. 243 KK | do 3 lat |
| Niestosowanie się do orzeczonych środków karnych (zakaz zawodu, prowadzenia pojazdów, zbliżania się itd.) | art. 244 KK | 3 mies.–5 lat |
| Niestosowanie się do obowiązków związanych z zakazem wstępu na imprezę masową | art. 244a KK | grzywna, ogr. wolności albo do 2 lat |
| Niestosowanie się do obowiązków środka zabezpieczającego (w tym udaremnienie elektronicznej kontroli miejsca pobytu) | art. 244b KK | grzywna, ogr. wolności albo do 2 lat |
| Niedopełnienie obowiązku zawiadomienia o przestępstwie (funkcjonariusz) | art. 231 §1 KK (nadużycie funkcji, szerszy zakres) | do 3 lat |

> ⚠️ Art. 242-244b dodane 2026-07-26 (audyt pełnego systemu T8 — tytuł
> modułu deklarował "art. 233-244b", te przepisy wcześniej nie były
> wspomniane w treści wcale). Zweryfikowano online 2026-07-26 (lexlege.pl,
> prawnik.cc, arslege.pl) — WERYFIKUJ aktualność na ELI (RZĄD 1).

⚠️ WSZYSTKIE zagrożenia do potwierdzenia na isap.sejm.gov.pl przed
użyciem w piśmie (PRAWO-HARDGATE).

---

## CROSS-REFERENCJE

- Odróżnienie poplecznictwa od pomocnictwa do przestępstwa bazowego →
  `mod-KK-art18-22-formy-popelnienia.md` (nowy moduł, formy zjawiskowe).
- Poplecznictwo a pranie pieniędzy (gdy "pomoc" polega na ukryciu
  korzyści majątkowej z przestępstwa) → `mod-KK-art291-pranie-pieniedzy.md`
  (zbieg realny możliwy — analizuj oba przepisy niezależnie).
- Tryb ścigania poszczególnych przepisów (wszystkie z urzędu, brak
  wyjątków wnioskowych w tym rozdziale) → `mod-KPK-tryby-scigania.md`.

---

## ⭐⭐ DRZEWO S.5 — KARALNE NIEZAWIADOMIENIE O CZYNIE ZABRONIONYM (art. 240 KK) — dodane 2026-07-21

> Odpowiedź na pytanie użytkownika o sytuacje, w KTÓRYCH zgłoszenie do
> prokuratury JEST prawnym obowiązkiem (nie tylko moralnym).

### Zasada ogólna — obowiązek WYJĄTKOWY, nie powszechny

```
⭐⭐⭐ W polskim prawie NIE ISTNIEJE ogólny, powszechny obowiązek
denuncjacji (donoszenia o przestępstwach) — brak zawiadomienia o
ZWYKŁYM przestępstwie (kradzież, oszustwo, pobicie) NIE RODZI
ODPOWIEDZIALNOŚCI KARNEJ. Obowiązek PRAWNY (pod rygorem
odpowiedzialności karnej) dotyczy WYŁĄCZNIE ZAMKNIĘTEGO katalogu
NAJCIĘŻSZYCH zbrodni wymienionych w art. 240 §1 KK.
```

### Zamknięty katalog przestępstw objętych obowiązkiem (art. 240 §1)

```
Obowiązek zawiadomienia dotyczy WYŁĄCZNIE:
  □ art. 118 — LUDOBÓJSTWO
  □ art. 118a — udział w MASOWYM zamachu (zbrodnie przeciw ludzkości)
  □ art. 120-124 — zbrodnie WOJENNE (m.in. wytwarzanie/gromadzenie
    środków masowej zagłady, niedopuszczalne sposoby walki, zamach na
    jeńców/ludność cywilną)
  □ art. 127 — ZAMACH STANU
  □ art. 128 — zamach na ORGAN KONSTYTUCYJNY RP
  □ art. 130 — SZPIEGOSTWO
  □ art. 134 — zamach na ŻYCIE PREZYDENTA RP
  □ art. 140 — zamach na JEDNOSTKĘ SIŁ ZBROJNYCH RP/obiekt obronny
  □ art. 148 — ZABÓJSTWO
  □ art. 148a — przyjęcie ZLECENIA zabójstwa
  □ art. 156 — spowodowanie CIĘŻKIEGO uszczerbku na zdrowiu
  □ art. 163 — sprowadzenie ZDARZENIA NIEBEZPIECZNEGO (pożar, wybuch,
    zawalenie budowli zagrażające wielu osobom)
  □ art. 166 — przejęcie KONTROLI nad statkiem wodnym/powietrznym/
    publicznym środkiem transportu lądowego
  □ art. 189 — POZBAWIENIE człowieka WOLNOŚCI
  □ art. 197 §3-5 — ZGWAŁCENIE w typach KWALIFIKOWANYCH
  □ art. 198 — seksualne wykorzystanie BEZRADNOŚCI/niepoczytalności
  □ art. 200 — obcowanie płciowe z MAŁOLETNIM
  □ art. 252 — WZIĘCIE/przetrzymywanie ZAKŁADNIKA
  □ przestępstwo o charakterze TERRORYSTYCZNYM

⭐ Katalog JEST ZAMKNIĘTY i wg RPO WYKAZUJE pewne NIEKONSEKWENCJE
(np. obejmuje zabójstwo, ale POMIJA dzieciobójstwo, nieumyślne
spowodowanie śmierci) — ⚠️ ZWERYFIKUJ na ISAP aktualny, PEŁNY katalog
przed zastosowaniem — RPO postulował ZMIANY (w tym łagodniejsze
sankcje), sprawdź STATUS tych postulatów
```

### Wyłączenia od obowiązku (przesłanki negatywne)

```
□ Obowiązek NIE POWSTAJE, gdy sprawca ZANIECHAŁ zawiadomienia, MAJĄC
  DOSTATECZNĄ podstawę do PRZYPUSZCZENIA, że organ ŚCIGANIA JUŻ WIE o
  czynie (np. przestępstwo popełnione W MIEJSCU PUBLICZNYM lub w
  OBECNOŚCI funkcjonariuszy publicznych)
□ NIE PODLEGA obowiązkowi ten, kto ZAPOBIEGŁ popełnieniu/przygotowaniu/
  usiłowaniu czynu (np. udaremnił planowany zamach)
□ ⭐ NIE PODLEGA KARZE, kto ZANIECHAŁ zawiadomienia Z OBAWY przed
  odpowiedzialnością karną GROŻĄCĄ jemu SAMEMU lub jego NAJBLIŻSZYM
  (analogiczna logika do kontratypu z art. 239 dla poplecznictwa —
  patrz DRZEWO S.3 wyżej)
```

### ⭐⭐ Kolizja z tajemnicami zawodowymi

```
⭐ Obowiązek zawiadomienia z art. 240 UCHYLA (ma PIERWSZEŃSTWO przed):
  tajemnicę LEKARSKĄ, DZIENNIKARSKĄ, PSYCHOLOGICZNĄ, ADWOKACKĄ
  (ZWYKŁĄ, nie obrończą — patrz niżej), NOTARIALNĄ i INNE tajemnice
  zawodowe
□ ⭐⭐ WYJĄTKI (BEZWZGLĘDNE, obowiązek NIE UCHYLA tych tajemnic):
  1) DUCHOWNY — informacja powzięta PODCZAS SPOWIEDZI
  2) OBROŃCA — w RAMACH tajemnicy OBROŃCZEJ (informacje od WŁASNEGO
     klienta w związku z OBRONĄ w sprawie karnej)
⚠️ TO OZNACZA: PSYCHOLOG, LEKARZ, DZIENNIKARZ, ADWOKAT działający w
INNEJ roli niż obrońca w konkretnej sprawie — MAJĄ obowiązek
zawiadomienia mimo tajemnicy zawodowej, jeśli dowiedzą się o
przestępstwie z KATALOGU art. 240 §1 — RÓŻNI SIĘ TO fundamentalnie od
sytuacji obrońcy wobec WŁASNEGO klienta
```

### Sankcja i forma

```
□ KARA: pozbawienie wolności DO 3 LAT
□ ⭐ RPO wskazywał (postulat, ⚠️ sprawdź czy WPROWADZONY) na
  NIEPROPORCJONALNOŚĆ sankcji — WYŁĄCZNIE pozbawienie wolności, BRAK
  możliwości orzeczenia grzywny/ograniczenia wolności jako
  ALTERNATYWY — postulowano UZUPEŁNIENIE katalogu kar
□ ZAWIADOMIENIE kieruje się do ORGANU POWOŁANEGO do ŚCIGANIA
  przestępstw (Policja, prokuratura) — BRAK szczególnych wymogów
  formalnych, liczy się TREŚĆ i NIEZWŁOCZNOŚĆ
```

### Checklist praktyczny

```
□ Czy przestępstwo, o KTÓRYM klient wiedział, MIEŚCI SIĘ w ZAMKNIĘTYM
  katalogu art. 240 §1 — jeśli NIE (np. zwykła kradzież), BRAK
  obowiązku prawnego (może istnieć WYŁĄCZNIE moralny)
□ Czy klient MIAŁ podstawy przypuszczać, że organy JUŻ WIEDZĄ (np.
  zdarzenie publiczne) — jeśli TAK, obowiązek NIE POWSTAJE
□ Czy klient DZIAŁAŁ z OBAWY przed odpowiedzialnością WŁASNĄ/
  najbliższych — możliwe wyłączenie karalności
□ Czy klient jest OSOBĄ ZWIĄZANĄ tajemnicą zawodową — sprawdź, CZY
  jest to duchowny/obrońca (tajemnica NIE uchylona) czy inny zawód
  (tajemnica UCHYLONA obowiązkiem z art. 240)
```

---

## ⭐⭐ LIST GOŃCZY KRAJOWY (art. 278-280 KPK) — ODRÓŻNIENIE OD ENA — dodane 2026-07-21

> Uzupełnienie `mod-KPK-wspolpraca-miedzynarodowa-karna.md`, który
> opracowuje TYLKO Europejski Nakaz Aresztowania — list gończy
> KRAJOWY (mechanizm analogiczny, ale odrębny, DZIAŁAJĄCY W GRANICACH
> Polski) dotąd nie był opracowany.

### Przesłanki wydania (art. 278-279 KPK)

```
□ ART. 278 KPK: jeżeli MIEJSCE POBYTU oskarżonego LUB osoby
  podejrzanej NIE JEST znane — ZARZĄDZA SIĘ jego poszukiwanie
□ ART. 279 §1: JEŻELI oskarżony, WOBEC którego wydano postanowienie o
  TYMCZASOWYM ARESZTOWANIU, UKRYWA SIĘ — sąd LUB prokurator MOŻE
  wydać postanowienie o POSZUKIWANIU go LISTEM GOŃCZYM
□ ART. 279 §2: JEŻELI postanowienie o tymczasowym aresztowaniu NIE
  BYŁO wcześniej wydane — MOŻNA je wydać (RAZEM z listem gończym)
  NIEZALEŻNIE od tego, czy NASTĄPIŁO wcześniej przesłuchanie
  podejrzanego
□ List gończy MOŻE być wydany na RÓŻNYCH etapach: postępowania
  PRZYGOTOWAWCZEGO, SĄDOWEGO, a NAWET WYKONAWCZEGO (np. poszukiwanie
  osoby PRAWOMOCNIE skazanej, uchylającej się od wykonania kary)
□ FORMA: WYMAGA postanowienia (nie samego zarządzenia) — może je
  wydać SĄD LUB PROKURATOR
```

### Treść listu gończego (art. 280 KPK)

```
List gończy PODAJE:
  1) SĄD/PROKURATORA, który wydał postanowienie
  2) DANE o osobie ułatwiające POSZUKIWANIE (personalia, RYSOPIS,
     znaki SZCZEGÓLNE, miejsce zamieszkania/pracy, w miarę możliwości
     FOTOGRAFIĘ)
  3) informację o TREŚCI zarzutu oraz o POSTANOWIENIU o tymczasowym
     aresztowaniu/ZAPADŁYM wyroku
  4) WEZWANIE każdego, KTO zna miejsce pobytu poszukiwanego, do
     ZAWIADOMIENIA najbliższej jednostki Policji/prokuratora/sądu
  5) OSTRZEŻENIE o odpowiedzialności KARNEJ za UKRYWANIE (⭐
     BEZPOŚREDNIE odesłanie do art. 239 — patrz DRZEWA S.3 i sekcja o
     umyślności WYŻEJ w tym module — TO WŁAŚNIE list gończy jest
     NAJCZĘSTSZYM praktycznym KONTEKSTEM, w KTÓRYM aktualizuje się
     pytanie o poplecznictwo)
```

### Skutki ujęcia osoby ściganej listem gończym (art. 279 §3-4)

```
□ Po UJĘCIU i ZATRZYMANIU — NALEŻY NIEZWŁOCZNIE DOPROWADZIĆ osobę do
  SĄDU, który WYDAŁ postanowienie o tymczasowym aresztowaniu, W CELU
  rozstrzygnięcia o UTRZYMANIU, ZMIANIE lub UCHYLENIU tego środka —
  CHYBA że prokurator PO przesłuchaniu ZATRZYMANEGO JUŻ zmienił środek
  zapobiegawczy/uchylił areszt
□ JEŚLI osoba była POSZUKIWANA WIĘCEJ niż JEDNYM listem gończym
  (RÓŻNE postępowania) — WYSTARCZY doprowadzenie do JEDNEGO z sądów,
  które WYDAŁY postanowienia o tymczasowym aresztowaniu
```

### ⭐ RELACJA do Europejskiego Nakazu Aresztowania (ENA)

```
⭐ List gończy TO ODPOWIEDNIK ENA "wewnątrz kraju" — POTOCZNIE
PORÓWNYWANY do ENA, ale to ODRĘBNE instytucje o RÓŻNYM ZASIĘGU
TERYTORIALNYM:
  □ List gończy — POSZUKIWANIE w GRANICACH Polski
  □ ENA — poszukiwanie na TERYTORIUM innych PAŃSTW UE (patrz
    `mod-KPK-wspolpraca-miedzynarodowa-karna.md` dla PEŁNEJ treści,
    NIE duplikowanej tutaj)
□ ⭐ ROZSZERZENIE poszukiwań: GDY poszukiwania KRAJOWE (list gończy)
  okażą się NIESKUTECZNE, A ISTNIEJĄ podstawy PRZYPUSZCZAĆ, że osoba
  poszukiwana ZNAJDUJE SIĘ POZA granicami Polski — MOŻLIWE jest
  ROZSZERZENIE poszukiwań POPRZEZ wydanie ENA — MECHANIZMY te MOGĄ
  funkcjonować RÓWNOLEGLE/SEKWENCYJNIE, list gończy NIE WYKLUCZA
  późniejszego ENA
```

### Checklist praktyczny

```
□ Czy KLIENT ma zostać ZATRZYMANY na podstawie listu gończego —
  sprawdź NATYCHMIASTOWE prawo do DOPROWADZENIA przed sąd, który
  WYDAŁ postanowienie o areszcie
□ Czy WARTO złożyć WNIOSEK o UCHYLENIE/zmianę tymczasowego aresztowania
  RÓWNOLEGLE z reakcją na list gończy
□ Czy KTOŚ udzielił klientowi SCHRONIENIA, wiedząc o liście gończym —
  sprawdź TEST umyślności z sekcji WYŻEJ (art. 239, wymóg wiedzy/
  przewidywania i godzenia się)
□ Czy zachodzi RYZYKO rozszerzenia poszukiwań na ENA — jeśli klient
  planuje WYJAZD za granicę
```

### Literatura i źródła (zweryfikowane online 2026-07-21)

- lexlege.pl (2×), e-prawnik.pl (2×), sip.lex.pl — pełna treść art.
  278-280 KPK (Dz.U. 2026 poz. 490 t.j.), przesłanki, treść listu gończego,
  skutki ujęcia.
- adwokatkkr.pl, adwokat-skoczylas.pl, obrona24h.pl, kancelarialexacta.pl
  — praktyczne aspekty (etapy postępowania, forma postanowienia,
  relacja do ENA, obrona po zatrzymaniu).
- 116sos.pl, arslege.pl, bip.brpo.gov.pl, sprawy-karne.biz.pl,
  zaufanyprawnik.pl, prawo-karne-adwokat.com.pl, adwokatdulniak.pl —
  pełny katalog art. 240 §1 KK, wyłączenia, kolizja z tajemnicami
  zawodowymi, postulaty RPO, wymóg umyślności i orzecznictwo SN dot.
  poplecznictwa (I KR 340/72, IV KK 276/07, SA Łódź II AKa 168/15).

---

## ⭐ UCIECZKA Z MIEJSCA ZDARZENIA DROGOWEGO — ODESŁANIE (dodane 2026-07-21)

> Użytkownik zapytał RÓWNIEŻ o "ucieczkę z miejsca zdarzenia" —
> ⚠️ NIE jest to odrębne przestępstwo w TYM rozdziale (przeciwko
> wymiarowi sprawiedliwości), lecz OKOLICZNOŚĆ OBCIĄŻAJĄCA w kontekście
> przestępstw DROGOWYCH, już OPRACOWANA w `mod-PRD-nowe-przestepstwa-
> drogowe-BRD.md` (DR-03, sekcja 1) — ZBIEGŁ Z MIEJSCA zdarzenia jest
> JEDNĄ z PRZESŁANEK obligatoryjnego DOŻYWOTNIEGO zakazu prowadzenia
> pojazdów (art. 42 §3 KK, przy PRZESTĘPSTWACH z art. 173/177 §2-2a/355
> §2 popełnionych w stanie NIETRZEŹWOŚCI LUB gdy sprawca zbiegł) — NIE
> ✅ **ZWERYFIKOWANE (2026-08-18, F-26):** TAK — art. 44 Prawa o ruchu
> drogowym to ODRĘBNY, SAMODZIELNY obowiązek administracyjno-porządkowy
> (nie karny sensu stricto, ale wykroczeniowy — sankcja z art. 44 ust. 1
> pkt 4 jako podstawa wniosku o ukaranie w orzecznictwie, np. VI Ka
> 526/16). **Treść (Dz.U. aktualny t.j. 2024 poz. 1251):**
> - **Ust. 1 (KAŻDY wypadek):** zatrzymać pojazd bezpiecznie; przedsięwziąć
>   środki zapewnienia bezpieczeństwa ruchu w miejscu wypadku; usunąć
>   pojazd z miejsca (jeśli brak zabitego/rannego); podać dane personalne
>   i dane ubezpieczyciela NA ŻĄDANIE osoby uczestniczącej w wypadku.
> - **Ust. 2 (TYLKO gdy jest zabity lub ranny) — obowiązki DODATKOWE:**
>   udzielić niezbędnej pomocy i wezwać ZRM oraz Policję; NIE utrudniać
>   ustalenia przebiegu wypadku; powstrzymać się od alkoholu do czasu
>   badania przez Policję (pkt 2a); POZOSTAĆ na miejscu (z możliwością
>   krótkiego oddalenia się w celu wezwania pomocy, z obowiązkiem powrotu).
> - **Ust. 3:** te same obowiązki stosuje się ODPOWIEDNIO do INNYCH osób
>   uczestniczących w wypadku (nie tylko kierującego) — obowiązany jest
>   zarówno sprawca, jak i POKRZYWDZONY.
> ⭐ **Rozgraniczenie od kontekstu karnego (uzupełnienie, nie duplikacja):**
> ten obowiązek administracyjny (art. 44 PRD) jest ODRĘBNY od okoliczności
> obciążającej "zbiegnięcia z miejsca zdarzenia" jako przesłanki
> obligatoryjnego dożywotniego zakazu prowadzenia pojazdów z art. 42 §3 KK
> — mogą wystąpić RÓWNOLEGLE (naruszenie art. 44 PRD jako wykroczenie +
> ta sama ucieczka jako przesłanka zaostrzenia kary za przestępstwo
> drogowe), ale mają różną podstawę prawną i różny reżim odpowiedzialności.
> Źródła zbieżne: arslege.pl, lexlege.pl, dlajurysty.pl, standardyprawa.pl,
> orzeczenie VI Ka 526/16 (Portal Orzeczeń SO Warszawa-Praga).
