# Przemoc Domowa — Szczegółowy Framework

**Akt:** KK — t.j. Dz.U. 2026 poz. 1342 (zm. 2026/1466 [OD 2026-11-21: 2026/1466] — art. 42, 84).
**Akt:** KPK — t.j. Dz.U. 2026 poz. 490 (zm. po t.j., w mocy: 2026/421 od 2026-04-14 i 2026/760 od 2026-06-12 — art. 21h, 74, 213, 332, 336; 2026/638 od 2026-05-28 — art. 25; 2026/882 od 2026-07-16 — art. 607k–607zb; 2026/901 od 2026-07-21 — art. 87).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: zagrożenia karą i terminy porównane z t.j.).

## ABSOLUTNY PRIORYTET — BEZPIECZEŃSTWO PRZED ANALIZĄ PRAWNĄ
```
⚠️ ZAWSZE sprawdź przed przystąpieniem do analizy:
□ Czy ofiara jest teraz bezpieczna?
□ Czy przemoc trwa aktualnie lub niedawno miała miejsce?

NUMERY ALARMOWE — PODAJ NATYCHMIAST GDY SYTUACJA NAGŁA:
  112                — Policja / Pogotowie / Straż Pożarna
  116 123            — Niebieska Linia (całodobowa, bezpłatna)
  800 12 00 02       — Ogólnopolskie Pogotowie dla Ofiar Przemocy (bezpłatna)
  22 668 70 00       — Niebieska Linia (Instytut Psychologii Zdrowia)
```

## FAZA 0 — INTAKE
```
□ Rodzaj przemocy: fizyczna / psychiczna / seksualna / ekonomiczna / cyfrowa?
□ Sprawca i ofiara: mieszkają razem? (wspólny lokal → nakaz opuszczenia)
□ Czy są małoletnie dzieci w środowisku?
□ Czy Policja była już wzywana? Czy jest wszczęta Niebieska Karta?
□ Czy jest postępowanie karne w toku?
□ Czy ofiara chce opuścić lokal czy chce usunąć sprawcę?
□ Czy jest przemoc ekonomiczna? (blokada kont, zadłużanie, brak dostępu do środków)
□ Pilność sytuacji — ocena zagrożenia życia lub zdrowia
```

## MAPA INSTRUMENTÓW PRAWNYCH

### NATYCHMIASTOWE (bez sądu)
```
1. NAKAZ NATYCHMIASTOWY (art. 15aa KPK / art. 11a u.p.d.):
   → Wydaje Policja lub Żandarmeria Wojskowa — natychmiast na miejscu zdarzenia
   → Nakaz opuszczenia lokalu LUB zakaz zbliżania i kontaktu
   → Obowiązuje 14 dni od wydania
   → Przedłużenie: sąd na wniosek pokrzywdzonego — przed upływem 14 dni
   → Naruszenie: art. 244 KK (3 mies.–5 lat) obejmuje środki ORZECZONE PRZEZ SĄD (w tym nakaz
     okresowego opuszczenia lokalu, zakaz kontaktowania się i zbliżania); nakazu wydanego przez
     Policję art. 244 nie wymienia — skutek naruszenia ustal w ustawie o Policji i KPK ⚠️ [NIEWERYFIKOWANE]

2. NIEBIESKA KARTA (procedura NK):
   → Wszczynana przez: Policję, MOPS, szkołę, ochronę zdrowia, GKRPA
   → Nie wymaga zgody ofiary
   → Powołuje Zespół Interdyscyplinarny
   → Nie wszczyna postępowania karnego — to procedura pomocowa, nie ścigania
```

### POSTĘPOWANIE KARNE
```
PODSTAWOWE PRZEPISY:
  Art. 207 KK — znęcanie fizyczne lub psychiczne nad osobą bliską
    §1:    kara pozbawienia wolności od 3 miesięcy do 5 lat
    §1a:   wobec osoby nieporadnej ze względu na wiek/stan — **6 miesięcy do 8 lat**
    §2:    ze szczególnym okrucieństwem — 1–10 lat
    §3:    pokrzywdzony targnie się na życie — **2–15 lat** (nowelizacja 7.07.2022, Dz.U. 2022 poz. 2600, od 1.10.2023)
  TRYB ŚCIGANIA: z urzędu (Policja działa bez wniosku)

  Art. 190 KK — groźba karalna (np. groźby SMS, poczta głosowa)
    §1: do 3 lat | TRYB: na wniosek (§2) — ZŁÓŻ WNIOSEK PISEMNIE

  Art. 190a KK — stalking / cyberstalking (często łącznie z art. 207)
    §1/§2: **6 miesięcy – 8 lat** (Dz.U. 2026 poz. 1342)
    §3:   targnięcie pokrzywdzonego na życie — **2–15 lat** (art. 190a §3 KK)
    TRYB: na wniosek pokrzywdzonego

  Art. 197 KK — zgwałcenie / wymuszenie czynności seksualnej
    TRYB: z urzędu (zmiana od 01.10.2023 — wcześniej: na wniosek)
    §1: **2–15 lat** (typ podstawowy)
    §2: 6 miesięcy – 8 lat (inna czynność seksualna)
    §3: **3–20 lat** (typ kwalifikowany: wspólnie z inną osobą, broń, wstępny/zstępny, kobieta ciężarna, utrwalanie)
    §4: **≥5 lat lub dożywocie** (małoletni <15 lat / szczególne okrucieństwo / ciężki uszczerbek na zdrowiu)
    §5: **≥8 lat lub dożywocie** (następstwo: śmierć człowieka)

  Art. 209 KK — niealimentacja
    §1: do 1 roku / ograniczenie wolności | §1a (narażenie na niemożność zaspokojenia potrzeb): do 2 lat
    TRYB: na wniosek (§2) — złóż wniosek o ściganie

ZAWIADOMIENIE O PRZESTĘPSTWIE:
  → Pisemne lub ustne do protokołu na Policji / w prokuraturze
  → Brak formularza — wystarczy opis zdarzenia
  → Policja ma obowiązek przyjąć i nadać bieg (art. 304 §2 KPK)
  → Termin na wszczęcie: niezwłocznie — pokrzywdzony może złożyć zażalenie na bezczynność
```

### POSTĘPOWANIE CYWILNE / RODZINNE
```
NAKAZ OPUSZCZENIA LOKALU — SĄDOWY (art. 11a ustawy o przeciwdziałaniu przemocy):
  → Wniosek do sądu rejonowego (wydział cywilny)
  → Możliwy nakaz kontaktu z małoletnimi dziećmi / zakaz zbliżania
  → Niezależny od postępowania karnego

ROZDZIELNOŚĆ MAJĄTKOWA (przemoc ekonomiczna):
  → Wniosek do SR — z ważnych powodów (art. 52 KRO)
  → Skutek od daty pozwu (co do zasady) — możliwe wstecz

ALIMENTY ZABEZPIECZAJĄCE (art. 730 KPC):
  → Wniosek łącznie z pozwem o alimenty
  → SR w trybie natychmiastowym — bez rozprawy jeśli pilne

WŁADZA RODZICIELSKA / KONTAKTY:
  → Sąd może zakazać kontaktów sprawcy z dziećmi (art. 113⁶ KRO)
  → Wniosek o ograniczenie władzy rodzicielskiej — art. 109 KRO
  → Tryb zabezpieczający — możliwy przed złożeniem pozwu
```

## DOWODY W SPRAWACH O PRZEMOC — KATALOG
```
□ Dokumentacja medyczna (ER, lekarz pierwszego kontaktu, zaświadczenia)
□ Zdjęcia obrażeń z datą (eksif lub opis pisemny tego samego dnia)
□ SMS / wiadomości komunikatorów / e-maile (zrzuty ekranu + eksport backupu)
□ Nagrania audio/video (własne nagrania własnych rozmów — LEGALNE w Polsce)
□ Zeznania świadków: sąsiedzi, bliscy, wychowawcy dzieci, nauczyciele
□ Historia wezwań Policji (notatki policyjne — żądaj kopii)
□ Niebieska Karta — kopia dla pokrzywdzonej osoby na żądanie
□ Wiadomości z mediów społecznościowych (zrzuty ekranu z adresem URL)
□ Dokumenty bankowe — blokada kont, przelewy (przemoc ekonomiczna)
□ Historia lokalizacji z telefonu (ostrożnie: prywatność)
```

## IZOLACJA OFIARY I PLAN BEZPIECZEŃSTWA
```
ZAWSZE zapytaj / poinformuj o:
  □ Dokumenty (dowód, PESEL, akty urodzenia dzieci, paszport)
  □ Pieniądze / karta bankowa — zabezpiecz dostęp
  □ Leki i przedmioty niezbędne dla dzieci
  □ Telefon z naładowaną baterią i numerami alarmowymi
  □ Numery kontaktów do zaufanych osób
  → Schroniska dla ofiar przemocy — bezpłatne, adres zastrzeżony:
    Centrum Praw Kobiet (cpk.org.pl), Fundacja Dajemy Dzieciom Siłę
```

## PREDYKCJA WYNIKU — SZABLON
```
Szanse na skazanie / ochronę: [0–100%]
IN PLUS: obdukcja lekarska, historia wezwań Policji, Niebieska Karta,
         zeznania dzieci / świadków, nagrania, wiadomości elektroniczne
IN MINUS: brak dokumentacji, odwołanie zeznań przez ofiarę (możliwe — ale
          sąd ocenia całokształt materiału), długi czas bez zgłoszenia

BENCHMARKING:
  → Wywołaj orzeczenia-sadowe-v2 z frazą:
    "art. 207 KK znęcanie znamiona SN wyrok"
    "nakaz opuszczenia lokalu naruszenie art. 244 KK"
  ⚠️ NIEZWERYFIKOWANE — wyszukaj URL przed powołaniem: sn.pl / orzeczenia.ms.gov.pl

REKOMENDACJA: □ Nakaz natychmiastowy  □ Zawiadomienie karne  □ Nakaz sądowy  □ Alimenty
```

## ŁĄCZ Z
| Sytuacja | Skill |
|---|---|
| Zawiadomienie o przestępstwie (art. 207 KK) | `pisma-procesowe-v3` |
| Wniosek o nakaz opuszczenia lokalu (sąd) | `pisma-procesowe-v3` |
| Wniosek o alimenty / zabezpieczenie | `pisma-procesowe-v3` + `dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KRO-rodzinne.md` |
| Analiza karna / kwalifikacja | `dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-KPK-framework-karne.md` + `mod-KK-kwalifikator-karnomaterialny.md` |
| Stalking jako element przemocy | `dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art190a-stalking.md` |
| Przemoc ekonomiczna — rozdzielność | `dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/mod-KRO-rodzinne.md` |
| Orzecznictwo SN / SA | `orzeczenia-sadowe-v2` |

*Art. 207 KK: Dz.U. 2025 poz. 383 t.j. (obecny t.j. Dz.U. 2026 poz. 1342) | Art. 190a KK: nowelizacja od 01.10.2023*
*Ustawa o przeciwdziałaniu przemocy domowej (dawniej „w rodzinie"): Dz.U. 2024 poz. 1673 t.j. (✅ [VER] RZĄD 1 2026-09-16e; `2021/1249` — wygasły) — weryfikuj w isap.sejm.gov.pl*
*KRO: Dz.U. 2026 poz. 236 t.j. | KPC: Dz.U. 2026 poz. 468 t.j.*
*Weryfikacja: 22.05.2026 — zakaz cytowania przepisów z pamięci*
