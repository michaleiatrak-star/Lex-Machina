# Moduł [I] — Wykroczenia

**Akt:** KK — t.j. Dz.U. 2026 poz. 1342 (zm. 2026/1466 [OD 2026-11-21: 2026/1466] — art. 42, 84).
**Akt:** KPK — t.j. Dz.U. 2026 poz. 490 (zm. po t.j., w mocy: 2026/421 od 2026-04-14 i 2026/760 od 2026-06-12 — art. 21h, 74, 213, 332, 336; 2026/638 od 2026-05-28 — art. 25; 2026/882 od 2026-07-16 — art. 607k–607zb; 2026/901 od 2026-07-21 — art. 87).
**Akt:** KW — t.j. Dz.U. 2026 poz. 1372 (po t.j. bez zmian, ELI 2026-11-14).
**Akt:** KPW — t.j. Dz.U. 2026 poz. 1336 (zm. 2020/2320 [OD 2029-10-01: 2020/2320] — art. 38 (doręczenia elektroniczne)).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: zagrożenia karą i terminy porównane z t.j.).

**Zakres:** Mandat karny, wyrok nakazowy i sprzeciw, wykroczenia drogowe,
porządkowe, przeciwko mieniu, przedawnienie, apelacja, uchylenie mandatu,
granica wykroczenie/przestępstwo (800 zł / 0,5‰).

---

## ZASADA ABSOLUTNA — TERMIN 7 DNI NA SPRZECIW

Sprzeciw od wyroku nakazowego → **7 dni od doręczenia** (art. 94 § 1 KPW w zw. z art. 506 § 1 KPK). ZAWITY. ✅ [VER] RZĄD 1 2026-10-17 — KPW `Dz.U. 2026 poz. 1336` art. 94 § 1, KPK `Dz.U. 2026 poz. 490` art. 506 § 1.
**Po upływie wyrok nakazowy staje się prawomocny — brak możliwości cofnięcia.**

---

## GRANICA WYKROCZENIE / PRZESTĘPSTWO

```
Kradzież (art. 119 KW / 278 KK):
  ≤ 800 zł  → WYKROCZENIE (od 01.10.2023 — zmiana z 500 zł)
  > 800 zł  → PRZESTĘPSTWO
  ⚠️ Czyn ciągły (art. 12 §2 KK): kumulacja kilku kradzieży < 800 zł
     może łącznie przekroczyć próg → PRZESTĘPSTWO

Alkohol za kierownicą (art. 87 KW / 178a KK):
  0,2–0,5‰ (lub 0,1–0,25 mg/l) → WYKROCZENIE
  > 0,5‰   (lub > 0,25 mg/l)   → PRZESTĘPSTWO
```

---

## KLUCZOWE AKTY PRAWNE

- KW → ELI (RZĄD 1) (**Dz.U. 2026 poz. 1372** t.j., stan 23.09.2026) — **weryfikuj online**
- KPSW → ELI (RZĄD 1) (**Dz.U. 2026 poz. 1336** t.j.) — **weryfikuj online**
- KPK (stosowany posiłkowo) → ELI (RZĄD 1) (**Dz.U. 2026 poz. 490; sprawdź Dz.U. 2026 poz. 638 i przepisy przejściowe** t.j.)

---

## ORZECZNICTWO KLUCZOWE

```
Uchwała SN I KZP 7/25 z 19.03.2026:
  Prawomocny mandat za wykroczenie = powaga rzeczy osądzonej →
  wyklucza objęcie czynu czynem ciągłym z art. 12 §2 KK
  → sn.pl (weryfikuj URL przed powołaniem — uzasadnienie w przygotowaniu)

Postanowienie SN IV KK 145/24 z 10.09.2024:
  Prawomocne zakończenie postępowania wykroczeniowego (w tym mandatem)
  kreuje stan powagi rzeczy osądzonej i aktualizuje zasadę ne bis in idem
```

---

## OBOWIĄZEK KWALIFIKACJI — KWALIFIKATOR KARNOMATERIALNY

> ⚠️ **OBOWIĄZEK KWALIFIKACJI:** Gdy sprawa dotyczy art. 119 KW, 278, 279,
> 280, 281, 282, 283, 286, 287, 297 KK, art. 156, 157, 217, 160, 189, 190,
> 190a, 191, 267 KK, art. 87 KW, 178a, 177 KK, art. 62, 62a ustawy PN —
> **wczytaj drzewo decyzyjne przed kwalifikacją.**

```
view dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-kwalifikator-karnomaterialny.md
```

---

## SZCZEGÓŁOWY FRAMEWORK

```
view dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KW-KPW-framework-szczegolowy.md
```

Zawiera: schemat postępowania, mandat (przyjąć/odmówić), uchylenie prawomocnego
mandatu (art. 101 KPSW — pełne podstawy §1, §1a, §1b), kary mandatowe vs sądowe
(rozróżnienie!), taryfikator z recydywą, 5 linii obrony, powaga mandatu (SN
I KZP 7/25 i IV KK 145/24), przedawnienie i zatarcie, kalkulator terminów.

---

## ŁĄCZ Z

| Sytuacja | Skill / Moduł |
|---|---|
| Sprzeciw od wyroku nakazowego | `pisma-proste-v2` |
| Analiza sprawy wykroczeniowej | `analiza-sadowa-v6` |
| Granica z przestępstwem → | `dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-KPK-framework-karne.md` |
| Dowody (kamera, GPS, radar) | `analizator-dowodow-v3` |
| Kwalifikacja czynu (przepisy z indeksu) | `dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-kwalifikator-karnomaterialny.md` |
