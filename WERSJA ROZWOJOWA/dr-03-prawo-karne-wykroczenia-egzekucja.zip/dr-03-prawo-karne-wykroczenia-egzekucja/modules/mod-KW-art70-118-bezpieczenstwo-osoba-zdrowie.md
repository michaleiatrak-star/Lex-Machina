# mod-KW-art70-118-bezpieczenstwo-osoba-zdrowie

**Akt:** KK — t.j. Dz.U. 2026 poz. 1342 (zm. 2026/1466 [OD 2026-11-21: 2026/1466] — art. 42, 84).
**Akt:** KW — t.j. Dz.U. 2026 poz. 1372 (po t.j. bez zmian, ELI 2026-11-14).
**Akt:** KPW — t.j. Dz.U. 2026 poz. 1336 (zm. 2020/2320 [OD 2029-10-01: 2020/2320] — art. 38 (doręczenia elektroniczne)).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: zagrożenia karą i terminy porównane z t.j.).

**Wersja:** 1.1 | **Dodano:** 2026-07-17 | **Aktualizacja:** 2026-08-27 (art. 82)
**Rola w systemie:** kontynuacja uzupełniania pokrycia Kodeksu wykroczeń
— trzy rozdziały o wysokiej częstości praktycznej, dotąd CAŁKOWICIE
nieobecne w systemie: bezpieczeństwo osób i mienia (X), przeciwko osobie
(XII — zawiera art. 107, jeden z najczęściej stosowanych przepisów przy
sporach sąsiedzkich i nękaniu), przeciwko zdrowiu (XIII).

> ⛔ HARDGATE — zweryfikuj aktualny t.j. na ISAP przed użyciem.

---

## 1. ROZDZIAŁ X — BEZPIECZEŃSTWO OSÓB I MIENIA (art. 70-83)

### Art. 70 — niebezpieczne czynności przez osoby niezdolne

```
§1 — kto, będąc NIEZDOLNY do czynności, której nieumiejętne wykonanie
     może wywołać niebezpieczeństwo dla życia/zdrowia, taką czynność
     PRZEDSIĘBIERZE, albo POWIERZA ją osobie niezdolnej, albo WBREW
     OBOWIĄZKOWI NADZORU dopuszcza do jej wykonania przez osobę niezdolną
     → areszt albo grzywna
§2 — TA SAMA kara dla tego, kto WBREW OBOWIĄZKOWI zachowania trzeźwości
     wykonuje czynności zawodowe/służbowe po użyciu alkoholu/środka
     odurzającego
§3 — można orzec podanie orzeczenia do publicznej wiadomości
```
**Przedmiot ochrony (sporny w doktrynie, orzecznictwo SAOS):** część
autorów wskazuje bezpieczeństwo osób i mienia OGÓLNIE (nie tylko życie/
zdrowie) — istotne przy ocenie, czy czyn bez konkretnej ofiary nadal
wypełnia znamiona.

### Art. 71 — wadliwe urządzenia

Kto przez wadliwe wykonanie urządzeń, uczynienie ich niezdatnymi do
funkcjonowania, niewłaściwe użytkowanie lub SAMOWOLNE URUCHOMIENIE
wywołuje stan niebezpieczny dla życia/zdrowia → areszt albo grzywna.

### Art. 77-78 — obchodzenie się ze zwierzętami (częste sprawy sąsiedzkie)

```
Art. 77 §1 — kto nie zachowuje zwykłych/nakazanych środków ostrożności
             przy TRZYMANIU zwierzęcia → ograniczenie wolności, grzywna
             do 1000 zł albo nagana
§2 — TA SAMA kara, gdy zwierzę swoim zachowaniem stwarza niebezpieczeństwo
     dla życia/zdrowia człowieka (typ obostrzony okolicznościowo)

Art. 78 — kto przez DRAŻNIENIE lub PŁOSZENIE doprowadza zwierzę do tego,
          że staje się niebezpieczne → ograniczenie wolności, grzywna do
          1000 zł
```
**Powiązanie praktyczne:** te dwa artykuły to podstawa prawna w sprawach
o "groźnego psa" (właściciel trzymający psa na nieogrodzonej posesji lub
puszczający luzem) — grzywna może sięgać do 5000 zł przy okolicznościach
obostrzonych.

### Art. 79 — oświetlenie miejsc publicznych

Kto wbrew obowiązkowi zaniecha oświetlenia miejsc dostępnych dla
publiczności → grzywna do 250 zł albo nagana. Kto ZE ZŁOŚLIWOŚCI lub
SWAWOLI takie oświetlenie gasi → grzywna do 500 zł (typ umyślny,
surowszy niż samo zaniechanie).

### Art. 82 — bezpieczeństwo pożarowe

Art. 82 obejmuje zachowania mogące spowodować pożar, jego
rozprzestrzenianie, utrudnić działanie ratownicze albo ewakuację. Katalog
§ 1 obejmuje m.in. niedozwolone używanie otwartego ognia i innych źródeł
zapłonu, prace pożarowo niebezpieczne bez wymaganego zabezpieczenia,
używanie niesprawnych lub niekontrolowanych instalacji/urządzeń w warunkach
mogących sprzyjać pożarowi lub wybuchowi, naruszenia zasad dotyczących
materiałów niebezpiecznych pożarowo oraz inne ustawowo wskazane zachowania.

**Aktualizacja sankcji:** ustawa z 7.11.2025 r. — Dz.U. 2025 poz. 1814
zmieniła sankcje w art. 82 § 1, 2, 4 i 5 oraz § 3. W aktualnym reżimie
wskazane jednostki przewidują karę aresztu, ograniczenia wolności albo
grzywny. Ta sama nowelizacja zmieniła art. 24 § 1a KW i art. 96 § 1ad KPW,
co ma znaczenie dla maksymalnej grzywny mandatowej.

**RZĄD 1 / weryfikacja 2026-08-27:**
- ELI, t.j. KW: Dz.U. 2026 poz. 1372 (stan 23.09.2026; poprzednio 2025/734);
- ELI, nowelizacja: Dz.U. 2025 poz. 1814.

Przed kwalifikacją konkretnego zachowania odczytaj pełny właściwy paragraf
art. 82 oraz przepisy ochrony przeciwpożarowej, do których znamiona mogą
odsyłać.

### Art. 83 — materiały niebezpieczne

Kto NIEOSTROŻNIE obchodzi się z materiałami wybuchowymi, łatwo
zapalnymi lub substancjami promieniotwórczymi, albo wykracza przeciwko
przepisom o ich wyrobie/sprzedaży/przechowywaniu/używaniu/przewożeniu
→ sankcja wykroczeniowa + możliwy PRZEPADEK przedmiotów (§2). Powiązanie
z `mod-KK-art163-172-bezpieczenstwo-powszechne.md` — przy poważniejszym
skutku (zagrożenie życia wielu osób/mienia wielkich rozmiarów)
kwalifikacja przechodzi do art. 163 KK.

⚠️ Pozostałe artykuły rozdziału (72-76, 80-81) NIE zostały w pełni
zweryfikowane w tej sesji; **art. 82 zweryfikowano w ELI 2026-08-27** — zweryfikuj na ISAP jeśli sprawa dotyczy
zagadnień spoza omówionych wyżej (np. materiały wybuchowe w innych
kontekstach, ostrzeżenia przy pracach budowlanych).

---

## 2. ROZDZIAŁ XII — PRZECIWKO OSOBIE (art. 104-108)

### Art. 104 — skłanianie małoletniego do żebractwa

Kto skłania do żebrania małoletniego lub osobę bezradną albo pozostającą
w stosunku zależności/pod jego opieką → areszt, ograniczenie wolności
albo grzywna.

### Art. 105 — demoralizacja nieletniego przez rażące naruszenie władzy rodzicielskiej

Kto przez RAŻĄCE naruszenie obowiązków wynikających z władzy
rodzicielskiej dopuszcza do popełnienia przez nieletniego czynu
zabronionego (przestępstwo, przestępstwo skarbowe, wykroczenie,
wykroczenie skarbowe) wskazującego na DEMORALIZACJĘ nieletniego.

### Art. 106 — zagrożenie małoletniego do lat 7

Dopuszczenie do przebywania małoletniego DO LAT 7 w okolicznościach
niebezpiecznych dla zdrowia (np. pozostawienie bez opieki w miejscu
niebezpiecznym).

### ⭐ Art. 107 — ZŁOŚLIWE NIEPOKOJENIE (przepis CENTRALNY, jeden z najczęściej stosowanych w praktyce)

**Treść:** kto W CELU DOKUCZENIA innej osobie ZŁOŚLIWIE wprowadza ją
w błąd lub w inny sposób ZŁOŚLIWIE NIEPOKOI → ograniczenie wolności,
grzywna do 1500 zł albo nagana.

**Katalog zachowań OTWARTY** — orzecznictwo/doktryna wymieniają: spory
sąsiedzkie, robienie zdjęć z ukrycia, dokuczanie, śledzenie, grożenie,
obserwowanie, wprowadzanie w błąd (np. fałszywe zamówienia na czyjeś
dane, uciążliwe telefony).

**Element kluczowy — UMYŚLNOŚĆ W FORMIE ZAMIARU BEZPOŚREDNIEGO:**
potwierdzone orzecznictwem SN (wyrok z 22.06.1995, sygn. III KRN 44/95)
— działanie musi być KIERUNKOWE ("w celu dokuczenia"), ze "złośliwością"
jako elementem strony podmiotowej. **Linia obrony:** "ja niechcący"/brak
zamiaru dokuczenia — SN podkreśla, że taka obrona bywa mało wiarygodna,
ale brak wykazanej złośliwości = brak wykroczenia (to nie jest czyn
nieumyślny).

**Zastosowanie praktyczne:** to PODSTAWOWY przepis w sprawach o nękanie
NIEOSIĄGAJĄCE progu przestępstwa stalkingu z art. 190a KK (patrz
`mod-KK-art190a-stalking.md`) — art. 107 KW jako "niższy próg"
odpowiedzialności, gdy brak elementu "uporczywości" wymaganego przez
art. 190a KK, lub gdy zachowanie ma charakter jednorazowy/sporadyczny,
ale wciąż złośliwy.

### Art. 107a — udaremnianie transmisji danych (nowszy, cyberprzestrzeń)

**§ 1:** sprawca, włączając się bez uprawnienia w transmisję danych
prowadzoną przy użyciu systemu teleinformatycznego, umyślnie udaremnia
lub utrudnia użytkownikowi tego systemu przekazywanie lub odbiór
informacji. Sankcja: ograniczenie wolności albo grzywna nie niższa niż
1000 zł.

**§ 2:** jeżeli sprawca czynu z § 1 używa słów powszechnie uznanych za
obelżywe albo w inny sposób dopuszcza się nieobyczajnego wybryku — areszt,
ograniczenie wolności albo grzywna nie niższa niż 3000 zł.

⛔ Koniunkcja znamion: samo nieuprawnione włączenie się do transmisji nie
wystarcza; trzeba też udowodnić umyślne udaremnianie lub utrudnianie
przekazywania albo odbioru informacji. ✅ [VER: ELI, Dz.U. 2025 poz. 734,
art. 107a, odczyt 2026-08-25]

### Art. 108 — szczucie psem człowieka

Kto szczuje psem człowieka → ograniczenie wolności, grzywna albo nagana.
Przepis nie ustanawia szczególnej granicy grzywny, więc działa granica
ogólna z art. 24 § 1 KW: od 20 do 5000 zł. ✅ [VER: ELI, Dz.U. 2025
poz. 734, art. 24 § 1 i art. 108, odczyt 2026-08-25]

---

## 3. ROZDZIAŁ XIII — PRZECIWKO ZDROWIU (art. 109-118)

### Art. 109 — zanieczyszczanie wody

Chroni zdrowie publiczne poprzez penalizację zanieczyszczania wody
pitnej oraz wody w obiektach rekreacyjnych — obejmuje dostarczanie wody
niespełniającej norm sanitarnych i jej zanieczyszczanie.

### Art. 110-114 (przegląd skrócony, ⚠️ dokładna treść częściowo potwierdzona)

```
110 — zatrudnianie na stanowisku nieodpowiednim ze względu na stan zdrowia
111 — niedopełnienie obowiązku zapewnienia stanu sanitarnego w produkcji/
      obrocie środkami spożywczymi
113 — niezachowanie należytej czystości przy świadczeniu usług
114 — odmowa udzielenia wyjaśnień organowi służby zdrowia
```

### Art. 115 — obowiązkowe szczepienia (⭐ istotne praktycznie)

Niepoddanie się OBOWIĄZKOWEMU SZCZEPIENIU ochronnemu lub badaniu stanu
zdrowia. **§2 — niewykonanie obowiązku poddania MAŁOLETNIEGO
obowiązkowemu szczepieniu ochronnemu** — bogata linia orzecznicza (SN,
WSA, NSA — 6 pozycji w bazie standardyprawa.pl) — istotne w sprawach
rodziców odmawiających szczepień dzieci.

### Art. 116 — nakazy przy chorobie zakaźnej (⭐ istotne po pandemii)

Nieprzestrzeganie NAKAZU, ZAKAZU lub OBOWIĄZKU przez CHOREGO lub
NOSICIELA choroby zakaźnej albo OSOBĘ SPRAWUJĄCĄ NAD NIMI PIECZĘ —
bogata linia orzecznicza SN (4 pozycje). **Bezpośrednie powiązanie z
`dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-stany-nadzwyczajne-sytuacje-kryzysowe.md`** — ten przepis
jest MATERIALNOPRAWNĄ podstawą sankcji za łamanie nakazów kwarantanny/
izolacji nakładanych w reżimie "stanu epidemii" (ustawa z 2008 r.) —
bezpośrednio istotny przy analizie kontrowersji konstytucyjnej opisanej
w module o stanach kryzysowych (czy sam NAKAZ miał podstawę ustawową,
zanim w ogóle powstanie pytanie o odpowiedzialność z art. 116 KW za jego
naruszenie).

### Art. 118 — ubój zwierząt i badanie mięsa

```
§1 — kto: 1) dokonuje uboju zwierzęcia bez wymaganego zezwolenia lub
     niezgodnie z jego warunkami, 2) usuwa części zwierzęcia przed
     wymaganym badaniem poubojowym, 3) nie poddaje mięsa badaniu, gdy
     jest ono wymagane
§2 — wprowadza do obrotu mięso warunkowo zdatne/niezdatne do spożycia
     wbrew określonemu sposobowi jego wykorzystania
§3 — MOŻNA orzec PRZEPADEK mięsa, choćby nie stanowiło własności sprawcy
```

---

## 4. INTEGRACJA Z SYSTEMEM

- **`mod-KK-art190a-stalking.md`** — art. 107 KW jako "niższy próg"
  odpowiedzialności za nękanie, gdy brak uporczywości wymaganej przez
  art. 190a KK — ZAWSZE sprawdź oba przepisy łącznie w sprawach o nękanie.
- **`dr-01-ustroj-konstytucyjny-i-zrodla-prawa/modules/mod-stany-nadzwyczajne-sytuacje-kryzysowe.md`** — art. 116 KW
  jako podstawa sankcji za naruszenie nakazów w stanie epidemii —
  bezpośrednie powiązanie z kontrowersją konstytucyjną tam opisaną.
- **`mod-KK-art163-172-bezpieczenstwo-powszechne.md`** — art. 83 KW
  (materiały niebezpieczne) jako niższy próg względem art. 163/171 KK.
- **`mod-KW-KPW-framework-szczegolowy.md`** — procedura (mandat, sprzeciw)
  wspólna dla wszystkich wykroczeń z tego modułu.

---

## 5. LITERATURA I ŹRÓDŁA (zweryfikowane online 2026-07-17)

- Tekst jednolity KW — ISAP/lexlege.pl/e-prawnik.pl.
- SN, wyrok z 22.06.1995, sygn. III KRN 44/95 — kierunkowość i
  złośliwość jako znamię art. 107 KW.
- SAOS, orzeczenie VII W 423/21 — spór doktrynalny o przedmiot ochrony
  art. 70 KW.
- wach-pawliczak.pl, tygodnik-rolniczy.pl — praktyczne omówienia art.
  107-108 (spory sąsiedzkie, zwierzęta).
- statusprawnypsawpolsce.com — kompendium przepisów o zwierzętach (art.
  77-78, 108 KW).
- standardyprawa.pl — orzecznictwo do art. 106, 115, 116 KW.
