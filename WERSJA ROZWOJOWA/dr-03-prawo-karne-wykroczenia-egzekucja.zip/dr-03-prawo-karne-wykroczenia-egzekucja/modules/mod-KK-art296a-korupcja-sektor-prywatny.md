# Korupcja w sektorze prywatnym (art. 296a KK) v1.0.0 (dodany 2026-07-16)

**Akt:** KK — t.j. Dz.U. 2026 poz. 1342 (zm. 2026/1466 [OD 2026-11-21: 2026/1466] — art. 42, 84).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: zagrożenia karą i terminy porównane z t.j.).

> ⛔ Do 2026-07-16 — ZERO wystąpień w całym systemie skilli. Ten moduł
> tworzy pokrycie od podstaw.
> ⚠️ Zweryfikowane 2026-07-16 — do potwierdzenia na isap.sejm.gov.pl.

---

## DRZEWO M.1 — ŁAPOWNICTWO MENADŻERSKIE (art. 296a KK)

```
START: Czy osoba pełni funkcję kierowniczą w jednostce organizacyjnej
wykonującej działalność gospodarczą LUB ma, z racji zajmowanego
stanowiska/pełnionej funkcji, istotny wpływ na podejmowanie decyzji
związanych z działalnością takiej jednostki?
│
├─ NIE → to nie jest osoba objęta zakresem podmiotowym art. 296a —
│  rozważ art. 228 (jeśli funkcja publiczna) zamiast tego przepisu
│
└─ TAK → czy PRZYJĘŁA korzyść majątkową/osobistą (lub jej obietnicę)
   W ZAMIAN ZA NADUŻYCIE UPRAWNIEŃ LUB NIEDOPEŁNIENIE OBOWIĄZKÓW,
   MOGĄCE WYRZĄDZIĆ TEJ JEDNOSTCE SZKODĘ MAJĄTKOWĄ LUB STANOWIĄCE CZYN
   NIEUCZCIWEJ KONKURENCJI albo niedopuszczalną czynność preferencyjną
   wobec nabywcy/odbiorcy towaru, usługi lub świadczenia?
   │
   ├─ Strona BIERNA (przyjęcie korzyści) → art. 296a §1 KK
   │  (3 m-ce – 5 lat)
   │
   ├─ Strona CZYNNA (udzielenie/obiecanie korzyści takiej osobie) →
   │  art. 296a §2 KK (3 m-ce – 5 lat, symetrycznie do §1)
   │
   ├─ Wypadek mniejszej wagi (art. 296a §3) → grzywna, ograniczenie
   │  wolności lub POZBAWIENIA WOLNOŚCI DO LAT 2 (⚠️ POPRAWKA 2026-07-26,
   │  FAZA 3E: poprzednia wersja błędnie podawała "do roku" — potwierdzono
   │  wielokrotnie online: lexlege.pl, arslege.pl, prawo-pl.com,
   │  adwokatlawicki.pl, skalski-adwokat.pl, karh.pl — wszystkie zgodnie
   │  wskazują "do lat 2", zgodnie z ogólnym wzorcem wypadku mniejszej
   │  wagi w KK dla przestępstw z podstawowym zagrożeniem 3 m-ce-5 lat,
   │  patrz też art. 228§2, 229§2, 230§2 — ten sam wzorzec "do lat 2")
   │
   ├─ Szkoda MAJĄTKOWA ZNACZNEJ WARTOŚCI wyrządzona jednostce
   │  (art. 296a §4) → 6 m-cy – 8 lat (typ kwalifikowany)
   │
   └─ ⛔ CZYNNY ŻAL (art. 296a §5 KK) — analogicznie do art. 229 §6:
      NIE PODLEGA KARZE sprawca strony czynnej (ten, kto udzielił
      korzyści), jeżeli korzyść lub jej obietnicę przyjęto, a sprawca
      zawiadomił o tym fakcie organ powołany do ścigania i ujawnił
      wszystkie istotne okoliczności czynu, zanim organ ten się o nim
      dowiedział
```

⚠️ **ESKALACJA ZBRODNIOWA (art. 306b KK) — dodane 2026-07-26
(MOD-PROPAGACJA-NOWELIZACJI, ustalenie przeniesione z
mod-KK-art296-naduzycie-zaufania.md, ten sam przepis dotyka OBU
modułów):** jeśli czyn z art. 296a **§1 LUB §4** (WYŁĄCZNIE strona
BIERNA — przyjęcie korzyści — NIE §2, czynna strona przekupstwa, którą
ustawodawca celowo wyłączył z tej eskalacji) dotyczy mienia/szkody:
```
> 5 mln zł  → art. 306b §1 → 3-20 lat (ZBRODNIA)
> 10 mln zł → art. 306b §2 → 5-25 lat (ZBRODNIA)
```
Potwierdzone w 6+ źródłach (arslege.pl [t.j. Dz.U. 2025 poz. 383 (obecny t.j. Dz.U. 2026 poz. 1342)], kairp.pl,
adwokatdulniak.pl, kancelarierp.pl, chmielniak.com.pl,
russellbedford.pl) — wejście w życie 1.10.2023. Zob. też
`mod-KK-art296-naduzycie-zaufania.md` DRZEWO N.1 dla pełnego opisu
mechanizmu (ta sama eskalacja obejmuje też art. 296 §1/§2, art. 299
§1/2/5/6, art. 303 §1).

⚠️ **Kluczowa różnica od art. 228-230 (korupcja urzędnicza):** art. 296a
NIE wymaga, by sprawca pełnił funkcję PUBLICZNĄ — dotyczy WYŁĄCZNIE
sektora prywatnego (spółki, przedsiębiorstwa, fundacje prowadzące
działalność gospodarczą). Menadżer spółki Skarbu Państwa działający w
ramach zwykłej działalności gospodarczej spółki (nie jako funkcjonariusz
publiczny wykonujący władztwo publiczne) może podlegać TEMU przepisowi,
a nie art. 228 — rozstrzyga charakter pełnionej funkcji, nie sama
struktura właścicielska podmiotu.

⚠️ **Znamię "mogące wyrządzić szkodę" jest znamieniem SKUTKU
ABSTRAKCYJNEGO** — nie wymaga rzeczywistego wystąpienia szkody,
wystarczy że działanie ABSTRAKCYJNIE mogło ją wyrządzić lub stanowiło
czyn nieuczciwej konkurencji / niedopuszczalną preferencję — dopiero
typ kwalifikowany z §4 wymaga RZECZYWISTEJ szkody znacznej wartości.

---

## 2. TRYB ŚCIGANIA (art. 296a §6 KK)

```
⛔ ŚCIGANIE NA WNIOSEK pokrzywdzonego (nie z urzędu!) — WYJĄTEK: jeśli
pokrzywdzonym jest Skarb Państwa, jednostka samorządu terytorialnego
lub inna osoba prawna prawa publicznego → ściganie Z URZĘDU.
```

⚠️ To istotna różnica proceduralna od art. 228-230 (zawsze z urzędu) —
w typowej sprawie korupcji między dwiema prywatnymi spółkami,
BEZ WNIOSKU pokrzywdzonej spółki postępowania nie wszczyna się z
urzędu — częsty błąd praktyczny przy zawiadomieniach kierowanych
bezpośrednio do prokuratury bez zadbania o formalny wniosek.

---

## 3. TABELA SZYBKIEGO ODCZYTU

| Czyn | Przepis | Zagrożenie | Tryb ścigania |
|---|---|---|---|
| Łapownictwo menadżerskie bierne | art. 296a §1 | 3 m-ce – 5 lat | na wniosek (wyjątek: Skarb Państwa/JST — z urzędu) |
| Łapownictwo menadżerskie czynne | art. 296a §2 | 3 m-ce – 5 lat | j.w. |
| Wypadek mniejszej wagi | art. 296a §3 | grzywna/ogr. wolności/do 2 lat | j.w. |
| Szkoda znacznej wartości | art. 296a §4 | 6 m-cy – 8 lat | j.w. |

⚠️ WSZYSTKIE zagrożenia do potwierdzenia na isap.sejm.gov.pl przed
użyciem w piśmie (PRAWO-HARDGATE).

---

## CROSS-REFERENCJE

- Korupcja urzędnicza (funkcja publiczna, zawsze z urzędu) →
  `mod-KK-art228-231-korupcja-urzednicza.md` — kryterium rozgraniczające:
  charakter pełnionej funkcji (publiczna vs prywatna gospodarcza).
- Nadużycie zaufania / działanie na szkodę spółki bez elementu korupcji
  (art. 296 KK, bez litery "a") — odrębny, szerszy przepis, do rozważenia
  jako kandydat na kolejną sesję (obecnie poza zakresem dr-03).
- Perspektywa compliance (ABMS, ISO 37001 obejmuje też sektor prywatny)
  → `dr-15-compliance-iso-governance-audyt/modules/mod-ISO-37001-antykorupcja.md`.
- Odpowiedzialność podmiotów zbiorowych, gdy korzyść przyjął pracownik
  na rzecz/w interesie podmiotu zbiorowego →
  `mod-ustawa-odpowiedzialnosc-podmiotow-zbiorowych.md`.
