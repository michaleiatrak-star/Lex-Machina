# Kwalifikator karnomaterialny — część 4: narkotyki, przestępstwa drogowe

**Akt:** KK — t.j. Dz.U. 2026 poz. 1342 (zm. 2026/1466 [OD 2026-11-21: 2026/1466] — art. 42, 84).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: zagrożenia karą i terminy porównane z t.j.).

> Część modułu `mod-KK-kwalifikator-karnomaterialny.md` (podział 2026-08-20,
> naprawa F-78 — plik źródłowy przekroczył 2000 linii). Pełny indeks i
> zasady użycia: zobacz plik nadrzędny w katalogu `modules/`. To NIE jest
> samodzielny skill — ładowany WYŁĄCZNIE przez indeks nadrzędny na żądanie
> konkretnego bloku.

---

## BLOK D — PRZESTĘPSTWA NARKOTYKOWE

### DRZEWO D.1 — POSIADANIE / OBRÓT / UPRAWA

```
START: Jaki jest przedmiot czynu?
│
└─ Środek odurzający lub substancja psychotropowa (ustawa o przeciwdziałaniu narkomanii) ↓

CO ROBIŁ SPRAWCA?
│
├─ POSIADAŁ (dla siebie, nie na sprzedaż)
│   └─ Jaka ilość?
│       ├─ Nieznaczna + własny użytek
│       │   → ART. 62a ustawy PN — UMORZENIE MOŻLIWE
│       │   ⚠️ „Nieznaczna" = brak definicji ustawowej — weryfikuj linię SN/SA
│       │   Wniosek do prokuratora o umorzenie — złóż jak najwcześniej
│       ├─ Powyżej nieznacznej
│       │   → ART. 62 §1 ustawy PN — posiadanie (do 3 lat PW)
│       └─ Znaczna ilość
│           → ART. 62 §2 ustawy PN — do 10 lat PW
│           ⚠️ „Znaczna" = kilkadziesiąt–kilkaset porcji — weryfikuj orzecznictwo SA
│
├─ UDZIELAŁ INNYM / SPRZEDAWAŁ
│   ├─ Odpłatnie/nieodpłatnie → ART. 58 §1 (do 3 lat PW)
│   ├─ W celu osiągnięcia korzyści → ART. 59 §1 (1–10 lat PW)
│   ├─ Odpłatnie małoletniemu → ART. 59 § 2 (3–20 lat PW)
│   ├─ Wprowadzanie do obrotu / udział w obrocie → ART. 56 § 1
│   │  (grzywna i 6 miesięcy–8 lat PW)
│   └─ Znaczna ilość w obrocie → ART. 56 § 3
│      (grzywna i 2–12 lat PW)
│
└─ UPRAWIAŁ (mak / konopie)
    └─ → ART. 63 §1 ustawy PN (do 3 lat PW)
         Uprawa mogąca dostarczyć znacznej ilości → 6 miesięcy–8 lat PW

STRATEGIA: „Typ uprzywilejowany" art. 62a — złóż wniosek do prokuratora
  o umorzenie przed zarzutem + skierowanie na leczenie (art. 72 ustawy PN)
```

---


---

## BLOK E — PRZESTĘPSTWA DROGOWE

### DRZEWO E.1 — ALKOHOL / STAN PO UŻYCIU / WYPADEK

```
START: Zdarzenie drogowe z udziałem kierowcy
│
CZY KIEROWCA BYŁ POD WPŁYWEM SUBSTANCJI?
│
├─ TAK — alkohol we krwi:
│   ├─ 0,2–0,5‰ (lub 0,1–0,25 mg/dm³ w wydychanym powietrzu)
│   │   → ART. 87 §1 KW — WYKROCZENIE (jazda „po użyciu")
│   │   Kara: ARESZT 5–30 DNI (art. 19 KW) albo GRZYWNA NIE NIŻSZA
│   │         NIŻ 2 500 zł (dolna granica
│   │         w art. 87 §1 KW), górna granica 30 000 zł — art. 87 §1 jest
│   │         wymieniony w katalogu art. 24 §1a KW
│   │         ⛔ NIE podawaj samej liczby „30 000 zł" — to WYŁĄCZNIE górna
│   │         granica; bez dolnej (2 500 zł) opis sankcji jest niepełny
│   │         i prowadzi do błędnego wniosku o możliwej grzywnie symbolicznej
│   │   + zakaz prowadzenia pojazdów OBLIGATORYJNY (art. 87 §3 KW)
│   │   ✅ [VER: ELI, Dz.U. 2025 poz. 734, art. 19, 24 §1a i 87 §1,
│   │      odczyt 2026-08-25; re-ver t.j. Dz.U. 2026 poz. 1372, 2026-10-31:
│   │      bez zmian w zakresie art. 19, 87 §1 i obecności art. 87 §1 w art. 24 §1a]
│   └─ > 0,5‰ (lub > 0,25 mg/dm³ w wydychanym powietrzu)
│       → ART. 178a §1 KK — PRZESTĘPSTWO (jazda „w stanie nietrzeźwości")
│       Kara: POZBAWIENIE WOLNOŚCI DO LAT 3 — sankcja JEDNORODNA
│       ⛔ W sankcji art. 178a §1 NIE MA już grzywny ani ograniczenia
│          wolności jako kar samoistnych (stan po nowelizacji obowiązującej
│          od 1.10.2023, która podniosła też górną granicę z 2 na 3 lata).
│          Kara wolnościowa jest osiągalna przez art. 37a/58 KK albo przez
│          warunkowe zawieszenie — to inna podstawa niż sankcja przepisu
│          i tak należy ją opisywać.
│       ✅ [VER: ELI, Dz.U. 2025 poz. 383 (obecny t.j. Dz.U. 2026 poz. 1342), art. 178a §1,
│          odczyt 2026-08-25]
│       ⛔ ZNACZENIE PROCESOWE górnej granicy: 3 lata < 8 lat, więc art. 258
│          §2 KPK (surowość kary jako samodzielna podstawa TA) NIE działa;
│          3 lata > 1 rok, więc art. 259 §3 KPK (zakaz TA przy zagrożeniu
│          do roku) też NIE działa. Podanie tu „2 lata" prowadzi do błędnej
│          oceny obu przesłanek — dlatego ta wartość jest krytyczna, nie
│          informacyjna.
│       + zakaz prowadzenia pojazdów obowiązkowy (min. 3 lata — art. 42 §2 KK)
│       + świadczenie pieniężne obowiązkowe (min. 5 000 zł — art. 43a § 2 KK)
│         ✅ [VER: ELI DU/2025/383 (obecny t.j. Dz.U. 2026 poz. 1342) + DU/2025/1872 art. 2 pkt 2, odczyt 2026-10-04]:
│         od 29.01.2026 katalog § 2 obejmuje także art. 177 § 2a, 178c § 1,
│         178d; § 3 (min. 10 000 zł) — także art. 244, jeżeli czyn polegał na
│         niezastosowaniu się do zakazu prowadzenia pojazdów mechanicznych;
│         górna granica obu — art. 43a § 1: 60 000 zł
│       + PRZEPADEK POJAZDU — art. 44b KK; ⚠️ STAN PO NOWELIZACJI z 4.12.2025
│         (Dz.U. 2025 poz. 1872), obowiązującej od 29.01.2026:
│           ─ art. 44b §1 — przepadek FAKULTATYWNY („sąd MOŻE orzec") m.in.
│             przy skazaniu z art. 178a §1 lub §4
│           ─ art. 44b §1a — przepadek OBLIGATORYJNY („sąd orzeka"), gdy
│             stężenie wynosiło co najmniej 1,5‰ we krwi lub 0,75 mg/dm³
│             w wydychanym powietrzu — chyba że zachodzi wyjątkowy wypadek
│             uzasadniony szczególnymi okolicznościami
│           ─ art. 44b §2 (przepadek RÓWNOWARTOŚCI pojazdu) — UCHYLONY
│           ─ art. 178a §5 (dawna podstawa przepadku w części szczególnej)
│             — UCHYLONY; nie powołuj go
│         ✅ [VER: ELI DU/2026/1342 text.pdf (t.j. KK), art. 44b §1–§6, RZĄD 1,
│            2026-10-20; §1 i §1a obejmują też art. 178c §1 pkt 2, 178d i sprawcę
│            z art. 178 §1 lub 1a; §2–§4 uchylone]
│         ✅ art. 44b § 6: gdy pojazd nie był wyłączną własnością
│            sprawcy, sąd orzeka nawiązkę na rzecz Skarbu Państwa od
│            5 000 do 500 000 zł; gdy przepadek jest niemożliwy lub niecelowy
│            z przyczyn z § 5 pkt 2 — sąd może ją orzec
│           ⛔ Każda z powyższych pozycji przed użyciem w piśmie: potwierdź
│             aktualne brzmienie w źródle urzędowym — obszar nowelizowany
│             trzykrotnie w latach 2023–2026
│       + CZYN SPRZED 29.01.2026 — art. 4 § 1 KK (ustawa względniejsza jako
│         całość, in concreto): dawniej przepadek obligatoryjny przy art. 178a
│         §1/§4 chyba że <1,5‰ (dawny art. 178a §5) i przy art. 178 §1/1a
│         gdy >1‰ (dawny art. 178 §3); przepadek równowartości (dawny 44b §2–4)
│         ✅ [VER: ELI DU/2025/383 (t.j. KK sprzed zmiany), RZĄD 1, 2026-10-20]
│       + TYMCZASOWE ZAJĘCIE POJAZDU — art. 295 § 1a KPK (od 29.01.2026):
│         Policja zajmuje pojazd tylko przy przepadku z art. 44b § 1a KK
│         (≥1,5‰); zajęcia sprzed 29.01.2026 wobec sprawców z 1–1,5‰ upadły
│         z mocy prawa, pojazd się zwraca, chyba że zajęcie z art. 295 § 1
│         (art. 8 ustawy 1872)
│         ✅ [VER: ELI DU/2025/1872 art. 3 i 8, RZĄD 1, 2026-10-20]
│       ⚠️ Art. 178a § 4 KK → 3 miesiące–5 lat PW; art. 42 § 3
│           w brzmieniu od 29.01.2026 przewiduje co do zasady dożywotni
│           zakaz prowadzenia, chyba że zachodzi wyjątkowy wypadek
│           uzasadniony szczególnymi okolicznościami; świadczenie z
│           art. 43a § 3 — co najmniej 10 000 zł
│       ⚠️ Weryfikuj progi: ustawa o wychowaniu w trzeźwości, art. 46 ust. 2-3
│
└─ Wypadek drogowy (niezależnie od alkoholu):
    CZY NASTĄPIŁ SKUTEK?
    ├─ Skutek nie sięga art. 157 § 1 KK, ale zachowanie spowodowało
    │  zagrożenie bezpieczeństwa w ruchu → sprawdź ART. 86 KW; sam
    │  uszczerbek do 7 dni nie przesądza automatycznie kwalifikacji
    ├─ Skutek z art. 157 § 1 → ART. 177 § 1 KK (do 3 lat PW)
    ├─ Śmierć lub ciężki uszczerbek → ART. 177 §2 KK (6 m-cy – 8 lat PW)
    ├─ Śmierć/ciężki uszczerbek + nielegalny wyścig, art. 178d albo
    │  obowiązujący zakaz → ART. 177 § 2a KK (1–10 lat PW)
    └─ Nietrzeźwość/odurzenie, ucieczka lub spożycie po czynie przed
       badaniem → obostrzenie z ART. 178 KK:
       • § 1: dla katalogu wskazanego w przepisie dolna i górna granica
         sankcji za czyn bazowy są zwiększane o połowę;
       • § 1a: minimum 3 lata przy ciężkim uszczerbku, minimum 5 lat
         przy śmierci, z górnymi granicami określonymi w tym przepisie.
```

---
