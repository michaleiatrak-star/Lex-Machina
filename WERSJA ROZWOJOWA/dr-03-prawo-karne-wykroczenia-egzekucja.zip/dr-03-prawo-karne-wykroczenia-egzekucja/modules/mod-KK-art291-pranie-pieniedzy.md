# Moduł — KK art. 291–293 (paserstwo) i art. 299 (pranie pieniędzy)

**Akt:** KK — t.j. Dz.U. 2026 poz. 1342 (zm. 2026/1466 [OD 2026-11-21: 2026/1466] — art. 42, 84).
**Akt:** KKS — t.j. Dz.U. 2025 poz. 633 (zm. po t.j., w mocy: 2026/347 od 2026-03-18 — art. 80cb–80cc; 2026/421 od 2026-04-14 — art. 113; 2026/901 od 2026-07-21 — art. 1, 87, 122; 2026/846 od 2026-10-01 — art. 16b, 80f, 133, 137, 138, 140).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: zagrożenia karą i terminy porównane z t.j.).

## Akt prawny
**Kodeks karny — art. 291–293 należą do rozdziału XXXV (art. 278–295, przestępstwa przeciwko mieniu); art. 299 — do rozdziału XXXVI (art. 296–309, przestępstwa przeciwko obrotowi gospodarczemu i interesom majątkowym w obrocie cywilnoprawnym)**
- Tekst jednolity KK: **Dz.U. 2026 poz. 1342**
  ✅ [VER: ELI DU/2025/383 (obecny t.j. Dz.U. 2026 poz. 1342) text.pdf, RZĄD 1, 2026-10-04]
- ⚠️ KOREKTA 2026-10-04i (nazwanie błędu): wcześniejszy nagłówek podawał „rozdział XXXV (art. 291–297) i rozdział XXXVI (art. 296–305)" — błędne granice rozdziałów (ELI: XXXV = art. 278–295; XXXVI zaczyna się od art. 296). Całość rozdziału XXXV (kradzież, rozbój, przywłaszczenie, oszustwo, paserstwo, art. 294–295): `mod-KK-art278-295-przestepstwa-przeciwko-mieniu.md`.

**Ustawa AML — karny wymiar:**
→ DR-03/mod-KKS-karny-skarbowy-i-AML

**Weryfikacja w ELI (RZĄD 1) przed każdym cytowaniem.**

## Paserstwo (art. 291–293 KK) — brzmienie ELI (korekta 2026-10-04i)
```
Art. 291 § 1:  nabywa / pomaga do zbycia / przyjmuje / pomaga do ukrycia rzeczy uzyskanej za pomocą
               czynu zabronionego — 3 miesiące–5 lat
Art. 291 § 2:  wypadek mniejszej wagi — grzywna, ograniczenie wolności albo PW do roku
Art. 292 § 1:  paserstwo nieumyślne („powinien i może przypuszczać") — grzywna, ograniczenie wolności
               albo PW do 2 lat
Art. 292 § 2:  rzecz znacznej wartości (> 200 000 zł) — 3 miesiące–5 lat
Art. 293:      § 1 — odpowiednio do programu komputerowego; § 2 — fakultatywny przepadek chociażby
               rzecz nie była własnością sprawcy
Art. 294 § 1:  art. 291 § 1 przy mieniu znacznej wartości — 1–10 lat (art. 292 NIE objęty)
```
✅ [VER: ELI DU/2025/383 (obecny t.j. Dz.U. 2026 poz. 1342) text.pdf, art. 291–295, RZĄD 1, 2026-10-04]

⛔ **Błędy usunięte w tej wersji (nazwane wprost):** (1) „do 8 lat przy znacznej wartości" przy art. 291 — takiej wartości w art. 291 nie ma; (2) „Art. 292 — do 2 lat (lub grzywna)" pomijał § 2 (3 mies.–5 lat przy znacznej wartości); (3) zdanie „Nie można być ukarany za paserstwo w stosunku do własnego przestępstwa" **nie jest przepisem** — to zasada doktrynalna (współukarany czyn następczy), niezweryfikowana tutaj; nie przytaczaj jej jako normy prawnej. Pełny opis, tryb, przedawnienie, art. 295: `mod-KK-art278-295-przestepstwa-przeciwko-mieniu.md` §9.

## Pranie pieniędzy (art. 299 KK)
```
Art. 299 § 1:  Przyjmowanie, posiadanie, używanie, przekazywanie, wywożenie za granicę,
               pomaganie w przeniesieniu własności — środków z przestępstwa — do 8 lat
Art. 299 § 2:  ⚠️ POPRAWKA 2026-07-26b (FAZA 3E/ZASADA 14 — korekta
               WŁASNEGO błędu z poprzedniej edycji tej samej sesji:
               pomylono treść §2 z §5). §2 dotyczy PRACOWNIKA lub osoby
               działającej w imieniu/na rzecz banku, instytucji
               finansowej/kredytowej lub innego podmiotu objętego
               obowiązkiem rejestracji transakcji, który WBREW PRZEPISOM
               przyjmuje środki płatnicze/instrumenty finansowe itd. —
               KARA TA SAMA CO §1 (6 m-cy — 8 lat), nie osobny, wyższy
               wymiar. Potwierdzone WPROST cytatem z arslege.pl (t.j.
               Dz.U. 2026 poz. 1342): "Karze określonej w §1 podlega, kto będąc
               pracownikiem lub działając w imieniu lub na rzecz banku,
               instytucji finansowej lub kredytowej..." — dosłowne
               brzmienie nie pozostawia wątpliwości.
Art. 299 § 5:  ⚠️ POPRAWKA 2026-07-26d (F-18, DOMKNIĘTA Z RZĄDEM 2B —
               poprzednia wersja 26c opierała się WYŁĄCZNIE na Rządzie 3,
               wbrew ZASADZIE 14; teraz potwierdzone DOSŁOWNYM cytatem z
               3 niezależnych agregatorów Rządu 2B): "Jeżeli sprawca
               dopuszcza się czynu określonego w § 1 lub 2, działając w
               porozumieniu z innymi osobami, podlega karze pozbawienia
               wolności od roku do lat 10." Potwierdzone dosłownie:
               lexlege.pl, prawo-pl.com, e-prawnik.pl (wszystkie 3
               identyczny tekst) — Rząd 2B jako główne potwierdzenie,
               Rząd 3 (karh.pl, adwokat-szymczyk.pl) i publikacja
               akademicka (journals.umcs.pl) jako dodatkowe.
Art. 299 § 6:  ⚠️ POPRAWKA 2026-07-26d (F-18, DOMKNIĘTA Z RZĄDEM 2B):
               "Karze określonej w § 5 podlega sprawca, jeżeli
               dopuszczając się czynu określonego w § 1 lub 2, osiąga
               znaczną korzyść majątkową." — czyli TA SAMA kara co §5
               (rok-10 lat), ODRĘBNA przesłanka (znaczna korzyść
               majątkowa, >200 000 zł, art. 115 §4/§5 KK). Dosłowny
               cytat identyczny w lexlege.pl, prawo-pl.com, e-prawnik.pl.
               Orzecznictwo (wg adwokat-skoczylas.pl) precyzuje, że
               "znaczna korzyść" z §6 to zysk z SAMEGO procederu prania
               (np. prowizja), NIE cała kwota prania środków.
Art. 299 § 6a: ⚠️ DODANE 2026-07-26d (F-18 — całkowicie pominięte we
               wcześniejszych wersjach modułu, znalezione przy
               weryfikacji §5/§6 z Rządu 2B). Przygotowanie do
               przestępstwa z §1 lub §2 — do 3 lat. Potwierdzone
               dosłownie: lexlege.pl, prawo-pl.com, e-prawnik.pl,
               karh.pl (wszystkie zgodne).
Art. 299 § 7:  Przepadek przedmiotów/korzyści z przestępstwa (§1 lub 2) — obligatoryjny
               (⚠️ POPRAWKA 2026-07-26b: BYŁO błędnie oznaczone jako "§8" —
               potwierdzone: adwokatdulniak.pl, rgn.legal, lexlege.pl,
               prawo-pl.com, e-prawnik.pl — dosłowny cytat identyczny)
Art. 299 § 8:  Czynny żal — brak kary, jeśli sprawca dobrowolnie ujawnił organowi
               ścigania informacje o osobach uczestniczących i okolicznościach,
               zanim zapobiegło to popełnieniu innego przestępstwa
               (⚠️ POPRAWKA 2026-07-26b: BYŁO błędnie oznaczone jako "§6" —
               potwierdzone: materiały szkoleniowe B.J. Stefańskiej [gov.pl],
               adwokatdulniak.pl — "art. 299 § 8 in fine k.k.")
```

⚠️ **ESKALACJA ZBRODNIOWA (art. 306b KK) — dodane 2026-07-26
(MOD-PROPAGACJA-NOWELIZACJI, ten sam mechanizm co w mod-KK-art296-
naduzycie-zaufania.md i mod-KK-art296a-korupcja-sektor-prywatny.md):**
jeśli czyn z art. 299 **§1, §2, §5 LUB §6** dotyczy mienia/szkody:
```
> 5 mln zł  → art. 306b §1 → 3-20 lat (ZBRODNIA)
> 10 mln zł → art. 306b §2 → 5-25 lat (ZBRODNIA)
```
Wejście w życie 1.10.2023. Potwierdzone: arslege.pl (t.j. Dz.U. 2025 poz. 383 (obecny t.j. Dz.U. 2026 poz. 1342)),
kairp.pl, adwokatdulniak.pl, kancelarierp.pl, chmielniak.com.pl,
russellbedford.pl.

## ⭐ FIKCYJNE FIRMY JAKO TECHNIKA PRANIA PIENIĘDZY (dodane 2026-07-18)

> Odpowiedź na wyraźne pytanie użytkownika o "fikcyjne firmy i
> działalności celem prania pieniędzy" — dotąd sam przepis art. 299 był
> opisany, ale bez rozwinięcia NAJCZĘSTSZEJ w polskiej praktyce TECHNIKI
> jego realizacji.

### Mechanizm — jak fikcyjne firmy służą praniu pieniędzy

```
□ ZAKŁADANIE lub WYKORZYSTYWANIE spółek do "wyprania" pieniędzy przez:
  FIKCYJNE FAKTURY, ZAWYŻONE KOSZTY, inne MANIPULACJE KSIĘGOWE — JEDNA
  Z NAJCZĘSTSZYCH metod w polskiej praktyce (potwierdzone niezależnie
  przez orzecznictwo i praktykę kancelarii karnych)
□ "FIRMY KRZAKI" — spółki UDAJĄCE (symulujące) rzeczywistą działalność
  gospodarczą, BEZ faktycznego obrotu towarami/usługami
□ "SŁUPY" — osoby (często w trudnej sytuacji materialnej lub bezdomne)
  formalnie zakładające/prowadzące takie firmy — patrz `mod-KK-slupy-
  fikcyjna-reprezentacja-spolki.md` (DR-03, już istniejący moduł) —
  BEZPOŚREDNIE połączenie tematyczne, ten moduł dostarcza WARSTWĘ AML/
  prania pieniędzy, tamten — warstwę odpowiedzialności KARNEJ samego
  słupa jako współsprawcy/pomocnika
□ RACHUNEK FIKCYJNY NA SŁUPA — otwarcie konta WYŁĄCZNIE w celu
  przeprowadzenia JEDNEJ lub kilku transakcji na DUŻE KWOTY w KRÓTKICH
  odstępach czasu — często przy użyciu SFAŁSZOWANYCH dokumentów
  tożsamości (zbieg z `mod-KK-slupy-fikcyjna-reprezentacja-spolki.md`
  i `mod-KK-art270-310-falszerstwa-dokumentow.md`)
```

### ⭐ Kluczowy mechanizm dowodowy — "obrót pustymi fakturami = pranie pieniędzy"

**Utrwalone orzecznictwo (SA Katowice, wyroki: II AKa 148/18 z 22.06.2018;
II AKa 216/16 z 21.07.2016; II AKa 327/19 z 6.08.2020):** PRZELANIE
środków jako ZAPŁATA za FIKCYJNĄ fakturę, a NASTĘPNIE BEZZWŁOCZNE
odebranie tej sumy w GOTÓWCE — REALIZUJE WPROST znamiona PRZYJĘCIA i
PRZEKAZANIA środków pieniężnych pochodzących z przestępstwa (art. 299
§1 KK). Sama SEKWENCJA (przelew → natychmiastowa wypłata gotówkowa)
jest silną POSZLAKĄ prania pieniędzy, NIEZALEŻNIE od formalnej
poprawności samej faktury.

**Podwójna podstawa odpowiedzialności przy pustych fakturach:**
```
1. Wystawienie/posłużenie się fikcyjną fakturą → SAMODZIELNE
   przestępstwo (pomniejszenie podatku należnego o VAT z takiej
   faktury — sprawdź `mod-KKS-karny-skarbowy-i-AML.md`)
2. PRZEPŁYW środków zapłaty za tę fakturę (przelew + wypłata) → ODRĘBNIE
   może wypełniać znamiona art. 299 KK (pranie pieniędzy)
→ To DWA RÓŻNE czyny/podstawy, mogące występować W ZBIEGU — nie
  wystarczy rozliczyć się TYLKO z przestępstwa skarbowego, jeśli
  doszło też do "prania" przepływu środków
```

### Inne techniki prania pieniędzy z użyciem fikcyjnych struktur (katalog uzupełniający)

```
□ TRANSFER PRICING — zaniżanie/zawyżanie wartości na fakturze w handlu
  MIĘDZYNARODOWYM — różnica między realną a zawyżoną ceną staje się
  "legalnym" zyskiem
□ TRANSFERY TRANSGRANICZNE przez ŁAŃCUCH powiązanych firm/rachunków —
  utrudnia śledzenie pochodzenia środków
□ SKRZYNKI ROZDZIELCZE (rachunki pośredniczące dzielące/scalające
  przepływy dla zatarcia śladu)
□ MIESZANIE legalnych i nielegalnych przychodów w RAMACH tej samej
  działalności (utrudnia rozdzielenie w toku kontroli)
□ Wykorzystanie KRYPTOWALUT — obszar SŁABIEJ uregulowany, sygnalizowany
  przez KNF jako obszar podwyższonego ryzyka nadużyć (⚠️ zweryfikuj
  aktualny stan regulacji AML dla kryptoaktywów — MICA/pakiet unijny —
  przy konkretnej sprawie, dynamicznie zmieniające się otoczenie prawne)
```

### Ryzyko dla członków zarządu/pełnomocników "nieświadomych"

**Ostrzeżenie praktyczne:** jeśli jesteś członkiem zarządu lub
pełnomocnikiem firmy wykorzystywanej do prania pieniędzy — MOŻESZ
zostać pociągnięty do odpowiedzialności, NAWET JEŚLI nie uczestniczyłeś
BEZPOŚREDNIO w procederze — NIEZNAJOMOŚĆ prawa ani BRAK PEŁNEJ
świadomości co do pochodzenia środków NIE ZAWSZE chroni przed
odpowiedzialnością karną (zamiar EWENTUALNY może wystarczyć — patrz
analogiczna logika w `mod-KK-slupy-fikcyjna-reprezentacja-spolki.md`
Część A, sekcja o rozbieżności orzecznictwa co do świadomości słupa).

### Checklist praktyczny — fikcyjne firmy jako pranie pieniędzy

```
□ Czy istnieje SEKWENCJA przelew→natychmiastowa wypłata gotówkowa
  za fakturę o WĄTPLIWEJ autentyczności — to SILNA poszlaka wg
  utrwalonego orzecznictwa SA Katowice
□ Czy firma wykazuje CECHY "firmy krzak" (brak realnego zatrudnienia,
  brak faktycznego miejsca prowadzenia działalności, obrót
  NIEADEKWATNY do zasobów)?
□ Czy osoba formalnie zarządzająca ma CECHY "słupa" (trudna sytuacja
  materialna, brak wiedzy branżowej adekwatnej do skali "działalności")
  → sprawdź RÓWNOLEGLE `mod-KK-slupy-fikcyjna-reprezentacja-spolki.md`
□ Czy doszło do ZBIEGU: przestępstwo skarbowe (puste faktury, VAT) +
  pranie pieniędzy (art. 299) — oba wymagają ODDZIELNEJ analizy, nie
  wystarczy rozliczyć TYLKO jednego z nich
□ Czy klient (członek zarządu/pełnomocnik) może wykazać BRAK
  świadomości — jak MOCNY jest ten argument w świetle jego roli
  faktycznej (formalna vs rzeczywista kontrola nad spółką)?
```

## Powiązania z AML
- GIIF (Generalny Inspektor Informacji Finansowej) — główny organ analityczny
- Instytucje obowiązane — raportowanie podejrzanych transakcji
- Powiązanie: KKS art. 37m–37n (karno-skarbowe pranie pieniędzy) i UZNK

## Zasady absolutne
```
Pranie brudnych pieniędzy: przestępstwo umyślne (zamiar bezpośredni lub ewentualny)
Czynny żal: skuteczny TYLKO gdy ujawnienie przed wszczęciem — art. 299 § 8
Przepadek: obligatoryjny (art. 299 § 7) — nie można się zwolnić
Przestępstwo bazowe: wystarczy, że środki pochodzą z JAKIEGOKOLWIEK przestępstwa
```

## Weryfikacja online
```
web_search: "KK art. 299 pranie pieniędzy Dz.U. 2026 poz. 1342 zakres"
web_search: "pranie pieniędzy Polska orzecznictwo SN 2024 2025"
```
