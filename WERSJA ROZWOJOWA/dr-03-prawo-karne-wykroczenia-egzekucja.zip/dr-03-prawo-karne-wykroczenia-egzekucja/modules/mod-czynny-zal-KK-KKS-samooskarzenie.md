# mod-czynny-zal-KK-KKS-samooskarzenie

**Wersja:** 1.0 | **Dodano:** 2026-07-21
**Rola w systemie:** odpowiedź na pytanie użytkownika o czynny żal i
samooskarżenie — "czynny żal" był dotąd przywoływany DZIESIĄTKI razy w
całym systemie (9+ modułów), ZAWSZE jako hasło w liście kontrolnej
("rozważ czynny żal", "web_search: czynny żal..."), NIGDY z rzeczywistą
treścią o elementach/procedurze/terminach. "Samooskarżenie" NIGDZIE
niewystępujące — wymaga UCZCIWEGO wyjaśnienia terminologicznego.

> ⛔ HARDGATE — zweryfikuj aktualny t.j. KK i KKS na ISAP.

---

## 0. ⭐ KOREKTA TERMINOLOGICZNA — "SAMOOSKARŻENIE" NIE JEST ODRĘBNĄ INSTYTUCJĄ

```
□ W polskim prawie karnym NIE ISTNIEJE samodzielna, nazwana instytucja
  "samooskarżenie" jako TAKA — to POTOCZNE określenie, które w
  ZALEŻNOŚCI od kontekstu odnosi się do JEDNEJ z poniższych,
  RZECZYWIŚCIE istniejących instytucji:
  1) CZYNNY ŻAL (art. 15 KK / art. 16-16a KKS) — dobrowolne
     ZAWIADOMIENIE organu O WŁASNYM czynie zabronionym, PRZED jego
     wykryciem — patrz sekcje 1-2 niżej
  2) PRZYZNANIE SIĘ DO WINY w toku JUŻ TOCZĄCEGO się postępowania —
     element FAKTYCZNY, brany pod uwagę przy wymiarze kary (art. 53
     §2 KK — właściwości i warunki osobiste sprawcy, jego zachowanie
     PO popełnieniu czynu), ale NIE ODRĘBNA instytucja proceduralna
  3) DOBROWOLNE PODDANIE SIĘ KARZE (art. 335/387 KPK) — MECHANIZM
     KONSENSUALNY zakończenia postępowania JUŻ WSZCZĘTEGO, gdzie
     akceptacja odpowiedzialności jest ELEMENTEM ugody z organem —
     patrz sekcja 3-4 niżej

⭐ KLUCZOWA RÓŻNICA: czynny żal działa PRZED wykryciem czynu przez
organy (PREWENCYJNIE, można UNIKNĄĆ kary CAŁKOWICIE) — dobrowolne
poddanie się karze i przyznanie się do winy działają PO wszczęciu
postępowania (gdy sprawa już jest ZNANA organom, chodzi o ZŁAGODZENIE
lub PRZYSPIESZENIE, nie o CAŁKOWITE uniknięcie odpowiedzialności)
```

---

## 1. CZYNNY ŻAL W KODEKSIE KARNYM (art. 15 KK) — dwie ODRĘBNE formy

```
⭐ ROZRÓŻNIENIE kluczowe (często mylone):
  1) DOBROWOLNE ODSTĄPIENIE od usiłowania — sprawca PORZUCA zamiar
     PRZED dokonaniem KOMPLETU czynności wykonawczych (np. wycelował
     broń, ale NIE strzelił, choć MÓGŁ)
  2) DOBROWOLNE ZAPOBIEŻENIE skutkowi stanowiącemu znamię czynu
     zabronionego — sprawca DZIAŁAŁ już w PEŁNI (np. ODDAŁ strzał), ALE
     PO fakcie ZAPOBIEGA nastąpieniu SKUTKU (np. WZYWA lekarza,
     RATUJĄC życie ofiary)

□ SKUTEK: sprawca NIE PODLEGA karze za USIŁOWANIE (art. 15 §1 KK) —
  ⚠️ dotyczy WYŁĄCZNIE usiłowania SAMEGO — jeśli w MIĘDZYCZASIE doszło
  już do DOKONANIA innego, odrębnego przestępstwa (np. przy nieudanym
  zabójstwie sprawca ZDĄŻYŁ spowodować uszczerbek na zdrowiu PRZED
  odstąpieniem) — za TO odrębne przestępstwo sprawca NADAL odpowiada
□ ✅ **art. 17 KK — ZWERYFIKOWANE (2026-08-18, F-26):** analogiczna
  instytucja dla PRZYGOTOWANIA. **§1:** nie podlega karze za przygotowanie,
  kto DOBROWOLNIE od niego odstąpił, w szczególności zniszczył
  przygotowane środki lub zapobiegł skorzystaniu z nich w przyszłości;
  jeżeli sprawca wszedł w porozumienie z inną osobą w celu popełnienia
  czynu, nie podlega karze TEN, kto DODATKOWO podjął ISTOTNE STARANIA
  zmierzające do zapobieżenia dokonaniu (nie wystarczy samo własne
  odstąpienie przy współdziałaniu z inną osobą — trzeba też próbować
  powstrzymać tę drugą osobę, choć nie trzeba odnieść skutku, wystarczy
  "istotne starania"). **§2:** nie podlega karze za przygotowanie osoba,
  do której stosuje się art. 15 §1 (czyli ten, kto po przejściu z
  przygotowania do usiłowania dobrowolnie odstąpił od usiłowania —
  klauzula "przechwytująca" sprawcę na późniejszym etapie). ⚠️ **Uwaga
  praktyczna:** przygotowanie samo w sobie jest karalne TYLKO gdy ustawa
  tak wprost stanowi (art. 16 §2 KK) — dotyczy wąskiej listy przestępstw
  (m.in. zamach stanu art. 127, przeciwko bezpieczeństwu powszechnemu
  art. 168, fałszerstwo dokumentów art. 270 §3) — art. 17 aktualizuje się
  więc rzadko, tylko przy tych typach. Źródła zbieżne: pl.wikipedia.org,
  standardyprawa.pl, infor.pl, zpe.gov.pl (materiał edukacyjny MEN).
□ ✅ **art. 23 KK — ZWERYFIKOWANE (2026-08-18, F-26):** czynny żal przy
  WSPÓŁDZIAŁANIU przestępczym. **§1 (żal SKUTECZNY):** nie podlega karze
  współdziałający, który DOBROWOLNIE ZAPOBIEGŁ dokonaniu czynu
  zabronionego — wymaga REALNEGO SKUTKU (czyn faktycznie nie doszedł do
  skutku dzięki działaniu współdziałającego). **§2 (żal NIESKUTECZNY, ale
  premiowany łagodniej):** sąd MOŻE (fakultatywnie, nie musi) zastosować
  nadzwyczajne złagodzenie kary wobec współdziałającego, który
  DOBROWOLNIE STARAŁ SIĘ zapobiec dokonaniu, ale mu się nie udało —
  różnica względem §1 to gradacja: §1 = całkowita niekaralność (skutek
  osiągnięty), §2 = tylko złagodzenie, i to uznaniowe (skutek nieosiągnięty,
  liczy się sama próba). Źródła zbieżne: pl.wikipedia.org (cytat wprost
  obu paragrafów), spójne z ogólną strukturą art. 15 (usiłowanie) i art.
  17 (przygotowanie) — trójstopniowa gradacja czynnego żalu w KK jest
  wewnętrznie spójna.
```

---

## 2. ⭐⭐⭐ CZYNNY ŻAL W KODEKSIE KARNYM SKARBOWYM (art. 16-16a KKS)

> To NAJCZĘŚCIEJ praktycznie stosowana forma czynnego żalu —
> odpowiedzialna za DZIESIĄTKI odwołań w systemie bez wyjaśnienia treści.

### Art. 16 KKS — forma OGÓLNA

> ✅ [VER] RZĄD 1 2026-09-16g — KKS t.j. `Dz.U. 2025 poz. 633`; nowelizacje po t.j.
> (`2026/347`, `421`, `846`, `901`) nie zmieniają art. 16 ani 16a. ⚠️ `2026/846` **uchyla
> art. 16b** (niepodleganie karze przy zeznaniu PIT przygotowanym przez organ — błędy z winy
> organu lub płatnika) z dniem **1.10.2026**.

```
□ NIE PODLEGA KARZE za przestępstwo/wykroczenie SKARBOWE sprawca,
  KTÓRY PO popełnieniu czynu ZABRONIONEGO ZAWIADOMIŁ o TYM organ
  POWOŁANY do ścigania, UJAWNIAJĄC ISTOTNE okoliczności czynu, W
  SZCZEGÓLNOŚCI osoby WSPÓŁDZIAŁAJĄCE w jego popełnieniu

⭐⭐⭐ KLUCZOWE, CZĘSTO POMIJANE ustalenie: czynny żal z ZASADY NIE
JEST TYLKO "SAMO-DONOSEM" — DRUGA przesłanka (ujawnienie ISTOTNYCH
okoliczności) WYMAGA, w SZCZEGÓLNOŚCI, ujawnienia RÓWNIEŻ INNYCH osób
WSPÓŁDZIAŁAJĄCYCH przy popełnieniu czynu — SAMO przyznanie się do
WŁASNEGO udziału, BEZ ujawnienia współsprawców (jeśli tacy ISTNIELI),
MOŻE być NIEWYSTARCZAJĄCE dla PEŁNEJ skuteczności — TO WŁAŚNIE
POTOCZNE "samooskarżenie" (patrz korekta terminologiczna wyżej) JEST
TYLKO CZĘŚCIĄ wymogu, NIE całością

□ ⭐ WARUNEK DODATKOWY (art. 16 §2) — SKUTECZNOŚĆ czynnego żalu
  WYMAGA, ABY w TERMINIE wyznaczonym PRZEZ uprawniony organ
  postępowania przygotowawczego UISZCZONO W CAŁOŚCI wymagalną
  NALEŻNOŚĆ publicznoprawną USZCZUPLONĄ popełnionym czynem —
  SAMO zawiadomienie BEZ zapłaty NIE WYSTARCZA, jeśli czyn POLEGAŁ na
  uszczupleniu należności
□ JEŚLI czyn NIE POLEGA na uszczupleniu należności, a PRZEPADEK
  przedmiotów jest OBOWIĄZKOWY — sprawca powinien ZŁOŻYĆ te
  przedmioty, a w RAZIE niemożności — UIŚCIĆ ich RÓWNOWARTOŚĆ
  pieniężną
□ ⭐ DLA SKUTECZNOŚCI CZYNNEGO ŻALU NIE MA znaczenia, JAKA kara
  GROZI za dane przestępstwo/wykroczenie skarbowe — MOŻE to BYĆ nawet
  SAMA kara grzywny
□ FORMA (§ 4–4a): na piśmie albo ustnie do protokołu; do finansowego
  organu postępowania przygotowawczego — także przez konto w e-Urzędzie
  Skarbowym
□ ⛔ BEZSKUTECZNOŚĆ (§ 5) — zawiadomienie jest bezskuteczne, jeżeli złożono je:
  1) gdy organ ścigania miał już WYRAŹNIE UDOKUMENTOWANĄ wiadomość o czynie;
  2) PO ROZPOCZĘCIU czynności służbowej — w szczególności PRZESZUKANIA,
     CZYNNOŚCI SPRAWDZAJĄCEJ lub KONTROLI zmierzającej do ujawnienia czynu —
     chyba że czynność nie dała podstaw do wszczęcia postępowania o ten czyn
□ ⛔ WYŁĄCZENIA PODMIOTOWE (§ 6) — art. 16 nie chroni sprawcy, który:
  1) kierował wykonaniem ujawnionego czynu; 2) wykorzystując uzależnienie
  innej osoby, polecił jej wykonanie czynu; 3) zorganizował grupę lub
  związek albo nim kierował — chyba że zawiadomił wraz ze WSZYSTKIMI
  członkami; 4) nakłaniał inną osobę do czynu, by skierować przeciw niej
  postępowanie
□ USIŁOWANIE — ⛔ KOREKTA 2026-09-16g: art. 16 KKS NIE zawiera odesłania do
  usiłowania (poprzedni zapis „stosuje się odpowiednio do usiłowania" nie
  miał podstawy). Przy usiłowaniu art. 21 § 3 KKS odsyła do art. 13, 14 § 2
  i **art. 15 Kodeksu karnego** (dobrowolne odstąpienie / zapobieżenie
  skutkowi) oraz art. 20 § 4 KKS
```

### Art. 16a KKS — forma SZCZEGÓLNA (deklaracje/księgi)

```
□ WĘŻSZY zakres niż art. 16 — dotyczy WYŁĄCZNIE czynu ZABRONIONEGO
  dotyczącego złożenia DEKLARACJI LUB przesłania KSIĘGI
□ NIE PODLEGA KARZE, JEŻELI PO popełnieniu czynu ZOSTAŁA złożona
  organowi PODATKOWEMU PRAWNIE SKUTECZNA KOREKTA deklaracji/księgi
  dotycząca OBOWIĄZKU, którego NIEPRAWIDŁOWE wykonanie STANOWIŁO ten
  czyn
□ ⭐ PROSTSZA procedura niż art. 16 — NIE WYMAGA odrębnego
  "zawiadomienia" w formie OPISOWEJ, WYSTARCZA SAMA skuteczna KOREKTA
  deklaracji/księgi
□ JEŚLI w związku z czynem NASTĄPIŁO uszczuplenie NALEŻNOŚCI — przepis
  STOSUJE SIĘ TYLKO, gdy należność UISZCZONO NIEZWŁOCZNIE, NIE
  PÓŹNIEJ niż w TERMINIE wyznaczonym PRZEZ finansowy organ postępowania
  przygotowawczego
□ ⛔ WYŁĄCZENIE (§ 3) — art. 16a nie działa, jeżeli PRZED złożeniem korekty
  WSZCZĘTO postępowanie przygotowawcze o przestępstwo lub wykroczenie
  skarbowe albo UJAWNIONO je w toku toczącego się postępowania
  przygotowawczego (✅ RZĄD 1 2026-09-16g; poprzednio „katalog
  niepotwierdzony")
```

### Praktyczne aspekty (oba przepisy)

```
□ ELEMENTY pisemnego czynnego żalu: oznaczenie ORGANU, do KTÓREGO jest
  skierowany, oraz SPRAWY której DOTYCZY; oznaczenie ORAZ adres
  zgłaszającego; OPIS czynu i OKOLICZNOŚCI (w tym WSPÓŁDZIAŁAJĄCYCH,
  jeśli DOTYCZY — patrz zastrzeżenie WYŻEJ)
□ Art. 16 KKS MOŻE być PODSTAWĄ apelacji — jeśli SĄD I instancji
  BŁĘDNIE nie uwzględnił skuteczności czynnego żalu; W OSTATECZNOŚCI
  możliwa SKARGA kasacyjna
□ ⭐ WYŁĄCZENIE zakresowe: PRZEPISEM tym NIE SĄ objęte zachowania z
  art. 79 ustawy o RACHUNKOWOŚCI — TE NIE SĄ ani przestępstwami
  skarbowymi, ani wykroczeniami skarbowymi (KKS dotyczy WYŁĄCZNIE
  TYCH dwóch kategorii)
```

---

## 3. CHECKLIST — WYBÓR MIĘDZY CZYNNYM ŻALEM A INNYMI ŚCIEŻKAMI

```
□ Czy organ ŚCIGANIA/podatkowy JUŻ WIE o czynie (np. trwa KONTROLA) —
  JEŚLI TAK, czynny żal z art. 16 jest BEZSKUTECZNY (art. 16 § 5): wyraźnie
  udokumentowana wiadomość organu albo rozpoczęta czynność służbowa —
  przeszukanie, CZYNNOŚĆ SPRAWDZAJĄCA, kontrola — chyba że czynność nie dała
  podstaw do wszczęcia postępowania. Dla art. 16a granicą jest WSZCZĘCIE
  postępowania przygotowawczego albo ujawnienie w jego toku (art. 16a § 3)
□ Czy czyn dotyczy DEKLARACJI/KSIĘGI (art. 16a, prostsza ścieżka
  korekty) czy INNEGO typu naruszenia (art. 16, pełne zawiadomienie +
  ujawnienie współsprawców)
□ Czy ISTNIEJĄ inne osoby WSPÓŁDZIAŁAJĄCE w czynie — jeśli TAK, sprawdź
  czy ICH ujawnienie jest WYMAGANE dla PEŁNEJ skuteczności (art. 16,
  NIE dotyczy art. 16a)
□ Czy KLIENT jest W STANIE UREGULOWAĆ należność w TERMINIE wyznaczonym
  przez organ — BRAK zapłaty UNIEWAŻNIA skuteczność czynnego żalu przy
  czynach POLEGAJĄCYCH na uszczupleniu
□ Czy sprawa dotyczy KK (nie KKS) — sprawdź ODRĘBNE przesłanki art. 15
  (odstąpienie od USIŁOWANIA vs zapobieżenie SKUTKOWI — dwie różne
  sytuacje faktyczne)
```

---

## 4. INTEGRACJA Z SYSTEMEM

- Ten moduł jest CENTRALNYM, dedykowanym opracowaniem czynnego żalu —
  DZIESIĄTKI innych modułów w systemie (m.in. `mod-OP-ordynacja-
  podatkowa.md`, `mod-KAS-kontrola-celno-skarbowa.md`, `mod-UCC-clo-
  taryfa-celna.md`, `mod-KK-art228-231-korupcja-urzednicza.md`,
  `mod-KK-art181-188a-przeciwko-srodowisku.md` i INNE, DR-03/DR-06)
  ODWOŁUJĄ SIĘ do czynnego żalu jako hasła kontrolnego — WSZYSTKIE
  powinny TERAZ odsyłać DO TEGO modułu po PEŁNĄ treść, bez duplikowania.
- **`mod-KK-KPK-framework-karne.md`** (DR-03) — ogólny framework,
  wcześniej zawierał TYLKO odesłanie do web_search bez treści.
- **`mod-dobrowolne-poddanie-sie-karze-KPK.md`** (DR-03, dodany
  2026-07-21) — INNY mechanizm, działający PO wszczęciu postępowania
  — NIE MYLIĆ, patrz korekta terminologiczna w sekcji 0.

---

## 5. LITERATURA I ŹRÓDŁA (zweryfikowane online 2026-07-21)

- infor.pl, lexlege.pl, sip.lex.pl (Dz.U. 2025 poz. 633 t.j.) — pełna treść
  art. 16 i 16a KKS.
- akademialtca.pl — kluczowe ustalenie: czynny żal NIE jest tylko
  samo-donosem, wymóg ujawnienia współdziałających.
- pwrz.pl — komentarz praktyczny (odpowiednie stosowanie do usiłowania,
  brak znaczenia wysokości grożącej kary, wyłączenie dla art. 79
  ustawy o rachunkowości, ścieżka apelacyjna/kasacyjna).
- gazetaprawna.pl — rozróżnienie dwóch form czynnego żalu w KK (art.
  15 — odstąpienie od usiłowania vs zapobieżenie skutkowi).
