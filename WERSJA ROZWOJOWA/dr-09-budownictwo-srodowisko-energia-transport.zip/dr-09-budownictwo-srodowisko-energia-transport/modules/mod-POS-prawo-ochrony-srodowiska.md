# Moduł [Y] — Prawo Ochrony Środowiska

**Zakres:** Decyzje środowiskowe (DŚU — decyzja o środowiskowych uwarunkowaniach);
ocena oddziaływania na środowisko (OOŚ); pozwolenia zintegrowane (IPPC);
odpowiedzialność za szkody środowiskowe; ochrona przyrody (obszary Natura 2000,
parki narodowe, rezerwaty); gospodarka odpadami (pozwolenia, nielegalne składowanie);
emisje i pozwolenia na wprowadzanie zanieczyszczeń; skargi na bezczynność RDOŚ / GDOŚ;
odpowiedzialność karna za przestępstwa przeciwko środowisku (KK art. 181–188).

---

## ZASADY ABSOLUTNE

1. **DECYZJA O ŚRODOWISKOWYCH UWARUNKOWANIACH (DŚU):**
   - Wymagana przed wydaniem m.in. pozwolenia na budowę, decyzji WZ dla przedsięwzięć
     mogących znacząco oddziaływać na środowisko (grupy I i II — Rozporządzenie OOŚ)
   - Organ: wójt / burmistrz / prezydent (z wyjątkami np. drogi krajowe → RDOŚ)
   - Odwołanie → SKO (14 dni) → WSA → NSA
2. **UDZIAŁ SPOŁECZEŃSTWA:** W postępowaniu OOŚ każdy może złożyć uwagi i wnioski
   (art. 29 UOOŚiS — Dz.U. 2026 poz. 670 t.j.). Organizacje ekologiczne mają prawa strony w postępowaniach
   dotyczących środowiska — mogą zaskarżyć decyzję do WSA.
3. **SZKODA ŚRODOWISKOWA (ustawa o zapobieganiu szkodom):**
   - Sprawca zobowiązany do działań zapobiegawczych / naprawczych
   - Organ: RDOŚ (lub starosta dla wód) nakazuje działania lub prowadzi je na koszt sprawcy
   - Odpowiedzialność niezależna od winy (zasada „zanieczyszczający płaci")
4. **ODPOWIEDZIALNOŚĆ KARNA (KK art. 181–188a) — Dz.U. 2025 poz. 383 t.j.:**
   - **Art. 181 §1 KK**: powodowanie zniszczeń w świecie roślinnym/zwierzęcym w znacznych rozmiarach → **6 miesięcy – 8 lat**
   - **Art. 182 §1 KK**: zanieczyszczenie wody/powietrza/ziemi w znacznych rozmiarach → **6 miesięcy – 8 lat**
   - **Art. 182 §3 KK**: jw. w związku z eksploatacją instalacji wymagającej pozwolenia → **1–10 lat**
   - **Art. 183 §1 KK**: nielegalne składowanie/przetwarzanie/transport odpadów zagrażające zdrowiu lub środowisku → **1–10 lat**
   - **Art. 183 §5 KK**: przywóz/wywóz odpadów niebezpiecznych bez zezwolenia → **2–12 lat**
   - **Art. 183 §5a KK**: porzucenie odpadów niebezpiecznych w miejscu niedozwolonym → **2–12 lat**
   - **Art. 183 §6 KK**: nieumyślne popełnienie czynów z §1–§5a → **grzywna / ograniczenie wolności / do 5 lat**
   - **Art. 185 §3 KK**: skutek śmiertelny lub ciężki uszczerbek u wielu osób → **3–20 lat** (typ kwalifikowany)
   - **Art. 186 §1 KK**: nieużywanie urządzeń zabezpieczających środowisko → **3 miesiące – 5 lat**
   - **Art. 188a KK**: dobrowolna naprawa szkody przez sprawcę → możliwość nadzwyczajnego złagodzenia / odstąpienie od kary
   ⚠️ Weryfikuj aktualne brzmienie w ISAP — artykuły KK były nowelizowane (nowelizacja 2022 r. znacznie zaostrzała kary).
5. **TERMINY ODWOŁAŃ:**
   - Odwołanie od decyzji środowiskowej → **14 dni** od doręczenia (KPA)
   - Skarga do WSA → **30 dni** od decyzji organu II inst.
   - Dla organizacji ekologicznych: te same terminy (po uzyskaniu statusu strony)

---

## KLUCZOWE AKTY PRAWNE — WERYFIKUJ W ISAP PRZED POWOŁANIEM

| Akt | Sygnatura t.j. / Uwagi |
|---|---|
| **Ustawa o udostępnianiu informacji o środowisku (UOOŚiS)** | **Dz.U. 2026 poz. 670 t.j.** ✅ [VER] RZĄD 1 2026-09-10g — obwieszczenie z 15.05.2026 (wcześniejszy zapis podawał datę 14.06.2024 — błędna), najnowszy. ⛔ KROK 2C (✅ [VER] RZĄD 1 2026-10-09 (ELI, daty z przepisów o wejściu w życie)): **2** nowelizacje po nim w mocy — Dz.U. 2026 poz. 1097 art. 3 (od 2.09.2026), 1157 art. 5 (od 16.09.2026); ⏳ 2026 poz. 875 art. 10 (od 1.01.2027) — OOŚ, DŚU, udział społeczeństwa |
| **Prawo ochrony środowiska (POŚ)** | **Dz.U. 2025 poz. 647 t.j.** ✅ [VER] RZĄD 1 2026-09-10g — najnowszy. ⛔ KROK 2C (✅ [VER] RZĄD 1 2026-10-09 (ELI, daty z przepisów o wejściu w życie)): **10** nowelizacji po tekście jednolitym w mocy — Dz.U. 2025 poz. 1080, 1812, 1863; 2026 poz. 426, 605, 607, 635, 912, 982, 1157 (art. 3, od 16.09.2026); ⏳ 2026 poz. 176 art. 11 (od 18.02.2027) (zapis z 2026-09-10g wymieniał 9; wcześniej tylko 2025/1812) — pozwolenia, emisje, IPPC |
| **Ustawa o odpadach** | **Dz.U. 2023 poz. 1587 t.j.** ✅ [VER] RZĄD 1 2026-09-10g — najnowszy tekst jednolity. ⛔ KROK 2C: **11** nowelizacji po nim — Dz.U. 2023 poz. 1597, 1688, 1852, 2029; 2024 poz. 1834, 1911, 1914; 2025 poz. 1812; 2026 poz. 174, 815 (od 4.07.2026 — art. 14: nowe brzmienie art. 25 ust. 6i pkt 2, odesłanie do wykazu z art. 6r ust. 1 ustawy o zarządzaniu kryzysowym); ⏳ 2026 poz. 875 (ELI: wejście w życie 1.01.2027) (wcześniejszy zapis wymieniał dwie, potem 10). Tekst jednolity z 2023 r. jest tu szczególnie zwodniczy |
| **Ustawa o ochronie przyrody** | **Dz.U. 2026 poz. 1315 t.j.** (ELI 2026-10-12) — najnowszy, ogł. 9.10.2026 (poprzednie: 2026 poz. 13, 2024 poz. 1478); obejmuje nowelizacje 2026 poz. 426, 737, 912; brak zmian po t.j. — parki, rezerwaty, Natura 2000, gatunki chronione |
| **Ustawa o zapobieganiu szkodom w środowisku i ich naprawie** | **t.j. Dz.U. 2020 poz. 2187** ✅ [VER] RZĄD 1 2026-09-10g — najnowszy, **ZERO** nowelizacji po tekście jednolitym (potwierdzone `/references`); poprzednio VER 2026-08-24 (ISAP WDU20200002187 — obwieszczenie Marszałka Sejmu z 18.11.2020, zastępuje t.j. Dz.U. 2019 poz. 1862) + RZĄD 2B (prawo.pl, infor.pl) + źródło rządowe (pgi.gov.pl). ⚠️ KOREKTA 2026-08-24 (F-125): wcześniej stało „Dz.U.2007.75.493 — **brak nowszego t.j.**” — twierdzenie NIEPRAWDZIWE, sprzeczne z własną mapą centralną, która od dawna oznaczała rocznik 2007 jako `PREV`. Zapis w notacji LEX ukrywał to przed testami T3/T11 (ślepota naprawiona przy F-125). ⚠️ NIEUSTALONE, czy po 2020 r. ogłoszono kolejny t.j. — zweryfikuj w ISAP przed powołaniem |
| **Kodeks karny art. 181–188a** | **Dz.U. 2025 poz. 383 t.j.** ✅ [VER] RZĄD 1 2026-09-10g — najnowszy. ⛔ KROK 2C: **4** nowelizacje po nim — Dz.U. 2025 poz. 1818, 1872; 2026 poz. 902, 988 |
| **KPA** | **Dz.U. 2025 poz. 1691 t.j.** ✅ [VER] RZĄD 1 2026-09-10g — najnowszy, zero nowelizacji po tekście jednolitym. Postępowanie przed organami ochrony środowiska |
| **Rozporządzenie OOŚ** | Rozporządzenie Rady Ministrów w sprawie przedsięwzięć — weryfikuj aktualny t.j. w isap |

---

## ORGANY I ŚCIEŻKA ODWOŁAWCZA

```
DECYZJA ŚRODOWISKOWA (DŚU):
Wójt / Burmistrz / Prezydent (I instancja — większość przedsięwzięć)
    ↓ odwołanie 14 dni
SKO (Samorządowe Kolegium Odwoławcze) — II instancja
    ↓ skarga 30 dni
WSA → NSA

RDOŚ (Regionalny Dyrektor Ochrony Środowiska):
    → I instancja dla dróg, linii kolejowych, strategicznych inwestycji
    → Opinie / uzgodnienia w postępowaniu OOŚ
Odwołanie → GDOŚ (Generalny Dyrektor Ochrony Środowiska)
    ↓ skarga do WSA

POZWOLENIA ZINTEGROWANE (IPPC / IED):
I instancja — **zależy od rodzaju instalacji** (art. 378 POŚ Dz.U. 2025 poz. 647):
  → **Marszałek Województwa** — instalacje IPPC mogące zawsze znacząco oddziaływać na środowisko, duże fermy, instalacje komunalne
  → **Starosta / Prezydent miasta na prawach powiatu** — pozostałe instalacje IPPC
  → RDOŚ — instalacje na terenach zamkniętych (wojskowych)
II instancja:
  → **Ministerstwo Klimatu i Środowiska** — gdy I inst. = Marszałek
  → **SKO** — gdy I inst. = Starosta
  → WSA → NSA
```

---

## MAPA ZAGADNIEŃ

### Nielegalne składowanie odpadów

```
Zawiadomienie do WIOŚ (Inspekcja Ochrony Środowiska) + RDOŚ
⭐ Struktura/kompetencje IOŚ (GIOŚ + 16 WIOŚ) → `mod-inspekcja-ochrony-srodowiska-GIOS-WIOS.md` (DR-09, nie duplikowane tutaj)
    ↓
Kontrola WIOŚ → mandat / decyzja nakazująca usunięcie
    ↓ odwołanie do Głównego Inspektora Ochrony Środowiska (GIOŚ)
    ↓ skarga do WSA
Roszczenie cywilne: odszkodowanie od sprawcy (art. 415 KC + ustawa o szk. środ.)
```

### Ochrona przyrody — Natura 2000

```
Inwestycja na obszarze Natura 2000
    → Obowiązek oceny habitatowej (art. 6 ust. 3 Dyrektywy Siedliskowej)
    → Organ: RDOŚ uzgadnia lub wydaje sprzeciw
    → Odwołanie: GDOŚ → WSA → NSA
    ⚠️ Naruszenie ochrony gatunkowej → KK art. 181 §1
```

---

## INTAKE — PYTANIA WSTĘPNE

```
□ Jaki problem? (decyzja środowiskowa / odpady / szkoda / ochrona przyrody / emisje)
□ Jaka inwestycja / działalność jest przedmiotem sprawy?
□ Jaki etap administracyjny? (wniosek / decyzja / odwołanie / WSA)
□ Jaki organ prowadzi postępowanie? (wójt / RDOŚ / WIOŚ / starosta)
□ Czy jest już decyzja i jaka data doręczenia? (termin odwołania!)
□ Czy sprawa dotyczy Natura 2000 / parku / rezerwatu?
□ Czy grozi odpowiedzialność karna (KK 181–188)?
□ Czy jesteś inwestorem, sąsiadem, organizacją ekologiczną?
```

---

## ŁĄCZ Z

| Sytuacja | Skill / Moduł |
|---|---|
| Odwołanie od DŚU / decyzji RDOŚ | `pisma-procesowe-v3` + `dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-KPA-postepowanie-administracyjne.md` |
| Skarga do WSA (środowiskowa) | `pisma-procesowe-v3` |
| Pozwolenie na budowę po DŚU | `dr-09-budownictwo-srodowisko-energia-transport/modules/mod-PrBud-prawo-budowlane.md` |
| Odpowiedzialność karna (KK 181–188) | `dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-art181-188a-przeciwko-srodowisku.md` + `dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-KPK-framework-karne.md` |
| Analiza szans (spór z RDOŚ / WIOŚ) | `analiza-sadowa-v6` |
| Orzecznictwo NSA / WSA (środowisko) | `orzeczenia-sadowe-v2` |

*⚠️ Moduł strategiczny — wszystkie przepisy i orzecznictwo wymagają weryfikacji
online w ISAP / orzeczenia.nsa.gov.pl / sn.pl przed powołaniem.*
*Weryfikacja: 22.05.2026 | UOOŚiS: Dz.U. 2024 poz. 1112 t.j. | POŚ: Dz.U. 2025 poz. 647 t.j. | Ochrona przyrody: Dz.U. 2026 poz. 1315 t.j. (ELI 2026-10-12) (poprzednie: 2026 poz. 13, 2024 poz. 1478) | KK: Dz.U. 2025 poz. 383 t.j.*
*Zakaz cytowania przepisów i kar z pamięci — każdy artykuł weryfikuj w ELI (RZĄD 1)*

---

## AKTUALIZACJA ISAP / ŚRODOWISKO — 2026-05-28

Dla decyzji środowiskowej, OOŚ, RDOŚ/GDOŚ, ochrony przyrody i Wód Polskich wczytaj
odpowiedni moduł lokalny (lazy loading — tylko właściwy do sprawy):

```text
view dr-09-budownictwo-srodowisko-energia-transport/modules/mod-ustawa-OOS-oceny-srodowiskowe.md
view dr-09-budownictwo-srodowisko-energia-transport/modules/mod-ustawa-lesna-lowiecka-ochrona-przyrody.md
view dr-09-budownictwo-srodowisko-energia-transport/modules/mod-PrWodne-gospodarka-sciekowa.md
```

Metryki kontrolne: Prawo ochrony środowiska — Dz.U. 2025 poz. 647 t.j. z koniecznością sprawdzenia zmian po t.j. (ELI 2026-10-12: m.in. 2026 poz. 605, 607, 635, 912, 982, 1157) (⛔ KOREKTA 2026-10-12: było „2026 poz. 670” — to t.j. ustawy o udostępnianiu informacji o środowisku); ustawa o ochronie przyrody — Dz.U. 2026 poz. 1315 t.j. (brak zmian po t.j., ELI 2026-10-12); Prawo wodne — Dz.U. 2025 poz. 960 ze zm. Dz.U. 2025 poz. 1535; 2026 poz. 445, 605, 815 (od 4.07.2026), 1033; ⏳ 1156 (od 1.01.2027).
