# mod-CQ-wodne-gospodarka-sciekowa.md — Prawo wodne, Wody Polskie i gospodarka ściekowa

**Akt:** PrBud (Prawo budowlane) — t.j. Dz.U. 2026 poz. 524 (zm. po t.j.: 2026/605 od 2026-05-21 — art. 64; 2026/646 od 2026-05-29 — art. 33; 2026/1161 od 2026-10-02 — art. 1, 2, 12, 96, 99; 2026/1347 od 2026-10-17 — art. 9, 9a).
**Akt:** UCPG (ustawa o utrzymaniu czystości i porządku w gminach) — t.j. Dz.U. 2025 poz. 733 (zm. po t.j.: 2026/912 od 2026-07-31 — art. 3, 4c, 4ca).
**Akt:** PrWod (Prawo wodne) — t.j. Dz.U. 2026 poz. 1335 (zm. po t.j.: 2026/1358 od 2026-11-03 — art. 16, 44, 45, 46, 46a, 47, 240, 344, 345, 346, 347).
**Akt:** UIOS (ustawa o Inspekcji Ochrony Środowiska) — t.j. Dz.U. 2024 poz. 425 (zm. po t.j.: 2025/1863 od 2026-01-13 — art. 2; 2026/1157 od 2026-09-16 — art. 2, 4a, 18).
**Akt:** KPA (Kodeks postępowania administracyjnego) — t.j. Dz.U. 2025 poz. 1691.
**Akt:** KK (Kodeks karny) — t.j. Dz.U. 2026 poz. 1342 (zm. po t.j.: 2026/1466 [OD 2026-11-21: 2026/1466] — art. 42, 84).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

Status: moduł prawa polskiego klasy wzorcowej. Stan metodyczny: 2026-05-28. Źródła prawa muszą być każdorazowo weryfikowane w ELI (RZĄD 1) / Dzienniku Ustaw; LEX/Legalis dopuszczalne pomocniczo przy braku praktycznego dostępu do aktu albo dla komentarza.

## 1. Akty i źródła do weryfikacji
- Prawo wodne
- ustawa o zbiorowym zaopatrzeniu w wodę i odprowadzaniu ścieków
- KPA/PPSA
- akty wykonawcze wodnoprawne

Nie cytuj literalnego brzmienia przepisu bez aktualnego sprawdzenia źródła. Przed użyciem artykułu ustal:

- akt i Dz.U.,
- status obowiązywania,
- wersję temporalną na dzień zdarzenia,
- wersję na dzień sporządzania pisma,
- przepisy przejściowe,
- właściwy organ i tryb zaskarżenia.

## 1a. OBOWIĄZEK PRZYŁĄCZENIA DO KANALIZACJI / SZAMBA (dodano
2026-07-27, na wyraźne żądanie użytkownika — dotąd CAŁKOWICIE
NIEOBECNE w tym module, mimo że to jeden z najczęstszych tematów
praktycznych w gospodarce ściekowej)

```
PODSTAWA: art. 5 ust. 1 pkt 2 ustawy z 13.09.1996 o utrzymaniu
  czystości i porządku w gminach (t.j. Dz.U. 2025 poz. 733; zm. 2026/912 od 2026-07-31 — tytuł rozdz. 2, art. 3 ust. 4, art. 4ca: związek metropolitalny pomorski) — "ucpg"

ZASADA: właściciel nieruchomości ma OBOWIĄZEK przyłączenia do
  ISTNIEJĄCEJ sieci kanalizacyjnej, JEŻELI sieć jest DOSTĘPNA —
  chyba że budowa sieci jest TECHNICZNIE lub EKONOMICZNIE
  NIEUZASADNIONA (wtedy: obowiązek wyposażenia w zbiornik
  bezodpływowy — szambo — LUB przydomową oczyszczalnię ścieków,
  art. 5 ust. 2)

⚠️ KLUCZOWA NIEŚCISŁOŚĆ DO UNIKANIA: USTAWA NIE OKREŚLA TERMINU, w
  którym właściciel MUSI wykonać przyłącze — wójt/burmistrz/prezydent
  NIE MOŻE wyznaczyć konkretnej DATY tego obowiązku (potwierdzone
  orzecznictwem sądów administracyjnych). Obowiązek istnieje "z mocy
  prawa" od momentu, gdy sieć staje się DOSTĘPNA, ale brak sztywnego
  kalendarza — EGZEKWOWANIE następuje przez decyzję administracyjną
  DOPIERO gdy gmina stwierdzi trwałe niewykonanie obowiązku (patrz
  procedura niżej), nie automatycznie w dniu X

⚠️ MYLONE Z TYM: DATA 15 CZERWCA 2026 — to NIE jest termin dla
  WŁAŚCICIELI nieruchomości (mimo alarmistycznych nagłówków medialnych)
  — to termin, do którego SAMORZĄDY muszą ZAKOŃCZYĆ I ROZLICZYĆ
  inwestycje wodno-kanalizacyjne finansowane z KPO. NIE nakłada
  bezpośrednio żadnego obowiązku na mieszkańca w tej konkretnej dacie.

JEDYNY WYJĄTEK zwalniający z obowiązku przyłączenia mimo dostępnej
  sieci: nieruchomość WYPOSAŻONA w PRZYDOMOWĄ OCZYSZCZALNIĘ ŚCIEKÓW
  spełniającą wymagania techniczne — ALE TYLKO jeśli oczyszczalnia
  została WYBUDOWANA I ODEBRANA PRZED pojawieniem się sieci
  kanalizacyjnej (prawo chroni już istniejące, legalne inwestycje;
  NIE MOŻNA budować oczyszczalni PO powstaniu sieci, żeby uniknąć
  przyłącza — organ odmówi/wniesie sprzeciw wobec zgłoszenia)
  ⚠️ ZWYKŁE SZAMBO (zbiornik bezodpływowy) NIE JEST oczyszczalnią —
  ten wyjątek GO NIE DOTYCZY, niezależnie od tego, jak szczelne/nowe

PROCEDURA EGZEKWOWANIA przy niewykonaniu obowiązku:
  1) DECYZJA ADMINISTRACYJNA wójta/burmistrza/prezydenta nakazująca
     wykonanie przyłącza w określonym w DECYZJI terminie (dopiero na
     TYM etapie pojawia się konkretna data)
  2) Odwołanie od decyzji — na zasadach ogólnych KPA
  3) Przy dalszym niewykonaniu → WYKONANIE ZASTĘPCZE: gmina zleca
     wykonanie przyłącza wybranej firmie NA KOSZT właściciela

KONTROLE GMINNE (obowiązek od nowelizacji 2022 r.): gminy mają
  obowiązek na bieżąco AKTUALIZOWAĆ EWIDENCJĘ zbiorników
  bezodpływowych i przydomowych oczyszczalni na swoim terenie,
  SPRAWOZDANIE ROCZNE do WIOŚ i dyrektora RZGW Wody Polskie — termin
  **30 KWIETNIA** za rok poprzedni. Właściciel kontrolowany musi
  okazać: UMOWĘ z przedsiębiorcą odbierającym nieczystości ORAZ
  DOWODY REGULARNEGO WYWOZU (rachunki/faktury potwierdzające
  częstotliwość zgodną z przepisami)

SANKCJE:
  → Gmina (za niedopełnienie obowiązku nadzoru/kontroli) — kara
    administracyjna do **50 000 zł**
  → Mieszkaniec (za brak umowy/dowodów wywozu, nieprawidłowości) —
    kara do **5 000 zł** (grzywna na zasadach KW, wymierzana w
    postępowaniu mandatowym lub przed sądem)
  → ⚠️ ODRĘBNA, DUŻO SUROWSZA sankcja dla umyślnego, nielegalnego
    POZBYWANIA SIĘ NIECZYSTOŚCI Z OMINIĘCIEM przepisów (np. nielegalne
    zrzuty do gruntu/wód) — może być kwalifikowane jako PRZESTĘPSTWO
    przeciwko środowisku z KK, NIE tylko wykroczenie — sprawdź
    kwalifikację w konkretnym stanie faktycznym, to INNA kategoria niż
    zwykłe niedopełnienie obowiązku administracyjnego

BUDOWA SZAMBA (zbiornika bezodpływowego) — WYMOGI FORMALNE:
  → Zbiorniki DO 10 m³ pojemności: BEZ pozwolenia na budowę, TYLKO
    ZGŁOSZENIE do organu architektoniczno-budowlanego (starostwo/urząd
    miasta na prawach powiatu) — art. 29 ust. 1 pkt 3 w zw. z art. 30
    ust. 1 PrBud
  → ODLEGŁOŚCI (rozporządzenie ws. warunków technicznych budynków —
    ⛔ rozp. z 12.04.2002 nie obowiązuje od 20.09.2026; nowe — brak
    w ELI na 2026-10-04 (F-224); przejściowo art. 102a–102b PrBud,
    Dz.U. 2026 poz. 1161 → `mod-PrBud-uzupelnienie-pokrycia-2026` § 9a):
    min. **5 M** od okien/drzwi zewnętrznych budynków przeznaczonych
    na pobyt ludzi; min. **2 M** od granicy działki sąsiedniej

Potwierdzone w 7+ zgodnych źródłach z 2024-2026 (blog.ongeo.pl [15.06.
2026 — sprostowanie medialnych alarmów], portalsamorzadowy.pl [x2],
agrofakt.pl, farmer.pl, wodkangaz.com, szambo.online).
```

## 1b. AWARYJNE DOSTAWY WODY (BECZKOWÓZ) — dodano 2026-07-27, na
wyraźne żądanie użytkownika (dotąd nieobecne)

```
PODSTAWA: art. 3 ust. 1 ustawy o zbiorowym zaopatrzeniu w wodę —
  zbiorowe zaopatrzenie w wodę jest ZADANIEM WŁASNYM GMINY. Gmina NIE
  MOŻE "umyć rąk" od problemu braku wody — musi zapewnić KAŻDEMU
  mieszkańcowi REALNĄ możliwość dostępu do wody do spożycia (prawo do
  wody = potrzeba bytowa, fundamentalne prawo człowieka, NIE MOŻE
  być całkowicie odebrane)

DWIE GŁÓWNE SYTUACJE WYMAGAJĄCE ZASTĘPCZEGO PUNKTU POBORU (beczkowóz
LUB ogólnodostępny hydrant):

1) ODCIĘCIE ZA ZALEGŁOŚCI PŁATNICZE:
   → Przesłanka: brak zapłaty za DWA PEŁNE OKRESY OBRACHUNKOWE
   → Warunek WSTĘPNY: wcześniejsze UPOMNIENIE — termin biegnie
     DOPIERO od doręczenia upomnienia zalegającemu
   → Termin PRZED faktycznym odcięciem: informacja o ZAMIARZE
     odcięcia ORAZ o sposobie udostępnienia punktu zastępczego —
     CO NAJMNIEJ **20 DNI** przed odcięciem
   → OBOWIĄZEK przedsiębiorstwa: mimo odcięcia regularnego przyłącza,
     MUSI udostępnić ZASTĘPCZY punkt poboru (najczęściej beczkowóz,
     czasem ogólnodostępny hydrant) — zapewniający MINIMUM SANITARNE
   → ⚠️ Odbiorcy w budynkach WIELOLOKALOWYCH: umowa jest zawierana ZE
     WSPÓLNOTĄ/SPÓŁDZIELNIĄ/ZARZĄDCĄ, NIE z indywidualnym mieszkańcem
     — mieszkaniec NIE JEST bezpośrednim "odbiorcą usług" w rozumieniu
     ustawy, co ma znaczenie przy analizie kto może być odcięty

2) SYTUACJA KRYZYSOWA (awaria sieci, skażenie, klęska żywiołowa, akt
   terrorystyczny, zagrożenie bezpieczeństwa kraju):
   → Gminy/przedsiębiorstwa wodociągowe powinny dysponować PLANAMI
     REAGOWANIA KRYZYSOWEGO z określonym minimalnym i niezbędnym
     zapotrzebowaniem na wodę
   → ⚠️ REALNY PROBLEM WDROŻENIOWY (potwierdzony raportem NIK):
     kontrole wykazały, że przedsiębiorstwa wodociągowe, prezydenci
     miast I wojewodowie CZĘSTO NIE DYSPONUJĄ aktualnymi informacjami
     o całkowitym zapotrzebowaniu na wodę w razie zdarzenia
     kryzysowego — SYSTEMOWA LUKA w praktyce, nie tylko w teorii
     przepisów, WARTA odnotowania przy doradzaniu jednostkom
     samorządu/przedsiębiorstwom wodociągowym o obowiązkach
     planistycznych
   → Podstawa formalna: rozporządzenie ws. zapewnienia funkcjonowania
     publicznych urządzeń zaopatrzenia w wodę w warunkach specjalnych
     (M.P. — dokładny numer i pozycja do zweryfikowania na ISAP przed
     cytowaniem)

Potwierdzone w 5+ zgodnych źródłach (lexlege.pl — dosłowny tekst
ustawy, infor.pl, witrynawiejska.org.pl [12.05.2026], raport NIK
[nik.gov.pl]).
```

## 2. Zakres spraw
- pozwolenie wodnoprawne
- zgłoszenie wodnoprawne
- opłaty za usługi wodne
- kary
- Wody Polskie
- spory taryfowe
- ścieki

## 3. Intake
Ustal obowiązkowo:

1. kto jest stroną / uczestnikiem / funkcjonariuszem / organem,
2. jaki akt, czynność albo zaniechanie jest kwestionowane,
3. data czynności, doręczenia, powzięcia wiadomości i termin do reakcji,
4. organ pierwszej instancji i organ odwoławczy,
5. czy sprawa jest administracyjna, cywilna, karna, dyscyplinarna, służbowa albo mieszana,
6. czy istnieje dokument urzędowy: decyzja, postanowienie, zarządzenie, protokół, notatka, polecenie, uchwała,
7. czy zachodzi ryzyko prekluzji, przedawnienia, bezczynności albo bezskuteczności środka.

## 4. Mapa proceduralna
Stosuj ścieżkę:

`zdarzenie/czynność → kwalifikacja prawna → właściwość organu → środek zwykły → środek nadzwyczajny → kontrola sądowa → wykonanie rozstrzygnięcia → odpowiedzialność odszkodowawcza/dyscyplinarna`

W sprawach publicznoprawnych zawsze rozważ równolegle:

- środek w toku sprawy,
- skargę na bezczynność/przewlekłość,
- wniosek o wstrzymanie wykonania,
- zabezpieczenie dowodów,
- odpowiedzialność funkcjonariusza/organu,
- dostęp do akt i informacji publicznej,
- ochronę danych osobowych i informacji niejawnych.

## 5. Warunki skuteczności
Sprawdź:

- termin,
- właściwość organu/sądu,
- legitymację,
- interes prawny albo faktyczny,
- podpis,
- pełnomocnictwo,
- opłatę,
- odpisy,
- załączniki,
- dowód doręczenia,
- wskazanie żądania,
- wskazanie zarzutów,
- relację dowód → fakt → norma.

## 6. Matryca dowodowa
Dla każdego faktu zbuduj tabelę:

| Fakt | Dowód | Źródło | Siła | Luka | Ryzyko |
|---|---|---|---|---|---|

Typowe dowody:

- decyzje, postanowienia, protokoły, notatki, zarządzenia,
- korespondencja z organem,
- nagrania, zdjęcia, logi, metadane,
- zeznania świadków,
- dokumentacja medyczna/techniczna/księgowa,
- opinie biegłych,
- akty prawa miejscowego,
- wydruki z BIP, rejestrów, systemów publicznych.

## 7. Zarzuty typowe
Rozważ co najmniej:

- naruszenie właściwości,
- naruszenie prawa do udziału w sprawie,
- brak podstawy prawnej,
- błędna wykładnia przepisu,
- dowolna ocena dowodów,
- brak uzasadnienia,
- nieproporcjonalność,
- nierówne traktowanie,
- naruszenie zaufania do organu,
- naruszenie terminów,
- brak rozpoznania istoty sprawy,
- pominięcie dowodu,
- wadliwe pouczenie.

## 8. Kontrargumenty organu / strony przeciwnej
Przewiduj:

- formalny brak legitymacji,
- spóźnienie środka,
- brak interesu prawnego,
- domniemanie prawidłowości dokumentu urzędowego,
- uznaniowość organu,
- tajemnicę ustawowo chronioną,
- bezpieczeństwo publiczne,
- brak szkody albo związku przyczynowego,
- nieadekwatność środka.

## 9. Strategia
Priorytety:

1. zabezpiecz termin i dowód doręczenia,
2. uzyskaj akta i pełną podstawę rozstrzygnięcia,
3. oddziel zarzuty formalne od materialnych,
4. wskaż fakty decydujące, nie wszystkie fakty,
5. buduj żądanie główne i ewentualne,
6. przygotuj wariant: organ → sąd administracyjny/cywilny/karny/dyscyplinarny,
7. oceń, czy korzystniejsze jest uchylenie, zmiana, stwierdzenie nieważności, wznowienie, odszkodowanie lub skarga.

## 10. Orzecznictwo
Nie wpisuj fikcyjnych sygnatur. Szukaj tylko realnych orzeczeń w:

- SN / NSA / TK,
- CBOSA,
- Portalu Orzeczeń Sądów Powszechnych,
- orzeczeniach sądów dyscyplinarnych, jeżeli publicznie dostępne,
- LEX/Legalis pomocniczo.

Każde orzeczenie oceniaj według: aktualność, hierarchia sądu, analogiczność stanu faktycznego, linia dominująca/odmienna.

## 11. Ryzyka
Oceń:

- ryzyko zwrotu/odrzucenia,
- ryzyko spóźnienia,
- ryzyko braku legitymacji,
- ryzyko niewykazania faktu,
- ryzyko niedopuszczalności dowodu,
- ryzyko uznania organu,
- ryzyko kosztowe,
- ryzyko retorsji służbowej/dyscyplinarnej,
- ryzyko równoległych postępowań.

## 12. Quality gate
Przed odpowiedzią lub pismem zastosuj:

- `prawo-polskie-v2/krajowe/shared/POLISH-LAW-FINAL-COMPLETENESS-GATE.md`,
- `shared/ISAP-AUDIT-PROTOCOL.md`,
- `shared/TEMPORAL-LAW-CHECK.md`,
- `shared/LEGAL-QUALITY-GATE.md`,
- `shared/RISK-ASSESSMENT.md`, jeżeli istnieje,
- `prawo-polskie-v2/krajowe/shared/FORMAL-CHECK.md`, jeżeli powstaje pismo.

---

## QUALITY GATE

- [ ] Aktualny tekst t.j. aktu zweryfikowany w ISAP?
- [ ] Wersja temporalna: stan prawny na dzień zdarzenia i na dzień orzekania?
- [ ] Właściwy organ (zarząd/decyzja/kontrola) ustalony?
- [ ] Termin na odwołanie (14 dni) i na skargę do WSA (30 dni) obliczony?
- [ ] Brzmienie przepisów ze źródeł, nie z pamięci modelu?
- [ ] Ryzyka formalne i procesowe ocenione?

## OUTPUT

1. Stan faktyczny; 2. Kwalifikacja prawna; 3. Stan prawny (Dz.U. z ISAP); 4. Terminy;
5. Przesłanki; 6. Matryca dowodowa; 7. Zarzuty i kontrargumenty;
8. Strategia (ostrożny/ofensywny/eskalacyjny); 9. Ryzyka; 10. Rekomendacja.

**Status:** moduł klasy kancelaryjnej — poziom DR-03
**Data weryfikacji:** 2026-06-05

## WERYFIKACJA Dz.U.

```
Prawo wodne: Dz.U. 2026 poz. 1335 t.j. (obwieszczenie 17.09.2026, ogł. 14.10.2026) ✅ [VER] RZĄD 1 2026-10-15 (ELI); brak zmian po t.j. do 2026-10-15; ⚡ po t.j.: **Dz.U. 2026 poz. 1358** (ustawa z 4.09.2026 o zmianie ustawy – Prawo wodne, ogł. 19.10.2026, w mocy 3.11.2026; tekst odczytany ✅ [VER: ELI DU/2026/1358 text.pdf, RZĄD 1, 2026-10-20] — zmienia WYŁĄCZNIE przepisy o kąpieliskach (wdrożenie dyr. 2006/7/WE): art. 16 pkt 15a, 23, 50c (definicje: duża liczba kąpiących się, klasyfikacja wody w kąpielisku, stały zakaz kąpieli), art. 44 ust. 4, art. 45 ust. 2, nowy art. 46a, art. 47 ust. 2 pkt 5, art. 240 ust. 3 pkt 14a, art. 344 ust. 5 pkt 9–10 (sinice, makroalgi), art. 345 ust. 1–2 (harmonogram próbek), art. 346 ust. 1, 6, 7, 9, art. 347 ust. 2a i 3; ⛔ gospodarki ściekowej i opłat nie dotyczy — żaden moduł korpusu nie obejmuje kąpielisk) ✅ [VER] RZĄD 1 2026-10-20 (metadane ELI DU/2026/1358, `Akty zmieniające` DU/2017/1566); t.j. obejmuje 2025/1535, 2026/445, 605, 815 (od 4.07.2026 — art. 18: art. 240 ust. 3 pkt 24), 1033 oraz 2026/1156 (w tekście jako brzmienie od 1.01.2027) (⛔ KOREKTA: było „2024 poz. 1773” — t.j. ustawy o minimalnym wynagrodzeniu)
  Metrum kontrolne: Dz.U. 2026 poz. 1335 — weryfikuj w ELI (RZĄD 1) czy jest nowszy t.j. (poprzedni t.j. 2025/960)
  ✅ VER: isap.sejm.gov.pl 2026-06-05
  → Źródło: https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20241773
Wody Polskie: https://wody.gov.pl
```
