# mod-DY — Geodezja, kartografia, wywłaszczenia i gospodarka nieruchomościami

**Akt:** PrEn (Prawo energetyczne) — t.j. Dz.U. 2026 poz. 43 (zm. po t.j.: 2026/516 od 2026-04-30 — art. 2, 3, 4, 4j, 5, 5ad, 5ga, 5gb, 6g, 6h, 6i, 7, 16, 31d, 49, 71, 72, 306i, 777; 2026/607 od 2026-05-21 — art. 23r, 35; 2026/900 od 2026-07-21 — art. 3, 3a, 4j, 5, 7, 7b, 11, 23, 32, 33, 43, 45, 46, 47, 54, 62c; 2026/1348 od 2026-10-17 — art. 3, 4k, 7, 9g, 9j, 9ja, 11, 11t, 11y, 11zc, 11zh, 11zha, 20d, 20e, 20f, 28, 32d, 43c, 56; 2026/1347 [OD 2026-12-01: 2026/1347] — art. 3, 7, 7a, 9g, 16, 23, 56).
**Akt:** PrGeod (Prawo geodezyjne i kartograficzne) — t.j. Dz.U. 2026 poz. 1389.
**Akt:** UGN (ustawa o gospodarce nieruchomościami) — t.j. Dz.U. 2026 poz. 399 (zm. po t.j.: 2026/912 od 2026-07-31 — art. 10; 2026/875 [OD 2027-01-01: 2026/875] — art. 93).
**Akt:** UPZP (ustawa o planowaniu i zagospodarowaniu przestrzennym) — t.j. Dz.U. 2026 poz. 538 (zm. po t.j.: 2026/781 od 2026-07-01 — art. 1, 2, 8f, 8g, 8h, 14, 15, 17, 20, 37ea, 37eb, 37eba, 37ebb, 37ec, 37ed, 37ee, 37eea, 37ef, 37efa, 37g; 2026/912 od 2026-07-31 — art. 8e, 17, 38b; 2026/864 od 2026-10-01 — art. 53).
**Akt:** ZRID (specustawa drogowa — ustawa o szczególnych zasadach przygotowania i realizacji inwestycji w zakresie dróg publicznych) — t.j. Dz.U. 2024 poz. 311.
**Akt:** KC (Kodeks cywilny) — t.j. Dz.U. 2026 poz. 795.
**Akt:** KPA (Kodeks postępowania administracyjnego) — t.j. Dz.U. 2025 poz. 1691.
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

## Status modułu

Moduł prawa polskiego klasy eksperckiej. Stosować analogicznie do modułów prawa pracy i prawa karnego: intake → akty prawne → procedura → dowody → strategia → ryzyka → orzecznictwo → checklisty → workflow.

## Źródła prawa i kontrola aktualności

Podstawą jest ISAP. Brzmienie przepisu, Dz.U., status aktu, tekst jednolity, nowelizacje i przepisy przejściowe muszą być sprawdzone w ISAP na dzień użycia. LEX/Legalis można użyć pomocniczo, gdy ISAP nie daje bezpośredniego dostępu do aktu albo gdy potrzebny jest komentarz/praktyka.

✅ ELI 2026-11-11: Prawo geodezyjne i kartograficzne — t.j. Dz.U. 2026 poz. 1389 (obwieszczenie
18.09.2026, stan na 17.09.2026); obejmuje Dz.U. 2024 poz. 1824, 2025 poz. 1019 (mObywatel), 1542
i 1792 (statystyka publiczna); poza t.j. art. 3 ustawy 2024/1824. Poprzedni t.j. 2024.1151.
✅ FAZA 3E ZAMKNIĘTA 2026-08-20 (F-40): po korekcie numerów t.j. (Prawo
geodezyjne 2023.1752→2024.1151 t.j.; UGN 2024.1899→2026.399 t.j.)
sprawdzono nowelizacje międzyokresowe. Prawo geodezyjne: 2 nowelizacje
techniczne (Dz.U. 2024 poz. 1824 — wydłużenie vacatio dla map wektorowych do
2027; Dz.U. 2025 poz. 1542 — porządkowanie tabel opłat/zakresu zbiorów
danych/rejestru cen nieruchomości) — ŻADNA nie dotyka treści
wywłaszczeniowej/gospodarki nieruchomościami opisanej w tym module. UGN:
przegląd obwieszczenia o t.j. 2026.399 wskazuje na nowelizacje techniczne
(wprowadzenie Prawa komunikacji elektronicznej, przepisy powodziowe,
Prawo energetyczne, mieszkalnictwo społeczne) — rdzeń przepisów o
wywłaszczeniu (art. 112-113 i dalsze) POTWIERDZONY jako niezmieniony w
treści cytowanej (przepisy.gofin.pl). Treść modułu POTWIERDZONA jako
aktualna mimo zmiany numerów t.j. obu aktów.

### Akty do sprawdzenia
- Prawo geodezyjne i kartograficzne;
- ustawa o gospodarce nieruchomościami;
- ustawy drogowe/specustawy inwestycyjne;
- KPA/PPSA/KPC;
- przepisy o księgach wieczystych, planowaniu, budowlane i środowiskowe — zależnie od sprawy.

## Zakres spraw
Ewidencja gruntów i budynków, granice, podziały, rozgraniczenie, wywłaszczenie, odszkodowanie, użytkowanie wieczyste, trwały zarząd, zajęcia pod inwestycje, decyzje ZRID i specustawy.

## WYWŁASZCZENIE — ODSZKODOWANIE I ZWROT (dodano 2026-07-27, na żądanie
użytkownika — dotąd wspomniane tylko jako pojęcie, bez konkretnej treści)

```
PODSTAWA: art. 112-142 ustawy o gospodarce nieruchomościami (ugn),
  Dz.U. 2026 poz. 399 t.j. — WYWŁASZCZENIE dopuszczalne TYLKO na cele
  publiczne i za "słusznym odszkodowaniem" (zasada konstytucyjna)

ODSZKODOWANIE:
  → Wysokość: RÓWNA WARTOŚCI RYNKOWEJ wywłaszczanego prawa (art. 128
    ust. 1 ugn) — na podstawie AKTUALNEGO operatu szacunkowego
    rzeczoznawcy (orzecznictwo NSA: odszkodowanie MUSI być oparte na
    aktualnym operacie, nie historycznym)
  → Pomniejszenie: o wartość innych praw rzeczowych obciążających
    nieruchomość (np. użytkowanie wieczyste JST)
  → Organ ustalający: STAROSTA (zadanie z zakresu administracji
    rządowej), w decyzji o wywłaszczeniu LUB decyzji odrębnej
  → Możliwa nieruchomość ZAMIENNA zamiast/obok odszkodowania
    pieniężnego, z dopłatą różnicy wartości

ZWROT WYWŁASZCZONEJ NIERUCHOMOŚCI (art. 136-142 ugn):
  → WARUNEK: cel wywłaszczenia NIE ZOSTAŁ ZREALIZOWANY (nieruchomość
    stała się zbędna na cel określony w decyzji)
  → Termin na złożenie WNIOSKU o zwrot: **3 MIESIĄCE** od otrzymania
    zawiadomienia od starosty o zbędności nieruchomości (art. 136
    ust. 3) — TERMIN ZAWITY, po jego upływie prawo do zwrotu WYGASA
  → WARUNEK ZWROTU: poprzedni właściciel/spadkobierca musi ZWRÓCIĆ
    otrzymane odszkodowanie (lub nieruchomość zamienną + ew. dopłatę),
    proporcjonalnie przy zwrocie udziału — WARTOŚĆ przeliczana na
    dzień ZWROTU (nie dzień wywłaszczenia), bez uwzględnienia zmian
    MPZP i otoczenia
  → Organ: STAROSTA wydaje decyzję o zwrocie (art. 141 ust. 1)
  → ⚠️ WAŻNE ZASTRZEŻENIE (uchwała 7 sędziów NSA z 13.04.2015, I OPS
    3/14): jeśli Skarb Państwa/JST ZBYŁO nieruchomość osobie trzeciej
    Z POMINIĘCIEM procedury zawiadomienia o zbędności — to może być
    PODSTAWĄ ODMOWY zwrotu (nie automatycznie nieważność zbycia) —
    złożona, sporna materia orzecznicza, wymaga analizy konkretnego
    stanu faktycznego
  → Jeśli nieruchomość ISTOTNIE PRZEKSZTAŁCONA (np. zabudowana
    infrastrukturą publiczną) — zamiast zwrotu w naturze może
    przysługiwać ODSZKODOWANIE za utratę możliwości odzyskania

Potwierdzone w 6+ zgodnych źródłach (lexlege.pl — dosłowny tekst ugn,
inlegis.pl, sk-kancelaria.com.pl, wywlaszczenie.pl).
```

## PRAWO PIERWOKUPU — KODEKSOWE I ROLNE (dodano 2026-07-27, na żądanie
użytkownika — dotąd NIEOBECNE w systemie jako odrębny temat)

```
PIERWOKUP KODEKSOWY (ogólny, art. 596-602 KC):
  → Termin wykonania: **1 MIESIĄC** od otrzymania zawiadomienia o
    warunkowej umowie sprzedaży, CHYBA że inny termin zastrzeżono w
    umowie/ustawie szczególnej
  → Forma: oświadczenie uprawnionego w formie AKTU NOTARIALNEGO
  → Sprzedaż BEZWARUNKOWA mimo istniejącego prawa pierwokupu = zasadniczo
    NIEWAŻNA (sprzedawca musi zawrzeć umowę WARUNKOWĄ, dającą
    uprawnionemu szansę wykonania pierwokupu)

PIERWOKUP NIERUCHOMOŚCI ROLNEJ (ustawa z 11.04.2003 o kształtowaniu
  ustroju rolnego, art. 3-9) — HIERARCHIA UPRAWNIONYCH:
  1) DZIERŻAWCA nieruchomości rolnej — TYLKO gdy ŁĄCZNIE spełnione:
     a) umowa dzierżawy w FORMIE PISEMNEJ z DATĄ PEWNĄ,
     b) wykonywana NIEPRZERWANIE CO NAJMNIEJ 3 LATA licząc od daty pewnej,
     c) nabywana nieruchomość wchodzi w skład GOSPODARSTWA RODZINNEGO
        dzierżawcy
     Po WYGAŚNIĘCIU dzierżawy — BYŁY dzierżawca CO DO ZASADY TRACI
     to uprawnienie
  2) KOWR (Krajowy Ośrodek Wsparcia Rolnictwa, działający na rzecz
     Skarbu Państwa) — gdy BRAK uprawnionego dzierżawcy LUB dzierżawca
     NIE WYKONAŁ swojego prawa
     → Próg WEJŚCIA w reżim ustawy: nieruchomość rolna o powierzchni
       użytków rolnych **≥0,3 ha** (poniżej — ustawa NIE MA zastosowania)
     → Termin na oświadczenie KOWR: **1 MIESIĄC** od otrzymania
       zawiadomienia (notariusz zawiadamia AUTOMATYCZNIE — strony NIE
       muszą same informować KOWR)
     → WYŁĄCZENIE prawa KOWR: gdy nabycie POWIĘKSZA gospodarstwo
       rodzinne nabywcy DO POWIERZCHNI NIE WIĘKSZEJ niż 300 ha, a
       nieruchomość leży w gminie zamieszkania nabywcy LUB gminie
       SĄSIEDNIEJ
     → Jeśli cena w umowie RAŻĄCO ODBIEGA od wartości rynkowej — KOWR
       może w terminie **14 DNI** wystąpić do SĄDU o ustalenie ceny
  → Naruszenie procedury (brak zawiadomienia uprawnionego) → nabycie
    MOŻE BYĆ NIEWAŻNE (art. 9 ustawy) — w tym nabycie oparte na
    nieprawdziwych oświadczeniach

Potwierdzone w 6+ zgodnych źródłach (wir.org.pl, notariusz-
duszkiewicz.pl, praworolne.info, poradyprawne-taurus.pl, dzialkanad-
morzem.pl) — wszystkie zgodne co do progów, terminów i hierarchii.
```

## DZIERŻAWA (dodano 2026-07-27, na żądanie użytkownika — dotąd
BRAK odrębnego opracowania w całym systemie, tylko wzmianki poboczne)

```
PODSTAWA KODEKSOWA: art. 693-709 KC (odesłanie do przepisów o najmie
  w zakresie nieuregulowanym odrębnie, z modyfikacjami)

KLUCZOWE ODRĘBNOŚCI od najmu:
  → Dzierżawca ma prawo do POBIERANIA POŻYTKÓW z rzeczy (nie tylko
    używania) — to ISTOTA dzierżawy, odróżniająca ją od najmu
  → Czynsz MOŻE być zastrzeżony w PIENIĄDZACH LUB W ŚWIADCZENIACH
    INNEGO RODZAJU (np. część plonów — dzierżawa rolna)
  → Wypowiedzenie: przy dzierżawie GRUNTU ROLNEGO — jeśli czas
    trwania NIE OZNACZONO, wypowiedzenie na JEDEN ROK NAPRZÓD, na
    koniec roku dzierżawnego (art. 704 KC, chyba że zwyczaj miejscowy
    stanowi inaczej); przy INNEJ dzierżawy — na 6 miesięcy naprzód
    (art. 704 KC odczytywany a contrario dla nieokreślonego czasu)

⚠️ POWIĄZANIE Z PRAWEM PIERWOKUPU (patrz sekcja wyżej): dzierżawca
  NIERUCHOMOŚCI ROLNEJ, przy spełnieniu warunków formy pisemnej+daty
  pewnej+3-letniego stażu+gospodarstwa rodzinnego, ma USTAWOWE prawo
  pierwokupu PRZED KOWR — to NAJWAŻNIEJSZE praktyczne powiązanie
  dzierżawy z resztą systemu (dziedziczenie gospodarstw rolnych,
  planowanie sukcesji)

⚠️ TEN MODUŁ POKRYWA DZIERŻAWĘ WYŁĄCZNIE W KONTEKŚCIE NIERUCHOMOŚCI
  (rolnych/gruntowych) I POWIĄZANIA Z PIERWOKUPEM — pełna, systematyczna
  analiza dzierżawy jako TYPU UMOWY CYWILNEJ (dzierżawa
  przedsiębiorstwa, dzierżawa praw, szczegóły przedawnienia roszczeń
  z czynszu itd.) NIE była dotąd opracowana w żadnym module DR-02 —
  ODNOTOWANE JAKO TODO na przyszłość, jeśli potrzebne pełne pokrycie
  cywilnoprawne dzierżawy poza kontekstem nieruchomości rolnych.
```

## Organy i ścieżki instancyjne
Starosta, wojewoda, wójt/burmistrz/prezydent, geodeta powiatowy, WSA/NSA, sąd cywilny przy własności i rozgraniczeniach.

## Intake — pytania obowiązkowe

1. Jaki jest organ, sąd albo podmiot prowadzący sprawę?
2. Czy istnieje decyzja, postanowienie, czynność faktyczna, zaniechanie albo akt wewnętrzny?
3. Jaka jest data doręczenia albo data dowiedzenia się o czynności?
4. Jaki środek prawny jest właściwy i czy termin jeszcze biegnie?
5. Czy sprawa ma komponent karny, cywilny, administracyjny, dyscyplinarny, RODO, UE albo konstytucyjny?
6. Jakie dokumenty pierwotne istnieją, a jakie są tylko relacją strony?
7. Czy występuje tajemnica prawnie chroniona, dane osobowe, informacja niejawna albo ograniczony dostęp do akt?
8. Jaki jest cel klienta: uchylenie aktu, odszkodowanie, zabezpieczenie, dostęp do informacji, wstrzymanie wykonania, odpowiedzialność osoby, dowód do innej sprawy?

## Procedura
Najpierw rozdziel stan ewidencyjny od stanu prawnego. EGiB nie przesądza własności. Przy wywłaszczeniu sprawdź decyzję lokalizacyjną, operat szacunkowy, doręczenia, krąg stron i termin odwołania.

## Dowody
Dowody: mapa, wypis/wyrys, KW, decyzje, operat szacunkowy, dokumentacja geodezyjna, protokoły graniczne, zdjęcia, opinie biegłych, MPZP/WZ, dokumenty inwestycji.

## Strategia procesowa
Strategia: w sporach granicznych zabezpieczyć dokumenty geodezyjne historyczne. Przy odszkodowaniu atakować operat, datę stanu i wartość. Przy specustawach pilnować krótkich terminów i skutków wykonalności.

## Ryzyka
Ryzyka: mylenie KW z EGiB, pominięcie współwłaściciela, prawomocność decyzji, związanie organu operatem, niedopuszczalność drogi cywilnej lub administracyjnej w danym fragmencie.

## Orzecznictwo i praktyka
Orzecznictwo: NSA przy EGiB, podziałach i wywłaszczeniach; SN przy własności, zasiedzeniu, rozgraniczeniu i odszkodowaniach.

## Checklisty jakości

- ustal aktualny stan prawny w ISAP;
- odróżnij akt powszechnie obowiązujący od aktu wewnętrznego;
- sprawdź właściwość organu i tryb;
- sprawdź termin i sposób doręczenia;
- oznacz ciężar dowodu;
- wskaż fakty kluczowe i fakty niewykazane;
- oddziel zarzuty formalne od materialnych;
- dodaj wnioski dowodowe tylko powiązane z tezami;
- sprawdź możliwość wstrzymania wykonania lub zabezpieczenia;
- sprawdź kolizję z innymi postępowaniami.

## Powiązania shared

- `shared/ISAP-AUDIT-PROTOCOL.md`
- `shared/TEMPORAL-LAW-CHECK.md`
- `shared/LEGAL-KNOWLEDGE-GRAPH.md`
- `shared/CROSS-DOMAIN-CONFLICT-ROUTER.md`
- `shared/POLISH-LAW-MAX-COVERAGE-STANDARD.md`
- `shared/RISK-ASSESSMENT.md`
- `shared/DOWODY-METODOLOGIA.md`

## Uwagi szczególne
Moduł łączyć z nieruchomościami, budowlanym, planistycznym i środowiskowym.
