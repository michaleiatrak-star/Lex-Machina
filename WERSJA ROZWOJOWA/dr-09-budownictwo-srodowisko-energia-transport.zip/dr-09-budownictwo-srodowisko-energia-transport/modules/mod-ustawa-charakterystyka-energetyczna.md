# Moduł — Charakterystyka energetyczna budynków i certyfikaty energetyczne

**Akt:** UCEB (ustawa o charakterystyce energetycznej budynków) — t.j. Dz.U. 2024 poz. 101.
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

## Akt prawny / źródło
- Ustawa o charakterystyce energetycznej budynków — t.j. **Dz.U. 2024 poz. 101** ze zm. — ✅ [VER] RZĄD 1 2026-09-16d
  (⛔ poprzedni zapis `2024 poz. 544` to rozporządzenie MON — podmiana aktu)
  ✅ [VER: isap.sejm.gov.pl, 2026-05-31]
- Dyrektywa EPBD (2010/31/UE + rewizja 2024/1275/UE — EPBD recast)
  ✅ [VER: EUR-Lex, 2026-05-31]

**Weryfikacja:** ELI (RZĄD 1) i EUR-Lex przed każdym cytowaniem.

## Zakres
Certyfikat energetyczny: obowiązkowy przy sprzedaży lub najmie budynku/lokalu
(art. 11 u.ch.e.b.). Skala A–G (klasy energetyczne). Centralny rejestr certyfikatów
(portal BEP, prowadzony przez GUNB).

EPBD recast (2024): Dyrektywa zobowiązuje do stopniowego wygaszenia budynków klasy F i G
do 2030/2033. Nowe budynki od 2028 (publiczne) i 2030 — NZEB (Nearly Zero Energy Building).
Polska musi wdrożyć do 2026 r.

## Zasady absolutne
```
Obowiązek:    Przy każdej transakcji sprzedaży/najmu — kara za brak: 5000 zł
Uprawnienie:  Certyfikator — egzamin + wpis do rejestru (GUNB)
Ważność:      10 lat od wystawienia
Nowe budynki: Obowiązek spełnienia wymagań EP (wskaźnik nieodnawialnej energii)
```

## Dyrektywa EPBD recast 2024 (nowe!)
```
Dz.Urz. UE L 2024/1275 — wejście w życie 28.05.2024
Transpozycja: Polska ma czas do 29.05.2026
Kluczowe: Klasy A-G na europejskiej skali; plan renowacji budynków; MEPS (min. standardy)
```

## Weryfikacja online
```
web_search: "ustawa charakterystyka energetyczna budynków certyfikat Dz.U. 2024 poz. 101"
web_search: "dyrektywa EPBD recast 2024 Polska transpozycja 2026"
```
