---
name: mod-AK-energetyczne-oze-ure

**Standard jakości:** stosuj `prawo-polskie-v2/krajowe/shared/MODULE-STANDARD-POLISH-LAW.md` oraz `prawo-polskie-v2/krajowe/shared/POLISH-LAW-COMPLETENESS-MATRIX.md`.
description: |
  Moduł prawa energetycznego i OZE. Stosuj przy URE, koncesjach, taryfach, prosumentach,
  fotowoltaice, przyłączeniach, odmowie przyłączenia, reklamacji energii/gazu/ciepła,
  wspólnotach energetycznych, magazynach energii.
compatibility:
  tools: [web_search, web_fetch]
---

# mod-AK — Prawo Energetyczne / OZE / URE

**Akt:** PrBud (Prawo budowlane) — t.j. Dz.U. 2026 poz. 524 (zm. po t.j.: 2026/605 od 2026-05-21 — art. 64; 2026/646 od 2026-05-29 — art. 33; 2026/1161 od 2026-10-02 — art. 1, 2, 12, 96, 99; 2026/1347 od 2026-10-17 — art. 9, 9a).
**Akt:** PrEn (Prawo energetyczne) — t.j. Dz.U. 2026 poz. 43 (zm. po t.j.: 2026/516 od 2026-04-30 — art. 2, 3, 4, 4j, 5, 5ad, 5ga, 5gb, 6g, 6h, 6i, 7, 16, 31d, 49, 71, 72, 306i, 777; 2026/607 od 2026-05-21 — art. 23r, 35; 2026/900 od 2026-07-21 — art. 3, 3a, 4j, 5, 7, 7b, 11, 23, 32, 33, 43, 45, 46, 47, 54, 62c; 2026/1348 od 2026-10-17 — art. 3, 4k, 7, 9g, 9j, 9ja, 11, 11t, 11y, 11zc, 11zh, 11zha, 20d, 20e, 20f, 28, 32d, 43c, 56; 2026/1347 [OD 2026-12-01: 2026/1347] — art. 3, 7, 7a, 9g, 16, 23, 56).
**Akt:** UOZE (ustawa o odnawialnych źródłach energii) — t.j. Dz.U. 2026 poz. 68 (zm. po t.j.: 2026/516 od 2026-04-30 — art. 9, 38ac, 38ad, 69b, 69c, 70b, 81, 120; 2026/900 od 2026-07-21 — art. 47, 116, 135, 152; 2026/912 od 2026-07-31 — art. 2, 133; 2026/1347 [OD 2026-12-01: 2026/1347] — art. 2, 2a, 4, 7, 8, 8a, 9, 11, 12, 19, 23, 25, 28, 30, 31, 31a, 31b, 33, 38c, 38da).
**Akt:** KPA (Kodeks postępowania administracyjnego) — t.j. Dz.U. 2025 poz. 1691.
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

## AKTY PRAWNE — WERYFIKUJ

| Akt | Zakres |
|---|---|
| Prawo energetyczne | koncesje, taryfy, przyłączenia, URE |
| Ustawa o OZE | prosumenci, aukcje, instalacje OZE |
| Instrukcje IRiESD/IRiESP | warunki sieciowe |
| KPA/PPSA | decyzje URE i skargi |

## ODMOWA PRZYŁĄCZENIA — ANALIZA

```
□ Czy złożono kompletny wniosek?
□ Czy operator wskazał techniczne lub ekonomiczne podstawy odmowy?
□ Czy odmowa zawiera uzasadnienie i pouczenie?
□ Czy możliwy jest spór do Prezesa URE?
□ Jakie dowody: warunki, korespondencja, mapa, moc, ekspertyza sieciowa.
```

## PROGI MOCY I OBOWIĄZKI FORMALNE — TABELA (dodano 2026-07-27, na
żądanie użytkownika, zweryfikowane w 10+ zgodnych źródłach)

```
MIKROINSTALACJA (≤50 kW elektrycznych):
  → BEZ koncesji URE, BEZ wpisu do jakiegokolwiek rejestru
  → Zgłoszenie do OSD: BEZPŁATNE, elektronicznie lub papierowo,
    NIE PÓŹNIEJ niż 30 DNI przed planowanym pierwszym wprowadzeniem
    energii do sieci
  → Rozliczenie: NET-BILLING (system wartościowy) dla instalacji
    zgłoszonych od 1.04.2022 — wcześniejsze mogły zachować
    net-metering na zasadach przejściowych, weryfikuj indywidualnie
  → ⚠️ POWIĄZANIE Z PRAWEM BUDOWLANYM: instalacje fotowoltaiczne DO
    150 kW (próg WYŻSZY niż próg mikroinstalacji dla celów
    energetycznych!) są ZWOLNIONE z pozwolenia na budowę ORAZ ze
    zgłoszenia robót budowlanych (nowelizacja Prawa budowlanego z
    2023 r.) — traktowane jako urządzenie budowlane. Sprawdź
    dodatkowe warunki techniczne (np. wysokość konstrukcji) w module
    `mod-PrBud-prawo-budowlane.md` — NIE BYŁO tam dotąd odnotowane,
    dodaj cross-referencję

MAŁA INSTALACJA (>50 kW do 1 MW elektrycznych — próg PODNIESIONY z
  500 kW nowelizacją z 2021/2023 r., podobnie moc cieplna w
  skojarzeniu >150 kW do 3 MW, podniesiona z 900 kW):
  → BEZ koncesji URE
  → OBOWIĄZKOWY wpis do Rejestru Wytwórców Energii w Małej
    Instalacji (MIOZE), prowadzonego przez Prezesa URE
  → Czas oczekiwania na wpis: 21 DNI
  → Opłata skarbowa za wpis: 616 zł
  → Wyjątek zwolniony z wpisu: wytwarzanie WYŁĄCZNIE z biopłynów lub
    biogazu rolniczego (niezależnie od mocy)
  → OBOWIĄZEK SPRAWOZDAWCZY: półroczne sprawozdanie MIOZE (nowy
    wzór obowiązuje od sprawozdania za I półrocze 2026 r., termin
    31 LIPCA 2026 — licząc datę WPŁYWU do URE, nie nadania
    przesyłki!) — kara za brak: 1000 zł. NIE dotyczy typowych
    prosumentów-mikroinstalacji do 50 kW w net-billingu

INSTALACJA POWYŻEJ 1 MW: WYMAGANA koncesja URE na wytwarzanie energii
  elektrycznej (pełna procedura koncesyjna)

DUŻE FARMY OZE ≥10 MW: od LIPCA 2026 R. obowiązek sprzedaży min. 80%
  wytworzonej energii na Towarowej Giełdzie Energii (TGE) — obligo
  giełdowe. Wyłączenia: linie bezpośrednie, cPPA z odbiorcą końcowym
  (NIE ze spółką obrotu), kogeneracja >52,5% sprawności, energia na
  potrzeby własne
```

⚠️ Wszystkie powyższe progi i terminy zmieniają się stosunkowo często
(kilka nowelizacji w ostatnich 5 latach) — sprawdź ISAP przed użyciem
w konkretnej sprawie, zwłaszcza próg mocy dla małej instalacji, który
był PODNOSZONY WIELOKROTNIE.

## ⛔ NOWELIZACJA `Dz.U. 2026 poz. 516` — REFORMA PRZYŁĄCZEŃ (dodano 2026-09-16, F-190)

✅ [VER] RZĄD 1 2026-09-16 — odczyt treści `Dz.U. 2026 poz. 516` (ustawa z 13.03.2026
o zmianie ustawy – Prawo energetyczne oraz niektórych innych ustaw; ogłoszona 15.04.2026).
Zmienia w PE (t.j. `Dz.U. 2026 poz. 43`) m.in. art. 3, 4j, 5, 5ad, 5ga, 5gb, 6g, **7**, 16,
33a, 33c, 43g, 50b, 56 oraz ustawę o OZE, UPEA (art. 3a), giełdach towarowych i innych.

**Wejście w życie (art. 38):** zasada — 14 dni od ogłoszenia (**30.04.2026**, zgodnie z ELI);
część przepisów (art. 1 pkt 14 lit. a tiret pierwsze i lit. d, pkt 20, art. 34) — dzień po
ogłoszeniu; **art. 9 ust. 1, 3, 4 pkt 1, ust. 5, art. 11 ust. 1, 3, 4 pkt 1 i 3, art. 13 i 14
ustawy zmieniającej — po 6 miesiącach od ogłoszenia (16.10.2026)**.
⚠️ „Art. 9, 11, 13, 14" to artykuły USTAWY ZMIENIAJĄCEJ (przepisy przejściowe), nie PE.

### ⛔⛔ Wygaśnięcie umów o przyłączenie Z MOCY PRAWA (art. 13–14 ustawy zmieniającej)

Dotyczy umów z art. 7 ust. 1 PE dla instalacji lub sieci przyłączanej do sieci
**powyżej 1 kV**. Umowa wygasa, jeżeli podmiot **nie zawiadomi operatora** o uzyskaniu
**ostatecznej decyzji o pozwoleniu na budowę** (gdy prawo budowlane jej wymaga) w terminie:

| Umowa zawarta | Instalacja | Termin zawiadomienia | Podstawa |
|---|---|---|---|
| nie wcześniej niż 48 mies. przed wejściem ustawy w życie | PV + przekształtniki (≥ 80 % mocy); magazyn bateryjny (≥ 80 % mocy i pojemności); urządzenia odbiorcze (≥ 50 % mocy) | **30 miesięcy** | art. 13 ust. 1 pkt 1 |
| jw. | turbina wiatrowa (≥ 80 %); biogaz / biogaz rolniczy (≥ 80 %); transformatory i rozdzielnie | **42 miesiące** | art. 13 ust. 1 pkt 2 |
| jw. | zasilanie kolejowej sieci trakcyjnej / sterowanie ruchem kolejowym | **60 miesięcy** | art. 13 ust. 1 pkt 3 |
| **wcześniej** niż 48 mies. przed wejściem ustawy w życie | turbina wiatrowa (≥ 80 %) | **6 miesięcy** | art. 14 ust. 1 pkt 1 |
| jw. | pozostałe instalacje z art. 13 ust. 1 pkt 1 i pkt 2 lit. b–c | **3 miesiące** | art. 14 ust. 1 pkt 2 |

Terminy liczone „od dnia wejścia w życie niniejszej ustawy". Art. 14 **nie stosuje się**
do przyłączeń kolejowych ani do umów, na podstawie których przed wejściem ustawy w życie
przyłączono co najmniej część instalacji (art. 14 ust. 2). Do umów z art. 13–14 stosuje się
art. 7 ust. 2b–2j (art. 14: 2h–2j) PE, a **dodatkowe zabezpieczenie z art. 7 ust. 2i pkt 2 —
w połowie kwoty** (art. 13 ust. 2, art. 14 ust. 3).

⛔ **NIEROZSTRZYGNIĘTE — punkt startowy biegu terminów.** Art. 13–14 wchodzą w życie
16.10.2026, a liczą terminy „od dnia wejścia w życie niniejszej ustawy" — ustawa jako całość
weszła 30.04.2026. Przy odczycie „od 30.04.2026" 3-miesięczny termin z art. 14 ust. 1 pkt 2
upłynąłby **przed** wejściem w życie samego przepisu (30.07.2026 < 16.10.2026), a 6-miesięczny
z pkt 1 — dwa tygodnie po nim. Przy odczycie „od 16.10.2026" terminy biegną od daty wejścia
art. 13–14. **Nie rozstrzygaj za klienta:** przyjmij datę WCZEŚNIEJSZĄ jako graniczną dla
zawiadomienia, sprawdź stanowisko URE / operatora i orzecznictwo przy sprawie, a spór
o wygaśnięcie umowy traktuj jako realne ryzyko. Zawiadomienie — pisemnie, z dowodem
doręczenia i kopią ostatecznej decyzji.

**Pozostałe przepisy przejściowe (odczyt przy sprawie):** art. 9 — zaliczka z art. 7 ust. 8a
przy warunkach przyłączenia wydanych przed wejściem ustawy i ważnych co najmniej 6 miesięcy
dłużej (m.in. 60 miesięcy dla kolei); art. 11 — podmiot z art. 7 ust. 8c1, który przed
wejściem ustawy otrzymał warunki przyłączenia, ale nie zawarł umowy, składa zabezpieczenie
w wysokości **1/4** kwoty z art. 7 ust. 8c1, w terminie z art. 7 ust. 8c9 (zaliczane na poczet
opłaty przyłączeniowej); art. 15 — sprawy sporne o odmowę zawarcia umowy (art. 8 ust. 1 PE)
wszczęte przed wejściem ustawy — **przepisy dotychczasowe**; art. 22 — przyłączenia
kolejowe zwolnione z opłaty za wniosek (art. 7 ust. 8b1–8b2) przez 60 miesięcy; art. 23 —
ograniczenie zmian warunków przyłączenia (art. 7 ust. 8i3) — zakres czasowy: odczyt przy sprawie.

---

## ⏳ NOWELIZACJE `Dz.U. 2026 poz. 1347` (OZE) i `poz. 1348` (PE) — ogł. 16.10.2026

✅ [VER] RZĄD 1 2026-10-20 — 1347: metadane ELI i text.pdf (art. 1–6, 41); 1348: tylko metadane ELI.

| Akt | Co zmienia 1347 | Od kiedy (art. 41) |
|---|---|---|
| ustawa o OZE (t.j. `2026/68`) | art. 1 — m.in. biometan i aukcje biometanu, spółdzielnie energetyczne (art. 13–14 przejściowe) | 1.12.2026; pkt 48 lit. c–e: 17.10.2026; pkt 19, pkt 57 lit. e: 19.10.2026; pkt 3: 17.01.2027; aukcje biometanu: 17.02.2027 |
| Prawo energetyczne (t.j. `2026/43`) | art. 4: art. 3 pkt 3a (paliwa gazowe obejmują biometan, biogaz, biogaz rolniczy), art. 7 (ust. 1e–1ef: odmowa przyłączenia instalacji biometanu, lokalizacja alternatywna, deklaracja zawarcia umowy; ust. 2a pkt 3–4: termin pierwszego dostarczenia biometanu do 60 mies.; ust. 8d⁵, 8d¹²: mikroinstalacja z magazynem — moc magazynu do 2,2× mocy mikroinstalacji nie wlicza się), art. 9g, art. 16 | 1.12.2026 |
| Prawo energetyczne | art. 4 pkt 3, 4, 7, 8: art. 7a ust. 5–7, art. 7a¹, art. 23 ust. 2 pkt 18b lit. m, art. 56 (gazociągi bezpośrednie) | 17.10.2027 |
| kogeneracja (t.j. `2025/602`) | art. 5: uchylenia w art. 2 pkt 40, art. 11 pkt 2 lit. b, art. 14 ust. 2 pkt 1 lit. c, art. 94 ust. 1 pkt 2 lit. b | 1.12.2026 |
| Prawo budowlane | art. 3: art. 9a — art. 9 nie stosuje się do gazociągu bezpośredniego biogazu, biogazu rolniczego, biometanu | 17.10.2027 |

Przepisy przejściowe 1347: art. 12–40 (m.in. wnioski o przyłączenie złożone przed wejściem w życie — art. 31–34; art. 9g PE — art. 35). `1348` (ustawa z 18.09.2026 o zmianie PE; w mocy 17.10.2026, art. 1 pkt 1, 4–6, 12, pkt 15 lit. a tiret pierwsze, lit. c i d oraz art. 7–9 od 31.10.2026) ✅ [VER: ELI DU/2026/1348 text.pdf, RZĄD 1, 2026-10-20]:
- PE: art. 3 pkt 97–100 (nowe definicje), 4k, 7 ust. 3df, 9g ust. 4 pkt 5b–5c, 9j i nowe art. 9ja–9je (dane grafikowe), 11, 11t, 11y, 11zc, nowy 11zha, 28, 32d, 43c („organom administracji miar”), 56 (kary);
- zmiana sprzedawcy energii (art. 15 ustawy): od 19.10.2026 do rozpoczęcia przez OSD zadań z rozdz. 2d PE (centralny system informacji rynku energii), najpóźniej do 19.04.2028 — OSP i OSD umożliwiają zmianę sprzedawcy najpóźniej w 21 dni od poinformowania o nowej umowie; art. 14 — postępowanie OSD, gdy dla punktu poboru nie jest realizowana umowa sprzedaży lub kompleksowa;
- kary URE: art. 11 ustawy (niewszczynanie i umorzenie postępowań z art. 56 ust. 1 pkt 30d w związku z art. 11t ust. 3); art. 3 ustawy — nowe art. 20e–20f ustawy 2021/1093 (odstąpienie od kar dla OSD, który zawarł umowę przed 19.10.2026);
- przy sprawie: odczytaj brzmienie PE w ELI na datę zdarzenia (nowelizacje po t.j. 2026/43: 516, 607, 900, 1347, 1348).

## PROSUMENT / PV

Sprawdzaj: data zgłoszenia, system rozliczeń, moc instalacji, umowa kompleksowa, reklamacje faktur, błędy licznika, niedotrzymanie terminów.

## WYJŚCIE

Wskaż organ/tryb: reklamacja do sprzedawcy/operatora, spór do URE, sąd powszechny, WSA.

---

## AKTUALIZACJA ISAP / URE — 2026-05-28

Dla koncesji, taryf, przyłączeń, kar Prezesa URE i rynku energii wczytaj:

```text
view dr-12-sadownictwo-prokuratura-zawody-prawnicze/modules/mod-ustawa-regulatorzy-UOKiK-URE-UKE-KNF.md
```

Metryka kontrolna Prawa energetycznego: Dz.U. 2026 poz. 43.

---

# STANDARDOWE UZUPEŁNIENIE MODUŁU — poziom prawa pracy / prawa karnego

> Ten blok jest częścią obowiązkową modułu. Ma pierwszeństwo przed opisowym użyciem modułu. Nie zastępuje kontroli ISAP; wymusza praktyczny workflow kancelaryjny.

## 1. Intake szczególny

Przed odpowiedzią ustal co najmniej:
- koncesja/rejestr;
- instalacja;
- taryfa/umowa;
- organ URE;
- przyłączenie;
- sankcja;

## 2. Mapa proceduralna

```text
Identyfikacja trybu i organu/sądu
  ↓
Kontrola terminu, doręczenia, właściwości i legitymacji
  ↓
Ustalenie faktów materialnych i proceduralnych
  ↓
Matryca dowodowa: fakt → dowód → ciężar dowodu → luka
  ↓
Dobór pisma/środka: wniosek / odwołanie / zażalenie / skarga / pozew / zawiadomienie
  ↓
Walidacja formalna: prawo-polskie-v2/krajowe/shared/FORMAL-CHECK.md + shared/WARUNKI-SKUTECZNOSCI.md
  ↓
Ocena ryzyka: shared/RISK-ASSESSMENT.md + shared/QUALITY-CHECK.md
  ↓
Strategia: minimum, optimum, wariant eskalacyjny
```

## 3. Warunki skuteczności

```text
□ prawidłowy tryb
□ właściwy organ albo sąd
□ termin liczony od prawidłowego zdarzenia
□ legitymacja strony
□ żądanie możliwe prawnie
□ fakty powiązane z podstawą prawną
□ dowody przypisane do każdej tezy
□ kontrola opłat, odpisów, pełnomocnictw i podpisu
□ kontrola ISAP na dzień sporządzenia pisma
□ kontrola stanu prawnego na dzień zdarzenia oraz na dzień orzekania
```

## 4. Matryca dowodowa

Dowody typowe dla tego modułu:
- koncesje;
- umowy przyłączeniowe;
- taryfy;
- pomiary;
- decyzje URE;
- ekspertyzy techniczne;

Każdy dowód oceniaj według schematu:

```text
Dowód → fakt, który ma wykazać → bezpośredni/pośredni → wiarygodność → ryzyko podważenia → brakujący dowód wzmacniający
```

## 5. Typowe zarzuty i kontrzarzuty

W każdej sprawie przygotuj dwie wersje:

1. argumentację strony inicjującej sprawę,
2. argumentację organu/przeciwnika procesowego.

Typowe ryzyka i kontrargumenty:
- ryzyko kar URE;
- brak dokumentacji pomiarowej;
- terminy przyłączeniowe;
- spory techniczne;

## 6. Strategia procesowa

Zastosuj trzy warianty:

### Wariant ostrożny
Minimalizuje ryzyko formalne. Priorytet: termin, kompletność, zabezpieczenie dowodów.

### Wariant ofensywny
Eksponuje naruszenia proceduralne, wadliwość ustaleń, niewłaściwą wykładnię, naruszenie zasady proporcjonalności albo praw strony.

### Wariant eskalacyjny
Zakłada przejście do organu II instancji, WSA/NSA, sądu powszechnego, SN, TSUE, ETPC albo organu sektorowego — tylko gdy wynika to z trybu.

## 7. Quality gate

Przed końcową odpowiedzią sprawdź:

```text
□ Czy moduł działa praktycznie, a nie opisowo?
□ Czy wskazano decydujący element prawny?
□ Czy oddzielono fakty od interpretacji?
□ Czy podano ryzyka przeciwnika/organu?
□ Czy wskazano słabe punkty klienta?
□ Czy każdy przepis i Dz.U. ma kontrolę ISAP albo oznaczenie braku weryfikacji?
□ Czy użyto prawo-polskie-v2/krajowe/shared/MODULE-STANDARD-POLISH-LAW.md?
```

## 8. Łącz obowiązkowo z

| Potrzeba | Moduł współdzielony / skill |
|---|---|
| aktualność prawa | `shared/ISAP-AUDIT-PROTOCOL.md` + `prawo-polskie-v2/krajowe/shared/ISAP-METRYKI-AKTOW.md` |
| stan prawny w czasie | `shared/TEMPORAL-LAW-CHECK.md` |
| braki formalne | `prawo-polskie-v2/krajowe/shared/BRAKI-FORMALNE.md` |
| warunki skuteczności | `shared/WARUNKI-SKUTECZNOSCI.md` |
| dowody | `shared/DOWODY-METODOLOGIA.md` + `analizator-dowodow-v3` |
| ryzyka | `shared/RISK-ASSESSMENT.md` |
| pisma | `pisma-procesowe-v3` albo `pisma-proste-v2` |
| analiza sądowa | `analiza-sadowa-v6` |
