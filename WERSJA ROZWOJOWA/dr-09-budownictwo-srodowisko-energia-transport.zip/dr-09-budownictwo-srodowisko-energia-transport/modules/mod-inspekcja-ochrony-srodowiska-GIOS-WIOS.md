# mod-inspekcja-ochrony-srodowiska-GIOS-WIOS

**Akt:** POS (Prawo ochrony środowiska) — t.j. Dz.U. 2026 poz. 1453.
**Akt:** KC (Kodeks cywilny) — t.j. Dz.U. 2026 poz. 795.
**Akt:** UIOS (ustawa o Inspekcji Ochrony Środowiska) — t.j. Dz.U. 2024 poz. 425 (zm. po t.j.: 2025/1863 od 2026-01-13 — art. 2; 2026/1157 od 2026-09-16 — art. 2, 4a, 18).
**Akt:** UZSS (ustawa o zapobieganiu szkodom w środowisku i ich naprawie) — t.j. Dz.U. 2020 poz. 2187.
**Akt:** KPA (Kodeks postępowania administracyjnego) — t.j. Dz.U. 2025 poz. 1691.
**Akt:** KK (Kodeks karny) — t.j. Dz.U. 2026 poz. 1342 (zm. po t.j.: 2026/1466 [OD 2026-11-21: 2026/1466] — art. 42, 84).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

**Wersja:** 1.0 | **Dodano:** 2026-07-21
**Rola w systemie:** odpowiedź na pytanie użytkownika o GIOŚ/WIOŚ —
dotąd wymieniane WYŁĄCZNIE jako kroki w diagramie proceduralnym
(`mod-POS-prawo-ochrony-srodowiska.md`), bez własnej treści o
strukturze, kompetencjach i uprawnieniach kontrolnych.

> ⛔ HARDGATE — zweryfikuj aktualny t.j. ustawy o Inspekcji Ochrony
> Środowiska na ISAP.

---

## 1. STRUKTURA — DWUINSTANCYJNA INSTYTUCJA

```
□ PODSTAWA: ustawa z 20.07.1991 r. o Inspekcji Ochrony Środowiska
  (⚠️ zweryfikuj aktualny t.j.)
□ NADZÓR: minister właściwy do spraw KLIMATU/środowiska
□ DWA POZIOMY:
  1) GŁÓWNY INSPEKTORAT OCHRONY ŚRODOWISKA (GIOŚ) — poziom CENTRALNY
  2) 16 WOJEWÓDZKICH INSPEKTORATÓW OCHRONY ŚRODOWISKA (WIOŚ) — poziom
     WOJEWÓDZKI, po JEDNYM na każde województwo

□ KIEROWNICTWO:
  □ GŁÓWNY INSPEKTOR OCHRONY ŚRODOWISKA — POWOŁYWANY przez PREZESA
    RADY MINISTRÓW, OKREŚLA ogólne kierunki działania całej Inspekcji,
    ustala STANDARDY procedur kontrolnych, zapewnia JEDNOLITE
    stosowanie przepisów w całym kraju
  □ WOJEWÓDZKI INSPEKTOR OCHRONY ŚRODOWISKA — kieruje Inspekcją na
    obszarze DANEGO województwa — POWOŁYWANY przez WOJEWODĘ, ALE
    WYMAGA to ZGODY Głównego Inspektora Ochrony Środowiska (mechanizm
    "podwójnej kontroli" nad obsadą stanowiska — wojewoda NIE MOŻE
    powołać WIOŚ samodzielnie, bez akceptacji centrali)

□ ⭐ SKALA DZIAŁALNOŚCI: inspektorzy IOŚ przeprowadzają rocznie
  PONAD 30 000 KONTROLI zakładów w całym kraju
```

---

## 2. KOMPETENCJE — CO ROBI IOŚ

```
□ KONTROLA przestrzegania przepisów o ochronie środowiska przez
  PODMIOTY GOSPODARCZE (egzekwowanie obowiązków środowiskowych)
□ MONITOROWANIE i OCENA stanu środowiska (jakość powietrza, wód,
  hałasu, itd.) — w ramach PAŃSTWOWEGO MONITORINGU ŚRODOWISKA (PMŚ)
□ DOSTARCZANIE władzy publicznej i społeczeństwu INFORMACJI o stanie
  środowiska
□ WSPÓŁPRACA z POLICJĄ i organami ŚCIGANIA w zwalczaniu przestępstw
  środowiskowych (patrz KK art. 181-188, `mod-KK-art181-188a-
  przeciwko-srodowisku.md`, DR-03)
□ OD 1.01.2019 r.: GIOŚ jest organem realizującym zadania PMŚ oraz
  prowadzącym LABORATORIUM badawcze w ramach Centralnego Laboratorium
  Badawczego (CLB) — funkcja SCENTRALIZOWANA na poziomie krajowym
```

---

## 3. UPRAWNIENIA KONTROLNE INSPEKTORA — CO MOŻE ZROBIĆ PRZY KONTROLI

✅ **ZWERYFIKOWANE (2026-08-19, F-42)** — pełny katalog z art. 9
ustawy o Inspekcji Ochrony Środowiska (Dz.U. 2024 poz. 425 t.j.):

```
Inspektor IOŚ przy wykonywaniu kontroli jest UPRAWNIONY do:
  1) WSTĘPU przez CAŁĄ DOBĘ, wraz z niezbędnym SPRZĘTEM:
     a) na teren nieruchomości/obiektu (lub ich CZĘŚCI), na którym
        prowadzona jest działalność GOSPODARCZA,
     b) do ŚRODKÓW TRANSPORTU,
     c) na teren NIEZWIĄZANY z prowadzeniem działalności gospodarczej
        (⭐ rozszerzenie — nie tylko zakłady/firmy)
  2) przeprowadzania NIEZBĘDNYCH POMIARÓW LUB BADAŃ, w tym POBIERANIA
     PRÓBEK lub wykonywania innych czynności kontrolnych — W TYM z
     użyciem BEZZAŁOGOWYCH STATKÓW POWIETRZNYCH (drony) — w celu
     ustalenia stanu środowiska i oceny go w świetle przepisów
  3) OBSERWOWANIA I REJESTROWANIA przy użyciu środków technicznych
     (w tym techniki satelitarne i drony) obrazu zdarzeń oraz dźwięku
  4) GROMADZENIA I ZABEZPIECZANIA dowodów popełnienia przestępstwa lub
     wykroczenia
  5) ŻĄDANIA pisemnych lub ustnych INFORMACJI oraz PRZESŁUCHIWANIA osób
     w zakresie niezbędnym dla ustalenia stanu faktycznego — z
     pouczeniem o odpowiedzialności karnej za fałszywe zeznania (KK)
  6) USTALANIA TOŻSAMOŚCI osób oraz żądania okazania DOKUMENTÓW
     niezbędnych do wymierzenia grzywny mandatem lub sporządzenia
     wniosku o ukaranie
  7) NAKŁADANIA GRZYWIEN w postępowaniu mandatowym za wykroczenia
  8) dokonywania OGLĘDZIN pomieszczeń i innych miejsc
  9) zatrzymywania lub przeszukiwania POJAZDÓW przewożących towary +
     kontroli dokumentów przewozowych
  10) żądania od kierownika zakładu przeprowadzenia POSTĘPOWANIA
      SŁUŻBOWEGO przeciw osobom winnym uchybień + informacji o wynikach
```

⭐⭐ **UPRAWNIENIA DECYZYJNE w toku kontroli (art. 9, dalsze ustępy):**
WIOŚ może upoważnić inspektora do wydania W TRAKCIE kontroli decyzji o:
(a) **WSTRZYMANIU działalności** naruszającej wymagania ochrony
środowiska — TYLKO gdy zachodzi BEZPOŚREDNIE zagrożenie zdrowia/życia
ludzi LUB bezpośrednie zagrożenie zniszczenia środowiska w ZNACZNYCH
rozmiarach; (b) **wstrzymaniu oddania do użytku** obiektu/instalacji
niespełniających wymagań ochrony środowiska.

⭐ **Procedura formalna kontroli:** legitymacja służbowa OBOWIĄZKOWA
zawsze; dodatkowo UPOWAŻNIENIE do przeprowadzenia kontroli — z
WYJĄTKIEM kontroli interwencyjnej (na skutek zgłoszenia/skargi) oraz
sytuacji bezpośredniego zagrożenia życia/zdrowia/środowiska lub
przeciwdziałania przestępstwu/wykroczeniu, gdzie wystarczy sama
legitymacja, a upoważnienie doręcza się NIE PÓŹNIEJ niż w terminie
**3 dni roboczych** od wszczęcia kontroli. IOŚ ma status **oskarżyciela
publicznego** w sprawach o wykroczenia przeciwko środowisku.

□ RODZAJE kontroli WIOŚ — ✅ POTWIERDZONE: **planowe, interwencyjne**
  (na skutek zgłoszenia/skargi), **doraźne** — klasyfikacja zgodna z
  wcześniejszym orientacyjnym ustaleniem modułu.
```

Potwierdzone w 6+ zgodnych źródłach: arslege.pl (t.j. Dz.U. 2024 poz. 425,
art. 9 i 9c), lexlege.pl, prawo.pl, gov.pl/web/wios-gdansk (Rząd 1-adjacent,
oficjalna strona WIOŚ), okieminspektora.pl.

---

## 4. ⭐ ŚCIEŻKA ODWOŁAWCZA — RELACJA WIOŚ ↔ GIOŚ

```
□ WIOŚ (I INSTANCJA) — wydaje decyzję/nakłada mandat/nakazuje
  usunięcie naruszeń
□ ODWOŁANIE od decyzji WIOŚ → do GŁÓWNEGO INSPEKTORA OCHRONY
  ŚRODOWISKA (GIOŚ, II INSTANCJA)
□ ⭐ W STRUKTURZE GIOŚ funkcjonuje DEPARTAMENT INSPEKCJI, który PEŁNI
  ROLĘ organu DRUGIEJ INSTANCJI w sprawach rozstrzyganych przez WIOŚ —
  W SZCZEGÓLNOŚCI w sprawach dotyczących EMISJI GAZÓW i PYŁÓW do
  powietrza
□ Po wyczerpaniu II instancji — SKARGA do WSA (sądowa kontrola
  administracyjna)
□ Pełna ścieżka (już opisana w `mod-POS-prawo-ochrony-srodowiska.md`,
  BEZ duplikacji tutaj): zawiadomienie do WIOŚ/RDOŚ → kontrola WIOŚ →
  odwołanie do GIOŚ → skarga do WSA → RÓWNOLEGLE możliwe roszczenie
  CYWILNE (art. 415 KC + ustawa o szkodach w środowisku)
```

---

## 5. CHECKLIST PRAKTYCZNY

```
□ Czy sprawa dotyczy KONTROLI planowanej czy INTERWENCYJNEJ (na
  skutek zgłoszenia) — wpływa na PRZYGOTOWANIE klienta
□ Czy decyzja/mandat pochodzi z WIOŚ — sprawdź TERMIN odwołania do
  GIOŚ (patrz ogólne zasady KPA, `mod-KPA-postepowanie-
  administracyjne.md`, DR-05)
□ Czy sprawa dotyczy EMISJI gazów/pyłów do powietrza — sprawdź, czy
  WŁAŚCIWY jest Departament Inspekcji GIOŚ jako II instancja
  (potwierdzone jako SZCZEGÓLNIE właściwy dla TEGO typu spraw)
□ Czy WOJEWÓDZKI Inspektor został powołany PRAWID�ŁOWO (zgoda GIOŚ) —
  RZADKO kwestionowane, ale możliwy zarzut proceduralny w SPORNYCH
  sprawach
□ Czy warto RÓWNOLEGLE dochodzić roszczenia CYWILNEGO (odszkodowanie
  od sprawcy) obok postępowania administracyjnego przed WIOŚ/GIOŚ
```

---

## 6. INTEGRACJA Z SYSTEMEM

- **`mod-POS-prawo-ochrony-srodowiska.md`** i **`mod-POS-prawo-
  ochrony-srodowiska-szczegoly.md`** (DR-09) — PEŁNA ścieżka
  proceduralna (zawiadomienie → kontrola → odwołanie → WSA) — TEN
  moduł dostarcza WYŁĄCZNIE strukturę/kompetencje SAMEJ instytucji, bez
  duplikacji procedury.
- **`mod-formy-ochrony-przyrody-obszary-chronione.md`** (DR-09,
  dodany 2026-07-21) — INNA instytucja odpowiada za obszary chronione
  (RDOŚ, minister środowiska, sejmik województwa) — NIE MYLIĆ z IOŚ,
  która zajmuje się KONTROLĄ przestrzegania przepisów (emisje,
  zanieczyszczenia), nie WYZNACZANIEM obszarów chronionych.
- **`mod-KK-art181-188a-przeciwko-srodowisku.md`** (DR-03) —
  odpowiedzialność KARNA za przestępstwa środowiskowe, z którymi
  współpracuje IOŚ.
- **DR-05 (Prawo Administracyjne)** — `mod-KPA-postepowanie-
  administracyjne.md` — ogólne zasady odwołań/decyzji administracyjnych
  mające zastosowanie do decyzji WIOŚ/GIOŚ.

---

## 7. LITERATURA I ŹRÓDŁA (zweryfikowane online 2026-07-21)

- pl.wikipedia.org (2×) — struktura dwuinstancyjna, 16 WIOŚ, historia
  (reforma 1998/1999, wcześniej 49 wojewódzkich inspektorów przed
  reformą administracyjną).
- powietrze.gios.gov.pl — Państwowy Monitoring Środowiska, rola GIOŚ
  od 1.01.2019 (PMŚ + Centralne Laboratorium Badawcze).
- okieminspektora.pl (2×) — rodzaje kontroli, uprawnienia inspektora
  (wstęp całodobowy na teren nieruchomości).
- portalochronysrodowiska.pl — Departament Inspekcji GIOŚ jako organ
  II instancji, szczególnie dla spraw emisji gazów/pyłów, współpraca z
  policją.
- adwokatpazdan.pl — mechanizm powołania WIOŚ (wojewoda + zgoda GIOŚ),
  role obu szczebli.

---

## CHANGELOG

**1.0 (2026-07-21):** Utworzenie modułu na wyraźne żądanie użytkownika.
Zweryfikowano online: dwuinstancyjną strukturę Inspekcji Ochrony
Środowiska (GIOŚ centralnie + 16 WIOŚ wojewódzko), mechanizm powołania
(Główny Inspektor przez premiera, Wojewódzki Inspektor przez wojewodę
ZA ZGODĄ Głównego Inspektora), kompetencje (kontrola podmiotów,
Państwowy Monitoring Środowiska, współpraca z organami ścigania),
uprawnienia kontrolne inspektora (wstęp całodobowy), oraz KLUCZOWĄ
ścieżkę odwoławczą — Departament Inspekcji w strukturze GIOŚ pełniący
rolę II instancji, SZCZEGÓLNIE dla spraw emisji gazów/pyłów do
powietrza. Odnotowano niepewności (pełny katalog uprawnień kontrolnych
poza wstępem na teren, dokładna klasyfikacja rodzajów kontroli) jako
punkty startowe do dalszego pogłębienia.
