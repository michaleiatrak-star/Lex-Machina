# mod-formy-ochrony-przyrody-obszary-chronione

**Wersja:** 1.0 | **Dodano:** 2026-07-21
**Rola w systemie:** odpowiedź na pytanie użytkownika o obszary
chronione z podziałem na typy i rodzaje ograniczeń — dotąd tylko
GENERYCZNY szkielet proceduralny (`mod-ustawa-lesna-lowiecka-ochrona-
przyrody.md`), BEZ merytorycznego opracowania 10 form ochrony
przyrody i ich ZRÓŻNICOWANYCH reżimów zakazów.

> ⛔ HARDGATE — zweryfikuj aktualny t.j. ustawy o ochronie przyrody z
> 16.04.2004 r. na ISAP — Rozdział 2 (art. 6-64) bywał nowelizowany.

---

## 1. ⭐ KATALOG 10 FORM OCHRONY PRZYRODY (art. 6 ustawy)

```
Formami ochrony przyrody są (katalog ZAMKNIĘTY, w kolejności OD
NAJSUROWSZEJ do NAJŁAGODNIEJSZEJ):
  1) PARKI NARODOWE
  2) REZERWATY PRZYRODY
  3) PARKI KRAJOBRAZOWE
  4) OBSZARY CHRONIONEGO KRAJOBRAZU
  5) OBSZARY NATURA 2000
  6) POMNIKI PRZYRODY
  7) STANOWISKA DOKUMENTACYJNE
  8) UŻYTKI EKOLOGICZNE
  9) ZESPOŁY PRZYRODNICZO-KRAJOBRAZOWE
  10) OCHRONA GATUNKOWA roślin, zwierząt i grzybów

DODATKOWO: w drodze POROZUMIENIA z sąsiednimi PAŃSTWAMI mogą być
  wyznaczane PRZYGRANICZNE obszary cenne przyrodniczo, dla ICH
  wspólnej ochrony (⚠️ to NIE jest 11. forma z zamkniętego katalogu,
  lecz ODRĘBNY, MIĘDZYNARODOWY mechanizm)
```

---

## 2. FORMY OBSZAROWE O NAJSUROWSZYM REŻIMIE

### 2.1 Park narodowy

```
□ DEFINICJA: POWIERZCHNIOWA forma ochrony, obszar o SZCZEGÓLNYCH
  wartościach przyrodniczych/naukowych/społecznych/kulturowych/
  edukacyjnych, o powierzchni NIE MNIEJSZEJ niż 1000 HA
□ ZAKRES OCHRONY: CAŁA przyroda + walory KRAJOBRAZOWE (najszerszy
  możliwy zakres)
□ CEL: zachowanie różnorodności biologicznej, PRZYWRÓCENIE właściwego
  stanu zasobów, ODTWORZENIE zniekształconych siedlisk
□ ORGAN USTANAWIAJĄCY zadania ochronne: MINISTER właściwy ds.
  środowiska, w drodze ZARZĄDZENIA
□ ⭐ UTWORZENIE/POWIĘKSZENIE parku narodowego JEST CELEM PUBLICZNYM w
  rozumieniu ustawy o gospodarce nieruchomościami — GDY obejmuje
  nieruchomości NIEBĘDĄCE własnością Skarbu Państwa, następuje ZA
  ZGODĄ właściciela, a w RAZIE BRAKU zgody — W TRYBIE WYWŁASZCZENIA
  (patrz ogólne zasady wywłaszczenia, DR-02, oraz analogiczny
  mechanizm ZRID dla dróg w `mod-GDDKiA-specustawa-drogowa-ZRID.md`
  jako PORÓWNANIE — tu jednak zasady OGÓLNE ustawy o gospodarce
  nieruchomościami, NIE specustawa)
```

### 2.2 Rezerwat przyrody

```
□ ANALOGICZNIE do parku narodowego, ale MNIEJSZA skala (BRAK progu
  powierzchniowego 1000 ha) i węższy PRZEDMIOT ochrony (określone
  ekosystemy/gatunki/twory przyrody, NIE zawsze "cała przyroda")
□ ORGAN USTANAWIAJĄCY zadania ochronne: REGIONALNY DYREKTOR OCHRONY
  ŚRODOWISKA (RDOŚ), w drodze ZARZĄDZENIA (NIE minister, jak przy
  parku narodowym — to KLUCZOWA różnica kompetencyjna)
□ TA SAMA zasada wywłaszczeniowa co przy parku narodowym (cel
  publiczny + zgoda właściciela/wywłaszczenie)

TRZY RODZAJE OCHRONY W RAMACH ZADAŃ OCHRONNYCH (dotyczy OBU: park
  narodowy i rezerwat):
  □ OCHRONA ŚCISŁA — NAJSUROWSZA, całkowite zaniechanie ingerencji
  □ OCHRONA CZYNNA — z DOPUSZCZALNĄ, kontrolowaną ingerencją człowieka
    (np. wycinka w celu ochrony ekosystemu)
  □ OCHRONA KRAJOBRAZOWA — nakierowana na zachowanie WALORÓW
    krajobrazowych, nie tylko biologicznych
  Zadania ochronne USTANAWIA SIĘ na okres 1 ROKU LUB kolejnych lat, NIE
  DŁUŻEJ niż na 5 LAT
```

---

## 3. FORMY OBSZAROWE O POŚREDNIM REŻIMIE

### 3.1 Park krajobrazowy

```
□ Obejmuje obszar CHRONIONY ze względu na WARTOŚCI przyrodnicze,
  historyczne, kulturowe oraz WALORY KRAJOBRAZOWE — CEL: zachowanie,
  POPULARYZACJA tych wartości w warunkach ZRÓWNOWAŻONEGO rozwoju
□ REŻIM ŁAGODNIEJSZY niż rezerwat/park narodowy — DOPUSZCZALNA
  działalność gospodarcza/rolnicza/leśna w SPOSÓB nienaruszający
  szczególnych wartości (⚠️ dokładny katalog zakazów niepotwierdzony w
  pełni w tej sesji — sprawdź art. odpowiedni w ELI (RZĄD 1) przy konkretnej
  sprawie)
```

### 3.2 Obszar chronionego krajobrazu

```
□ Obejmuje tereny CHRONIONE ze względu na WYRÓŻNIAJĄCY SIĘ krajobraz o
  zróżnicowanych EKOSYSTEMACH, wartościowe pod względem możliwości
  zaspokajania potrzeb TURYSTYKI i WYPOCZYNKU, LUB pełniące funkcję
  KORYTARZY EKOLOGICZNYCH
□ ⭐ ORGAN: SEJMIK WOJEWÓDZTWA, w drodze UCHWAŁY stanowiącej AKT PRAWA
  MIEJSCOWEGO (patrz `mod-dzienniki-urzedowe-BIP-publikacja.md`,
  DR-08, dla publikacji takich uchwał)
□ ⭐ MECHANIZM STREF OCHRONY KRAJOBRAZU: sejmik MOŻE WYZNACZYĆ, W
  GRANICACH krajobrazów PRIORYTETOWYCH (zidentyfikowanych w ramach
  AUDYTU KRAJOBRAZOWEGO wg ustawy o planowaniu i zagospodarowaniu
  przestrzennym, art. 38a) — STREFY ochrony krajobrazu, obejmujące W
  SZCZEGÓLNOŚCI: PRZEDPOLA EKSPOZYCJI, OSIE WIDOKOWE, PUNKTY WIDOKOWE,
  oraz OBSZARY ZABUDOWANE wyróżniające się LOKALNĄ formą architektoniczną
  — WRAZ ze wskazaniem, KTÓRE z ustawowych zakazów mają zastosowanie w
  danej strefie (⭐ to oznacza, że zakazy NIE SĄ jednolite dla całego
  obszaru — MOGĄ różnić się STREFAMI w OBRĘBIE tego samego obszaru
  chronionego krajobrazu)
```

### 3.3 Obszary Natura 2000

```
□ Sieć obszarów WYZNACZANA na podstawie prawa UNIJNEGO (Dyrektywa
  Ptasia i Dyrektywa Siedliskowa) — DWA typy: OBSZARY SPECJALNEJ
  OCHRONY PTAKÓW (OSO) i SPECJALNE OBSZARY OCHRONY SIEDLISK (SOO)
□ FINANSOWANIE wdrożenia i funkcjonowania sieci — odrębnie uregulowane
  (art. 39 ustawy, ⚠️ dokładny mechanizm niepotwierdzony w pełni w tej
  sesji)
□ KLUCZOWE dla INWESTORÓW: każda inwestycja MOGĄCA znacząco oddziaływać
  na obszar Natura 2000 WYMAGA szczególnej OCENY oddziaływania (patrz
  `mod-ustawa-OOS-oceny-srodowiskowe.md`, DR-09, dla PEŁNEJ procedury
  OOŚ — NIE duplikowanej tutaj)
```

### 3.4 PARK KRAJOBRAZOWY — ZAKAZY (art. 17 ustawy) — dodano 2026-07-27,
na wyraźne żądanie użytkownika (dotąd wspomniany tylko w jednej linii
klasyfikacyjnej, BEZ treści merytorycznej — luka domknięta)

```
⚠️ KLUCZOWA CECHA SYSTEMOWA: zakazy z art. 17 ust. 1 SĄ FAKULTATYWNE
  ("MOGĄ być wprowadzone") — to NIE jest jednolity, automatyczny
  katalog dla WSZYSTKICH parków. SEJMIK WOJEWÓDZTWA w uchwale
  tworzącej/zmieniającej dany park WYBIERA, KTÓRE z zakazów
  katalogowych rzeczywiście obowiązują w TYM KONKRETNYM parku —
  ZAWSZE sprawdź AKTUALNĄ uchwałę sejmiku dla konkretnego parku, NIE
  zakładaj automatycznie pełnego katalogu

KATALOG ZAKAZÓW MOŻLIWYCH DO WPROWADZENIA (wybór spośród, art. 17 ust. 1):
  1) realizacji przedsięwzięć MOGĄCYCH ZNACZĄCO ODDZIAŁYWAĆ na
     środowisko — z WYJĄTKIEM tych, dla których OOŚ wykazała BRAK
     niekorzystnego wpływu na przyrodę/krajobraz parku
  2) umyślnego zabijania dziko występujących zwierząt, niszczenia ich
     nor/legowisk/miejsc rozrodu — z wyjątkiem amatorskiego połowu ryb
     i racjonalnej gospodarki rolnej/leśnej/rybackiej/łowieckiej
  3) likwidowania/niszczenia zadrzewień śródpolnych/przydrożnych/
     nadwodnych — z wyjątkiem potrzeb przeciwpowodziowych/bezpieczeństwa
  4) pozyskiwania do celów gospodarczych skał (w tym torfu),
     skamieniałości, minerałów, bursztynu
  5) wykonywania prac ziemnych TRWALE ZNIEKSZTAŁCAJĄCYCH rzeźbę terenu
  6) DOKONYWANIA ZMIAN STOSUNKÓW WODNYCH — jeśli NIE służą ochronie
     przyrody lub racjonalnej gospodarce rolnej/leśnej/wodnej/rybackiej
  7) ⭐ BUDOWANIA NOWYCH OBIEKTÓW BUDOWLANYCH W PASIE **100 M** od linii
     brzegów rzek/jezior/innych naturalnych zbiorników wodnych oraz od
     zasięgu lustra wody w zbiornikach SZTUCZNYCH przy normalnym
     poziomie piętrzenia — NAJWAŻNIEJSZY zakaz DLA INWESTORÓW
     PRYWATNYCH, konkretny próg METRAŻOWY
  8) [analogiczny próg odległościowy — szczegóły w pełnym tekście art. 17]
  ...oraz dalsze pozycje katalogu (niszczenie obiektów historycznych/
  kulturowych — TEN akurat jest zakazem BEZWZGLĘDNYM, nie fakultatywnym)

WYJĄTKI OD ZAKAZÓW (art. 17 ust. 2, stosują się NIEZALEŻNIE od tego,
  czy dany zakaz wprowadzono): realizacja zadań z planu ochrony/planu
  zadań ochronnych; zadania na rzecz obronności/bezpieczeństwa
  państwa; akcje ratownicze; inwestycje celu publicznego w rozumieniu
  ustawy o planowaniu przestrzennym

⚠️ WAŻNA ZASADA (potwierdzona orzecznictwem/doktryną): WOJEWODA/organ
  wykonawczy NIE MOŻE wprowadzić SUROWSZYCH zakazów niż przewiduje
  zamknięty katalog art. 17 ust. 1 — tylko sejmik województwa, w
  granicach tego katalogu, kształtuje zakres ochrony

USTANOWIENIE/LIKWIDACJA: uchwała SEJMIKU WOJEWÓDZTWA (nazwa, obszar,
  granice, otulina jeśli wyznaczona, cele ochrony, WYBRANE zakazy z
  katalogu). Likwidacja/zmniejszenie — WYŁĄCZNIE z powodu
  BEZPOWROTNEJ utraty wartości przyrodniczych/historycznych/
  kulturowych/krajobrazowych.

Potwierdzone w 6+ zgodnych źródłach (lexlege.pl — dosłowny art. 17,
arslege.pl, dlajurysty.pl, sip.lex.pl — w tym realny wyrok WSA VIII
SA/Wa 883/25 dot. budowy budynku rekreacji indywidualnej w parku
krajobrazowym pokrywającym się z Naturą 2000).
```

---

## 4. FORMY PUNKTOWE/OBIEKTOWE O NAJŁAGODNIEJSZYM REŻIMIE

### 4.1 Pomniki przyrody (art. 40)

```
□ POJEDYNCZE twory przyrody ŻYWEJ (np. sędziwe/okazałych rozmiarów
  drzewa, krzewy, źródła, wodospady) LUB NIEOŻYWIONEJ (głazy narzutowe,
  jaskinie) o SZCZEGÓLNEJ wartości przyrodniczej/naukowej/kulturowej/
  historycznej/krajobrazowej oraz ODZNACZające się INDYWIDUALNYMI
  cechami wyróżniającymi je spośród innych tworów
□ USTANOWIENIE: RADA GMINY, w drodze UCHWAŁY (akt prawa miejscowego)
□ ZAKRES OCHRONY: NAJWĘŻSZY punktowo, ale MOŻE obejmować OTOCZENIE
  pomnika w zakresie NIEZBĘDNYM dla jego ochrony
```

### 4.2 Stanowiska dokumentacyjne (art. 41)

```
□ Ochrona NIEOŻYWIONYCH tworów przyrody, WAŻNYCH dla dokumentacji
  historii GEOLOGICZNEJ, w tym miejsc występowania FORMACJI
  geologicznych, nagromadzeń SKAMIENIAŁOŚCI/mineraŁów, RZADKICH lub
  UNIKATOWYCH form skalnych, jaskiń/schronisk podskalnych — RÓWNIEŻ
  fragmenty EKSPLOATOWANYCH/nieczynnych wyrobisk GÓRNICZYCH
□ USTANOWIENIE: RADA GMINY, w drodze uchwały (analogicznie do pomników)
```

### 4.3 Użytki ekologiczne (art. 42)

```
□ ZASŁUGUJĄCE na ochronę POZOSTAŁOŚCI ekosystemów, mające ZNACZENIE
  dla zachowania RÓŻNORODNOŚCI biologicznej — np. NATURALNE zbiorniki
  wodne, śródpolne i śródleśne "OCZKA WODNE", KĘPY drzew i krzewów,
  BAGNA, TORFOWISKA, WYDMY, PŁATY nieużytkowanej roślinności, STAROROZŁA
□ USTANOWIENIE: rada GMINY, w drodze uchwały
```

### 4.4 Zespoły przyrodniczo-krajobrazowe (art. 43)

```
□ FRAGMENTY krajobrazu NATURALNEGO i KULTUROWEGO ZASŁUGUJĄCE na
  ochronę ze względu na ich WALORY WIDOKOWE lub ESTETYCZNE
□ USTANOWIENIE: rada gminy, w drodze uchwały (⭐ TA SAMA droga —
  uchwała rady gminy — dla WSZYSTKICH CZTERECH form "lokalnych" —
  pomniki, stanowiska dokumentacyjne, użytki ekologiczne, zespoły
  przyrodniczo-krajobrazowe — w PRZECIWIEŃSTWIE do "wysokich" form,
  gdzie decyduje minister/RDOŚ/sejmik województwa)
```

### 4.5 Ochrona gatunkowa roślin, zwierząt i grzybów (10. forma) — ✅
ZWERYFIKOWANE (2026-08-19, F-42)

```
□ ⭐ JEDYNA forma NIE OBSZAROWA/PUNKTOWA — dotyczy KONKRETNYCH
  GATUNKÓW, niezależnie od ich lokalizacji (chroniony gatunek jest
  chroniony WSZĘDZIE, gdzie występuje, nie tylko na wyznaczonym
  terenie) — obejmuje NIE TYLKO osobniki, ale TAKŻE siedliska, ostoje,
  stanowiska, miejsca rozrodu i regularnego przebywania. Zniszczenie
  siedliska może naruszać prawo NAWET gdy w chwili kontroli nie widać
  samego osobnika.
□ USTANAWIANA odrębnymi rozporządzeniami MINISTRA środowiska DLA
  KAŻDEJ z 3 grup organizmów — ✅ katalog aktów wykonawczych POTWIERDZONY:
  - Rozporządzenie MŚ z 16.12.2016 r. w sprawie ochrony gatunkowej
    ZWIERZĄT (weszło w życie 1.01.2017) — załączniki: nr 1 (ochrona
    ścisła), nr 2 (ochrona częściowa), nr 3 (gatunki dopuszczone do
    pozyskiwania + sposoby pozyskiwania), nr 4 (gatunki wymagające
    ochrony strefowej + wielkość stref).
  - Rozporządzenie MŚ z 9.10.2014 r. w sprawie ochrony gatunkowej
    GRZYBÓW.
  - Rozporządzenie MŚ w sprawie ochrony gatunkowej ROŚLIN (analogiczny
    mechanizm, data nie potwierdzona w tej sesji).
  ⚠️ Wszystkie 3 rozporządzenia mogły być nowelizowane po dacie
  pierwotnego wydania — sprawdź aktualny t.j. przy konkretnej sprawie,
  nie zakładaj automatycznie dat z 2014/2016 bez weryfikacji.
□ TRZY POZIOMY OCHRONY (potwierdzone jednolicie we wszystkich źródłach):
  1) **OCHRONA ŚCISŁA (całkowita)** — całkowity zakaz niszczenia,
     usuwania, zabijania, przenoszenia; najbardziej restrykcyjna.
  2) **OCHRONA CZĘŚCIOWA** — mniej restrykcyjna, dopuszcza NIEKTÓRE
     czynności/ingerencję w liczebność osobników wobec objętych nią
     gatunków (np. wiewiórka pospolita — częściowa).
  3) **OCHRONA STREFOWA** — DODATKOWY mechanizm (nie alternatywa dla
     1-2, lecz nakładka) — wyznaczenie fizycznych STREF wokół ostoi,
     miejsc rozrodu, regularnego przebywania (głównie dla ptaków
     drapieżnych: orlik krzykliwy, bocian czarny, puchacz, bielik, orzeł
     przedni, głuszec — przykłady z praktyki RDLP Kraków, 55 stref).
□ KATALOG ZAKAZÓW (§6 rozporządzenia o zwierzętach) — zestaw wspólny dla
  gatunków objętych ochroną ścisłą i częściową (zakres per gatunek może
  być WĘŻSZY, nie każdy zakaz dotyczy każdego gatunku): zabijanie,
  okaleczanie, chwytanie, przetrzymywanie, płoszenie, niepokojenie,
  niszczenie jaj/gniazd/nor/siedlisk/stanowisk, zrywanie, wykopywanie,
  uszkadzanie, pozyskiwanie. ⭐ Dokładny zakres zależy od KONKRETNEGO
  gatunku i właściwego załącznika — nie zakładać identycznego katalogu
  dla wszystkich gatunków bez sprawdzenia.
□ ⭐⭐ WYJĄTEK PRAKTYCZNY: zakazy NIE dotyczą czynności związanych z
  RACJONALNĄ GOSPODARKĄ LEŚNĄ, jeżeli technologia prac UNIEMOŻLIWIA ich
  przestrzeganie (odesłanie do dyrektywy siedliskowej UE 92/43/EWG).
□ ODSTĘPSTWA OD ZAKAZÓW: możliwe za ZEZWOLENIEM (GDOŚ/RDOŚ w zależności
  od zasięgu) — obecność gatunku chronionego NIE blokuje automatycznie
  inwestycji, ale wymaga rzetelnej oceny, unikania szkody, działań
  minimalizujących, właściwego harmonogramu prac (np. poza okresem
  lęgowym) i czasem formalnego zezwolenia na odstępstwo.
□ Procedura praktyczna dla inwestora/wykonawcy: rozpoznać gatunek →
  ustalić status ochronny → sprawdzić właściwe zakazy → ocenić siedlisko
  → określić wpływ planowanego działania → dopiero potem decyzja —
  szczególnie istotne przy wycince drzew, remontach budynków, pracach
  na ciekach wodnych.
```
Potwierdzone w 6+ zgodnych źródłach: gov.pl/web/gdos (Rząd 1 — Generalna
Dyrekcja Ochrony Środowiska), archiwum.mos.gov.pl (Ministerstwo
Środowiska), krakow.lasy.gov.pl (RDLP), prawo.pl (pełny tekst
rozporządzenia), szkoladendrologii.pl, przygodyprzyrody.pl.

---

## 5. TABELA ZBIORCZA — ORGAN USTANAWIAJĄCY WG FORMY (⭐ kluczowe dla praktyki)

```
Forma ochrony                    | Organ ustanawiający
----------------------------------|---------------------------
Park narodowy                     | Rada Ministrów (utworzenie) / Minister środowiska (zadania ochronne, zarządzenie)
Rezerwat przyrody                 | Regionalny Dyrektor Ochrony Środowiska (RDOŚ)
Park krajobrazowy                 | Sejmik województwa (⚠️ zweryfikuj dokładny tryb)
Obszar chronionego krajobrazu     | Sejmik województwa (uchwała, akt prawa miejscowego)
Obszary Natura 2000                | Minister środowiska (na podstawie prawa UE)
Pomnik przyrody                    | Rada gminy (uchwała)
Stanowisko dokumentacyjne          | Rada gminy (uchwała)
Użytek ekologiczny                 | Rada gminy (uchwała)
Zespół przyrodniczo-krajobrazowy   | Rada gminy (uchwała)
Ochrona gatunkowa                  | Minister środowiska (rozporządzenie)
```

---

## 6. CHECKLIST PRAKTYCZNY

```
□ Z JAKĄ formą ochrony mamy do czynienia — sprawdź KTÓRY organ ją
  ustanowił (rada gminy/sejmik/RDOŚ/minister) — to WSKAZUJE właściwy
  tryb ZASKARŻENIA (uchwała rady gminy → inny tryb niż zarządzenie
  ministra)
□ Czy inwestycja/nieruchomość klienta znajduje się NA terenie objętym
  KTÓRĄKOLWIEK z 10 form — sprawdź rejestr form ochrony przyrody
  prowadzony przez WŁAŚCIWEGO RDOŚ
□ Czy sprawa dotyczy OBSZARU CHRONIONEGO KRAJOBRAZU — sprawdź, czy
  nieruchomość leży w WYZNACZONEJ STREFIE ochrony krajobrazu (mogą
  obowiązywać INNE zakazy niż na pozostałym obszarze)
□ Czy planowana inwestycja może ODDZIAŁYWAĆ na obszar NATURA 2000 —
  sprawdź obowiązek OCENY oddziaływania (`mod-ustawa-OOS-oceny-
  srodowiskowe.md`)
□ Czy sprawa dotyczy UTWORZENIA/POWIĘKSZENIA parku narodowego/rezerwatu
  na nieruchomości PRYWATNEJ — sprawdź mechanizm zgody właściciela/
  wywłaszczenia
□ Czy sprawa dotyczy KONKRETNEGO GATUNKU (nie terenu) — sprawdź reżim
  ochrony gatunkowej NIEZALEŻNIE od lokalizacji
```

---

## 7. INTEGRACJA Z SYSTEMEM

- **`mod-ustawa-lesna-lowiecka-ochrona-przyrody.md`** (DR-09) —
  OGÓLNY szkielet proceduralny (intake, strategia, orzecznictwo) — TEN
  moduł dostarcza MERYTORYCZNĄ treść o 10 formach, bez duplikacji.
- **`mod-inspekcja-ochrony-srodowiska-GIOS-WIOS.md`** (DR-09, dodany
  2026-07-21) — INNA instytucja (kontrola zanieczyszczeń/emisji) —
  NIE MYLIĆ z organami ustanawiającymi obszary chronione (RDOŚ/
  minister/sejmik/rada gminy).
- **`mod-ustawa-OOS-oceny-srodowiskowe.md`** (DR-09) — ocena
  oddziaływania na środowisko, szczególnie ISTOTNA dla Natura 2000.
- **`mod-lowiectwo-klusownictwo.md`** (DR-09) — ochrona GATUNKOWA
  zwierząt łownych w KONTEKŚCIE łowiectwa — sprawdź tam dla ZBIEGU
  reżimów.
- **DR-08 (Samorząd)** — `mod-dzienniki-urzedowe-BIP-publikacja.md` —
  publikacja uchwał rady gminy/sejmiku ustanawiających formy ochrony.

---

## 8. LITERATURA I ŹRÓDŁA (zweryfikowane online 2026-07-21)

- lexlege.pl (3×), arslege.pl (2×), prawnik.cc — pełna treść art. 6
  (katalog 10 form) oraz art. 39-44 (pomniki, stanowiska dokumentacyjne,
  użytki ekologiczne, zespoły przyrodniczo-krajobrazowe) ustawy o
  ochronie przyrody, mechanizm wywłaszczenia dla parku narodowego/
  rezerwatu, organy ustanawiające zadania ochronne (minister/RDOŚ),
  trzy rodzaje ochrony (ścisła/czynna/krajobrazowa), strefy ochrony
  krajobrazu w obszarze chronionego krajobrazu.
- wlin.pl — definicja parku narodowego (próg 1000 ha, zakres ochrony
  "cała przyroda").
- lop.org.pl — rola RDOŚ w prowadzeniu rejestru form ochrony przyrody.
