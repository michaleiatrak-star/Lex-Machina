# mod-ustawa-transport-drogowy-kolejowy-lotniczy-morski

**Akt:** PrBud (Prawo budowlane) — t.j. Dz.U. 2026 poz. 524 (zm. po t.j.: 2026/605 od 2026-05-21 — art. 64; 2026/646 od 2026-05-29 — art. 33; 2026/1161 od 2026-10-02 — art. 1, 2, 12, 96, 99; 2026/1347 od 2026-10-17 — art. 9, 9a).
**Akt:** PrEn (Prawo energetyczne) — t.j. Dz.U. 2026 poz. 43 (zm. po t.j.: 2026/516 od 2026-04-30 — art. 2, 3, 4, 4j, 5, 5ad, 5ga, 5gb, 6g, 6h, 6i, 7, 16, 31d, 49, 71, 72, 306i, 777; 2026/607 od 2026-05-21 — art. 23r, 35; 2026/900 od 2026-07-21 — art. 3, 3a, 4j, 5, 7, 7b, 11, 23, 32, 33, 43, 45, 46, 47, 54, 62c; 2026/1348 od 2026-10-17 — art. 3, 4k, 7, 9g, 9j, 9ja, 11, 11t, 11y, 11zc, 11zh, 11zha, 20d, 20e, 20f, 28, 32d, 43c, 56; 2026/1347 [OD 2026-12-01: 2026/1347] — art. 3, 7, 7a, 9g, 16, 23, 56).
**Akt:** PrGeod (Prawo geodezyjne i kartograficzne) — t.j. Dz.U. 2026 poz. 1389.
**Akt:** UGN (ustawa o gospodarce nieruchomościami) — t.j. Dz.U. 2026 poz. 399 (zm. po t.j.: 2026/912 od 2026-07-31 — art. 10; 2026/875 [OD 2027-01-01: 2026/875] — art. 93).
**Akt:** UDP (ustawa o drogach publicznych) — t.j. Dz.U. 2025 poz. 889 (zm. po t.j.: 2026/982 od 2026-09-21 — art. 13, 13k, 13naa, 40a).
**Akt:** ZRID (specustawa drogowa — ustawa o szczególnych zasadach przygotowania i realizacji inwestycji w zakresie dróg publicznych) — t.j. Dz.U. 2024 poz. 311.
**Akt:** UTD (ustawa o transporcie drogowym) — t.j. Dz.U. 2025 poz. 1490 (zm. po t.j.: 2025/1843 od 2026-01-01 — art. 30a, 30b, 87, 89; 2025/1676 od 2026-03-03 — art. 4, 39a, 39aa, 39b, 39e, 39ha, 39hb, 39i, 103a; 2025/1795 od 2026-03-18 — art. 4; 2026/982 od 2026-08-06 — art. 1, 23, 24, 24a, 39aa, 39c; 2026/875 [OD 2027-01-01: 2026/875] — art. 18).
**Akt:** UTK (ustawa o transporcie kolejowym) — t.j. Dz.U. 2026 poz. 1324.
**Akt:** PrLot (Prawo lotnicze) — t.j. Dz.U. 2026 poz. 1407.
**Akt:** KM (Kodeks morski) — t.j. Dz.U. 2023 poz. 1309 (zm. po t.j.: 2026/1004 od 2026-08-27 — art. 37, 37a).
**Akt:** KC (Kodeks cywilny) — t.j. Dz.U. 2026 poz. 795.
**Akt:** UEPA (ustawa o elektromobilności i paliwach alternatywnych) — t.j. Dz.U. 2026 poz. 1243.
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

**Status:** moduł klasy kancelaryjnej — poziom DR-03
**Źródło weryfikacji:**
- Transport drogowy: Dz.U. 2025 poz. 1490 t.j. ze zm. ✅ VER: 2026-06-05
- Drogi publiczne: **Dz.U. 2025 poz. 889 t.j.** z 26.06.2025 ✅ VER: 2026-06-05; ⏳ Po t.j.: Dz.U. 2026 poz. 815 (od 4.07.2026 — dodany art. 20i: wojewoda „w drodze rozporządzenia porządkowego, po zasięgnięciu opinii zarządcy drogi" może w sytuacji kryzysowej wprowadzić „czasowe ograniczenia w korzystaniu z dróg publicznych, w tym czasowo wyłączyć je z ruchu"), 982 (od 21.09.2026)
- Specustawa drogowa ZRID: Dz.U. 2024 poz. 311 t.j. ze zm. ✅ VER: 2026-06-05
- Transport kolejowy: **Dz.U. 2026 poz. 1324 t.j.** (obwieszczenie z 1.09.2026; poprzedni t.j. 2025/1234) ✅ [VER] RZĄD 1 2026-10-15 (ELI); brak zmian po t.j.; t.j. obejmuje Dz.U. 2026 poz. 41, 815 (od 4.07.2026 — dodany art. 29g: wojewoda „w drodze rozporządzenia porządkowego, po zasięgnięciu opinii zarządcy infrastruktury kolejowej" może w sytuacji kryzysowej „wprowadzić czasowe ograniczenia w dostępie do infrastruktury kolejowej, w tym całkowicie wyłączyć dostęp do infrastruktury kolejowej"), 912
- Prawo lotnicze: Dz.U. 2026 poz. 1407 t.j. (obejmuje zmiany 2025 poz. 1668 i 2026 poz. 176, 607, 864, 1157) — VER RZĄD 1: ELI, 2026-10-31; ⏳ art. 209uo ust. 1 i 3 od 1.01.2027, zmiany z 2026 poz. 176 od 18.02.2027
- Elektromobilność: **Dz.U. 2026 poz. 1243 t.j.** (obwieszczenie z 1.09.2026; poprzedni t.j. 2024/1289 wygasł) ✅ [VER] RZĄD 1 2026-10-04
- Kodeks morski: Dz.U. 2023 poz. 1309 t.j. ze zm. ⛔ [POPRAWKA 2026-08-15n — BYŁO 2023.1523; poz. 1523/2023 to ustawa o delegowaniu kierowców w transporcie drogowym, nie Kodeks morski]
**Zasada:** Każde brzmienie przepisu przed powołaniem → isap.sejm.gov.pl

---

## 1. CORE

### Zakres
Licencje i zezwolenia transportu drogowego, kary ITD/Inspekcji Transportu Drogowego, drogi publiczne i odpowiedzialność zarządcy, decyzja ZRID (specustawa drogowa), transport kolejowy (UTK, dostęp do infrastruktury), prawo lotnicze (ULC, drony, prawa pasażerów), elektromobilność i strefy czystego transportu, kodeks morski.

---

## 2. TRANSPORT DROGOWY

### Akty i organy

```
Ustawa o transporcie drogowym (Dz.U. 2025 poz. 1490 t.j. ze zm. — weryfikuj w ELI (RZĄD 1))
Organ kontrolny: ITD (Inspekcja Transportu Drogowego)
Organ licencyjny: starosta (licencja taxi, przewóz osób) / Główny Inspektor Transportu Drogowego

Licencje:
  → Przewóz osób i rzeczy: licencja od starosty lub GITD
  → Transport kabotażowy: licencja wspólnotowa (UE)
  → ADR: zezwolenie na przewóz materiałów niebezpiecznych
```

### Kary ITD (weryfikuj aktualne stawki w ustawie i rozporządzeniach w ELI (RZĄD 1))

```
Kara administracyjna: decyzja → odwołanie do GITD (14 dni) → WSA (30 dni)
Typowe naruszenia: czas jazdy/odpoczynku (tachograf), przekroczenie masy, brak dokumentów
Kara pieniężna: do 15 000 PLN (weryfikuj aktualny taryfikator)
Mandat karny (art. 96 KPW): naruszenia z art. 92f ust. 1 i zał. nr 1 ustawy
  o transporcie drogowym (ITD, Policja, KAS, SG) — do 2 000 zł (§ 1a pkt 2);
  wykroczenia z rozdziału XI KW — do 5 000 zł, przy zbiegu 6 000 zł (§ 1ad)
  ✅ [VER: ELI DU/2026/1336 art. 96 § 1a pkt 2 i § 1ad (t.j. obejmuje DU/2026/473, DU/2025/1814); 2026-10-17]
  (korekta AUDYT-2026-10-04f: było „do 5 000 PLN” bez rozróżnienia)
```

---

## 3. DROGI PUBLICZNE (Dz.U. 2025 poz. 889 ze zm. 2026 poz. 815, 982)

### Kategorie dróg i zarządcy

```
Drogi krajowe:      GDDKiA + autostrady/ekspresowe (zarząd ministerialny)
Drogi województwa:  Zarząd Dróg Wojewódzkich
Drogi powiatowe:    Zarząd Dróg Powiatowych / Starosta
Drogi gminne:       Wójt / Burmistrz / Prezydent
```

⭐ Mechanizm SPECUSTAWY DROGOWEJ (ZRID — Zezwolenie na Realizację
Inwestycji Drogowej, decyzja łącząca pozwolenie na budowę/podział
nieruchomości/wywłaszczenie) — patrz DEDYKOWANY moduł `mod-GDDKiA-
specustawa-drogowa-ZRID.md` (dodany 2026-07-21), NIE duplikowany tutaj.

### Pas drogowy i odpowiedzialność odszkodowawcza

```
Pas drogowy: grunt + droga + pobocze + rowy + urządzenia
Zajęcie pasa: decyzja zarządcy drogi + opłata (zezwolenie indywidualne lub kategoryzowane)
Reklama w pasie: zakaz dla autostrad; ograniczenia dla innych — weryfikuj art. 43 w ELI (RZĄD 1)

Odpowiedzialność zarządcy za szkodę z nieutrzymania drogi:
  → Art. 20 ustawy o drogach + art. 415 KC / 429 KC
  → Orzecznictwo SN: zarządca odpowiada jak sprawca deliktu
  → Szkoda: przewrót pojazdu na dziurze, poślizgnięcie na lodzie, wpadnięcie w wyrwę
  → Przedawnienie: 3 lata od dowiedzenia się o szkodzie (art. 442¹ § 1 KC), nie dłużej niż 10 lat od zdarzenia
    — ⛔ WYJĄTEK: przy szkodzie na osobie (obrażenia) granica 10 lat nie obowiązuje (§ 3);
    przestępstwo — 20 lat (§ 2). ✅ [VER] RZĄD 1 2026-09-16f (KC `Dz.U. 2026 poz. 795`)
  → Pozew do sądu cywilnego właściwego dla siedziby zarządcy
```

---

## 4. SPECUSTAWA DROGOWA — ZRID (Dz.U. 2024 poz. 311 t.j.; ⛔ KOREKTA 2026-10-09: było „2024 poz. 1641” — rozporządzenie RM)

### Decyzja ZRID — jedna decyzja zastępuje trzy

```
ZRID (Zezwolenie na Realizację Inwestycji Drogowej) = 
  pozwolenie na budowę + podział nieruchomości + wywłaszczenie (w jednej decyzji)

Organ I instancji:
  → Starosta: drogi powiatowe i gminne
  → Wojewoda: drogi krajowe, ekspresowe, autostrady

Termin: 90 dni od złożenia kompletnego wniosku
Rygor natychmiastowej wykonalności: DECYZJA NADAJE GO Z MOCY USTAWY
  → Odwołanie NIE wstrzymuje budowy!
  → Wniosek o wstrzymanie wykonania: WSA (art. 61 §3 PPSA) — rzadko skuteczny

Zaskarżenie: odwołanie do Wojewody / Ministra Infrastruktury (14 dni) → WSA (30 dni)
```

### Wywłaszczenie i odszkodowanie przy ZRID

```
Wywłaszczenie z mocy prawa: grunty pod drogę stają się własnością Skarbu Państwa / JST
  z dniem uprawomocnienia ZRID

Odszkodowanie:
  → Starosta ustala w terminie 30 dni od ZRID
  → Podstawa: 105% wartości rynkowej nieruchomości (premia za szybkość)
  → Wszczęcie postępowania o wyższe odszkodowanie: sąd cywilny
  → Termin na wniesienie pozwu o wyższe odszkodowanie: weryfikuj przepisy w ELI (RZĄD 1)

Prawo wejścia na teren: natychmiast po rygorzę natychmiastowej wykonalności
```

---

## 5. TRANSPORT KOLEJOWY (Dz.U. 2026 poz. 1324 t.j.)

### Organy i licencje

```
Prezes UTK (Urząd Transportu Kolejowego):
  → Nadzór nad bezpieczeństwem i regulacja rynku kolejowego
  → Certyfikaty bezpieczeństwa dla przewoźników
  → Decyzje w sprawach dostępu do infrastruktury
  → Licencje przewoźnika kolejowego

PLK (PKP Polskie Linie Kolejowe S.A.): Zarządca infrastruktury

Licencja przewoźnika: UTK na podstawie kryteriów wiarygodności i zasobów
Certyfikat bezpieczeństwa:
  Część A (SMS — System Zarządzania Bezpieczeństwem)
  Część B (konkretna sieć/infrastruktura)
```

### Dostęp do infrastruktury

```
Zasada otwartego dostępu: każdy uprawniony przewoźnik ma prawo dostępu do infrastruktury PLK
Harmonogram (rozkład jazdy): negocjowany z PLK (aktualizowany co grudzień)
Opłaty dostępowe (unit charges): stawki zatwierdzone przez UTK
Odmowa dostępu: decyzja PLK → odwołanie do Prezesa UTK → WSA
```

---

## 6. PRAWO LOTNICZE (Dz.U. 2026 poz. 1407 t.j.)

### Organy i certyfikacja

```
ULC (Urząd Lotnictwa Cywilnego): nadzór, certyfikacja, licencje, rejestry
PANSA (Polska Agencja Żeglugi Powietrznej): ATM — kontrola ruchu lotniczego
EASA (Agencja UE): certyfikacja typów statków powietrznych, regulacje UE
```

### Drony (UAV/UAS) — regulacje UE i polskie

```
Kategorie unijne (Rozp. UE 2019/945 + 2019/947):
  Otwarta (A1–A3): loty do 120 m, bez specjalnego zezwolenia — warunki operacyjne
  Szczególna (STS): deklaracja / autoryzacja ULC
  Certyfikowana: dla dużych dronów — pełna certyfikacja

Rejestracja: drony > 250 g lub z kamerą → obowiązkowa w ewidencji ULC
Strefy zakazu lotów: lotniska, granice państwa, drogi — mapa ULC/PANSA (app PansaUTM)
Certyfikat operatora (UAVO): wymagany przy komercyjnym lataniu dronem
Naruszenie stref zakazu: mandat + przepadek drona
```

### Prawa pasażera lotniczego

```
Rozporządzenie UE 261/2004 (odszkodowania za opóźnienia/odwołania):
  → Opóźnienie ≥ 3 h lub odwołanie → odszkodowanie 250/400/600 EUR (zależnie od dystansu)
  → Wyłączenie: nadzwyczajne okoliczności (weryfikuj orzecznictwo TSUE)
  → Skarga do ULC lub pozew do sądu cywilnego
```

---

## 7. ELEKTROMOBILNOŚĆ (Dz.U. 2026 poz. 1243 t.j.)

### Strefy Czystego Transportu (SCT)

```
Tworzy: Rada gminy (na wniosek wójta/burmistrza/prezydenta)
Wjazd tylko: pojazdy elektryczne, wodorowe, CNG/LNG, hybrydowe (warunki)
Wyłączenia: pojazdy niepełnosprawnych, służby ratunkowe, mieszkańcy na wniosek
Opłaty: gmina może pobierać opłaty za wjazd (weryfikuj przepisy w ELI (RZĄD 1))
```

### Infrastruktura ładowania — AFIR

```
Rozp. UE 2023/1804 (AFIR): sieci ładowania co 60 km wzdłuż sieci TEN-T
Obowiązek budynków: biurowce i obiekty handlowe → min. % miejsc z LPE (weryfikuj EPBD)
Operatorzy OC-P: wymagana rejestracja w URE + interoperacyjność
```

---

## 8. KODEKS MORSKI (Dz.U. 2023 poz. 1309 t.j.)

> ⛔ **KOREKTA NUMERU 2026-08-15n (ZASADA 8 — „nazwa zgodna ≠ numer poprawny"):**
> do 2026-08-15 moduł, ROUTING-MAP i mapa Dz.U. podawały zgodnie **Dz.U. 2023
> poz. 1523**. Ten numer należy do **ustawy z 28.07.2023 o delegowaniu
> kierowców w transporcie drogowym** (ISAP `WDU20230001523`) — aktu z TEJ SAMEJ
> dziedziny transportowej, co maskowało błąd. Właściwy tekst jednolity Kodeksu
> morskiego pochodzi z obwieszczenia Marszałka Sejmu z 25.05.2023 i ma numer
> **Dz.U. 2023 poz. 1309**. ✅ [VER 2026-08-15n — 4 niezależne źródła: dwa PDF-y
> ISAP cytujące ten numer, tekst ustawy z 11.06.2026 na orka.sejm.gov.pl,
> infor.pl dla identyfikacji poz. 1523]. ⚠️ Przed powołaniem w piśmie —
> potwierdzić w ELI (RZĄD 1), czy nie ma nowszego t.j. (weryfikacja objęła numer, nie
> aktualność wobec nowelizacji z 2026 r.).

```
Armator: właściciel lub użytkownik statku we własnym imieniu i na własny rachunek
Bandera polska: statek wpisany do rejestru okrętowego (Izba Morska)
Konosament (bill of lading): dokument przewozu morskiego — papier wartościowy
Odpowiedzialność armatora: wg Reguł Haga-Wisby (ograniczona do SDR)
Termin dochodzenia: 1 rok od wydania ładunku lub daty przewozu (Reguły Haga)
Konwencje: SOLAS, MARPOL, MLC 2006, UNCLOS — stosowane bezpośrednio
```

---

## 9. MAPA PROCEDURALNA — KTÓRY TRYB

```
Problem → kwalifikacja trybu:
  Kara ITD → decyzja administracyjna → GITD → WSA
  Odmowa licencji transportowej → decyzja → odwołanie → WSA
  Szkoda z dziury w drodze → pozew do sądu cywilnego (art. 415 KC)
  ZRID (budowa drogi) → odwołanie → Wojewoda/Minister → WSA (nie wstrzymuje!)
  Odmowa dostępu do torów → Prezes UTK → WSA
  Dron w zakazanej strefie → mandat ITD lub sprawa karna
  Opóźnienie lotu → skarga do ULC lub pozew (sąd cywilny)
```

---

## 10. DOWODY

| Teza | Dowód | Źródło | Siła | Luka | Działanie |
|---|---|---|---|---|---|
| Szkoda z nieutrzymania drogi | Zdjęcia dziury + obrażenia + protokół policji | wnioskodawca | wysoka | brak zdjęć z miejsca | dokumentuj natychmiast |
| Kara ITD niezasadna | Zapis tachografu / CMR / list przewozowy | pojazd | wysoka | manipulacja tachografem | weryfikuj biegły |
| Odszkodowanie ZRID – za niskie | Operat szacunkowy rzeczoznawcy | majątkowy | wysoka | — | zlecaj własny operat |
| Prawo pasażera UE 261/2004 | Karta pokładowa + potwierdzenie opóźnienia | linia lotnicza | wysoka | „nadzwyczajne okoliczności" | żądaj szczegółów od linii |

---

## 11. QUALITY GATE

- [ ] Właściwa kategoria transportu i ustawa zidentyfikowane?
- [ ] Aktualny Dz.U. (transport kolejowy: 2026 poz. 1324; drogi: 2025 poz. 889) zweryfikowany?
- [ ] Termin 14 dni na odwołanie od decyzji nie upłynął?
- [ ] ZRID — rygor natychmiastowej wykonalności uwzględniony?
- [ ] Drony — kategoria UE i obowiązki rejestracyjne sprawdzone?
- [ ] Brzmienie przepisów z ISAP, nie z pamięci?

---

## POWIĄZANIA

| Sytuacja | Skill / Moduł |
|---|---|
| Specustawa — wywłaszczenie | `mod-PrGeodezyjne-kartografia-wywlaszczenia` |
| Środowisko przy inwestycji drogowej | `mod-ustawa-OOS-oceny-srodowiskowe` |
| Zamówienia publiczne (infrastruktura) | `dr-07` |
| Transport publiczny JST (PTZ) | `dr-08` → `mod-ustawa-komunalne-wod-kan-transport-czystosc` |
| Pismo: odwołanie od decyzji ITD | `pisma-procesowe-v3` |

---

**Źródła:**
- Drogi publiczne: https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20250000889
- Transport kolejowy: https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20260001324
- ULC (drony, prawo lotnicze): https://ulc.gov.pl
- ITD: https://www.itd.gov.pl
- UTK: https://utk.gov.pl
