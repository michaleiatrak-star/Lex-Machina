# DR-09 — Lokalna Mapa Aktów Prawnych

## Budownictwo, środowisko, energia, transport

Mapa runtime zawiera wyłącznie bieżące przypisanie **akt / zakres → moduł**. Historia korekt, dawne błędy numerów, zamknięte flagi i opisy sesji audytowych pozostają poza runtime.

| Akt / zakres | Bieżąca podstawa | Moduł / routing | Status runtime |
|---|---|---|---|
| Prawo ochrony środowiska (POŚ) | Dz.U. 2025 poz. 647 t.j. ze zm. | `mod-POS-prawo-ochrony-srodowiska` | ✅ aktywny; fresh gate |
| POŚ / OOŚ / Natura 2000 — workflow szczegółowy | POŚ jw. + UOOŚiS Dz.U. 2026 poz. 670 t.j. ze zm. + ustawa o ochronie przyrody Dz.U. 2026 poz. 1315 t.j. (ogł. 9.10.2026; brak zmian po t.j. (ELI 2026-10-12)) | `mod-POS-prawo-ochrony-srodowiska-szczegoly` | ✅ aktywny; fresh gate |
| Ustawa o zapobieganiu szkodom w środowisku i ich naprawie | Dz.U. 2020 poz. 2187 t.j. ze zm. | `mod-POS-prawo-ochrony-srodowiska` | ✅ aktywny; fresh gate |
| Prawo budowlane | Dz.U. 2026 poz. 524 t.j. ze zm. (po t.j.: 2026/605, 2026/646, **2026/1161** — w mocy 2.10.2026, rozdz. 10a od 2.09.2026) ✅ [VER] RZĄD 1 2026-10-04 | `mod-PrBud-prawo-budowlane` | ✅ aktywny; temporal gate |
| Prawo budowlane — pozostałe części | Prawo budowlane — Dz.U. 2026 poz. 524 t.j. ze zm. | `mod-PrBud-uzupelnienie-pokrycia-2026` | 🟡 B+ |
| Prawo budowlane — zmiana użytkowania / małe obiekty / ograniczenia | Prawo budowlane — Dz.U. 2026 poz. 524 t.j. ze zm. + właściwe akty wykonawcze | `mod-PrBud-patodeweloperka-uzytkowanie-male-obiekty-ograniczenia` | ✅ aktywny; fresh gate |
| Warunki techniczne budynków (art. 7 ust. 2 pkt 1 PrBud) — reżim przejściowy | ⛔ rozp. MI z 12.04.2002 (Dz.U. 2002 nr 75 poz. 690; t.j. 2022 poz. 1225 ze zm.) — NIE OBOWIĄZUJE od 20.09.2026 (art. 66 ustawy o zapewnianiu dostępności, t.j. Dz.U. 2024 poz. 1411 — 84 mies. od 20.09.2019); stosowalne przejściowo wyłącznie wg art. 102a–102c PrBud (Dz.U. 2026 poz. 1161; 18 mies. od 20.09.2026); 🟨 nowe rozp. — brak w ELI na 2026-10-04 (F-224) ✅ [VER] RZĄD 1 2026-10-04 | `mod-PrBud-uzupelnienie-pokrycia-2026` § 9a; `mod-PrBud-patodeweloperka-uzytkowanie-male-obiekty-ograniczenia` cz. B; `mod-ochrona-zabytkow-obiekty-uzytecznosci-publicznej` | ⚠️ fresh gate — sprawdzaj publikację nowego rozp. |
| Samorządy zawodowe architektów i inżynierów budownictwa | Dz.U. 2025 poz. 1783 t.j. ze zm. (po t.j.: **2026/1161** — w mocy 2.10.2026; art. 3–4 — sprawy w toku wg przepisów dotychczasowych) ✅ [VER] RZĄD 1 2026-10-04 | `mod-ustawa-architekci-inzynierowie-budownictwa-zawod` | ✅ aktywny; temporal gate |
| Prawo energetyczne / URE / OZE | Dz.U. 2026 poz. 43 t.j. ze zm. ✅ [VER] RZĄD 1 2026-09-16d (było `2025/459` — obwieszczenie MF, podmiana aktu) | `mod-PrEnergetyczne-URE-OZE` | ✅ aktywny; temporal gate |
| Prawo geodezyjne i kartograficzne / wywłaszczenia | Dz.U. 2024 poz. 1151 t.j. ze zm. | `mod-PrGeodezyjne-kartografia-wywlaszczenia` | ✅ aktywny |
| Ustawa o gospodarce nieruchomościami (UGN) | Dz.U. 2026 poz. 399 t.j. ze zm. | `mod-UGN-gospodarka-nieruchomosciami` | 🟢 B+/COV |
| Ustawa o przekształceniu prawa użytkowania wieczystego w prawo własności nieruchomości (29.07.2005) — przekształcenie NA WNIOSEK | **Dz.U. 2024 poz. 900 t.j.** ✅ [VER] RZĄD 1 2026-09-10e — obwieszczenie Marszałka Sejmu z 11.06.2024, akt bazowy Dz.U. 2005 nr 175 poz. 1459, najnowszy z 3 t.j., zero nowelizacji po tekście jednolitym | brak dedykowanego modułu — obsługa przez `mod-UGN-gospodarka-nieruchomosciami` | 🔴 KATALOGOWANY, bez modułu |
| Ustawa o przekształceniu prawa użytkowania wieczystego gruntów zabudowanych na cele mieszkaniowe w prawo własności (20.07.2018) — przekształcenie Z MOCY PRAWA od 1.01.2019 | **Dz.U. 2025 poz. 6 t.j.** ✅ [VER] RZĄD 1 2026-09-10e — obwieszczenie z 23.12.2024, akt bazowy Dz.U. 2018 poz. 1716, zero nowelizacji po tekście jednolitym | brak dedykowanego modułu — obsługa przez `mod-UGN-gospodarka-nieruchomosciami` | 🔴 KATALOGOWANY, bez modułu |
| Prawo geologiczne i górnicze | Dz.U. 2026 poz. 69 t.j. ze zm. | `mod-prawo-geologiczne-gornicze` | ✅ aktywny |
| Prawo wodne | Dz.U. 2026 poz. 1335 t.j. (obwieszczenie 17.09.2026, ogł. 14.10.2026; obejmuje 2025/1535, 2026/445, 605, 815, 1033 i 1156 — zmiany z 2026/1156 w tekście jako brzmienie od 1.01.2027); brak zmian po t.j. (ELI 2026-10-15) | `mod-PrWodne-gospodarka-sciekowa` | ✅ aktywny |
| Ustawa o OOŚ / oceny środowiskowe | Dz.U. 2026 poz. 670 t.j. ze zm. | `mod-ustawa-OOS-oceny-srodowiskowe` | ✅ aktywny |
| Ustawa o elektromobilności i paliwach alternatywnych | **Dz.U. 2026 poz. 1243 t.j.** (obwieszczenie z 1.09.2026, ogłoszone 23.09.2026; poprzedni t.j. 2024/1289 — status ELI „wygaśnięcie aktu”) ✅ [VER] RZĄD 1 2026-10-04 | `mod-ustawa-transport-drogowy-kolejowy-lotniczy-morski` (§ 7 ELEKTROMOBILNOŚĆ) | ✅ aktywny; fresh gate; ✅ VER 2026-09-01 RZĄD 1 (ELI DU/2024/1289: obwieszczenie 19.08.2024, status obowiązujący) — KOREKTA: dawny numer 2024 poz. 1634 należy do rozporządzenia MF ws. zwrotu VAT siłom zbrojnym |
| Ustawa o charakterystyce energetycznej budynków (świadectwa charakterystyki energetycznej) | Dz.U. 2024 poz. 101 t.j. ze zm. — ✅ [VER] RZĄD 1 2026-09-16d (w module) | `mod-ustawa-charakterystyka-energetyczna` | ✅ aktywny |
| Ustawa o planowaniu i zagospodarowaniu przestrzennym | Dz.U. 2026 poz. 538 t.j. ze zm. | `mod-ustawa-planowanie-przestrzenne` | ✅ aktywny |
| Prawo energetyczne — rynek gazu (brak odrębnej ustawy „Prawo gazowe") | Dz.U. 2026 poz. 43 t.j. ze zm. ✅ [VER] RZĄD 1 2026-09-16d (było `2024/1538` — obwieszczenie MSWiA, podmiana aktu) | `mod-ustawa-prawo-gazowe` | ✅ aktywny; fresh gate |
| Transport drogowy / kolejowy / lotniczy / morski | transport drogowy Dz.U. 2025 poz. 1490 t.j.; drogi publiczne Dz.U. 2025 poz. 889 t.j.; specustawa ZRID Dz.U. 2024 poz. 311 t.j.; transport kolejowy Dz.U. 2026 poz. 1324 t.j.; Prawo lotnicze Dz.U. 2025 poz. 1431 t.j.; Kodeks morski Dz.U. 2023 poz. 1309 t.j.; elektromobilność Dz.U. 2026 poz. 1243 t.j. — wszystkie ze zm.; ⛔ po t.j. (✅ [VER] RZĄD 1 2026-10-09 (ELI, daty z przepisów o wejściu w życie)): transport drogowy — Dz.U. 2025 poz. 1676 art. 3 (pkt 2–7 od 17.12.2025, pkt 1 od 3.09.2026), 1795 art. 110–111 (od 18.03.2026), 1843 art. 2 (z mocą od 1.01.2026), Dz.U. 2026 poz. 982, ⏳ 2026 poz. 875 art. 7 (od 1.01.2027); drogi publiczne — Dz.U. 2026 poz. 815 art. 2 (od 4.07.2026), 982 (w mocy 21.09.2026, cz. 23.07 i 06.08.2026); transport kolejowy — brak zmian po t.j. 2026/1324 (✅ [VER] RZĄD 1 2026-10-15, ELI; t.j. obejmuje 2026/41, 815, 912); Prawo lotnicze — Dz.U. 2025 poz. 1668 art. 3 (od 9.12.2025), Dz.U. 2026 poz. 607 art. 1 (od 21.05.2026, art. 209uo ust. 1 i 3 od 1.01.2027), 864 art. 3 (od 1.10.2026), 1157 art. 4 (od 16.09.2026), ⏳ 176 art. 13 (od 18.02.2027); Kodeks morski — Dz.U. 2026 poz. 1004 art. 4 (od 27.08.2026). Brzmienie czytać u źródła | `mod-ustawa-transport-drogowy-kolejowy-lotniczy-morski` | ✅ aktywny; fresh gate |
| Specustawa drogowa / ZRID | Dz.U. 2024 poz. 311 t.j. ze zm. | `mod-GDDKiA-specustawa-drogowa-ZRID` | ✅ aktywny |
| Ustawa o odpadach / gospodarka komunalna | Dz.U. 2026 poz. 1328 t.j. (obwieszczenie 1.09.2026, ogł. 14.10.2026; obejmuje 12 ustaw zmieniających, m.in. 2025/1812, 2026/174, 815, 875 — 2026/875 w tekście jako brzmienie od 1.01.2027); brak zmian po t.j. (ELI 2026-10-15) | `mod-ustawa-odpadach-gospodarka-komunalna` | ✅ aktywny; fresh gate |
| Ustawa o ochronie przyrody — formy ochrony | Dz.U. 2026 poz. 1315 t.j. (ogł. 9.10.2026; brak zmian po t.j. (ELI 2026-10-12)) | `mod-formy-ochrony-przyrody-obszary-chronione` | ✅ aktywny |
| Wycinka / odpady niebezpieczne / remediacja | ustawa o ochronie przyrody Dz.U. 2026 poz. 1315 t.j. + ustawa o odpadach Dz.U. 2026 poz. 1328 t.j. (brak zmian po t.j., ELI 2026-10-15) + POŚ Dz.U. 2025 poz. 647 t.j. ze zm. (ELI 2026-10-12) | `mod-srodowisko-wycinka-odpady-niebezpieczne-rekultywacja` | ✅ aktywny; fresh gate |
| Inspekcja Ochrony Środowiska | Dz.U. 2024 poz. 425 t.j. ze zm. | `mod-inspekcja-ochrony-srodowiska-GIOS-WIOS` | ✅ aktywny; fresh gate |
| System kaucyjny / opakowania | Dz.U. 2026 poz. 619 t.j. ze zm. | `mod-system-kaucyjny-opakowania` | ✅ aktywny; fresh gate |
| ⛔ **PPWR — rozporządzenie (UE) 2025/40** (opakowania i odpady opakowaniowe; uchyla dyrektywę 94/62/WE) | **CELEX `32025R0040`**, ELI `data.europa.eu/eli/reg/2025/40/oj` ✅ [VER] RZĄD 1 2026-09-13 — EUR-Lex, status **In force**. ⛔ **STOSUJE SIĘ OD 12.08.2026** (art. 67 ust. 5 — od 12.02.2029). Dyrektywa 94/62/WE traci moc od 12.08.2026 z wyjątkiem art. 8 ust. 2 i art. 9 ust. 1-2 | `mod-UE-PPWR-EUDR-rozporzadzenia-srodowiskowe` | ✅ aktywny; ⛔ akt UE **bezpośrednio stosowany** — nie szukać obowiązku w ustawie polskiej |
| ⛔ **EUDR — rozporządzenie (UE) 2023/1115** (produkty niepowodujące wylesiania; uchyla rozp. 995/2010) | **CELEX `32023R1115`**, wersja skonsolidowana `02023R1115-20251226` ✅ [VER] RZĄD 1 2026-09-13. ⛔⛔ **DATA STOSOWANIA PRZESUWANA DWUKROTNIE** — obowiązuje **30.12.2026**, a dla osób fizycznych oraz mikro- i małych przedsiębiorstw ustanowionych do 31.12.2024 — **30.06.2027** (art. 38 ust. 2-3). Powtarzane daty 30.12.2025 / 30.06.2026 są NIEAKTUALNE | `mod-UE-PPWR-EUDR-rozporzadzenia-srodowiskowe` | ✅ aktywny; ⛔ odczyt WERSJI SKONSOLIDOWANEJ, nie tekstu pierwotnego |
| Ustawa o ochronie zabytków + obiekty użyteczności publicznej | Dz.U. 2024 poz. 1292 t.j. ze zm. + Prawo budowlane Dz.U. 2026 poz. 524 t.j. ze zm. + właściwe akty wykonawcze | `mod-ochrona-zabytkow-obiekty-uzytecznosci-publicznej` | ✅ aktywny; fresh gate |
| Prawo łowieckie — moduł ogólny / ochrona przyrody | Dz.U. 2025 poz. 539 t.j. ze zm. | `mod-ustawa-lesna-lowiecka-ochrona-przyrody` | ✅ aktywny |
| Prawo łowieckie — szkody łowieckie | Prawo łowieckie — Dz.U. 2025 poz. 539 t.j. ze zm. | `mod-szkody-lowieckie-szacowanie-odszkodowanie` | ✅ aktywny |
| Prawo łowieckie — obwody / dzierżawa / odszkodowania | Prawo łowieckie — Dz.U. 2025 poz. 539 t.j. ze zm. | `mod-lowieckie-obwody-dzierzawa-odszkodowania` | ✅ aktywny |
| Prawo łowieckie — wykonywanie polowania | Prawo łowieckie — Dz.U. 2025 poz. 539 t.j. ze zm. | `mod-lowieckie-wykonywanie-polowania-uprawnienia` | ✅ aktywny |
| Prawo łowieckie — odpowiedzialność dyscyplinarna PZŁ | Prawo łowieckie — Dz.U. 2025 poz. 539 t.j. ze zm. | `mod-lowieckie-odpowiedzialnosc-dyscyplinarna-PZL` | ✅ aktywny |
| Prawo łowieckie — PZŁ / koła / nadzór ministra | Prawo łowieckie — Dz.U. 2025 poz. 539 t.j. ze zm. | `mod-lowieckie-PZL-kola-nadzor-ministra` | ✅ aktywny |
| Prawo łowieckie — straż łowiecka | Prawo łowieckie — Dz.U. 2025 poz. 539 t.j. ze zm. | `mod-lowieckie-straz-lowiecka-PSL-uprawnienia` | ✅ aktywny |
| Prawo łowieckie — zasady gospodarki / plany | Prawo łowieckie — Dz.U. 2025 poz. 539 t.j. ze zm. | `mod-lowieckie-zasady-gospodarki-lowieckiej-plany` | ✅ aktywny |
| Prawo łowieckie — przepisy ogólne / organy administracji | Prawo łowieckie — Dz.U. 2025 poz. 539 t.j. ze zm. | `mod-lowieckie-przepisy-ogolne-organy-administracji` | ✅ aktywny |
| Prawo łowieckie — działalność gospodarcza / turystyka / obrót | Prawo łowieckie — Dz.U. 2025 poz. 539 t.j. ze zm. | `mod-lowieckie-dzialalnosc-gospodarcza-turystyka-obrot` | ✅ aktywny |
| Prawo łowieckie — przepisy przejściowe / końcowe | Prawo łowieckie — Dz.U. 2025 poz. 539 t.j. ze zm. | `mod-lowieckie-przepisy-przejsciowe-koncowe-derogacja` | ✅ aktywny |
| Kłusownictwo | Prawo łowieckie Dz.U. 2025 poz. 539 t.j. ze zm. + ustawa o rybactwie śródlądowym Dz.U. 2022 poz. 883 t.j. ze zm. | `mod-lowiectwo-klusownictwo` | ✅ aktywny; fresh gate |

> ⛔ **Dwie różne ustawy o przekształceniu użytkowania wieczystego — nie mylić.**
> Ustawa z 2005 r. działa **na wniosek** i obejmuje szeroki krąg nieruchomości;
> ustawa z 2018 r. przekształciła **z mocy prawa** grunty zabudowane na cele
> mieszkaniowe z dniem 1.01.2019. Powołanie niewłaściwej z nich jest błędem
> podstawy prawnej, nie nieścisłością nazewniczą. Obie mają odrębne t.j.
> (2024/900 i 2025/6) i odrębne akty bazowe (2005/1459 i 2018/1716).

## Reguły runtime

- każdy fizyczny moduł DR-09 pozostaje jawnie rejestrowany w tej mapie zgodnie z `check_rejestracja_modulow.py`;
- mapy nie przechowują dawnych błędów numerów, opisów napraw, zamkniętych flag ani narracji kolejnych sesji;
- przepisy wykonawcze, projekty, harmonogramy wejścia w życie i dynamiczne akty środowiskowe/energetyczne wymagają fresh lub temporal gate;
- status runtime wskazuje routing, nie `FULL` artykuł-po-artykule.
