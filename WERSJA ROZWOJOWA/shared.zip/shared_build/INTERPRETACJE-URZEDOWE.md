# INTERPRETACJE-URZEDOWE — Rejestr oficjalnych źródeł interpretacji prawa per dziedzina

## Cel

ISAP (akty prawne) i portale orzecznictwa (sn.pl, nsa.gov.pl, orzeczenia.ms.gov.pl,
trybunal.gov.pl, curia.europa.eu, hudoc.echr.coe.int) pokrywają WARSTWĘ LEGISLACYJNĄ
i ORZECZNICZĄ. Dla prawa miejscowego i aktów jednostek z własnym reżimem (gmina,
powiat, samorządy zawodowe, uczelnie, regulatorzy) źródłem równoważnym są: dzienniki
urzędowe województw, BIP właściwego organu/jednostki, rejestry urzędowe, statuty,
regulaminy, uchwały, zarządzenia i akty nadzorcze — weryfikuj online, nigdy z pamięci.

Ten moduł uzupełnia trzecią warstwę: **oficjalne interpretacje, wytyczne, stanowiska
i wyjaśnienia organów administracji i regulatorów** — istotne przy ocenie praktyki
stosowania prawa (jak organ faktycznie interpretuje przepis), niezależnie od linii
orzeczniczej sądów.

## Zasada

Każdy moduł DR przy analizie powołującej się na praktykę administracyjną organu
(a nie tylko na sam przepis/wyrok) powinien — jeśli to istotne dla sprawy — sprawdzić
także właściwy organ interpretacyjny z listy poniżej. Lazy loading: wczytuj tylko
wiersz właściwy dla dziedziny sprawy. Status interpretacji organu ≠ status wyroku —
zawsze zaznacz, czy źródło to interpretacja administracyjna (niewiążąca sądu) czy
orzeczenie.

## Rejestr per DR

| DR | Dziedzina | Dodatkowe źródła interpretacji urzędowej |
|---|---|---|
| DR-01 | Ustrój konstytucyjny, źródła prawa | `rcl.gov.pl` (Rządowe Centrum Legislacji — projekty, OSR, uzasadnienia), `rpo.gov.pl` (wystąpienia generalne RPO) |
| DR-02 | Cywilne, rodzinne, gospodarcze | `rf.gov.pl` (Rzecznik Finansowy — interpretacje w sporach konsumenckich finansowych/ubezpieczeniowych), `uokik.gov.pl` (decyzje, wyjaśnienia, rejestr klauzul niedozwolonych), `ekrs.ms.gov.pl` (KRS — wpisy, dokumenty spółek) |
| DR-03 | Karne, wykroczenia, egzekucja | `gov.pl/web/prokuratura-krajowa` (wytyczne i komunikaty Prokuratury Krajowej), `komornik.pl` (Krajowa Izba Komornicza — wytyczne egzekucyjne) |
| DR-04 | Praca, ZUS, świadczenia | `zus.pl` (interpretacje indywidualne ZUS, baza wyjaśnień składkowych/świadczeniowych), `pip.gov.pl` (Państwowa Inspekcja Pracy — stanowiska prawne), `gov.pl/web/rodzina` (MRPiPS — interpretacje KP, świadczenia rodzinne) |
| DR-05 | Administracyjne, sądowoadministracyjne | `rpo.gov.pl` (wystąpienia RPO w sprawach administracyjnych), `gov.pl` (BIP właściwego ministerstwa — wyjaśnienia KPA) |
| DR-06 | Podatki, finanse publiczne, AML | *(już szeroko pokryte: interpretacje.podatki.gov.pl, eureka)* + `gov.pl/web/finanse` (komunikaty MF), `gov.pl/web/finanse/giif` (GIIF — interpretacje AML/przeciwdziałanie praniu pieniędzy) |
| DR-07 | Zamówienia publiczne, fundusze UE | *(już: uzp.gov.pl, kio.gov.pl)* + `funduszeeuropejskie.gov.pl` (interpretacje wytycznych kwalifikowalności UE), `gov.pl/web/uokik` (pomoc publiczna — decyzje i wyjaśnienia) |
| DR-08 | Samorząd terytorialny, prawo lokalne | `rio.gov.pl` (Regionalne Izby Obrachunkowe — rozstrzygnięcia nadzorcze ws. budżetów i uchwał JST), BIP właściwego wojewody (rozstrzygnięcia nadzorcze wojewody) |
| DR-09 | Budownictwo, środowisko, energia, transport | `gunb.gov.pl` (Główny Urząd Nadzoru Budowlanego — wyjaśnienia Prawa budowlanego), `gdos.gov.pl` (Generalna Dyrekcja Ochrony Środowiska — wytyczne OOŚ/Natura 2000), `ure.gov.pl` (Urząd Regulacji Energetyki — interpretacje, decyzje) |
| DR-10 | Zdrowie, farmacja, żywność, rolnictwo | *(już: urpl.gov.pl, gif.gov.pl, mz.gov.pl)* + `gis.gov.pl` (Główny Inspektorat Sanitarny — stanowiska sanepid), `wetgiw.gov.pl` (Główny Inspektorat Weterynarii) |
| DR-11 | Cyfrowe, cyberbezpieczeństwo, AI, dane, IP | *(już: uodo.gov.pl, uprp.gov.pl)* + `uke.gov.pl` (Urząd Komunikacji Elektronicznej — interpretacje Prawa telekomunikacyjnego), `cert.pl` / `gov.pl/web/baza-wiedzy` (CSIRT NASK — wytyczne KSC/NIS2) |
| DR-12 | Sądownictwo, prokuratura, zawody prawnicze | `gov.pl/web/sprawiedliwosc` (komunikaty i wytyczne MS), `rpo.gov.pl`, samorządy zawodowe: `nra.pl` (adwokatura), `kirp.pl` (radcowie prawni), `kin.pl` (notariat — KRN) |
| DR-13 | Służby, bezpieczeństwo, informacje niejawne | `abw.gov.pl` (wytyczne ochrony informacji niejawnych), `gov.pl/web/sluzby-specjalne` |
| DR-14 | Prawo UE, międzynarodowe, prawa człowieka | *(już szeroko pokryte: eur-lex, curia, echr, hcch)* — bez zmian |
| DR-15 | Compliance, ISO, governance, audyt | *(już: iso.org, pkn.pl)* + `uodo.gov.pl` (wytyczne RODO w compliance), `knf.gov.pl` (governance — sektor finansowy, ESG) |
| DR-16 | Pisma, strategia, dowody, orzecznictwo | brak dodatkowych — dziedzina metodyczna, korzysta ze źródeł DR-01…DR-15 wg sprawy |

## Status interpretacji vs orzecznictwo

- Interpretacja indywidualna / stanowisko organu → wiąże tylko adresata (np. interpretacja
  podatkowa, ZUS) lub ma charakter informacyjny (np. stanowisko PIP, GIS).
- Rozstrzygnięcie nadzorcze RIO/wojewody → wiążące dla aktu JST, zaskarżalne do WSA.
- Decyzja regulatora (URE, UKE, UOKiK, KNF, UODO) → akt administracyjny, zaskarżalny.
- W piśmie procesowym/analizie zawsze odróżnij: ⚖️ orzeczenie sądu vs 📋 interpretacja/
  stanowisko organu — różna siła wiążąca.
