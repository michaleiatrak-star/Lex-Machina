# WERYFIKACJA-ŚLAD — Moduł Audytu Śladu Weryfikacji

> **Plik:** `shared/WERYFIKACJA-SLAD.md`
> **Wersja:** 1.8 (2026-09-22) — F-194: drugi precedens NSA (I OSK 590/26, 🟨 bez awansu), GRAD-3b-SYM (flaga symbolu CBOSA) i KALIBRACJA-PRZECIWNIK (wadliwe powołania przeciwnika ≠ argument merytoryczny).
> **Wersja:** 1.4 (2026-07-15b) — dodano obowiązkową kategoryzację RZĄD
>              (odesłanie do `shared/HIERARCHIA-ZRODEL.md`) przy każdej
>              kotwicy tekstowej i w tabeli śladu — zgłoszone przez
>              użytkownika po incydencie: link 🔗 podany bez kategoryzacji
>              źródła (patrz CHANGELOG)
> **Wersja 1.2** (2026-07-05b) — naprawa luki "cytat na poparcie tezy bez
>              parafrazy" (NSA I FZ 104/26) + GUARD INSTYTUCJA/PRZEDMIOT dla
>              orzeczeń anonimizowanych (adm./karne)
> **Wersja 1.1** (2026-07-05a) — GRADIENT ISTNIENIE/TREŚĆ/FRAGMENT
>              + guard STRON; wzorzec citation-grounding-pl v2.1
> **Status:** AKTYWNY — naprawa BLOKER-3, rozszerzenie po AUDYT-2026-07-05b,
>              rozszerzenie 1.3 po teście KOTWICA-TEKSTOWA (2026-07-15),
>              rozszerzenie 1.4 po dodaniu kategoryzacji RZĄD (2026-07-15b)

---

## PROBLEM

Model może pominąć web_search i nadal "zaliczyć" self-check przez błędne zaznaczenie
checkboxa. Brak widocznego artefaktu URL w odpowiedzi uniemożliwia użytkownikowi
weryfikację. System musi generować **widzialny ślad weryfikacji** dla każdego
artykułu, liczby i orzeczenia.

---

## ZASADA ŚLADU

**Każdy przepis / liczba / termin / orzeczenie musi mieć JEDEN Z DWÓCH znaczników:**

```
✅ [VER: isap.sejm.gov.pl, 2026-05-25] — zweryfikowano online (URL + data)
⚠️ [NIEWERYFIKOWANE] — weryfikacja niemożliwa (brak dostępu, timeout)
```

> ⛔ **ZAKAZ** oznaczania `✅ [VER]` bez faktycznego wykonania narzędzia.
> Samo wywołanie narzędzia nie wystarcza, jeżeli narzędzie jawnie zwraca kopię
> crawlera/indexu zamiast bieżącego odczytu originu. W takim przypadku zachowaj
> `⚠️ [NIEWERYFIKOWANE]` i zapisz provenance `access_mode=CRAWLED_OR_INDEXED`,
> chyba że istnieje niezależne bieżące potwierdzenie w oficjalnym kanale.

---

## PROVENANCE KANAŁU — NIE JEST NOWYM STATUSEM

Do każdego elementu można dopisać techniczne pole `access_mode`:
- `DIRECT_LIVE` — bieżący odczyt originu/API;
- `CRAWLED_OR_INDEXED` — snapshot/crawler/index;
- `DIRECT_UNAVAILABLE` — bieżąca próba direct zawiodła;
- `POLICY_BLOCKED` — narzędzie odmówiło dostępu.

Pole to nie zastępuje i nie rozszerza statusów ✅/⚠️.

Przykład dla CBOSA:

```
Wyrok NSA II GSK 2297/25
⚠️ [NIEWERYFIKOWANE]
access_mode=CRAWLED_OR_INDEXED
content_scope=METADATA_SENTENCE_REASONING_FULL
```

Znaczenie: system faktycznie przeczytał bogatą reprezentację dokumentu i może
jej użyć do researchu/analizy, ale nie twierdzi, że origin został odczytany
bieżąco. Po późniejszym potwierdzeniu direct można zaktualizować ślad zgodnie
z normalnymi warunkami ✅ [VER].
---

## FORMAT ŚLADU WERYFIKACJI

### Poziom minimalny (śródtekstowy)

```
art. 190 §1 KK ✅ [VER: isap.gov.pl]
art. 190a §4 KK — tryb na wniosek ✅ [VER: orka.sejm.gov.pl, 25.05.2026]
Termin: 2 tygodnie na sprzeciw od nakazu zapłaty (art. 502 §1 KPC) ✅ [VER: isap.gov.pl]
```

### Poziom pełny (sekcja na końcu analizy / pisma)

```
---
## 🔍 Ślad weryfikacji

| Element | Źródło | Data weryfikacji | Status |
|---|---|---|---|
| art. 190 §1 KK — kara do 3 lat PW | isap.sejm.gov.pl (Dz.U.2025.383) | 2026-05-25 | ✅ |
| art. 190a §4 KK — tryb na wniosek | orka.sejm.gov.pl | 2026-05-25 | ✅ |
| art. 12 §4 KPK — wyjątek wnioskowy | isap.sejm.gov.pl (Dz.U.2026.490) | 2026-05-25 | ✅ |
| Wyrok SN V KK 123/22 | sn.pl (nie znaleziono) | 2026-05-25 | ⚠️ NIEWERYFIKOWANE |
```

---

## 🔗 KOTWICA-TEKSTOWA (Text Fragment) — SCALONE do PRAWO-HARDGATE.md (2026-07-15c)

> ⛔ **Ten mechanizm nie jest już opisany tutaj osobno.** Powstał 2026-07-15
> niezależnie od KROK 5A w `shared/PRAWO-HARDGATE.md` (dodanego tego samego
> dnia) — dwie osobne implementacje tego samego problemu w dwóch plikach
> shared/, wykryte przez użytkownika jako duplikacja po incydencie, w którym
> odpowiedź z modułu karnego (dr-03) nie zastosowała żadnej z nich.
>
> Pełna, kanoniczna procedura (Text Fragment `#:~:text=`, KT-1→KT-4,
> kategoryzacja RZĄD, zastrzeżenie o wsparciu przeglądarek, FALLBACK) jest
> teraz WYŁĄCZNIE w:
> `view shared/PRAWO-HARDGATE.md` → sekcja KROK 5A
>
> Ten plik (WERYFIKACJA-SLAD.md) pozostaje właściwym miejscem dla znaczników
> ✅/⚠️ [VER/NIEWERYFIKOWANE] i GRADIENTU (ISTNIENIE/TREŚĆ/FRAGMENT) — patrz
> sekcje niżej. KOTWICA-TEKSTOWA jest odrębnym, dodatkowym mechanizmem
> nawigacyjnym opisanym w PRAWO-HARDGATE.md, nie zastępuje GRADIENTU.
>
> Pełny opis scalenia: `audyt-systemu-v4/references/AUDIT-JOURNAL.md`,
> wpis AUDYT-2026-07-15c.

---

## 🎚️ GRADIENT WERYFIKACJI CYTATU — ISTNIENIE / TREŚĆ / FRAGMENT

> Dodano: 2026-07-05 (AUDYT-2026-07-05a). Wzorzec: citation-grounding-pl v2.1
> (adaptacja gradientu Existence/Content/Paragraph). Zamyka lukę
> "prawdziwy cytat, fałszywa teza" (problem Stanford "false-under-true"):
> dotychczasowy ślad ✅ [VER] potwierdzał ISTNIENIE przepisu/sygnatury,
> ale nie sprawdzał, czy PARAFRAZA oddaje faktyczną treść źródła.

> ⚠️ **Case study zamknięty przez v1.2 (2026-07-05b):** postanowienie NSA z
> 23.06.2026, sygn. **I FZ 104/26** — pełnomocnik powołał w zażaleniu
> postanowienia NSA jako rzekome poparcie tezy o przesłankach wstrzymania
> wykonania decyzji (art. 61 § 3 p.p.s.a.). NSA ustalił, że: (1) powołane
> postanowienia zapadły w innych datach niż podane, (2) żadne z nich w
> ogóle nie dotyczyło instytucji wstrzymania wykonania, (3) teza pisma
> była sprzeczna z ugruntowaną linią orzeczniczą co do ciężaru dowodu.
> NSA nazwał to wprost "bezrefleksyjnym korzystaniem z AI" i brakiem
> profesjonalizmu pełnomocnika. Luka w v1.1: GRAD-1 klasyfikował "gołe"
> powołanie (bez cudzysłowu, bez wprost sformułowanej parafrazy) jako
> wymagające tylko ISTNIENIA — a to za mało, gdy powołanie ma poprzeć
> konkretną tezę. v1.2 zamyka to w GRAD-1 (poniżej) i dodaje GUARD
> INSTYTUCJA dla spraw, gdzie strony są anonimizowane (adm./karne) i
> GUARD STRON nie ma czego porównać.

> 🟨 **Drugi precedens (dodano 2026-09-22, F-194) — wyrok NSA z 31.08.2026,
> sygn. I OSK 590/26** (Izba Ogólnoadministracyjna; sprawa zasiłku stałego —
> renta wyrównawcza a kryterium dochodowe). Status: **🟨 snapshot, BEZ AWANSU** —
> istnienie potwierdzone dwoma źródłami wtórnymi RZĘDU 2B (prawo.pl, 22.09.2026;
> wykaz orzeczeń inforfk.pl), CBOSA w dniu dodania: HTTP 503 na `/cbo/search`
> i `/cbo/find` (kanał kodu), dokument nieodczytany → content_scope =
> METADATA. ⛔ Do odczytu z CBOSA wolno powołać WYŁĄCZNIE metrykę, nie tezy.
> Wg relacji prasowej: skarga kasacyjna SKO sporządzona przez radcę prawnego
> powoływała 7 orzeczeń; NSA sprawdził wszystkie — część miała inną datę
> i inny przedmiot (m.in. odszkodowanie za nieruchomość, przewlekłość
> postępowania przed ministrem), część nie figurowała w rejestrze NSA.
> ⭐ **Co wnosi ponad I FZ 104/26:** (1) linia obejmuje już dwie izby NSA;
> (2) powołania o innym PRZEDMIOCIE były wykrywalne tanio — różnym symbolem
> sprawy (→ GRAD-3b-SYM); (3) SKO mimo to WYGRAŁO co do istoty — wadliwe
> powołania nie przesądziły wyniku (→ KALIBRACJA-PRZECIWNIK).
> Awans do ✅: po odczycie `/doc/{ID}` w CBOSA (V-SYG-0.7) — flaga F-194.

**Zasada:** samo `✅ [VER]` (istnienie) NIE wystarcza, gdy odpowiedź twierdzi coś
o TREŚCI źródła. Poziom weryfikacji musi odpowiadać sile twierdzenia.

### Trzy poziomy weryfikacji

| Poziom | Co potwierdza | Wymagany dla |
|---|---|---|
| **ISTNIENIE** | Kotwica (sygnatura / nr Dz.U. / CELEX, data, organ) jest realna i zgodna z deklaracją | wyłącznie neutralne wzmianki bez funkcji dowodowej: "sprawa toczyła się pod sygn. X", spis/wykaz orzeczeń bez tezy |
| **TREŚĆ** | Źródło CO DO ISTOTY zawiera to, co twierdzi odpowiedź | parafraza ("SN przyjął, że…"), ORAZ **każde powołanie użyte jako poparcie tezy/argumentu — nawet bez cudzysłowu i bez wprost sformułowanej parafrazy** (np. "zgodnie z ugruntowaną linią orzeczniczą (por. sygn. X, Y, Z)…", "analogicznie orzekł NSA w sprawach…") |
| **FRAGMENT** | Cytowany fragment istnieje DOSŁOWNIE w źródle | każdy cytat w cudzysłowie, każdy pinpoint (§, ustęp, akapit uzasadnienia) |

> ⛔ **Reguła I FZ 104/26 (v1.2):** "powołanie na poparcie" ≠ "sama kotwica".
> Jeśli sygnatura/Dz.U. pojawia się w zdaniu, które ma PRZEKONAĆ o czymś
> (poprzeć tezę, argument, linię orzeczniczą) — to zawsze **minimum TREŚĆ**,
> niezależnie od tego, czy jest cudzysłów. Do ISTNIENIA wolno zejść WYŁĄCZNIE
> gdy powołanie nie pełni żadnej funkcji dowodowej (czysty spis/inwentarz).
> W razie wątpliwości, czy dane powołanie "popiera tezę" — traktuj jako TREŚĆ
> (zasada ostrożności, nie odwrotnie).

### Procedura GRAD

```
GRAD-1: Sklasyfikuj każde powołanie w planowanej odpowiedzi:
          cytat dosłowny / teza z pinpointem     → wymagany poziom FRAGMENT
          stanowisko sądu / parafraza przepisu    → wymagany poziom TREŚĆ
          powołanie użyte jako poparcie tezy/argumentu (nawet gołe,
            bez cudzysłowu i bez wprost sformułowanej parafrazy)
            → wymagany poziom TREŚĆ (reguła I FZ 104/26, patrz wyżej)
          samo powołanie bez funkcji dowodowej (spis/inwentarz)
            → wymagany poziom ISTNIENIE

GRAD-2: Zweryfikuj na WYMAGANYM poziomie — wobec treści pobranej ze źródła
        (PRAWO-HARDGATE KROK 3: odczyt ze źródła, nie z pamięci):
          FRAGMENT → porównaj cytat ze źródłem znak-po-znaku (po normalizacji:
                     wielkość liter, białe znaki, cudzysłowy „"», myślniki —–,
                     [...] jako dozwolona luka). Słowo nośne inne = brak trafienia.
          TREŚĆ    → sprawdź czy terminy nośne twierdzenia (≥4 znaki, bez słów
                     funkcyjnych) występują w źródle I czy sens nie jest odwrócony
                     (zwłaszcza: kto wygrał, co oddalono, zakres wyjątku).
                     Dla powołania-na-poparcie: dodatkowo ustal, czy źródło W OGÓLE
                     dotyczy tej samej INSTYTUCJI/PROCEDURY co teza (nie tylko tego
                     samego działu prawa) — patrz GRAD-3b.
          ISTNIENIE→ kontrakt FOUND/NOT_FOUND/AMBIGUOUS (shared/SYGNATURY.md)
                     lub KROK 2B PRAWO-HARDGATE (tytuł aktu vs teza).

GRAD-3: GUARD STRON (dla orzeczeń, gdy znane są strony postępowania):
        porównaj strony deklarowane w odpowiedzi ze stronami ze źródła.
        Sygnatura zgodna + strony RAŻĄCO rozbieżne = 🔴 blokada
        ("prawdziwa sygnatura doczepiona do INNEJ sprawy").
        Formy prawne pomijaj w porównaniu (S.A. ≡ Spółka Akcyjna, sp. z o.o.).

GRAD-3b: GUARD INSTYTUCJA/PRZEDMIOT (NOWE v1.2 — gdy GUARD STRON niemożliwy,
        np. sprawy administracyjne/karne z anonimizacją do inicjałów,
        LUB jako dodatkowa kontrola obok GUARD STRON):
        Ustal PRZEDMIOT sprawy cytowanego orzeczenia wprost ze źródła
        (sentencja / pierwszy akapit uzasadnienia — nie z pamięci ani
        z tego, jak przedstawia go pełnomocnik/model). Porównaj z INSTYTUCJĄ
        PRAWNĄ, którą powołanie ma poprzeć (np. "wstrzymanie wykonania decyzji
        art. 61 § 3 p.p.s.a." vs orzeczenie faktycznie dotyczące np. kosztów
        postępowania albo przywrócenia terminu — RÓŻNE instytucje mimo tej
        samej gałęzi prawa/tego samego typu sprawy administracyjnej).
        Przedmiot NIE zgadza się z powoływaną instytucją = 🔴 blokada
        ("prawdziwe orzeczenie, niewłaściwy temat") — usuń powołanie,
        NIE "napraw" go dobieraniem innej tezy pod tę samą sygnaturę.

        ⚠️ DEDUPLIKACJA: `pisma-procesowe-v3` ma już lokalną, bardziej
        rozbudowaną implementację tej samej kontroli — KROK 3a
        ZAKRES-STOSOWANIA w `references/W3-WERYFIKACJA.md` (pytania o typ
        podmiotu, ten sam przepis/kontekst, ograniczony zakres, utrwalenie
        doktryny). GRAD-3b NIE zastępuje ZAKRES-STOSOWANIA tam, gdzie już
        działa — jest wersją OGÓLNĄ dla skilli, które własnej kontroli
        tematu jeszcze nie mają (np. `orzeczenia-sadowe-v2` poza kontekstem
        pisma, `analiza-sadowa-v6`). Mapowanie statusów (żeby audit-bundle
        i tabela śladu używały spójnego słownika):
          ZAKRES-OK      ≈ 🟢 (GRAD-3b: przedmiot zgodny)
          WARN-ZAKRES    ≈ 🟠 (GRAD-3b: przedmiot częściowo/pomocniczo zgodny)
          ZAKAZ-ZAKRES   ≈ 🔴 (GRAD-3b: przedmiot niezgodny — blokada)

GRAD-3b-SYM: FLAGA SYMBOLU CBOSA (dodano 2026-09-22, F-194 — tylko NSA/WSA):
        Każdy dokument CBOSA ma pole „Symbol z opisem". Przy powołaniu
        orzeczenia sądu administracyjnego na poparcie tezy porównaj symbol
        powołanego orzeczenia z symbolem sprawy, do której ma być użyte.
          symbol zgodny          → bez flagi (GRAD-3b nadal obowiązuje)
          symbol różny           → 🟠 FLAGA-SYM: GRAD-3b OBOWIĄZKOWY przed
                                   użyciem; brak odczytu przedmiotu = 🔴
          symbolu nie odczytano  → brak flagi ≠ zgodność; zapisz „SYM: nieodczytany"
        ⛔ FLAGA, nie blokada: orzeczenia o przepisach p.p.s.a. (skarga
        kasacyjna, prawo pomocy, wstrzymanie wykonania) legalnie przekraczają
        symbole materialne. Flaga wymusza odczyt, nie rozstrzyga o trafności.
        ⛔ Symbolu nie zgaduj z sygnatury (repertorium OSK/FSK/GSK ≠ symbol).

KALIBRACJA-PRZECIWNIK (dodano 2026-09-22, F-194 — analiza cudzych pism,
        kategoria [11] i silnik V10): ustalenie, że przeciwnik powołał
        orzeczenie nieistniejące, z inną datą lub o innym przedmiocie, to
        argument o WIARYGODNOŚCI i staranności pisma — NIE argument co do
        istoty. Zakaz: (a) przedstawiania go jako przesądzającego o
        zasadności stanowiska przeciwnika; (b) pomijania odpowiedzi na istotę
        zarzutu dlatego, że jego obudowa orzecznicza upadła (REM-GATE REM-1).
        Wzorzec: I OSK 590/26 — autor wadliwych powołań wygrał co do istoty.
        Tabela audytu powołań przeciwnika: sygnatura | status (FOUND /
        NOT_FOUND / OUT_OF_SCOPE) | data zgodna? | przedmiot zgodny? | skutek.

GRAD-4: REGUŁA KALIBRACJI — porównaj poziom OSIĄGNIĘTY z WYMAGANYM:
          osiągnięty ≥ wymagany → 🟢 ZWERYFIKOWANY
          twierdzisz FRAGMENT, osiągnąłeś tylko TREŚĆ → 🟠 KALIBRACJA:
             złagodź cytat dosłowny do parafrazy ALBO oznacz pinpoint
             jako prowizoryczny — NIGDY nie zostawiaj cudzysłowu bez FRAGMENT
          TREŚĆ niepotwierdzona co do istoty → 🟡 WYMAGA_OSĄDU (decyzja
             człowieka przed użyciem w piśmie) lub usuń twierdzenie
          kotwica nierozwiązana / rozbieżna / guard STRON / guard INSTYTUCJA
             → 🔴 NIEZWERYFIKOWANY = potencjalna halucynacja, BLOKADA
             (usuń z odpowiedzi/pisma)
```

### Rozszerzone statusy śladu

Dotychczasowe `✅ [VER]` / `⚠️ [NIEWERYFIKOWANE]` pozostają w mocy dla poziomu
ISTNIENIE. Dla TREŚĆ i FRAGMENT stosuj rozszerzenie:

```
🟢 [VER-FRAGMENT: źródło, data]  — cytat dosłowny potwierdzony w źródle
🟢 [VER-TREŚĆ: źródło, data]     — parafraza potwierdzona co do istoty
✅ [VER: źródło, data]           — potwierdzone ISTNIENIE kotwicy (jak dotąd)
🔗 [KOTWICA-TEKSTOWA: URL#:~:text=…] — link z Text Fragment do miejsca cytowania
                                   (TOWARZYSZY 🟢/✅, nie zastępuje — procedura
                                   kanoniczna: shared/PRAWO-HARDGATE.md KROK 5A)
🟠 [KALIBRACJA]                  — osiągnięto niższy poziom niż twierdzono → złagodź tezę
⚠️ [NIEWERYFIKOWANE]             — weryfikacja niemożliwa (jak dotąd)
🔴 [BLOKADA]                     — rozbieżność kotwicy / stron / treści → usuń przed wysłaniem
```

> ℹ️ **Status źródła przepisu (ISTNIENIE) ma czwarty wariant pośredni,**
> `🟨 [KOTWICA-URZĘDOWA]`, definiowany wyłącznie w `shared/PRAWO-HARDGATE.md`
> (sekcja "🟨 KOTWICA URZĘDOWA"). Ten plik go NIE powiela — jeśli ślad
> weryfikacji dotyczy przepisu ocenionego jako KOTWICA (blokada `robots.txt`
> na RZĄD 2, warunki K-1…K-4 spełnione), przenieś status `🟨` bez zmian
> i traktuj go w hierarchii ważności jak w źródle: `✅ > 🟨 > ⚠️ > ⬛`.

⛔ ZAKAZ: cytat w cudzysłowie lub pinpoint bez statusu 🟢 [VER-FRAGMENT].
⛔ ZAKAZ: "SN przyjął, że…" z samym ✅ [VER] (istnienie) — parafraza wymaga
   co najmniej poziomu TREŚĆ albo przeformułowania na "orzeczenie dotyczy [tematu]".
Statusy 🟠 i 🔴 podlegają STRIP-VER-GATE tak samo jak pozostałe znaczniki.

### Kolumna poziomu w tabeli śladu (poziom pełny)

Przy analizach z cytatami/parafrazami dodaj kolumnę "Poziom (wym.→osiąg.)":

```
| Element | Źródło | Data | Poziom (wym.→osiąg.) | Status |
|---|---|---|---|---|
| „sąd związany jest granicami zaskarżenia" (II CSK 123/19) | saos.org.pl API | 2026-07-05 | FRAGMENT→FRAGMENT | 🟢 |
| "SN dopuścił klauzulę waloryzacyjną" (I CSK 50/18) | sn.pl | 2026-07-05 | TREŚĆ→ISTNIENIE | 🟠 KALIBRACJA |
| art. 385¹ §1 KC — powołanie | api.sejm.gov.pl ELI | 2026-07-05 | ISTNIENIE→ISTNIENIE | ✅ |
```

---

## KIEDY STOSOWAĆ KTÓRY FORMAT

```
Analiza ≤ 3 przepisów            → poziom minimalny (znaczniki śródtekstowe)
Analiza ≥ 4 przepisów            → poziom pełny (tabela na końcu)
Pismo procesowe (.docx)          → tabela WYŁĄCZNIE w wiadomości (nie w .docx) — patrz STRIP-VER-GATE
Umowa / regulamin / wzorzec      → tabela WYŁĄCZNIE w wiadomości (nie w dokumencie) — patrz STRIP-VER-GATE
Orzeczenie                       → ZAWSZE URL bezpośredni do orzeczenia + data
```

---

## ⛔ STRIP-VER-GATE — BRAMKA OCZYSZCZANIA PRZED EKSPORTEM DOKUMENTU

> **Wersja:** 1.0 (2026-06-23) — patch STRIP-VER
> **Obowiązuje dla:** pism procesowych (.docx), umów, regulaminów, wzorców, OWU

```
TRIGGER: każdorazowo PRZED wywołaniem view HOST_CAPABILITY[document_generation]
         i przed finalnym zapisem umowy / regulaminu / wzorca.

⛔ ZAKAZ: znaczniki [VER: …] i [NIEWERYFIKOWANE] NIE mogą pojawić się
          w treści właściwej dokumentu kierowanego do sądu, kontrahenta
          lub klienta.

PROCEDURA:
  SVG-1: Zidentyfikuj WSZYSTKIE wystąpienia:
           ✅ [VER: …]
           ⚠️ [NIEWERYFIKOWANE]
         w treści właściwej pisma / umowy (nagłówek, uzasadnienie,
         żądania, petitum, klauzule, podpisy).

  SVG-2: USUŃ je z treści dokumentu — przepis pozostaje, znacznik znika.
         Przykład przed: „art. 25¹ §3 KP ✅ [VER: isap.sejm.gov.pl, 2026-06-23]"
         Przykład po:    „art. 25¹ §3 KP"

  SVG-3: Przenieś pełną tabelę śladu weryfikacji (format POZIOM PEŁNY)
         do wiadomości towarzyszącej — PRZED present_files:

         ## 🔍 Ślad weryfikacji (wewnętrzny — nie jest częścią dokumentu)
         | Element | Źródło | Data | Status |
         |---|---|---|---|
         | … | … | … | ✅ / ⚠️ |

  SVG-4: Dopiero po SVG-1–SVG-3 → generuj .docx / finalizuj dokument.

⛔ ZAKAZ pominięcia SVG-2: „sąd nie weryfikuje naszego procesu walidacji"
   nie jest uzasadnieniem — znaczniki VER są artefaktem wewnętrznym systemu
   i nigdy nie powinny trafiać do dokumentu urzędowego ani handlowego.

⛔ ZAKAZ „skrótu": przeniesienie tabeli do stopki .docx NIE jest
   równoważne usunięciu — stopka też trafia do adresata. Jedyne
   dopuszczalne miejsce: wiadomość w Claude (nie w pliku .docx).
```

---

## PROCEDURA WERYFIKACJI — SEKWENCJA OBOWIĄZKOWA

```
KROK W-1: Zidentyfikuj wszystkie artykuły / liczby / terminy / orzeczenia w planowanej odpowiedzi.

KROK W-2: Dla każdego elementu → wywołaj narzędzie:
  Przepis KK/KPC/KPA/KC/KP → publikator RZĘDU 1 wg shared/HIERARCHIA-ZRODEL.md.
      ⛔ isap.sejm.gov.pl: pętla 302 w obu kanałach — NIE używaj jako pierwszego wyboru.
      Kanał kodu (curl): api.sejm.gov.pl/eli/... lub eli.gov.pl — zmierzone HTTP 200.
      Kanał web_fetch: URL konstruowany na api.sejm.gov.pl jest odrzucany
      (PERMISSIONS_ERROR) → sekwencja dwukrokowa B-1/B-2 wg PRAWO-HARDGATE.md.
  Orzeczenie SN/SA → web_search: "[sygnatura]" + web_fetch: sn.pl lub orzeczenia.ms.gov.pl
  Rejestr UOKiK → web_fetch: rejestr.uokik.gov.pl

KROK W-3: Przypisz znacznik do każdego elementu:
  Narzędzie zwróciło wynik → ✅ [VER: URL, data]
  Narzędzie nie zwróciło / brak dostępu → ⚠️ [NIEWERYFIKOWANE]
  ⛔ ZAKAZ: ✅ bez wywołania narzędzia

KROK W-3b: Dla elementów na poziomie FRAGMENT (cytat dosłowny/pinpoint) lub
  dla orzeczeń → wykonaj KT-1→KT-4 (procedura kanoniczna: shared/PRAWO-
  -HARDGATE.md KROK 5A) W TEJ SAMEJ odpowiedzi, korzystając z treści
  właśnie zwróconej przez narzędzie — NIE dobudowuj kotwicy tekstowej po
  fakcie, w kolejnej turze, bez ponownego web_fetch/web_search tego źródła.

KROK W-4: Przy ≥ 3 nieudanych weryfikacjach z rzędu:
  → Wyświetl użytkownikowi komunikat:
    "⚠️ Weryfikacja online niedostępna (ISAP / sn.pl nie odpowiada).
     Dane poniżej pochodzą z ostatniej weryfikacji systemu (data).
     Zalecam samodzielną weryfikację na isap.sejm.gov.pl przed użyciem
     w postępowaniu."
  → Kontynuuj z oznaczeniem ⚠️ [NIEWERYFIKOWANE] dla wszystkich elementów.
  → NIE blokuj całkowicie odpowiedzi — informuj i kontynuuj z zastrzeżeniami.
```

---

## 🧮 REJESTR POKRYCIA WERYFIKACJI (RPW) — przy dużej liczbie cytowań

> Dodano: 2026-08-27, na zgłoszenie użytkownika. Wzorzec analogiczny do
> `shared/MOD-REJESTR-POKRYCIA-JEDNOSTEK.md` (RPK), ale zamiast jednostek
> sprawy (kazusy, świadkowie, dokumenty) pokrywa **powołania wymagające
> weryfikacji** (przepisy, orzeczenia).

### PROBLEM, KTÓRY RPW ZAMYKA

KROK W-4 (wyżej) reaguje dopiero po **≥3 kolejnych NIEUDANYCH** próbach
weryfikacji — chroni przed błędem sieciowym, nie przed **cichym
pominięciem**. Gdy odpowiedź zawiera wiele powołań (np. 8–15 przepisów w
jednym raporcie o środkach zapobiegawczych), model może zweryfikować
pierwszą część listy, a resztę pominąć bez żadnego widocznego błędu — po
prostu nie wracając już do tych pozycji. Użytkownik nie ma wtedy sposobu
odróżnić "sprawdzone i pominięte celowo" od "sprawdzone i zapomniane" ani
ustalić, gdzie kończy się realna weryfikacja tej tury. Dotychczasowy
mechanizm (znacznik przy KAŻDYM elemencie z osobna) nie wymuszał jednego,
zbiorczego podsumowania zasięgu — dało się rozproszyć znaczniki po tekście
bez nigdy nie policzenia ich razem.

### PRÓG WYZWALAJĄCY

RPW jest obowiązkowy, gdy odpowiedź / pismo zawiera **≥ 8 odrębnych
powołań** wymagających weryfikacji (przepis, artykuł ustawy innej niż
główna, sygnatura orzeczenia). Ten sam artykuł powołany wielokrotnie w
tekście liczy się **raz**. Próg niższy niż w RPK (≥10 jednostek sprawy),
bo koszt pominięcia jednego przepisu w piśmie procesowym jest wyższy niż
koszt pominięcia jednego dokumentu w inwentarzu.

Poniżej progu (< 8 powołań) — wystarcza dotychczasowy ślad per-element
(✅/⚠️ przy każdym), bez osobnego rejestru.

### PROCEDURA

```
RPW-INIT (przed pierwszym web_search/web_fetch tej tury):
  Sporządź NUMEROWANĄ listę wszystkich powołań do zweryfikowania w
  odpowiedzi, którą zamierzasz napisać — to jest MIANOWNIK (Y pozycji).
  Lista powstaje z PLANU odpowiedzi, nie jest rekonstruowana po fakcie.

RPW-COMMIT (po każdej próbie weryfikacji, udanej lub nie):
  Odznacz pozycję na liście w KOLEJNOŚCI listy — nie przeskakuj do
  wygodniejszej pozycji, nawet jeśli narzędzie już zwróciło wynik dla
  dalszej pozycji przy okazji innego zapytania.

RPW-CHECKPOINT (obowiązkowy, na końcu odpowiedzi, PRZED disclaimerem
  i PRZED ewentualną tabelą śladu "poziom pełny" — może ją poprzedzać
  jednym zdaniem podsumowania):

  "Zweryfikowano {X}/{Y} pozycji (do pozycji {N} na liście włącznie).
   Pozycje {N+1}…{Y}: ⬛ [DO WERYFIKACJI] — bez próby w tej turze."

  Ten wiersz jest OBOWIĄZKOWY nawet gdy X = Y — wtedy: "Zweryfikowano
  {Y}/{Y} — pełne pokrycie tej tury."
  ⛔ Braku tego wiersza przy ≥8 powołaniach NIE usprawiedliwia to, że
  każdy pojedynczy element miał już swój własny znacznik ✅/⚠️ —
  RPW-CHECKPOINT to zbiorcze podsumowanie zasięgu, nie duplikat
  znaczników per-element.

RPW-RESUME (gdy sesja/turę kontynuuje się dalej — dociąganie reszty,
  porównanie z kluczem, kolejne pytanie o tę samą sprawę):
  Pierwszym krokiem jest odczyt OSTATNIEGO checkpointu RPW z tej rozmowy
  i kontynuacja weryfikacji od pozycji {N+1} — nie od nowa (marnotrawstwo)
  i nie z pominięciem reszty (to właśnie ta luka, którą RPW zamyka).
```

### FORMAT — rozszerzenie tabeli śladu (poziom pełny)

Przy ≥8 powołaniach tabela z sekcji "Poziom pełny" wyżej dostaje
dodatkową kolumnę `Nr` (numer porządkowy z RPW-INIT), żeby checkpoint
dało się odczytać wprost z tabeli:

```
---
## 🔍 Ślad weryfikacji

| Nr | Element | Źródło | Data | Status |
|---|---|---|---|---|
| 1 | art. 249 §1 KPK — przesłanka ogólna | api.sejm.gov.pl ELI DU/2026/490 (t.j., RZĄD 1) | 2026-09-14 | ✅ |
| 2 | art. 258 §1-2 KPK — przesłanki szczególne | api.sejm.gov.pl ELI DU/2026/490 (RZĄD 1), SN II KZ 47/23 (2A) | 2026-09-14 | ✅ |
| … | … | … | … | … |
| 9 | art. 73 §4 KPK — wygaśnięcie zastrzeżenia | eli.gov.pl DU/2026/490 (RZĄD 1) | 2026-09-14 | ✅ |

**RPW-CHECKPOINT:** zweryfikowano 9/9 — pełne pokrycie tej tury.
```

### NARUSZENIE

Odpowiedź z ≥8 powołaniami bez wypisanego RPW-CHECKPOINT = **WARN**
(ten sam poziom co brak kategoryzacji RZĄD) — odnotować, jeśli operacja
toczy się w ramach audytu (`audyt-systemu-v4`); w zwykłej rozmowie
wystarczy, że kolejna odpowiedź w tej samej sprawie uzupełnia brakujący
checkpoint retroaktywnie, zanim doda nowe powołania.

---

## OBSŁUGA BŁĘDÓW SIECIOWYCH (naprawa WAŻNE-3: SLA)

```
TIMEOUT (brak odpowiedzi w ~15s):
  → Spróbuj INNY PUBLIKATOR RZĘDU 1 (eli.gov.pl ↔ api.sejm.gov.pl ↔
    dziennikustaw.gov.pl) oraz drugi kanał (kod ↔ web_fetch).
  ⛔ NIE degraduj do źródeł komercyjnych (lexlege.pl / prawo.pl / arslege.pl).
    Są poza RZĘDEM 1; ich użycie nie uprawnia do znacznika ✅ [VER].
    Dopuszczalne wyłącznie jako wskazówka nawigacyjna, z ⚠️ [NIEWERYFIKOWANE].
  → Jeśli wszystkie publikatory RZĘDU 1 niedostępne → ⚠️ [NIEWERYFIKOWANE]

HTTP 5xx / serwis niedostępny:
  → 1 ponowna próba po 5s
  → Jeśli nadal błąd → ⚠️ [NIEWERYFIKOWANE]

≥ 3 nieudane weryfikacje z rzędu (dowolna kombinacja):
  → Komunikat użytkownikowi (patrz KROK W-4 powyżej)
  → Dalsze odpowiedzi w trybie ⚠️ [NIEWERYFIKOWANE] aż do powrotu dostępu

Tryb awaryjny NIE oznacza pominięcia disclaimera — DISCLAIMER.md stosuje się zawsze.
```

---

## INTEGRACJA Z ROUTEREM

### Dodaj do SELF-CHECK:

```
□ [WERYFIKACJA-ŚLAD] Każdy artykuł / termin / orzeczenie ma znacznik VER lub NIEWERYFIKOWANE?
□ [WERYFIKACJA-ŚLAD] Użyłem narzędzia (web_search/web_fetch) dla każdego VER?
□ [WERYFIKACJA-ŚLAD] ≥3 błędy sieci → komunikat użytkownikowi wyświetlony?
□ [WERYFIKACJA-ŚLAD] Analiza ≥4 przepisów → tabela śladu na końcu odpowiedzi?
□ [GRADIENT] Każdy cytat w cudzysłowie / pinpoint ma 🟢 [VER-FRAGMENT]?
□ [GRADIENT] Każda parafraza ("SN przyjął, że…") zweryfikowana na poziomie TREŚĆ,
             nie tylko ISTNIENIE?
□ [GRADIENT] Każde "gołe" powołanie użyte na poparcie tezy (bez cudzysłowu,
             bez parafrazy) TEŻ zweryfikowane na poziomie TREŚĆ (reguła
             I FZ 104/26) — nie potraktowane jako sama ISTNIENIE?
□ [GRADIENT] Dla orzeczeń bez możliwości porównania stron (anonimizacja
             adm./karna) — wykonany GUARD INSTYTUCJA/PRZEDMIOT (GRAD-3b)?
□ [GRADIENT] Twierdzenia z poziomem osiągniętym < wymaganym → skalibrowane (🟠)
             lub usunięte (🔴)?
□ [KOTWICA-TEKSTOWA] Każdy cytat na poziomie FRAGMENT / każde orzeczenie
             ma dołączony link z Text Fragment (🔗), skonstruowany w TEJ
             odpowiedzi z treści właśnie zwróconej przez narzędzie?
□ [KOTWICA-TEKSTOWA] Czy przy każdym 🔗 podano zastrzeżenie (a)/(b)/(c)
             z shared/PRAWO-HARDGATE.md KROK 5A, zamiast przedstawiać link jako
             gwarantowany?
□ [RZĄD] Czy KAŻDY link/URL w odpowiedzi (nie tylko 🔗) ma przypisaną
             kategorię RZĄD 1/2A/2B/3 wg `shared/HIERARCHIA-ZRODEL.md`?
□ [RZĄD] Czy źródła Rządu 3 mają sprawdzoną datę (>24 mies. → ostrzeżenie)
             i są skrzyżowane z Rzędem 1/2A przed użyciem jako poparcia tezy?
□ [RPW] Odpowiedź zawiera ≥8 odrębnych powołań? → sporządzony RPW-INIT
             PRZED weryfikacją i wypisany RPW-CHECKPOINT na końcu, przed
             disclaimerem?
□ [RPW] Liczba pozycji w RPW-CHECKPOINT (Y) zgadza się z liczbą odrębnych
             powołań faktycznie użytych w tekście odpowiedzi (żadne nie
             pominięte przy liczeniu MIANOWNIKA)?
□ [RPW] Jeśli X < Y (niepełne pokrycie) — pozycje N+1…Y wypisane wprost
             jako ⬛ [DO WERYFIKACJI], a nie po prostu nieobecne w tekście?
```

### Dodaj do REGUŁ NADRZĘDNYCH routera (punkt 14):

```
14. WERYFIKACJA-ŚLAD: Każdy artykuł / liczba / termin / orzeczenie musi mieć znacznik
    ✅ [VER: źródło, data] (po narzędziu) lub ⚠️ [NIEWERYFIKOWANE] (brak dostępu).
    ⛔ ZAKAZ oznaczania VER bez wywołania web_search / web_fetch.
    ⛔ Dla FRAGMENT/orzeczeń — dołącz też 🔗 [KOTWICA-TEKSTOWA], procedura
       kanoniczna w `shared/PRAWO-HARDGATE.md` KROK 5A (SCALONE 2026-07-15c —
       nie duplikuj tutaj), zbudowaną w tej samej odpowiedzi, z zastrzeżeniem
       o ograniczonym wsparciu przeglądarek i braku gwarancji trwałości
       dopasowania.
    ⛔ Przy ≥8 odrębnych powołaniach — sekcja RPW (REJESTR POKRYCIA
       WERYFIKACJI, wyżej) jest obowiązkowa: RPW-INIT przed weryfikacją,
       RPW-CHECKPOINT na końcu odpowiedzi. Brak checkpointu = WARN, ten
       sam poziom co brak kategoryzacji RZĄD.
```
