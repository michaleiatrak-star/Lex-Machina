# ISAP-METRYKI-AKTOW — rejestr kontrolny aktów prawnych

**Data audytu:** 2026-06-07  
**Źródło wyłączne:** Internetowy System Aktów Prawnych — `isap.sejm.gov.pl`.  
**Zasada:** nie cytuj treści przepisu, numeru Dz.U. ani statusu aktu z pamięci. Jeżeli metryka nie znajduje się poniżej albo użytkownik wymaga cytatu przepisu, przed odpowiedzią sprawdź aktualny tekst w ISAP.

---

## 1. Procedura cywilna i prawo cywilne

| Akt | Metryka ISAP zweryfikowana | Status roboczy systemu | Uwagi wdrożeniowe |
|---|---:|---|---|
| Kodeks postępowania cywilnego | Dz.U. 2026 poz. 468; tekst ujednolicony opracowany na podstawie Dz.U. 2026 poz. 468 i 473 | aktualny na dzień audytu | używać dla pism cywilnych, pracy, gospodarczych i egzekucji sądowej |
| Kodeks cywilny | Dz.U. 2026 poz. 795 t.j.; późniejsze zmiany sprawdzać przed zastosowaniem | aktualny t.j. na 2026-08-28 | konkretny artykuł i temporalność zawsze fresh gate |
| Prawo przedsiębiorców | tekst ujednolicony opracowany na podstawie Dz.U. 2025 poz. 1480, 1795, 1826 oraz Dz.U. 2026 poz. 507 | aktualny na dzień audytu | stosować przy działalności regulowanej i gospodarczej |

---

## 2. Procedura administracyjna i sądowoadministracyjna

| Akt | Metryka ISAP zweryfikowana | Status roboczy systemu | Uwagi wdrożeniowe |
|---|---:|---|---|
| Kodeks postępowania administracyjnego | Dz.U. 2025 poz. 1691 | aktualny na dzień audytu | ogólna procedura administracyjna; nie stosować do podatków, gdy Ordynacja stanowi lex specialis |
| Prawo o postępowaniu przed sądami administracyjnymi | Dz.U. 2026 poz. 143 | aktualny na dzień audytu | skargi do WSA, skargi kasacyjne do NSA, bezczynność i przewlekłość |
| Ustawa o postępowaniu egzekucyjnym w administracji | Dz.U. 2026 poz. 1311 t.j. (obwieszczenie z 1.09.2026, ogł. 9.10.2026; zastąpił 2026 poz. 268; obejmuje zm. 2026/516, 739 i 1003; art. 17 § 1a w dwóch brzmieniach — dotychczasowym do 27.10.2026 i nadanym art. 116 ustawy 2026/1003 od 28.10.2026 (odnośniki 13–14 t.j.); brak zmian po t.j. (ELI 2026-10-12, obwieszczenie odczytane)) — HISTORIA: ✅ POTWIERDZONE bezpośrednio na ISAP (Rząd 1) — ⚠️ UWAGA (zsynchronizowane 2026-08-09 z prawny-router-v3/references/ISAP-METRYKI-AKTOW.md): TA sama ustawa ma JUŻ TRZY kolejne, PÓŹNIEJSZE nowelizacje: Dz.U. 2026 poz. 516, poz. 739, poz. 1003 — sam numer "poz. 268" NIE WYSTARCZY do cytowania AKTUALNEGO stanu | aktualny na dzień audytu | odrębny tryb od egzekucji sądowej |
| Ustawa o dostępie do informacji publicznej | tekst ujednolicony ISAP `D20011198Lj.pdf` | wymaga sprawdzenia Dz.U. przed cytowaniem | tryb wnioskowy, bezczynność, odmowa decyzją administracyjną |

---

## 3. Prawo podatkowe, KAS i celno-skarbowe

| Akt | Metryka ISAP zweryfikowana | Status roboczy systemu | Uwagi wdrożeniowe |
|---|---:|---|---|
| Ordynacja podatkowa | tekst ujednolicony ISAP `D19970926Lj.pdf`, opracowanie Kancelarii Sejmu z 25.05.2026 | aktualny na dzień audytu | postępowanie podatkowe jako moduł odrębny od KPA |
| Ustawa o Krajowej Administracji Skarbowej | Dz.U. 2025 poz. 1131; tekst ujednolicony ISAP `D20161947Lj.pdf` | aktualny na dzień audytu z wymogiem sprawdzenia zmian po t.j. | kontrola celno-skarbowa, czynności sprawdzające, uprawnienia UCS |
| Kodeks karny skarbowy | Dz.U. 2025 poz. 633 t.j.; po t.j. opublikowano zmiany, dlatego sprawdzać ELI na dzień czynu/czynności | PO-TJ-ZMIANY | konkretny przepis zawsze fresh gate |

---

## 4. Prawo karne

| Akt | Metryka ISAP zweryfikowana | Status roboczy systemu | Uwagi wdrożeniowe |
|---|---:|---|---|
| Kodeks karny | Dz.U. 2026 poz. 1342 t.j. (ELI 2026-10-20: tekst t.j. opublikowany, obejmuje 2025/1818, 1872, 2026/902, 988; brak nowelizacji po t.j.) | wymaga sprawdzenia przepisu na datę czynu | zawsze weryfikować brzmienie historyczne |
| Kodeks postępowania karnego | Dz.U. 2026 poz. 490; widoczna nowelizacja Dz.U. 2026 poz. 638 oczekująca/zmieniająca | aktualny z koniecznym sprawdzeniem wejścia zmian | kontrolować datę czynności procesowej |

---

## 5. Prawo pracy, gospodarcze i regulacyjne

| Akt | Metryka ISAP zweryfikowana | Status roboczy systemu | Uwagi wdrożeniowe |
|---|---:|---|---|
| Kodeks pracy | Dz.U. 2025 poz. 277; tekst ujednolicony ISAP `D19740141Lj.pdf`, opracowanie z 16.04.2026 | aktualny na dzień audytu z wymogiem sprawdzenia zmian 2026 | szczególnie sprawdzać zmiany PIP i ZFŚS |
| Kodeks spółek handlowych | tekst ujednolicony ISAP `D20001037Lj.pdf`, opracowanie z 12.03.2026; widoczne zmiany 2025 i 2026 | wymaga sprawdzania wejścia zmian dla spółek | istotne przy zarządzie, KRS, odpowiedzialności, transformacjach |
| Ustawa o ochronie konkurencji i konsumentów | Dz.U. 2025 poz. 1714 | aktualny na dzień audytu | moduł UOKiK/regulacyjny |
| Prawo energetyczne | Dz.U. 2026 poz. 43; tekst ujednolicony ISAP `D19970348Lj.pdf` | aktualny na dzień audytu | sprawy URE, taryfy, przyłączenia, koncesje |
| Prawo komunikacji elektronicznej | Dz.U. 2024 poz. 1221 (brak t.j.; zm. (ELI 2026-10-12): 2025 poz. 637, 820; 2026 poz. 252, 815 od 4.07.2026, 1296) | stosować zamiast uchylanego Prawa telekomunikacyjnego w nowych sprawach | sprawdzać przepisy przejściowe |
| Ustawa o wspieraniu rozwoju usług i sieci telekomunikacyjnych | Dz.U. 2026 poz. 562 t.j. (poprzedni: 2025 poz. 311); po t.j. (ELI 2026-10-12): 2026 poz. 815 (od 4.07.2026) | aktualny na dzień audytu | inwestycje telekomunikacyjne i dostęp infrastrukturalny |

---

## 6. Planowanie, budownictwo, środowisko

| Akt | Metryka ISAP zweryfikowana | Status roboczy systemu | Uwagi wdrożeniowe |
|---|---:|---|---|
| Ustawa o planowaniu i zagospodarowaniu przestrzennym | Dz.U. 2026 poz. 538; tekst ujednolicony ISAP `D20030717Lj.pdf` | aktualny na dzień audytu | plan ogólny, MPZP, WZ, procedura partycypacyjna |
| Prawo budowlane | Dz.U. 2026 poz. 524 t.j., ze zm. — zmiany z Dz.U. 2025 poz. 1847 (art. 1 pkt 1 lit. a i c, pkt 3) W MOCY od 20.09.2026 (F-195, RZĄD 1 ELI 2026-09-22); po t.j. także 2026/605, 2026/646, **2026/1161** (w mocy 2.10.2026; rozdz. 10a art. 102a–102c od 2.09.2026) ✅ [VER: ELI DU/1994/414/references, 2026-10-04]. ⛔ Rozp. WT budynków z 12.04.2002 (Dz.U. 2002 nr 75 poz. 690) NIE OBOWIĄZUJE od 20.09.2026 (art. 66 ustawy o zapewnianiu dostępności, t.j. Dz.U. 2024 poz. 1411); nowe — brak w ELI na 2026-10-04 (F-224); przejściowo art. 102a–102c | aktualny t.j. ze zm.; WT — reżim przejściowy | pozwolenie, zgłoszenie, samowola, PINB/WINB |
| Prawo ochrony środowiska | Dz.U. 2025 poz. 647 t.j. — ⚠️ POPRAWIONE 2026-08-09 (FAZA 3E/ZASADA 14): poprzednia wersja BŁĘDNIE wskazywała "Dz.U. 2026 poz. 670" — TA pozycja jest tekstem jednolitym ZUPEŁNIE INNEJ ustawy (o udostępnianiu informacji o środowisku i jego ochronie, udziale społeczeństwa w ochronie środowiska oraz o ocenach oddziaływania na środowisko — tzw. "ustawa OOŚ", akt Z 2008 R., ODRĘBNY od Prawa ochrony środowiska z 2001 r.) — potwierdzone bezpośrednio przez ISAP (obwieszczenie z 9.05.2025, WDU20250000647) | aktualny na dzień aktualizacji (VER 2026-08-09) | decyzje środowiskowe, emisje, kary administracyjne |
| Ustawa o udostępnianiu informacji o środowisku (OOŚ) — ODRĘBNY akt od Prawa ochrony środowiska, dodane 2026-08-09 | Dz.U. 2026 poz. 670 t.j. (obwieszczenie z 15.05.2026) | aktualny na dzień aktualizacji | decyzje środowiskowe (udział społeczeństwa, oceny oddziaływania — OOŚ/EIA), NIE MYLIĆ z Prawem ochrony środowiska (wiersz wyżej) |
| Ustawa o ochronie przyrody | Dz.U. 2026 poz. 1315 t.j. (obwieszczenie z 4.09.2026, ogł. 9.10.2026; obejmuje zm. 2026/426, 737, 912; brak zmian po t.j. (ELI 2026-10-12)) | aktualny na dzień audytu | drzewa, formy ochrony, RDOŚ/GDOŚ |
| Prawo wodne | Dz.U. 2026 poz. 1335 t.j. (ogł. 14.10.2026; obejmuje 2025/1535, 2026/445, 605, 815, 1033 i 1156 — 2026/1156 w tekście jako brzmienie od 1.01.2027); brak zmian po t.j. do 2026-10-15; ⚡ po t.j.: **Dz.U. 2026 poz. 1358** (ustawa z 4.09.2026 o zmianie ustawy – Prawo wodne, ogł. 19.10.2026, w mocy 3.11.2026; tekst odczytany ✅ [VER: ELI DU/2026/1358 text.pdf, RZĄD 1, 2026-10-20] — zmienia WYŁĄCZNIE przepisy o kąpieliskach (wdrożenie dyr. 2006/7/WE): art. 16 pkt 15a, 23, 50c (definicje: duża liczba kąpiących się, klasyfikacja wody w kąpielisku, stały zakaz kąpieli), art. 44 ust. 4, art. 45 ust. 2, nowy art. 46a, art. 47 ust. 2 pkt 5, art. 240 ust. 3 pkt 14a, art. 344 ust. 5 pkt 9–10 (sinice, makroalgi), art. 345 ust. 1–2 (harmonogram próbek), art. 346 ust. 1, 6, 7, 9, art. 347 ust. 2a i 3; ⛔ gospodarki ściekowej i opłat nie dotyczy — żaden moduł korpusu nie obejmuje kąpielisk) ✅ [VER] RZĄD 1 2026-10-20 (metadane ELI DU/2026/1358, `Akty zmieniające` DU/2017/1566) | aktualny na dzień audytu z weryfikacją zmian | Wody Polskie, zgody wodnoprawne |

---

## 7. Migracje, dane osobowe, pomoc społeczna

| Akt | Metryka ISAP zweryfikowana | Status roboczy systemu | Uwagi wdrożeniowe |
|---|---:|---|---|
| Ustawa o cudzoziemcach | Dz.U. 2025 poz. 1079; po t.j. widoczna zmiana Dz.U. 2025 poz. 1794 | wymaga sprawdzenia przepisów przejściowych | pobyt, powrót, wydalenie, zezwolenia |
| Ustawa o ochronie danych osobowych | tekst ujednolicony ISAP `D20181000Lj.pdf` | wymaga sprawdzenia Dz.U. przed cytowaniem | postępowanie przed UODO + RODO |
| Ustawa o pomocy społecznej | Dz.U. 2025 poz. 1214; tekst ujednolicony ISAP z późniejszymi zmianami 2025/2026 | wymaga sprawdzenia aktualnego ujednolicenia | zasiłki, DPS, świadczenia, odwołania SKO/WSA |

---

## 8. Reguły użycia rejestru

1. Rejestr nie zastępuje ISAP; jest lokalną mapą kontrolną.
2. Jeżeli pismo ma zawierać cytat przepisu — pobierz aktualne brzmienie z ISAP.
3. Jeżeli sprawa dotyczy zdarzenia historycznego — sprawdź brzmienie przepisu na datę zdarzenia.
4. Jeżeli status aktu to „oczekujący na wejście w życie”, nie stosuj go do zdarzeń wcześniejszych bez analizy przepisów przejściowych.
5. Jeżeli w module dziedzinowym jest sprzeczny Dz.U., nadrzędny jest ten rejestr i aktualny ISAP.

---

# Aktualizacja metryk — 2026-06-07

Źródło: wyłącznie ISAP. Ten wykaz ma charakter kontrolny; cytowanie przepisu wymaga bieżącego sprawdzenia ISAP.

| Akt | Metryka kontrolna | Status roboczy |
|---|---:|---|
| KPC | Dz.U. 2026 poz. 468 | AKTUALNY-ISAP |
| KPA | Dz.U. 2025 poz. 1691 | AKTUALNY-ISAP |
| PPSA | Dz.U. 2026 poz. 143 | AKTUALNY-ISAP |
| Ordynacja podatkowa | Dz.U. 2026 poz. 622 (t.j. 25.05.2026) | AKTUALNY-ISAP |
| Prawo restrukturyzacyjne | Dz.U. 2026 poz. 533 | AKTUALNY-ISAP |
| Prawo upadłościowe | Dz.U. 2026 poz. 913 t.j. | aktualny t.j.; późniejsze zmiany fresh gate |
| Koszty sądowe w sprawach cywilnych | Dz.U. 2025 poz. 1228 | PO-TJ-ZMIANY |
| Prawo budowlane | Dz.U. 2026 poz. 524 ze zm. — art. 1 pkt 1 lit. a i c, pkt 3 zm. 2025/1847 w mocy od 20.09.2026 (F-195); zm. 2026/1161 w mocy od 2.10.2026 | PO-TJ-ZMIANY |
| Planowanie i zagospodarowanie przestrzenne | Dz.U. 2026 poz. 538 | AKTUALNY-ISAP |
| Prawo ochrony środowiska | Dz.U. 2026 poz. 670 | AKTUALNY-ISAP |
| Ustawa o cudzoziemcach | Dz.U. 2025 poz. 1079 + zmiana Dz.U. 2025 poz. 1794 | PO-TJ-ZMIANY |
| Prawo energetyczne | Dz.U. 2026 poz. 43 + zmiana Dz.U. 2026 poz. 516 | PO-TJ-ZMIANY |
| Krajowy system cyberbezpieczeństwa | Dz.U. 2026 poz. 20 t.j.; po t.j. (ELI 2026-10-12): 2026 poz. 252, 815 (od 4.07.2026), 1003, 1206 | PO-TJ-ZMIANY |
| Ochrona ludności i obrona cywilna | Dz.U. 2024 poz. 1907 (brak t.j.); zm. (ELI 2026-10-12): 2025 poz. 1705; 2026 poz. 646 (od 29.05.2026), 815 (od 4.07.2026) | PO-TJ-ZMIANY |
| KSH | tekst ujednolicony ISAP, aktualizacja 2026-03-12 + zmiany 2026 | PO-TJ-ZMIANY |
| PIT | Dz.U. 2026 poz. 592 (t.j. 17.04.2026) | PO-TJ-ZMIANY |
| CIT | Dz.U. 2026 poz. 554 (t.j. 27.03.2026) | PO-TJ-ZMIANY |

## Aktualizacja metryk — ZUS, FUS, niepełnosprawność, sądownictwo, ORA/OIRP, biegli (2026-05-28)

Źródłem podstawowym jest ISAP. Metryki w module są wskaźnikiem kontrolnym, a nie zastępują kontroli aktualnego tekstu na dzień użycia.

| Akt / grupa | Stan kontrolny w systemie |
|---|---|
| ustawa o systemie ubezpieczeń społecznych | ISAP wskazuje tekst ujednolicony i obwieszczenie tekstu jednolitego Dz.U. 2026 poz. 199; sprawdzać późniejsze zmiany |
| ustawa o emeryturach i rentach z FUS | ISAP wskazuje tekst jednolity Dz.U. 2025 poz. 1749 oraz zmiany 2026; sprawdzać późniejsze zmiany |
| ustawa rehabilitacyjna | tekst jednolity Dz.U. 2026 poz. 884 (✅ VER 2026-09-01 RZĄD 1 (ELI DU/2026/884: obwieszczenie 19.06.2026, ogł. 1.07.2026, obowiązujący; DU/2025/913 — status wygaśnięcie aktu)); poprzedni t.j. 2025 poz. 913 — wygasł; sprawdzać późniejsze zmiany |
| Prawo o ustroju sądów powszechnych | ISAP wskazuje tekst jednolity Dz.U. 2024 poz. 334 oraz późniejsze zmiany 2025/2026; używać tekstu ujednoliconego ISAP na dzień kontroli |
| Prawo o adwokaturze | ISAP wskazuje tekst jednolity Dz.U. 2024 poz. 1564 oraz akty wykonawcze i zmiany; kontrolować aktualny tekst ujednolicony |
| ustawa o radcach prawnych | ISAP wskazuje tekst jednolity Dz.U. 2024 poz. 499 oraz późniejsze akty; kontrolować aktualny tekst ujednolicony |
| biegli — wynagrodzenia w postępowaniu cywilnym | ISAP wskazuje tekst jednolity rozporządzenia MS Dz.U. 2025 poz. 1444; sprawdzać odrębnie KPC/KPK i koszty |
