# Terminy procesowe — tabela referencyjna

> **Stan weryfikacji:** ✅ [VER] RZĄD 1 2026-09-12d — odczyt treści KPC
> `Dz.U. 2026 poz. 468`, KPK `Dz.U. 2026 poz. 490`, KPW `Dz.U. 2025 poz. 860`.
> Pozycje spoza tych trzech kodeksów zachowują wcześniejsze daty weryfikacji.

## Terminy procesowe — tabela referencyjna

| Termin | Czynność | Podstawa |
|--------|----------|----------|
| **7 dni** (zawity) | Sprzeciw od wyroku nakazowego (wykroczenia) | **art. 94 § 1 KPW w zw. z art. 506 § 1 KPK** — od doręczenia wyroku |
| **7 dni** | Wniosek o uzasadnienie wyroku (KPC) | art. 328 §1 KPC ⚠ POPRAWIONE 2026-08-08: było błędnie "328¹" |
| **tydzień** | Zażalenie (KPC) ⚠ patrz przypis niżej — od doręczenia postanowienia z uzasadnieniem, także gdy doręczono z urzędu; przy odstąpieniu od uzasadnienia — od ogłoszenia, a gdy podlegało doręczeniu — od doręczenia | art. 394 § 2 KPC |
| **7 dni** (zawity) ⚠️ | Wniosek o uzasadnienie (KPK) — biegnie od **OGŁOSZENIA** wyroku, nie od doręczenia | art. 422 § 1 KPK |
| **7 dni** (zawity) ⛔ | Wniosek o uzasadnienie wyroku (wykroczenia) — od **OGŁOSZENIA**, a przy wyroku zaocznym od doręczenia (§ 2) | **art. 35 § 1 KPW** ⛔ NAPRAWIONE 2026-09-12d: było 3 dni z art. 105 § 1, który reguluje apelację |
| **7 dni** (zawity) | Wniosek o przekład uzasadnienia przedstawionego **ustnie** (wykroczenia) | art. 82 § 7 KPW |
| **7 dni** | Apelacja wykroczeniowa — od otrzymania wyroku **z uzasadnieniem** | **art. 105 § 1 KPW** (§ 2 dotyczy apelacji wniesionej przedwcześnie) |
| **2 tygodnie** | **Sprzeciw** od nakazu w post. **upominawczym** — doręczenie **w kraju** | **art. 480² § 2 pkt 1 KPC** ⛔ NAPRAWIONE 2026-09-12d: art. 503 KPC jest **UCHYLONY** |
| **miesiąc** | Sprzeciw od nakazu upominawczego — doręczenie **poza krajem, na terytorium UE** | art. 480² § 2 pkt 2 KPC |
| ⛔ **MIESIĄC** | **Zarzuty** od nakazu w post. **NAKAZOWYM** — doręczenie **na terytorium UE, a więc także w Polsce** | **art. 480² § 2 pkt 3 KPC** |
| **3 miesiące** | Zaskarżenie nakazu — doręczenie **poza terytorium UE** | art. 480² § 2 pkt 4 KPC |
| **2 tygodnie** | Sprzeciw od **wyroku zaocznego** | art. 344 § 1 KPC |
| **min. 2 tygodnie** ⛔ | Odpowiedź na pozew — termin **SĄDOWY**, wyznaczany przez przewodniczącego (nie stałe 14 dni); przekroczenie → ZWROT pisma (patrz przypis) | **art. 205¹ §1 KPC** |
| **2 tygodnie** | Apelacja cywilna — od doręczenia wyroku z uzasadnieniem | art. 369 § 1 KPC |
| **3 tygodnie** ⚠️ | Apelacja cywilna, gdy **przedłużono termin** do sporządzenia uzasadnienia; sąd zawiadamia o tym stronę, a przy błędnym pouczeniu apelację uważa się za wniesioną w terminie | **art. 369 § 1¹ KPC** |
| **14 dni** | Apelacja karna | art. 445 §1 KPK |
| **14 dni** | Odwołanie od decyzji admin. | art. 129 §2 KPA |
| **14 dni** | Sprzeciw od orzeczenia lekarza ZUS | art. 14 ustawy FUS |
| **14 dni** | Odstąpienie od umowy (internet/poza lokalem) | art. 27 ustawy PK |
| **⚠ 21 dni** | Odwołanie od wypowiedzenia/dyscyplinarki | **art. 264 §1 KP** |
| **30 dni** | Skarga do WSA | art. 53 §1 PPSA |
| **1 miesiąc** | Odwołanie od decyzji ZUS do sądu | art. 477⁹ §1 KPC |
| **6 tygodni** | Zaskarżenie uchwały wspólnoty mieszkaniowej | art. 25 uWŁ |
| **6 miesięcy** | Przyjęcie/odrzucenie spadku | art. 1015 §1 KC |
| **tydzień** | Wniosek o **przywrócenie terminu** — od ustania przyczyny uchybienia; równocześnie należy dokonać czynności (§ 3); po roku tylko w wypadkach wyjątkowych (§ 4) | **art. 169 § 1 KPC** |
| **tydzień** | **Skarga na czynności komornika** — od dokonania czynności | art. 767 § 4 KPC |
| **3 miesiące** | Skarga o **wznowienie** postępowania cywilnego | art. 407 § 1 KPC |
| **2 miesiące** | Skarga kasacyjna (cywilna) — od doręczenia orzeczenia z uzasadnieniem | art. 398⁵ § 1 KPC |
| **7 dni** | Zażalenie / sprzeciw w postępowaniu karnym — od ogłoszenia postanowienia, a gdy ustawa nakazuje doręczenie — od doręczenia | **art. 460 KPK** |
| **30 dni** | **Kasacja** karna — od doręczenia orzeczenia z uzasadnieniem | **art. 524 § 1 KPK** |
| **7 dni** (zawity) | Sprzeciw od wyroku nakazowego (karne) — od doręczenia wyroku | **art. 506 § 1 KPK** |

> ⛔⛔ **NAPRAWA 2026-09-12d — art. 503 KPC JEST UCHYLONY, a plik kanoniczny
> powoływał go jako podstawę jednego z najczęstszych terminów w praktyce.**
> ✅ [VER] RZĄD 1 2026-09-12d — odczyt treści KPC `Dz.U. 2026 poz. 468`:
> **art. 500, 501, 502, 502¹, 503 i 504 mają brzmienie (uchylony)**. Obecny układ:
> - **dopuszczalność** środka: art. 505 § 1 (sprzeciw, upominawcze) oraz
>   art. 493 § 1 (zarzuty, nakazowe) — oba mówią wyłącznie o tym, ŻE przysługuje;
> - **tryb** wnoszenia: art. 480³ § 1–3 (do sądu, który wydał nakaz; rygor
>   odrzucenia środka spóźnionego, nieopłaconego lub dotkniętego brakami);
> - ⛔ **TERMIN: art. 480² § 2 KPC**, różnicowany trybem oraz **miejscem
>   doręczenia** — 2 tygodnie (upominawczy, w kraju), miesiąc (upominawczy,
>   poza krajem w UE), **miesiąc (NAKAZOWY, doręczenie na terytorium UE — czyli
>   także w Polsce)**, 3 miesiące (poza UE).
>
> ⛔ Sześć plików systemu powoływało art. 503 KPC, a trzy podawały termin zarzutów
> od nakazu nakazowego jako 7 albo 14 dni. Przy doręczeniu krajowym jest to
> **miesiąc**. Reprodukcja:
> `curl -s api.sejm.gov.pl/eli/acts/DU/2026/468/text.pdf | pdftotext -layout - - | grep -n "Art. 503\."`

> ⛔ **Przypis PRZEREDAGOWANY 2026-08-22 (F-83, propagacja uchylenia art. 207 KPC)** —
> poprzednia treść (z 2026-07-12) opierała się na **przepisie uchylonym** i przez to
> stawiała wniosek ODWROTNY do stanu prawnego. Zachowana dla zrozumienia starych
> odesłań: twierdziła, że termin na odpowiedź na pozew jest "instrukcyjny" i że jego
> przekroczenie "nie powoduje wygaśnięcia prawa do złożenia odpowiedzi".
>
> **Stan aktualny (✅ VER 2026-08-22, RĄD 2A/2B: lexlege.pl, rp.pl, palestra.pl,
> standardyprawa.pl + orzeczenie w bazie saos.org.pl):**
> - **art. 207 KPC został UCHYLONY** ustawą z 4.07.2019, ze skutkiem od **7.11.2019**
>   (razem z art. 217). Powoływanie go dziś jako podstawy jest błędem.
> - Podstawą jest **art. 205¹ §1 KPC**: przewodniczący zarządza doręczenie pozwu i
>   **wzywa pozwanego do złożenia odpowiedzi w terminie nie krótszym niż dwa tygodnie**.
>   To termin **sądowy** (przedłużalny na wniosek), a nie sztywne 14 dni — w sprawach
>   obszernych bywa wyznaczany na miesiąc i dłużej.
> - ⛔ **Skutek uchybienia jest OSTRZEJSZY, nie łagodniejszy, niż głosił stary przypis:**
>   wg **art. 205¹ §2** przewodniczący **zarządza ZWROT** odpowiedzi złożonej po terminie.
>   Pismo zwrócone traktuje się tak, jakby nie zostało wniesione — co otwiera drogę do
>   **wyroku zaocznego (art. 339 §1 KPC)**. Nazywanie tego terminu "instrukcyjnym"
>   i sugerowanie, że uprawnienie nie gaśnie, mogło realnie kosztować sprawę.
> - Prekluzja twierdzeń i dowodów to **osobny** mechanizm: **art. 205¹²** (ogólny),
>   **art. 458⁵** (sprawy gospodarcze, ostrzejszy).
>
> ⭐ Lekcja audytowa: błąd przetrwał sześć tygodni w pliku KANONICZNYM dla terminów,
> mimo że inny plik systemu (`shared/MOD-TIMING.md`) opisał to uchylenie poprawnie
> już 2026-08-08. Jedna naprawa punktowa nie propaguje się sama — patrz
> `audyt-systemu-v4/modules/MOD-PROPAGACJA-NOWELIZACJI.md`.

> **Przypis (dodany 2026-07-25, wykryty przy audycie pisma-proste-v2 /
> pisma-procesowe-v3 / mod-USP — brak wskazania adresata zażalenia w
> wielu modułach):** termin 7 dni (art. 394 §2 KPC) jest wspólny, ale
> **adresat zażalenia NIE zawsze jest sądem wyższej instancji.** Rozróżnij:
> - **Zażalenie dewolutywne (pionowe)** — do sądu **II instancji**, katalog
>   zamknięty w art. 394 §1 KPC (m.in. zwrot pozwu, odrzucenie sprzeciwu,
>   zawieszenie postępowania, postanowienia kończące postępowanie).
> - **Zażalenie poziome** — do **innego składu tego samego sądu**
>   (art. 394¹ᵃ §1 KPC dla sądu I instancji; art. 394² §1 KPC dla sądu
>   II instancji) — obejmuje m.in. odmowę zwolnienia od kosztów sądowych,
>   odmowę ustanowienia pełnomocnika z urzędu, **oddalenie wniosku o
>   wyłączenie sędziego**, zwrot zaliczki, wynagrodzenie biegłego.
> - **Wyjątek bez zażalenia:** oddalenie żądania wyłączenia zgłoszonego
>   przez samego sędziego (a nie przez stronę) — niezaskarżalne
>   (uchwała SN III CZP 33/69, podtrzymana w późniejszym orzecznictwie).
> Przed sporządzeniem zażalenia **zawsze ustal, którego postanowienia
> dotyczy** i sprawdź właściwy przepis (art. 394 §1 / 394¹ᵃ §1 / 394² §1
> KPC) zamiast zakładać domyślnie sąd wyższej instancji.

## Przedawnienia (instrukcyjne)

| Termin | Zakres | Podstawa |
|--------|--------|----------|
| 3 lata | Roszczenia ze stosunku pracy | art. 291 KP |
| 3/6 lat | Roszczenia cywilne ogólne | art. 118 KC |
| 5 lat | Zachowek | art. 1007 KC |
| 1 rok / maks. 3 lata przy wszczęciu postępowania w pierwszym roku | Wykroczenia — karalność | art. 45 §1 KW; re-ver ELI Dz.U. 2025 poz. 734, 2026-08-28 |

## ⛔ Reguła, która wyszła z tego audytu

**Podstawa terminu rzadko stoi w tym samym przepisie, co sama czynność.**
Trzy potwierdzone przypadki: art. 493 § 1 i art. 505 § 1 KPC mówią o dopuszczalności
środka, ale termin daje art. 480² § 2; art. 105 § 1 KPW reguluje apelację, a termin
wniosku o uzasadnienie — art. 35 § 1 KPW; art. 94 § 1 KPW nie zawiera terminu, tylko
odsyła do art. 506 § 1 KPK. ⛔ Odesłanie typu termin X — art. Y sprawdzaj **czytając
art. Y**, a nie kojarząc go z instytucją.

## Reguły liczenia
- Start: następny dzień po doręczeniu/ogłoszeniu
- Koniec w sobotę/niedzielę/święto → przesuwa się na następny dzień roboczy
- Skutki uchybienia i możliwość przywrócenia ustalaj w reżimie właściwej procedury; nie wolno stosować jednej reguły do KPC/KPK/KPW/KPA. Przykład: KPC art. 168 §1 pozwala przywrócić termin, gdy strona uchybiła mu bez swojej winy.

## Ostrzeżenie automatyczne
Gdy termin ≤5 dni: 🚨 **PILNE — zostały [n] dni!**
Gdy termin minął: ❌ **TERMIN UPŁYNĄŁ — natychmiast sprawdź skutek uchybienia i przesłanki przywrócenia we właściwej procedurze**
