# ORKA-BAS — Leksykon Definicji Ministerialnych i Parlamentarnych — INDEKS
## Shared Library · Silnik Prawny v1.0 (podzielony 2026-08-20, naprawa F-78)

> **Źródło:** Baza ORKA_COMBINED v1.8 (interpelacje sejmowe BAS-001–125)
> + weryfikacja online 2026-06-11 + uzupełnienia z aktualnych aktów prawnych
>
> **Wartość prawna:** wykładnia autentyczna organów administracji (ministerstwa);
> niewiążąca sądów, ale powszechnie stosowana przez organy, US, ZUS, PFRON.
>
> **Format każdego rekordu:** Hasło | Źródło | Definicja | Podstawa prawna | Reguła
>
> ⛔ HARD GATE: definicje wymienione ze źródłem interpelacji są wykładnią
> ministerialną; definicje ustawowe — weryfikuj ZAWSZE aktualny t.j. w ELI (RZĄD 1).

> ⚡ **ZMIANA STRUKTURALNA 2026-08-20 (F-78, priorytet 2):** ten plik był
> 1975 linii. Treść 20 CZĘŚCI (I-XX) PODZIELONA na 8 plików w podkatalogu
> `orka-bas-leksykon/`. TEN plik pozostaje pod NIEZMIENIONĄ nazwą jako
> LEKKI INDEKSATOR — dekady odsyłaczy w całym systemie (m.in. WSZYSTKIE
> pliki `dr-XX/SKILL.md`, `ROUTING-MAP.md`, `DEFINICJE-KLUCZOWE.md`) NIE
> WYMAGAŁY EDYCJI, ponieważ odsyłają po nazwie pliku, nie po numerze
> linii. METAREGUŁY i QUALITY GATE (treść stosowana ZAWSZE, niezależnie
> od szukanego hasła) POZOSTAJĄ w tym indeksie — nie zostały przeniesione.

---

## METAREGUŁY WYKŁADNI (ORKA-REG) — stosuj ZAWSZE, niezależnie od części

```
ORKA-REG-01 — PIERWSZEŃSTWO DEFINICJI LEGALNEJ
  Jeżeli akt prawny zawiera własną definicję pojęcia, definicja ta wiąże
  przy stosowaniu tego aktu. Nie stosuje się automatycznie definicji z innych ustaw.

ORKA-REG-02 — UPRAWDOPODOBNIENIE ≠ UDOWODNIENIE
  Jeżeli przepis wymaga uprawdopodobnienia, wystarcza wykazanie prawdopodobieństwa.
  Nie wolno żądać pełnego dowodu ani dokumentu urzędowego, jeżeli ustawa
  tego nie wymaga.
  Źródło: odpowiedź MPiPS na interpelację nr 5379, 22.11.2006

ORKA-REG-03 — STAŁE MIEJSCE DZIAŁALNOŚCI WYMAGA REALNEJ INFRASTRUKTURY
  Stałe miejsce prowadzenia działalności gospodarczej (VAT) wymaga trwałego
  zaplecza personalnego i technicznego, nie tylko adresu ani sporadycznych czynności.
  Źródło: odpowiedź MF na interpelację nr 24082, 6.09.2011

ORKA-REG-04 — OCENA AD CASUM
  Pojęcia zależne od stopnia organizacji, funkcji albo okoliczności wymagają
  oceny całokształtu konkretnego stanu faktycznego.

ORKA-REG-05 — DEFINICJA TECHNICZNA NIE PRZESĄDZA PRAWA MATERIALNEGO
  Definicja z aktu technicznego obowiązuje w granicach tego aktu i nie tworzy
  samodzielnego prawa do inwestycji lub świadczenia.
  Źródło: MŚ na interpelację nr 23020 (zabudowa zagrodowa vs grunty leśne)

ORKA-REG-06 — FUNKCJA OBIEKTU WAŻNIEJSZA NIŻ NAZWA
  O kwalifikacji prawnej nie decyduje nazwa użyta przez stronę, lecz rzeczywista
  funkcja, przeznaczenie i związek z działalnością przewidzianą przez ustawę.

ORKA-REG-07 — TOŻSAMOŚĆ BIOLOGICZNA ≠ TOŻSAMOŚĆ PRAWNA
  Ten sam obiekt, zwierzę, rzecz lub czynność może mieć różny status prawny
  w różnych ustawach. Różnica definicji sektorowych nie jest sprzecznością prawa.
  Źródło: MRiRW na interpelację nr 31430 (gołąb jako drób)

ORKA-META-01 — ZAKAZ AUTOMATYCZNEGO PRZENOSZENIA DEFINICJI
  Definicji legalnej nie wolno automatycznie przenosić do innej ustawy,
  chyba że ustawodawca wyraźnie tak przewidział.
  Źródło: MPiPS na interpelację nr 5781 (org. pozarządowa w ustawie o rehabilitacji)

ORKA-META-02 — BRAK JEDNOLITOŚCI DEFINICJI NIE OZNACZA SPRZECZNOŚCI PRAWA
  Różne definicje sektorowe mogą współistnieć, jeżeli ustawy realizują odmienne
  cele regulacyjne.
```

---

## TABELA NAWIGACYJNA — KTÓRA CZĘŚĆ, W KTÓRYM PLIKU

| Część | Temat | Linie orient. | Plik |
|---|---|---|---|
| I | Prawo pracy i rynek pracy | ~93 | `JUR:leksykon-praca-admin-drogowe` |
| II | Prawo administracyjne i procedura | ~42 | `JUR:leksykon-praca-admin-drogowe` |
| III | Prawo drogowe | ~56 | `JUR:leksykon-praca-admin-drogowe` |
| IV | Finanse publiczne i podatki | ~77 | `JUR:leksykon-finanse-nieruchomosci-energetyczne` |
| V | Nieruchomości i budownictwo | ~43 | `JUR:leksykon-finanse-nieruchomosci-energetyczne` |
| IX | Prawo energetyczne | ~20 | `JUR:leksykon-finanse-nieruchomosci-energetyczne` |
| VI | Prawo cywilne i rodzinne | ~25 | `JUR:leksykon-cywilne-niepelnosprawnosc` |
| XI | Prawo cywilne — uzupełnienie (DR-02) | ~105 | `JUR:leksykon-cywilne-niepelnosprawnosc` |
| VII | Niepełnosprawność (ogólna) | ~40 | `JUR:leksykon-cywilne-niepelnosprawnosc` |
| XIII | Osoba niewidoma — odesłanie do modułów specjalistycznych | ~41 | `JUR:leksykon-cywilne-niepelnosprawnosc` |
| XIV | Niepełnosprawność intelektualna i głuchota — odesłanie | ~49 | `JUR:leksykon-cywilne-niepelnosprawnosc` |
| VIII | Prawo karne i wykroczeniowe | ~57 | `JUR:leksykon-karne` |
| XII | Prawo karne — uzupełnienie (DR-03) | ~81 | `JUR:leksykon-karne` |
| X | Rekordy-kandydaci (wymagają pełnej weryfikacji online) | ~58 | `JUR:leksykon-kandydaci-prawa-obywatelskie-sporne` |
| XV | Prawa obywatelskie — utrata i odzyskanie | ~35 | `JUR:leksykon-kandydaci-prawa-obywatelskie-sporne` |
| XVI | Pojęcia sporne i ocenne — uzupełnienie z audytu DR-skillów | ~138 | `JUR:leksykon-kandydaci-prawa-obywatelskie-sporne` |
| XIX | Brakujące priorytety P1 (audyt archiwum v1.8) | ~207 | `JUR:leksykon-priorytety-p1` |
| XX | Priorytety P2 (audyt archiwum v1.8) | ~74 | `JUR:leksykon-priorytety-p2-bas-v18` |
| XVII | Brakujące z oryginału BAS v1.8 — uzupełnienie | ~298 | `JUR:leksykon-priorytety-p2-bas-v18` |
| XVIII | Kluczowe pojęcia praktyki prawniczej — audyt uzupełniający | ~345 | `JUR:leksykon-praktyka-prawnicza` |

**Dane maszynowe:** `shared/ORKA-BAS-001-125.json` — 125 rekordów BAS-001…BAS-125
(`id`, `haslo`, `modul`, `definicja`); 41 z nich (od BAS-025) nie ma odpowiednika
w częściach `.md` (pomiar shared 3.19). Przy haśle nieznalezionym w częściach
sprawdź JSON. Rekord to definicja robocza — definicję LEGALNĄ weryfikuj w ELI
(QUALITY GATE niżej).

⚠️ **UWAGA O NUMERACJI:** w oryginalnym pliku CZĘŚĆ XIX i XX występowały
FIZYCZNIE PRZED CZĘŚCIĄ XVII i XVIII (kolejność dodawania w czasie, nie
kolejność numeryczna) — ta sama, NIEZMIENIONA kolejność fizyczna
zachowana jest w podziale (czesc-06 zawiera XIX, czesc-07 zawiera
XX+XVII). To NIE jest błąd tego podziału — odziedziczone po oryginale.

---

## QUALITY GATE — PRZED POWOŁANIEM DEFINICJI ORKA

```
□ Sprawdź czy hasło ma definicję LEGALNĄ (ustawową) → ZAWSZE aktualizuj przez ELI (RZĄD 1)
□ Sprawdź datę interpelacji źródłowej — akty prawne mogły się zmienić
□ Zastosuj odpowiednią ORKA-REG (szczególnie REG-01 i META-01)
□ Dla kandydatów BAS-107–125: pobierz pełny tekst odpowiedzi (API Sejmu / ręcznie)
  → api.sejm.gov.pl/sejm/term{kadencja}/interpellations?title={haslo}
  → kadencja 7 = VII Sejm (2011–2015) → przeszukaj przez google snippety
  → kadencja 8–10: dostępne przez API

ŹRÓDŁA DO AKTUALNEJ WERYFIKACJI DEFINICJI:
  isap.sejm.gov.pl    → aktualne t.j. ustaw
  api.sejm.gov.pl     → interpelacje VIII–X kadencji
  orzeczenia.nsa.gov.pl → definicje przez pryzmat orzecznictwa
  sn.pl               → kluczowe uchwały SN definiujące pojęcia
  sejm.gov.pl/Sejm7.nsf → interpelacje VII kadencji (z ograniczeniami)
  orka2.sejm.gov.pl   → starsze kadencje (blokuje roboty → przez snippety Google)
```

---

## JAK UŻYWAĆ TEGO LEKSYKONU

```
KROK 1 — Zidentyfikuj dziedzinę/hasło, którego szukasz.
KROK 2 — Znajdź właściwą CZĘŚĆ w tabeli nawigacyjnej wyżej.
KROK 3 — Wczytaj WYŁĄCZNIE plik zawierający tę część (view czesc-0X-*.md
  z podkatalogu `orka-bas-leksykon/`) — NIE wczytuj wszystkich 8 naraz.
KROK 4 — Zastosuj METAREGUŁY (wyżej) przy interpretacji znalezionej definicji.
KROK 5 — Przejdź przez QUALITY GATE (wyżej) przed powołaniem definicji w piśmie.
```

---
*ORKA-BAS-LEKSYKON.md · shared/ · indeks utworzony 2026-08-20 (F-78)*
*Baza: ORKA_COMBINED v1.8 (BAS-001–125) + weryfikacja online 2026-06-11*
*Metareguły: ORKA-REG-01–07, ORKA-META-01–02*
