# MOD-ATAK-NA-SWIADKA — Podważanie świadka jako ogniwa łańcucha dowodowego

> **Plik:** `shared/MOD-ATAK-NA-SWIADKA.md`
> **Wersja:** 1.2.0 (2026-11-19, F-240) — SW-DETECT-HARD, inwentarz wszystkich protokołów świadka
> (SW-P2, `tools/inwentarz_zeznan.py`), SW-P6 niepamięć wobec wiedzy, SW-A9, checkpoint SW-INW.
> Poprzednio: 1.1.0 (2026-07-02) — naprawa WARN-22: dodano FAZA 6 (specyfika
> dziedzinowa DR-02/03/04/05), zastępująca nieaktualne odwołania CHECKLIST-DEDUP
> do nieistniejącej struktury §CZĘŚĆ I-IV / TA-1..TA-9 (patrz HISTORIA ZMIAN)
> **Status:** PRODUKCJA — plik kanoniczny shared/
> **Pozycja w pipeline:**
>   - pisma-procesowe-v3: W1.2c-LANCUCH (ŁD-3 EQG — ocena ogniwa zeznanie)
>   - pisma-procesowe-v3: W2.4 ROZSZERZENIE W2.4c (gdy ≥1 ogniwo = zeznanie)
>   - pisma-procesowe-v3: W3.4 BLOK J (weryfikacja twierdzeń o świadku)
>   - przesluchanie-swiadkow-v2-min90: W3 (pytania do cross-examination)
>
> **Powiązania:**
>   - MOD-LANCUCH-DOWODOWY §ŁB-1 (ogniwo BASE kl.D — zeznanie)
>   - MOD-ATAK-NA-DOWOD §AD-3 (brak weryfikowalności), §AD-10 (konflikt interesu)
>   - MOD-NEGACJA-DOWODOW §N2 (odporność klasy D)
>   - KPC art. 248, 261, 266, 271–272 (dowód ze świadków i przesłuchanie)
>     ⚠️ art. 258 KPC — UCHYLONY 23.04.2026 (Dz.U.2026.0.468); obowiązki strony
>     dotyczące wskazania świadków i faktów przeniesione do art. 235² §1 KPC
>
> ⛔ HARD GATE: przepisy i sygnatury — weryfikuj ISAP przed użyciem w piśmie.
> ⛔ WERYFIKACJA art. KPC: wszystkie art. zweryfikowane w Dz.U.2026.0.468 (24.06.2026):
>   art. 248 ✅ · art. 261 ✅ · art. 266 ✅ · art. 271 ✅ · art. 272 ✅
>   art. 258 ❌ UCHYLONY — zastąp art. 235² §1 KPC przy powoływaniu świadków

---

## DLACZEGO OSOBNY MODUŁ

```
Zeznanie świadka ≠ dokument.
  Dokument atakuje się przez: autentyczność, treść, datę, podpis.
  Świadka atakuje się przez: wiarygodność osoby + wiarygodność zeznania.

Problem w obecnym systemie:
  MOD-ATAK-NA-DOWOD §AD-3/AD-10 obsługuje "brak weryfikowalności"
  i "konflikt interesu" — ale nie daje procedury kompletnego ataku
  na świadka jako OGNIWO ŁAŃCUCHA z antycypacją kontrataków.

  MOD-LANCUCH-DOWODOWY §ŁA-1..ŁA-4 atakuje łańcuch strukturalnie
  — ale nie wchodzi w techniki podważenia konkretnego świadka.

  W2.4 MOD-ATAK-NA-DRAFT §D2 (ataki przeciwnika) nie uwzględnia
  ścieżki: "przeciwnik podważy świadka który jest naszym BASE."

Ten moduł wypełnia tę lukę.
```

---

## FAZA 0 — DETEKCJA (wykonaj automatycznie w W1.2c-LANCUCH)

```
⛔ SW-DETECT: sprawdź per każdy łańcuch ŁD-n:

  Czy ≥1 ogniwo = zeznanie świadka (klasa D z MOD-NEGACJA §N2)?
    TAK → MOD-ATAK-NA-SWIADKA AKTYWNY dla tego ogniwa
          Oznacz: ŁD-n → ogniwo [ŁO-BASE/POŚR] → typ: ZEZNANIE
          → wykonaj FAZĘ 1 dla każdego takiego ogniwa
    NIE → moduł nieaktywny; kontynuuj normalnie

  ⛔ SW-DETECT-HARD (F-240) — AKTYWNY niezależnie od W1.2c, gdy:
    zadanie = podważenie / ocena wiarygodności / sprzeczne zeznania świadka, LUB
    akta zawierają ≥2 protokoły zeznań tego samego świadka (także z innej sprawy).
    Wczytaj PRZED CP-1b. Brak wykonania = krok W1-SW-INW „✗ POMINIĘTY” w ST-FINAL
    (zakaz opisu „skrótowo”). Luka źródłowa F-240: moduł był wpięty tylko w W1.2c-LANCUCH;
    pominięcie W1.2c pominęło inwentarz zeznań i istotną sprzeczność.

  Trigger dodatkowy:
    Materiał zawiera protokół rozprawy z zeznaniami świadka → AKTYWNY
    Prośba o "podważenie świadka" / "cross-examination" → AKTYWNY
    Pismo riposta/odpowiedź gdy strona przeciwna powołuje świadka → AKTYWNY
```

---

## FAZA 1 — PROFIL ŚWIADKA (SW-PROFIL)

```
Per każdy świadek-ogniwo W[id]:

SW-P1 DANE FORMALNE:
  Imię, nazwisko, wiek (z protokołu lub akt)
  Status: strona / pracownik strony / osoba trzecia / biegły
  Relacja ze stronami: zależność służbowa? osobista? ekonomiczna?
  Karalność za składanie fałszywych zeznań (protokół: "pouczony / nie karany")

SW-P2 TREŚĆ ZEZNAŃ (per twierdzenie) — ze WSZYSTKICH protokołów świadka (każda rozprawa,
  każda sprawa), nie tylko z protokołu, którego dotyczy pismo. Host z powłoką:
    python3 -I shared/tools/inwentarz_zeznan.py --swiadek NAZWISKO P1.txt P2.txt [--pismo PISMO.txt]
  (tekst protokołu: pdftotext -layout). Narzędzie wskazuje pary; ocenia autor.
  Kolumny inwentarza: ID | protokół + znacznik czasu | pytający | cytat | źródło wiedzy |
    KIERUNEK wobec DOSŁOWNEJ tezy dowodowej z protokołu (KORZ / NIEKORZ / NEUTR) | STATUS
    (UŻYTE: pkt pisma / POMINIĘTE: powód).
  ⛔ Kierunek ustalaj z brzmienia tezy dowodowej, nie z parafrazy (autora, recenzenta).
  Synonimy ról i pojęć traktuj jako jeden temat (informatyk = programista; SMS / WhatsApp =
  wiadomość); inaczej sprzeczność między protokołami nie zostanie zestawiona.
  Wyodrębnij KAŻDE twierdzenie faktyczne:
    W-001: "[cytat/parafraza]" — bezpośrednio zaobserwowane / z relacji / domysł
    W-002: "[cytat/parafraza]" — ...
  Wyodrębnij KAŻDE "nie wiem" / "nie pamiętam" / "nie byłem przy tym":
    W-NW-001: "[cytat]" — co świadek wyklucza ze swojej wiedzy
  Wyodrębnij każde twierdzenie warunkowe / niepewne:
    W-COND-001: "[cytat z 'chyba' / 'zdaje się' / 'bodajże']"

SW-P3 ŹRÓDŁO WIEDZY ŚWIADKA:
  Kategoria per twierdzenie W-xxx:
    BEZPOŚREDNIE   — świadek osobiście widział/słyszał
    Z RELACJI      — ktoś mu powiedział (kto? kiedy?)
    WNIOSKOWANE    — świadek wyciąga wniosek z faktów
    DOMYSŁ         — świadek sam zaznacza niepewność

  ⛔ Twierdzenia kategorii Z RELACJI i WNIOSKOWANE są podatne na:
     SW-A3 (źródło wtórne) i SW-A4 (logika wnioskowania).

SW-P4 SPRZECZNOŚCI WEWNĘTRZNE:
  Porównaj wszystkie W-xxx między sobą:
    Czy daty się zgadzają?
    Czy sekwencja zdarzeń jest logiczna?
    Czy twierdzenie W-001 nie przeczy W-007?
  Format: [W-001] vs [W-007] — SPRZECZNOŚĆ: [opis]

SW-P5 SPRZECZNOŚCI ZEWNĘTRZNE:
  Porównaj zeznania z dokumentami w aktach:
    Każdy D[id] z SD-FAKTY który opisuje ten sam fakt → zestawienie
  Format: [W-001] vs [D03 str.2] — ROZBIEŻNOŚĆ: [opis]
  
  Porównaj z zeznaniami innych świadków:
    [W1-001 Nawrot] vs [W2-003 Parzych] — SPRZECZNOŚĆ: [opis]

SW-P6 NIEPAMIĘĆ WOBEC WIEDZY (F-240) — każde W-NW zestaw z wypowiedziami z INNYCH protokołów
  na ten sam temat (po synonimach). Wcześniejsza ocena, szczegół, data, dokument
  („współpraca układała się dobrze”, „było zarządzenie”) = świadek tę wiedzę miał.
  Format: [W-013 17.03 „współpraca jako informatyk dobra”] vs [W-032 13.11 „nie pamiętam,
  od kiedy był programistą”] — SW-A9.
```

---

## FAZA 1A — SW-INW: INWENTARZ DLA UŻYTKOWNIKA (checkpoint informacyjny, przed W2)

```
Pokaż użytkownikowi tabelę SW-P2 z kierunkiem i statusem, w tym:
  - wszystkie wypowiedzi KORZ (zachowywane w piśmie albo powód pominięcia),
  - wszystkie pary SW-P4/P5/P6 (użyte / pominięte + powód).
Pominięcie wypowiedzi KORZ albo pary SW-A9 bez powodu = błąd blokujący W2.
Po zmianach pisma (także po PEER-REVIEW) uruchom inwentarz z --pismo ponownie:
  kod 3 = para, której żadna strona nie trafiła do pisma → decyzja autora i informacja dla użytkownika.
```

---

## FAZA 2 — WEKTORY ATAKU NA ŚWIADKA (SW-ATAK)

```
SW-A1 — KONFLIKT INTERESU / STRONNICZOŚĆ:
  Pytanie: czy świadek ma powód by zeznawać na korzyść jednej ze stron?
  Sygnały: pracownik strony, beneficjent wyroku, osobiste animozje.
  Technika pisma:
    "Świadek [imię] pozostaje w [relacja służbowa/ekonomiczna] ze stroną
     [X]. Zeznanie świadka jest zatem obciążone potencjalnym konfliktem
     interesu, co powinno być uwzględnione przez Sąd przy ocenie jego
     wiarygodności zgodnie z art. 233 §1 k.p.c."
  Skuteczność: ↑ gdy udokumentowana relacja + brak zewnętrznego potwierdzenia

SW-A2 — ZAPRZECZENIE ISTNIENIU OKOLICZNOŚCI:
  ⛔ KLUCZOWY — atak wprost na prawdziwość ogniwa łańcucha
  Sygnały: nasze dowody dokumentowe zaprzeczają temu co zeznał świadek.
  Technika pisma:
    "Twierdzenie świadka [imię], że [W-xxx], stoi w bezpośredniej
     sprzeczności z dokumentem [D-NNN] (zał. nr [X]), który potwierdza
     że [fakt odwrotny]. W świetle tego dowodu dokumentowego (klasa [A/B])
     zeznanie świadka w zakresie [W-xxx] nie może być uznane za
     wiarygodne. Dokument pochodzi od [strony/organu] i wyprzedza
     datą zeznania — nie może być zatem efektem późniejszej korekty."
  Skuteczność: ↑↑↑ gdy kontrdownód klasy A/B + data wcześniejsza
  ⛔ Pamiętaj: samo zaprzeczenie bez dowodu = słabe; musi być poparte D[id]

SW-A3 — ŹRÓDŁO WTÓRNE (RELACJA Z DRUGIEJ RĘKI):
  Sygnały: świadek sam mówi "dowiedziałem się od X" / "opowiedział mi Y"
  Technika pisma:
    "Twierdzenie świadka [imię] dotyczące [W-xxx] opiera się wyłącznie
     na relacji osoby trzeciej — [imię osoby, jeśli znana]. Świadek
     nie był bezpośrednim uczestnikiem ani obserwatorem opisywanego
     zdarzenia. Wartość dowodowa zeznania z drugiej ręki jest
     ograniczona, a sama relacja nie może zastąpić zeznania
     bezpośredniego świadka zdarzenia."
  Skuteczność: ↑↑ — szczególnie gdy bezpośredni świadek jest znany
    ale nie był powołany (wniosek o wezwanie)

SW-A4 — LOGIKA WNIOSKOWANIA (DOMYSŁ, NIE FAKT):
  Sygnały: świadek wyciąga wniosek ("myślę że" / "moim zdaniem" / "chyba")
  Technika pisma:
    "Twierdzenie świadka [imię] w zakresie [W-xxx] ma charakter osobistej
     oceny / domysłu, nie relacji bezpośrednio zaobserwowanych faktów.
     Sam świadek zaznaczył: '[cytat z protokołu potwierdzający niepewność]'.
     Przedmiotem zeznania powinny być własne spostrzeżenia świadka (art. 271
     §1 k.p.c. — weryfikuj ISAP), a nie wnioski wyciągane z obserwacji.
     Oceny i domysły świadka nie mają waloru dowodowego w zakresie
     ustalania faktów, w odróżnieniu od opinii biegłego (art. 278 k.p.c.)."

SW-A5 — NIESPÓJNOŚĆ WEWNĘTRZNA:
  Sygnały: z SW-P4 — sprzeczności wewnętrzne zeznania tego samego świadka
  Technika pisma:
    "Zeznania świadka [imię] zawierają wewnętrzną sprzeczność:
     w [części X protokołu] świadek stwierdził [W-001],
     podczas gdy w [części Y protokołu] zeznał [W-007].
     Sprzeczność ta dotyczy [kluczowego faktu] i podważa
     wiarygodność zeznania w całości, nie tylko w spornym fragmencie."
  Szczególnie skuteczne: gdy sprzeczność dotyczy dat, kwot, sekwencji

SW-A6 — UPŁYW CZASU / ZAWODNOŚĆ PAMIĘCI:
  Sygnały: świadek zeznaje o zdarzeniach sprzed >6 miesięcy
           świadek wielokrotnie mówi "nie pamiętam dokładnie"
  Technika pisma:
    "Zeznania świadka [imię] dotyczą zdarzeń z [data], tj. sprzed
     [N] miesięcy. Świadek wielokrotnie wskazywał na ograniczoną
     pamięć szczegółów ([lista W-NW]). W zakresie [kluczowego faktu]
     świadek sam zaznaczył niepewność: '[cytat W-COND]'.
     Przy braku dokumentów potwierdzających zeznanie,
     zeznanie to nie może stanowić wyłącznej podstawy ustalenia
     faktu [X] — tym bardziej wobec dokumentu [D-NNN] wskazującego
     na [okoliczność odmienna]."

SW-A7 — ZASTRASZENIE LUB NACISK (gdy udokumentowany):
  Sygnały: kontakty z świadkiem udokumentowane w aktach
           świadek zeznał o nacisku / zastraszaniu przez stronę
  Technika pisma:
    "Strona [X] kontaktowała się ze świadkiem [imię] przed
     rozprawą, co wynika z [dowód: SMS/e-mail/zeznanie świadka].
     W świetle art. 233 §1 k.p.c. Sąd winien uwzględnić okoliczność
     potencjalnego nacisku na treść zeznań świadka."
  ⛔ Uwaga: stosuj ostrożnie — musi być udokumentowane. Bez dowodu = ryzyko
    zarzutu zniesławienia.

SW-A8 — WYKLUCZENIE PRZEZ BRAK WIEDZY (świadek nie był przy zdarzeniu):
  Sygnały: z W-NW — świadek sam deklaruje brak wiedzy o kluczowym fakcie
  Technika pisma:
    "Sam świadek [imię] zeznał, że [W-NW-001: cytat 'nie wiem' / 'nie byłem'].
     Twierdzenie dotyczące [faktu X] nie może zatem opierać się na
     zeznaniu tego świadka — który expressis verbis wykluczył posiadanie
     wiedzy w tym zakresie. Strona [X] nie powołała innego świadka
     bezpośrednio obserwującego [zdarzenie Y]."

SW-A9 — NIEPAMIĘĆ WOBEC WCZEŚNIEJSZEJ WIEDZY (F-240):
  Sygnały: z SW-P6 — świadek zaprzecza wiedzy albo „nie pamięta” tego, co w innym
           protokole opisał ze szczegółem lub ocenił.
  Technika pisma:
    "W [protokół 1, znacznik] świadek [ocenił / opisał] [fakt] ('[cytat]'). W [protokół 2,
     znacznik] zeznał, że [nie pamięta / nie miał z tym styczności] ('[cytat]'). Świadek
     znał tę okoliczność, więc rozbieżności nie tłumaczy upływ czasu."
  Skuteczność: ↑↑↑ — zarzut z protokołów, bez potrzeby dowodu zewnętrznego.
```

---

## FAZA 3 — PRIORYTETYZACJA ATAKÓW (SW-PRIOR)

```
Per świadek-ogniwo W[id]: wybierz ≤3 najsilniejsze wektory ataku:

MACIERZ PRIORYTETÓW:
  🔴 KRYTYCZNE (zawsze użyj gdy dostępne):
    SW-A2 (zaprzeczenie przez dokument klasy A/B)
    SW-A5 (niespójność wewnętrzna w protokole)
    SW-A8 (świadek sam wyklucza swoją wiedzę)
    SW-A9 (niepamięć wobec wcześniej wykazanej wiedzy)

  🟠 SILNE (użyj gdy brak 🔴 lub dla wzmocnienia):
    SW-A1 (konflikt interesu — udokumentowany)
    SW-A3 (relacja z drugiej ręki — kluczowy fakt)
    SW-A7 (zastraszenie — udokumentowane)

  🟡 UZUPEŁNIAJĄCE (tylko jako dodatkowy argument):
    SW-A4 (domysł vs fakt)
    SW-A6 (upływ czasu / zawodność pamięci)
    SW-A1 (konflikt interesu — domniemany)

⛔ ZAKAZ: nie atakuj wszystkich 8 wektorów naraz — traci moc.
  Zasada MacCarthy'ego: 1-3 mocne uderzenia > 8 słabych.
  Wybierz wektory z dowodami; wektory bez dowodów = tylko marginalnie.
```

---

## FAZA 4 — INTEGRACJA W W2.4 (ROZSZERZENIE W2.4c)

```
⛔ W2.4c — ATAK NA ŚWIADKA (gdy AKTYWNY z SW-DETECT):

FORMAT sekcji w piśmie:

## [Tytuł: Uwagi co do wiarygodności zeznań świadka X]

  Zeznania świadka [imię], złożone na rozprawie w dniu [data],
  jako [ogniwo BASE/POŚR] dla tezy [T-X], budzą istotne
  zastrzeżenia co do ich wiarygodności z następujących przyczyn:

  1. [SW-A2 jeśli aktywny]: ...
  2. [SW-A5 jeśli aktywny]: ...
  3. [SW-A8 / SW-A1 / SW-A3 jeśli aktywne]: ...

  W konsekwencji, zeznanie świadka [imię] nie może stanowić
  samodzielnej podstawy ustalenia [faktu X], w szczególności
  wobec [kontrdownodu D-NNN] potwierdzającego [fakt odmienny].

ANTYCYPACJA ZARZUTU WOBEC NASZEGO ŚWIADKA:
  Jeśli nasz łańcuch opiera się na świadku (np. Nawrot):
    → Wstaw sekcję SW-TARCZKA:
    "Wartość dowodowa zeznań świadka [imię] jest wysoka z uwagi na:
     (1) status osoby obcej wobec stron (protokół: 'obcy wobec stron');
     (2) brak aktywnego zatrudnienia u pozwanej w dniu przesłuchania;
     (3) potwierdzenie przez dokumenty SUDOP (D-XX, D-YY) kluczowego faktu
     dotyczącego [PFRON / premii / obsługi];
     (4) zeznanie pod rygorem odpowiedzialności karnej za fałszywe zeznania
     (art. 233 §1 k.k. — weryfikuj ISAP — kara pozb. wolności 6 mies. do 8 lat;
      pouczony przed złożeniem zeznań zgodnie z art. 266 §1 k.p.c.)."
```

---

## FAZA 5 — WNIOSKI PROCESOWE (SW-WNIOSKI)

```
Na podstawie SW-ATAK wygeneruj odpowiednie wnioski procesowe:

SW-W1: KONFRONTACJA (art. 272 k.p.c.) — weryfikuj ISAP
  Trigger: SW-A5 (sprzeczność między dwoma świadkami)
  Wniosek: "Wnoszę o zarządzenie konfrontacji świadka [X] ze świadkiem [Y]
    w zakresie [sprzecznych twierdzeń W-001 vs W-007]."

SW-W2: WNIOSEK O POWOŁANIE ŚWIADKA (art. 235² §1 k.p.c.) — weryfikuj ISAP
  ⚠️ art. 258 KPC UCHYLONY 23.04.2026 (Dz.U.2026.0.468) — używaj art. 235² §1 KPC
  Trigger: SW-A3 (relacja wtórna — osoba pierwotna znana)
  Wniosek: "Wnoszę o wezwanie [imię osoby pierwotnej] w charakterze świadka
    na okoliczność [X], o której świadek [imię wtórny] zeznawał z relacji.
    Powołuję ww. świadka na podstawie art. 235² §1 k.p.c., wskazując że
    wykazanie [faktu X] jest istotne dla rozstrzygnięcia sprawy."

SW-W3: PYTANIA DO CROSS-EXAMINATION
  Trigger: świadek będzie przesłuchiwany na przyszłej rozprawie
  Format: lista pytań do protokołu (per wektor ataku SW-A1..SW-A8)
  → Przekaż do przesluchanie-swiadkow-v2-min90 dla pełnego opracowania

SW-W4: WNIOSEK O DOKUMENTY (art. 248 k.p.c.) — weryfikuj ISAP
  Trigger: SW-A2 — zeznanie podważa dokument, ale dokument nie jest w aktach
  Wniosek: "Wnoszę o zobowiązanie [strona] do złożenia [dokument X] na
    okoliczność [fakt Y], który pozostaje w sprzeczności z zeznaniem świadka [Z]."
```

---

## FAZA 6 — SPECYFIKA DZIEDZINOWA PER DR (poglądowa)

```
⛔ ZASADA: ta sekcja jest POGLĄDOWA — nie zastępuje FAZ 0-5 powyżej (które
pozostają jedynym źródłem procedury SW-DETECT/SW-PROFIL/SW-ATAK/SW-PRIOR/
SW-WNIOSKI). Cel: wskazać, GDZIE w poszczególnych DR-skillach szukać pełnej
specyfiki dziedzinowej, oraz dać 2-3 przykłady typowych sygnałów per dziedzina,
żeby ułatwić rozpoznanie kiedy dany wektor SW-A1..SW-A8 jest szczególnie
prawdopodobny. Pełna, rozwinięta treść żyje w DR-skillu (nie tutaj — unikaj
duplikacji przy rozbudowie).
```

### DR-02 — Prawo cywilne/rodzinne/gospodarcze

```
Pełna specyfika: dr-02-prawo-cywilne-rodzinne-gospodarcze/modules/
  mod-KRO-rodzinne.md § "ŚWIADKOWIE W SPRAWACH ROZWODOWYCH" (S1-S4)

Sprawy rozwodowe/rodzinne — sygnały typowe:
  • Krąg świadków to głównie osoby bliskie stronom (rodzina, przyjaciele) →
    PODWYŻSZONE ryzyko SW-A1 (konflikt interesu) jako sytuacja STRUKTURALNA,
    nie wyjątkowa — traktuj tak przy każdym świadku powołanym na okoliczność
    winy rozkładu pożycia lub kompetencji rodzicielskich.
  • Świadkowie rodzinni często znają zdarzenia wyłącznie z relacji strony,
    która ich powołała → podwyższone ryzyko SW-A3 (źródło wtórne).
  • Nadmierna spójność / "wyuczony" charakter zeznań kilku świadków tej samej
    strony → sygnał możliwego przygotowania świadków, wykorzystaj przy
    SW-P4/SW-P5 jako element wniosku o konfrontację (SW-W1).
  • Ocena wiarygodności podlega standardowi art. 233 §1 KPC — zarzut wymaga
    wskazania konkretnego dowodu + braku logicznego powiązania z ustaleniem
    sądu, NIE samej odmiennej wersji zdarzeń (formuła 3-punktowa w DR-02).

Sprawy gospodarcze (KSH, upadłość/restrukturyzacja) — sygnały typowe:
  • Świadkowie-pracownicy/kontrahenci stron → SW-A1 z tytułu zależności
    służbowej/ekonomicznej jest częstszy niż w sprawach cywilnych ogólnych.
  • Świadkowie z zarządu/rady nadzorczej → weryfikuj status formalny (SW-P1)
    i ewentualną odpowiedzialność osobistą jako czynnik motywacyjny (SW-A1).
```

### DR-03 — Prawo karne, wykroczenia, egzekucja

```
Pełna specyfika: DO OPRACOWANIA w dr-03-prawo-karne-wykroczenia-egzekucja
  (moduł dedykowany świadkom w procesie karnym nie istnieje jeszcze —
  kandydat na przyszłą sesję).

Sygnały typowe (poglądowe, do rozwinięcia w DR-03):
  • Świadek koronny / świadek incognito — odrębny reżim proceduralny (KPK),
    SW-A1 (motyw: redukcja odpowiedzialności własnej) często kluczowy.
  • Pokrzywdzony jako świadek we własnej sprawie — status szczególny, SW-A1
    (interes procesowy) niemal zawsze aktualny, ale NIE dyskwalifikuje
    automatycznie zeznania.
  • Świadek z kartoteką karną — dopuszczalność powołania karalności jako
    okoliczności obniżającej wiarygodność wymaga odrębnej weryfikacji KPK
    (poza zakresem tego modułu — weryfikuj w DR-03).
```

### DR-04 — Prawo pracy, ZUS, świadczenia

```
Pełna specyfika: dr-04-prawo-pracy-zus-swiadczenia/modules/
  `dr-04-prawo-pracy-zus-swiadczenia/modules/mod-KP-mobbing-dyskryminacja.md` (częściowo — świadkowie mobbingu)
  — pełne rozwinięcie SW-specyfiki: DO OPRACOWANIA.

Sygnały typowe (poglądowe):
  • Świadkowie-współpracownicy pozwanego pracodawcy → SW-A1 (zależność
    służbowa, obawa przed konsekwencjami zawodowymi) — częsty i silny wektor.
  • Sprawy o mobbing/dyskryminację: świadkowie często zeznają "ze słyszenia"
    o zdarzeniach, których osobiście nie obserwowali → SW-A3.
  • Rotacja kadrowa w toku procesu → SW-A6 (upływ czasu/zawodność pamięci)
    bywa wzmocniony zmianą miejsca zatrudnienia świadka.
```

### DR-05 — Prawo administracyjne i sądowoadministracyjne

```
Pełna specyfika: DO OPRACOWANIA w dr-05-prawo-administracyjne-
  sadowoadministracyjne (moduł dedykowany nie istnieje jeszcze).

Sygnały typowe (poglądowe):
  • W postępowaniu administracyjnym dowód z zeznań świadka ma mniejsze
    znaczenie niż dokumenty urzędowe — SW-A2 (zaprzeczenie przez dokument)
    zyskuje relatywnie większą wagę niż w procesie cywilnym.
  • Świadkowie-urzędnicy organu → status szczególny (SW-P1: zależność
    służbowa od organu będącego stroną postępowania) — weryfikuj kontekst
    przed zastosowaniem SW-A1.
```

### Rejestr rozwinięć (aktualizuj przy każdym audycie targeted per DR)

| Dziedzina | Status rozwinięcia | Ostatnia aktualizacja |
|---|---|---|
| DR-02 (cywilne/rodzinne/gospodarcze) | ✅ pełne (mod-KRO-rodzinne S1-S4) | 2026-07-02 |
| DR-03 (karne) | ⚠️ poglądowe — pełny moduł DO OPRACOWANIA | 2026-07-02 (dodano poglądowe) |
| DR-04 (praca/ZUS) | ⚠️ poglądowe — pełny moduł DO OPRACOWANIA | 2026-07-02 (dodano poglądowe) |
| DR-05 (administracyjne) | ⚠️ poglądowe — pełny moduł DO OPRACOWANIA | 2026-07-02 (dodano poglądowe) |

---

## SELF-CHECK

```
□ SW-DETECT: czy wykryto ogniwa zeznaniowe w łańcuchach ŁD-n?
□ SW-P1..P5: profil per świadek-ogniwo — kompletny?
□ SW-P4: sprzeczności wewnętrzne — sprawdzone?
□ SW-P5: sprzeczności z dokumentami D[id] — sprawdzone?
□ SW-P2: inwentarz ze WSZYSTKICH protokołów świadka, kierunek wobec dosłownej tezy, status?
□ SW-P6: każde W-NW zestawione z innymi protokołami (synonimy ról)?
□ SW-INW: tabela pokazana użytkownikowi; inwentarz z --pismo po ostatniej zmianie pisma = kod 0
  albo każda pominięta para z powodem?
□ SW-ATAK: ≤3 wektory priorytetowe wybrane (nie wszystkie 8)?
□ W2.4c sekcja wbudowana do projektu pisma (W2)?
□ SW-TARCZKA dla naszych świadków — wbudowana do W2?
□ SW-WNIOSKI: wnioski procesowe wynikające z ataku — wygenerowane?
□ FAZA 6: sprawdzono specyfikę dziedzinową per DR (jeśli dostępna) — użyto
  jako uzupełnienie, nie zastąpienie FAZ 0-5?
Którykolwiek = NIE → wróć do brakującego kroku.
```
