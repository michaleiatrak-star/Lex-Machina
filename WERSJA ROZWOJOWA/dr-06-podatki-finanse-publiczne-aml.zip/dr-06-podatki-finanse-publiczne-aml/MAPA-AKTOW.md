# DR-06 — Lokalna Mapa Aktów Prawnych

## Podatki, Finanse Publiczne, AML

| Akt prawny | Dz.U. (t.j.) | Moduł | Status |
|---|---|---|---|
| Prawo przedsiębiorców, art. 19 (limit płatności gotówkowych) | Dz.U. 2025 poz. 1480 t.j. — dodane 2026-07-27, na żądanie użytkownika | mod-limit-platnosci-gotowkowych | ✅ NOWY 2026-07-27 |
| Ustawa o CIT | Dz.U. 2026 poz. 554 t.j. — ROZBUDOWANE 2026-07-19: skorygowano błędną stawkę podatku minimalnego (było 1,5%, poprawnie 10%), dodano WHT/pay-and-refund | mod-CIT-podatek-dochodowy-prawne | ✅ OK |
| Ustawa o KAS | Dz.U. 2025 poz. 1131 t.j. — VER 2026-07-02h: nadal aktualne | mod-KAS-kontrola-celno-skarbowa | ✅ OK |
| Ordynacja podatkowa | Dz.U. 2026 poz. 622 t.j. (publ. 11.05.2026, stan prawny 21.04.2026) — VER 2026-07-13 (TRYB DZU): 622 to sam TEKST JEDNOLITY, nie nowelizacja; ⚡ część wcześniej wprowadzonych przepisów nowelizujących OP ma odroczone wejście (~IX.2026 część, do 16 mies. od ogłoszenia część) | mod-OP-ordynacja-podatkowa | ✅ OK |
| Ustawa o PIT | Dz.U. 2026 poz. 592 t.j. | mod-PIT-podatek-dochodowy-fizyczne | ✅ OK |
| Ustawa o finansach publicznych (UFP) + ustawa o NIK (art. 53-54) | Dz.U. 2025 poz. 1483 t.j. — VER 2026-07-02h: nadal aktualne (obwieszczenie 26.09.2025, liczne nowelizacje do 2026.635 bez nowego t.j.) + ⚠️ zweryfikuj t.j. ustawy o NIK | mod-UFP-finanse-publiczne-NIK-RIO | ✅ OK — ROZBUDOWANE 2026-07-21 (sekcja 11 — wystąpienie pokontrolne NIK, termin 21 dni zastrzeżeń), odpowiedź na pytanie użytkownika |
| Ustawa o VAT | Dz.U. 2025 poz. 775 t.j. — VER 2026-07-02g: nadal aktualne (obwieszczenie 21.05.2025, liczne nowelizacje do 2026.507 bez nowego t.j.) — ROZBUDOWANE 2026-07-19: VAT OSS/IOSS, procedura VAT marża (art. 120), eksport/WDT pełne warunki | mod-VAT-podatek-od-towarow-i-uslug | ✅ OK |
| Ustawa VAT art. 86a (samochody 50%/100%) + ustawa PIT art. 12 ust. 2a-2c (ryczałt użytek prywatny) + art. 22 PIT/15 CIT (KUP ogólne zasady) | Dz.U. 2025 poz. 775 t.j. (VAT) + ⚠️ zweryfikuj t.j. PIT/CIT na ISAP | mod-odliczenia-uzytek-mieszany-firma-prywatny-KUP | ✅ NOWY 2026-07-21, odpowiedź na audyt kompletności prawa podatkowego |
| Ustawa o nadzorze KNF | Dz.U. 2025 poz. 640 t.j. ✅ VER 2026-07-04 (audyt WARN-KNF): isap.sejm.gov.pl WDU20250000640 — obwieszczenie Marszałka Sejmu z 10.04.2025, jednolity tekst ustawy z 21.07.2006 r. o nadzorze nad rynkiem finansowym, zastępujący poprzedni t.j. Dz.U. 2024 poz. 135 (NIE 136, NIE 724 — oba te numery były błędne w poprzednich wersjach mapy) | mod-prawo-bankowe-KNF-BFG | ✅ OK |
| Ustawa AML | Dz.U. 2025 poz. 644 t.j. — VER 2026-07-02g: nadal aktualne (obwieszczenie 9.05.2025) | mod-ustawa-AML-instytucje-obowiazkowe | ✅ OK |
| Ustawa o PCC | Dz.U. 2026 poz. 191 t.j. — VER 2026-07-02h: nadal aktualne (obwieszczenie 17.02.2026) | mod-ustawa-PCC-i-podatek-spadkow-darowizn | ✅ OK |
| Ustawa akcyzowa | Dz.U. 2025 poz. 126 t.j. ✅ VER 2026-07-04 (audyt-DR06 — było "NIEZWERYFIKOWANE"): isap WDU20250000126, obwieszczenie Marszałka Sejmu 23.12.2024; potwierdzone niezależnie (infor.pl, dziennikustaw.gov.pl, MF podatki-arch.mf.gov.pl), ze zm. do 2025.340 bez nowego t.j. | mod-ustawa-akcyzowa-i-clo-UCC | ✅ ROZBUDOWANE 2026-07-15 (część 4/6 sesji dr-03) — dodano sekcję 4a: rozróżnienie art. 86 (przemyt) vs art. 87 (oszustwo celne) KKS, mechanizm WIT/WIS/WIA, zbieg z art. 286 KK — wcześniej "błędna klasyfikacja CN" było jednym wyrazem bez treści |
| Ustawa o wychowaniu w trzeźwości i przeciwdziałaniu alkoholizmowi (26.10.1982) + ustawa o ochronie zdrowia przed następstwami używania tytoniu (9.11.1995, nowelizacja 5.07.2025) + ustawa o wyrobie alkoholu etylowego (2.03.2001, art. 12a — bimbrownictwo) | Dz.U. 2023 poz. 2151 t.j. (alkohol-sprzedaż) + Dz.U. 2024 poz. 1162 t.j. (tytoń) + ⚠️ zweryfikuj t.j. ustawy z 2001 r. | mod-alkohol-tyton-regulacja-sprzedazy | ✅ ROZBUDOWANE 2026-07-20 (Część C — bimbrownictwo + sekcja DO MONITOROWANIA: 4 konkurencyjne projekty zmian ustawy alkoholowej, żaden jeszcze nieuchwalony) |
| Kodeks celny UE (UCC) + Taryfa celna (CN) | Rozp. (UE) 952/2013 + Rozp. (EWG) 2658/87 | mod-UCC-clo-taryfa-celna | ✅ OK |
| Rozporządzenie UE 2018/1672 (kontrola środków pieniężnych) + Prawo dewizowe (2002) + zwolnienia celne dla podróżnych + Konwencja CITES | Rozp. UE 2018/1672 + Dz.U. 2024 poz. 1131 (Prawo dewizowe) + ⚠️ zweryfikuj pozostałe | mod-clo-podroznych-limity-towary-zabronione | ✅ NOWY 2026-07-19, odpowiedź na pytanie użytkownika |
| Ustawa o podatkach i opłatach lokalnych | Dz.U. 2025 poz. 707 t.j. (reforma od 01.01.2025) — VER 2026-07-02h: nadal aktualne (obwieszczenie 21.05.2025) | mod-ustawa-podatek-nieruchomosci-i-lokalne | ✅ OK |
| Ustawa o ryczałcie od przychodów | Dz.U. 2025 poz. 843 t.j. — ROZBUDOWANE 2026-07-19: logika decyzyjna ryczałt vs skala/liniowy, zwolnienia PIT art. 21 | mod-ustawa-ryczalt-przychody | ✅ OK |
| Ustawa VAT (klasyfikacja produktów, PKWiU/CN, status wyrobu medycznego) | Dz.U. 2025 poz. 775 t.j. + rozporządzenie MDR 2017/745 + ustawa o wyrobach medycznych | mod-VAT-klasyfikacja-produktow-baza-niejednoznacznosci | ✅ NOWY 2026-07-19, odpowiedź na pytanie użytkownika |
| Ustawa o obligacjach | ⚠️ Dz.U. 2024 poz. 708 t.j. (POPRAWKA 2026-07-02g — BYŁO błędnie 2022.2218, nieaktualne od kwietnia 2024) | mod-ustawa-rynek-kapitalowy-fundusze | ⚠️ WYMAGA AKTUALIZACJI MODUŁU |
| Ustawa o usługach płatniczych | Dz.U. 2025 poz. 611 t.j. | mod-ustawa-uslugi-platnicze | ✅ OK |

| Interpretacje indywidualne i ogólne (Op art. 14a–14p), MDR (art. 86a–86o), WIS, objaśnienia MF | ⚠️ Op Dz.U. 2026 poz. 622 t.j. (POPRAWKA 2026-07-02g — BYŁO błędnie 2025 poz. 111, niespójne z wierszem Ordynacji podatkowej powyżej w tej samej tabeli, już poprawnie zaktualizowanym do 2026.622 w sesji 2026-07-02c) + EUREKA (podatki.gov.pl) | mod-interpretacje-definicje-podatkowe | ✅ OK (po korekcie) |
| PKWiU 2025 (Rozp. RM 17.12.2025) — harmonogram VAT/PIT/CIT/ryczałt | Dz.U. 2025 (Rozp. RM) + PKWiU 2015 do 31.12.2027 (VAT), 31.12.2028 (PIT/CIT) | mod-interpretacje-definicje-podatkowe | ✅ OK |
| Uchwały NSA (II FPS 1/21 najem; III FPS 2/24 PON wynajem) | orzeczenia.nsa.gov.pl | mod-interpretacje-definicje-podatkowe | ✅ OK |
| Ustawa o biegłych rewidentach, firmach audytorskich oraz nadzorze publicznym (zawód, zawód zaufania publicznego) | Dz.U. 2025 poz. 1891 t.j. ✅ VER: 2026-06-14 | mod-ustawa-biegli-rewidenci-zawod | ✅ NOWY |
| Ustawa o doradztwie podatkowym (zawód, zawód zaufania publicznego) | Dz.U. 2021 poz. 2117 (ostatni potwierdzony t.j.) + zm. do 2025.1882 i 2026.176 (POTWIERDZONE 2026-07-02g — brak nowszego t.j. mimo dużej nowelizacji wchodzącej w życie 1.03.2026; monitorować, t.j. może się pojawić wkrótce) | mod-ustawa-doradcy-podatkowi-zawod | ✅ OK (t.j. nadal aktualny) |
| Podatki sektorowe: ustawa o podatku od niektórych instytucji finansowych (2016) + ustawa o grach hazardowych (2009, Rozdział 7) + ustawa o podatku tonażowym (2006) + opłata cukrowa (ustawa o zdrowiu publicznym) + ustawa o podatku od sprzedaży detalicznej (2016) | Dz.U. 2016 poz. 68 (bankowy) + ⚠️ zweryfikuj t.j. pozostałych 4 ustaw na ISAP | mod-podatki-sektorowe-bankowy-gry-tonazowy-cukrowy-detaliczny | ✅ NOWY 2026-07-19, odpowiedź na audyt pokrycia prawa podatkowego — Część A (bankowy) w pełni opracowana, Części B-E oznaczone jako punkt startowy |

| Ustawa ESAP — o zmianie niektórych ustaw w związku z przekazywaniem informacji do europejskiego pojedynczego punktu dostępu (17.04.2026, wdraża pakiet UE ESAP: rozp. 2023/2859, dyr. 2023/2864, rozp. 2023/2869) | Dz.U. 2026 poz. 644 (podpisana 11.05.2026, publikacja 14.05.2026) ✅ VER: 2026-07-07 (naprawa WARN-24) | brak modułu | ⏳ OCZEKUJE — omnibus dot. ~17 ustaw sektora finansowego (rachunkowość, KRS, fundusze emerytalne, Prawo bankowe, listy zastawne, KSH, fundusze inwestycyjne, oferta publiczna, obrót instrumentami finansowymi, nadzór KNF, ubezpieczenia, BFG, biegli rewidenci); brak modułu dedykowanego w systemie — do rozważenia przy przyszłej sesji, jeśli sprawy z zakresu rynku kapitałowego/nadzoru finansowego staną się aktywne |
| ⚠️ FAKT NEGATYWNY (dodano 2026-07-30) — Ustawa z 3.07.2026 o podatku od nadzwyczajnych zysków ze zbycia paliw ciekłych (windfall tax, 60%, druk 2684) | ❌ NIE WESZŁA W ŻYCIE — Prezydent SKIEROWAŁ do Trybunału Konstytucyjnego w trybie KONTROLI PREWENCYJNEJ (24.07.2026), zarzucając naruszenie zasady lex retro non agit (próba opodatkowania z mocą wsteczną od marca 2026) — VER 2026-07-30 | brak modułu (podatek nie obowiązuje) | ⚠️ WAŻNE dla odpowiedzi klientom z branży paliwowej: TEN podatek OBECNIE NIE ISTNIEJE w polskim porządku prawnym, mimo szerokiego medialnego rozgłosu — sprawdź status TK przed jakąkolwiek poradą |
| ⚠️ FAKT NEGATYWNY (dodano 2026-07-30) — Ustawa z 15.05.2026 o zmianie ustawy o podatku akcyzowym (druk 2457) | ❌ NIE WESZŁA W ŻYCIE — Prezydent SKIEROWAŁ do TK w trybie kontroli prewencyjnej (2.07.2026), krytykując "legislacyjny chaos" (MF opublikowało kolejny, odmienny projekt 2 dni przed uchwaleniem tej ustawy) — VER 2026-07-30 | mod-ustawa-akcyzowa-i-clo-UCC (POWIĄZANIE ze skrajną zmiennością stawek akcyzowych odnotowaną w transzy 27z87 tej samej sesji) | ⚠️ Ta konkretna nowelizacja NIE obowiązuje — sprawdź, czy inna, nowsza wersja zmian akcyzowych nie została uchwalona w międzyczasie |

> Źródło weryfikacji: isap.sejm.gov.pl | podatki.gov.pl | orzeczenia.nsa.gov.pl
> Aktualizacja: 2026-07-02h (TRYB DZU krok 2/16 wg WARN-26, DOKOŃCZONY: 15/16
> pozycji zweryfikowane. 4 błędy CRIT naprawione: obligacje, interpretacje
> podatkowe (niespójność wewn.), nadzór KNF (całkowicie błędny numer Dz.U.).
> Nadal niezweryfikowane: akcyza (1 pozycja) — do domknięcia przy okazji)
>
> **Sesja katalogowania 2026-07-04:** ostatnia pozycja (akcyza) zweryfikowana
> i potwierdzona jako poprawna (2025.126). DR-06 ma teraz 0 pozycji
> niezweryfikowanych — pozostają 2 flagi "WYMAGA AKTUALIZACJI MODUŁU"
> (obligacje, interpretacje podatkowe) dotyczące treści modułu, nie numeru
> Dz.U. DR-06 W PEŁNI SKATALOGOWANA.
>
> **Sesja 2026-07-07 (naprawa WARN-24):** dodano ustawę ESAP (Dz.U. 2026.644),
> błędnie zakładaną wcześniej za "nowelizację KSH" — ustalono rzeczywisty,
> znacznie szerszy zakres (omnibus ~17 ustaw finansowych, KSH dotknięty tylko
> incydentalnie). Skatalogowana, bez modułu dedykowanego (niska aktywność
> tematyczna w typowych sprawach obsługiwanych przez system).
