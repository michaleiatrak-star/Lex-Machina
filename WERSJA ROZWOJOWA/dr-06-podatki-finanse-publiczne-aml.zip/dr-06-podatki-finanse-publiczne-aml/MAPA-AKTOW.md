# DR-06 — Lokalna Mapa Aktów Prawnych

## Podatki, finanse publiczne, AML

Mapa runtime zawiera wyłącznie bieżące przypisanie **akt / zakres → moduł**. Historia napraw, poprzednie numery, iteracje pokrycia i fakty negatywne pozostają poza runtime.

| Akt / zakres | Bieżąca podstawa | Moduł / routing | Status runtime |
|---|---|---|---|
| Ordynacja podatkowa | Dz.U. 2026 poz. 622 t.j. ze zm. | `mod-OP-ordynacja-podatkowa` + rodzina modułów OP | 🟢 aktywny; fresh gate |
| OP — pozostałe działy / pokrycie przekrojowe | jw. | `mod-OP-uzupelnienie-pokrycia-2026` | 🟡 B |
| OP — dowody w postępowaniu podatkowym | jw. | `mod-OP-dzial-IV-rozdzial-11-dowody` | ✅ aktywny |
| OP — kontrola podatkowa | jw. | `mod-OP-kontrola-podatkowa-dzial-VI` | ✅ aktywny |
| OP — ulgi w spłacie zobowiązań | jw. | `mod-OP-ulgi-w-splacie-dzial-III-rozdzial-7a` | ✅ aktywny |
| OP — czynności sprawdzające | jw. | `mod-OP-czynnosci-sprawdzajace-dzial-V` | ✅ aktywny |
| Interpretacje podatkowe / MDR / objaśnienia MF | OP jw. + właściwe akty wykonawcze | `mod-interpretacje-definicje-podatkowe` | ✅ aktywny; fresh gate |
| Ustawa o PIT — dochody osób fizycznych, w tym odpłatne zbycie (sprzedaż) mieszkania lub innej nieruchomości | Dz.U. 2026 poz. 592 t.j. ze zm.; m.in. **2026/1287** art. 12 — art. 52zu (podatek od nadzwyczajnych zysków nie jest KUP) od 1.11.2026; **2026/1347** art. 2 — uchylona lit. b w art. 14 ust. 2 pkt 14 od 1.12.2026 ✅ [VER] RZĄD 1 2026-10-20 (ELI DU/2026/1347 i 1348: metadane, `references`, 1347 text.pdf art. 1–6 i 41); **2026/1354** art. 2 — art. 14 ust. 2 pkt 10 lit. a (wynagrodzenie płatnika/inkasenta za terminowe wpłacanie podatków i opłat na rzecz budżetu państwa i JST) od 1.01.2027 ✅ [VER: ELI DU/2026/1354 text.pdf, RZĄD 1, 2026-10-20] | `mod-PIT-podatek-dochodowy-fizyczne` | ✅ aktywny |
| Ustawa o CIT | Dz.U. 2026 poz. 554 t.j. ze zm.: 2026/779 (od 1.07.2026), 2026/912 art. 67 (art. 17 ust. 1 pkt 4g, od 31.07.2026), 2026/846 (od 1.10.2026), 2026/1287 art. 13 (art. 38zb, od 1.11.2026), 2026/1371 (od 5.11.2026); ⏳ 2026/1123 (od 1.01.2028) ✅ [VER] ELI 2026-11-11 | `mod-CIT-podatek-dochodowy-prawne` | ✅ aktywny |
| Ustawa o VAT | **Dz.U. 2026 poz. 1263 t.j.** ✅ [VER] RZĄD 1 2026-10-09 (ELI, obwieszczenie odczytane) — obwieszczenie z 1.09.2026 (ogł. 28.09.2026), stan prawny na 26.08.2026; obejmuje nowelizacje 2025 poz. 894, 896, 1203, 1541, 1811 oraz 2026 poz. 507 i 846. ⛔ 2026/507 art. 6 (art. 96 ust. 3e–3f — spółka cywilna w CEIDG) wchodzi w życie dopiero 1.11.2028 (art. 31 pkt 4; ✅ [VER] RZĄD 1 2026-10-15) — t.j. zawiera już to brzmienie, do tej daty NIE stosować. ⏳ Po t.j.: Dz.U. 2026 poz. 1270 (od 1.01.2027; art. 1 pkt 13 lit. b od 1.12.2026; dalsze części 1.07.2027, 1.01.2028, 1.07.2028) ✅ [VER] RZĄD 1 2026-10-09. Materia wyjątkowo ruchliwa: brzmienie każdego powoływanego artykułu czytać u źródła | `mod-VAT-podatek-od-towarow-i-uslug` + rodzina modułów VAT | 🟢 aktywny; fresh gate |
| Rozporządzenie MF w sprawie obniżonych stawek VAT (stawki 0%/8%, przepisy epizodyczne dla paliw § 11a–11c) | Dz.U. 2023 poz. 2670 ze zm. — 13 nowelizacji wg ELI (2024/387, 1381, 1399, 1944; 2025/1253; 2026/417, 418, 573, 642, 699, 771, 1095, 1288); ostatnia: **2026/1288** — § 11c, 8% dla benzyn, olejów napędowych i biokomponentów od 3.10.2026 do 31.12.2026 ✅ [VER: ELI DU/2023/2670 `references`, DU/2026/1288 text.pdf, RZĄD 1, 2026-10-20] | `vat-podatek-od-towarow-i-uslug/part-01-core-intake-stawki` (sekcja 3, A2) | ✅ aktywny; ⛔ stawki tylko procedurą z sekcji 3, nigdy z tabeli |
| VAT — import towarów i zwolnienia importowe | jw. + właściwe akty wykonawcze | `mod-VAT-import-towarow-i-zwolnienia-importowe` | ✅ aktywny |
| VAT — WIS | jw. | `mod-VAT-WIS-tryb-i-ochrona` | ✅ aktywny |
| VAT — kursy walut / rachunek VAT / TAX FREE | jw. | `mod-VAT-kursy-walut-rachunek-VAT-tax-free` | ✅ aktywny |
| VAT — rejestracja / zapłata / metoda kasowa / likwidacja | jw. | `mod-VAT-rejestracja-zaplata-metoda-kasowa-likwidacja` | ✅ aktywny |
| VAT — płatnicy / egzekucja / kasy / transakcje trójstronne | jw. | `mod-VAT-platnicy-egzekucja-kasy-trojstronne` | ✅ aktywny |
| VAT — transakcje i fakturowanie | jw. | `mod-VAT-transakcje-fakturowanie` | ✅ aktywny |
| VAT — miejsce świadczenia i zwolnienia | jw. | `mod-VAT-miejsce-swiadczenia-zwolnienia` | ✅ aktywny |
| VAT — obowiązek podatkowy / podstawa / nieruchomości | jw. | `mod-VAT-obowiazek-podstawa-zwolnienia-nieruchomosci` | ✅ aktywny |
| VAT — sankcje / bony / odliczenia | jw. | `mod-VAT-sankcje-bony-odliczenia` | ✅ aktywny |
| VAT — ewidencja / deklaracje / zwrot | aktualne brzmienie VAT i właściwych aktów wykonawczych na dzień obowiązku | `mod-VAT-ewidencja-deklaracje` | ✅ aktywny; temporal gate |
| VAT — klasyfikacja produktów / PKWiU / CN / WIS | jw. + właściwe klasyfikacje i akty UE | `mod-VAT-klasyfikacja-produktow-baza-niejednoznacznosci` | ✅ aktywny; fresh gate |
| VAT / PIT / CIT — użytek mieszany i koszty samochodowe | właściwe bieżące przepisy VAT/PIT/CIT | `mod-odliczenia-uzytek-mieszany-firma-prywatny-KUP` | ✅ aktywny; fresh gate |
| Ustawa o Krajowej Administracji Skarbowej | Dz.U. 2026 poz. 1492 t.j. (obejmuje zm. 2026/1281 art. 9 — kontrola operacyjna: art. 118, 122 ust. 4, 123, w mocy 31.10.2026) | `mod-KAS-kontrola-celno-skarbowa` | ✅ aktywny |
| Kodeks karny skarbowy — routing podatkowo-karny | Dz.U. 2025 poz. 633 t.j. ze zm. | DR-03 `mod-KKS-karny-skarbowy-i-AML.md` | 🟢 B+/COV |
| Ustawa o finansach publicznych | Dz.U. 2026 poz. 1447 t.j. | `mod-UFP-finanse-publiczne-NIK-RIO` | ✅ aktywny; ELI 2026-11-11 |
| Prawo przedsiębiorców — limit płatności gotówkowych | Dz.U. 2026 poz. 1484 t.j. ze zm. | `mod-limit-platnosci-gotowkowych` + DR-02 `mod-Prawo-przedsiebiorcow-current-state-COV.md` | 🟢 B+/COV |
| Ustawa AML | Dz.U. 2025 poz. 644 t.j. ze zm. | `mod-ustawa-AML-instytucje-obowiazkowe` | ✅ aktywny |
| Ustawa o podatku od czynności cywilnoprawnych (PCC) + ustawa o podatku od spadków i darowizn | PCC: Dz.U. 2026 poz. 191 t.j. ze zm.; ⚡ **2026/1354** art. 3 — art. 9 pkt 6: próg zwolnienia sprzedaży rzeczy ruchomych 1000 → 3000 zł od 3.11.2026 (czynności sprzed tej daty — próg 1000 zł, art. 10) ✅ [VER: ELI DU/2026/1354 text.pdf, RZĄD 1, 2026-10-20] | `mod-ustawa-PCC-i-podatek-spadkow-darowizn` | ✅ aktywny |
| Ustawa o podatku akcyzowym | Dz.U. 2026 poz. 412 t.j. ze zm. | `mod-ustawa-akcyzowa-i-clo-UCC` | ✅ aktywny; fresh gate |
| Unijny kodeks celny (UCC) / taryfa celna | rozporządzenie (UE) nr 952/2013 + właściwa nomenklatura CN | `mod-UCC-clo-taryfa-celna` | ✅ aktywny; EUR-Lex fresh gate |
| Kontrola środków pieniężnych / prawo dewizowe / podróżni | rozporządzenie (UE) 2018/1672 + Dz.U. 2024 poz. 1131 t.j. ze zm. + akty właściwe | `mod-clo-podroznych-limity-towary-zabronione` | ✅ aktywny; fresh gate |
| Ustawa o podatkach i opłatach lokalnych — podatek od nieruchomości / opłata miejscowa / opłata uzdrowiskowa / opłata targowa | Dz.U. 2025 poz. 707 t.j. ze zm.; ⚡ zm. po t.j.: **Dz.U. 2026 poz. 1354** (ustawa z 18.09.2026, ogł. 19.10.2026; art. 1 — nowy art. 17 u.p.o.l., opłata miejscowa i uzdrowiskowa — od 1.01.2027; art. 3 — PCC art. 9 pkt 6, próg 3000 zł — od 3.11.2026) ✅ [VER: ELI DU/2026/1354 text.pdf, RZĄD 1, 2026-10-20] | `mod-ustawa-podatek-nieruchomosci-i-lokalne` | ✅ aktywny |
| Ustawa o opłacie skarbowej | Dz.U. 2026 poz. 1395 t.j. (✅ RZĄD 1 2026-10-31) | `mod-ustawa-oplata-skarbowa` | ✅ aktywny (od 2026-09-16) |
| Ustawa o podatku od wydobycia niektórych kopalin | Dz.U. 2026 poz. 454 t.j. (✅ RZĄD 1 2026-09-16) | `mod-ustawa-podatek-wydobycie-kopalin` | ✅ aktywny (od 2026-09-16) |
| Ustawa o ryczałcie od przychodów ewidencjonowanych | Dz.U. 2025 poz. 843 t.j. ze zm. | `mod-ustawa-ryczalt-przychody` | ✅ aktywny |
| Ustawa o nadzorze nad rynkiem finansowym | Dz.U. 2026 poz. 935 t.j. ze zm. | `mod-prawo-bankowe-KNF-BFG` | ✅ aktywny |
| Ustawa o obligacjach | Dz.U. 2025 poz. 1667 t.j. ze zm. | `mod-ustawa-rynek-kapitalowy-fundusze` | ✅ aktywny |
| Ustawa o usługach płatniczych | Dz.U. 2026 poz. 623 t.j. ze zm. | `mod-ustawa-uslugi-platnicze` | ✅ aktywny |
| Ustawa o rachunkowości | Dz.U. 2026 poz. 522 t.j. ze zm. | `mod-ustawa-rachunkowosci` | 🟢/🟡 aktywny |
| Biegli rewidenci i nadzór publiczny | Dz.U. 2025 poz. 1891 t.j. ze zm. | `mod-ustawa-biegli-rewidenci-zawod` | ✅ aktywny |
| Doradztwo podatkowe | Dz.U. 2026 poz. 1274 t.j. ze zm. | `mod-ustawa-doradcy-podatkowi-zawod` | ✅ aktywny; fresh gate |
| PKPiR / ewidencje uproszczone | właściwe akty wykonawcze obowiązujące od 2026 r. | `mod-PKPiR-ewidencje-uproszczone` | ✅ aktywny; fresh gate |
| JPK / księgi elektroniczne / e-sprawozdania | właściwe ustawy i akty wykonawcze | `mod-JPK-ksiegi-elektroniczne-e-sprawozdania` | ✅ aktywny; temporal gate |
| Kasy rejestrujące | właściwe akty wykonawcze MF | `mod-kasy-rejestrujace-fiskalizacja` | ✅ aktywny; fresh gate |
| Rachunkowość budżetowa JSFP | Dz.U. 2026 poz. 909 t.j. | `mod-rachunkowosc-budzetowa-JSFP` | ✅ aktywny |
| PKWiU / PKOB / CN | aktualne klasyfikacje statystyczne i okresy przejściowe | `mod-PKWiU-klasyfikacje-statystyczne` | ✅ aktywny; temporal gate |
| Podatki sektorowe | akty właściwe dla podatku bankowego, gier, tonażowego, opłaty cukrowej i sprzedaży detalicznej; podatek od nadzwyczajnych zysków ze zbycia paliw ciekłych — Dz.U. 2026 poz. 1287 (w mocy 1.11.2026) | `mod-podatki-sektorowe-bankowy-gry-tonazowy-cukrowy-detaliczny` | ✅ aktywny; fresh gate |
| Regulacja alkoholu i tytoniu | właściwe ustawy sektorowe | `mod-alkohol-tyton-regulacja-sprzedazy` | ✅ aktywny; fresh gate |

## Reguły runtime

- mapa nie przechowuje historycznych iteracji audytu, dawnych błędów, wet, projektów ani innych faktów negatywnych; takie informacje należą do dziennika audytowego i monitoringu temporalnego;
- każdy fizyczny moduł DR-06 pozostaje jawnie rejestrowany w tej mapie zgodnie z `check_rejestracja_modulow.py`;
- kwoty, stawki, progi, formularze, klasyfikacje, terminy i przepisy z odroczonym wejściem w życie zawsze wymagają fresh gate do ELI/ISAP, MF albo EUR-Lex;
- `COV` oznacza bieżącą mapę struktury/routingu, nie `FULL` artykuł-po-artykule.
