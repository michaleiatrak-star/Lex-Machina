# mod-interpretacje-definicje-podatkowe

**Akt:** OP — t.j. Dz.U. 2026 poz. 622 (zm. po t.j.: 2026/1154 od 2026-09-16 — art. 299; 2026/825 od 2026-09-24 — art. 14i, 14j; 2026/846 od 2026-10-01 — art. 11j, 12, 14b, 17, 17a, 18c, 21, 23v, 52, 59, 60, 62, 62b, 63, 67a, 67d, 74, 75, 76b, 77; 2026/875 [OD 2027-01-01: 2026/875] — art. 67a; 2026/1098 [OD 2027-01-01: 2026/1098] — art. 3b, 297, 298, 299, 299c, 306; 2026/1206 [OD 2027-01-11: 2026/1206] — art. 119zg).
**Akt:** VAT (ustawa o podatku od towarów i usług) — t.j. Dz.U. 2026 poz. 1263 (zm. po t.j.: 2026/1446 [OD 2026-11-18: 2026/1446] — art. 1, 2, 33, 33a, 33b, 34, 41, 52, 138i; 2026/1270 [OD 2027-01-01: 2026/1270] — art. 2, 12, 13, 14, 15, 15a, 17, 19a, 22, 29a, 33, 33a, 37, 41, 42, 43, 45, 83, 86, 88).
**Akt:** PIT (ustawa o podatku dochodowym od osób fizycznych) — t.j. Dz.U. 2026 poz. 592 (zm. po t.j.: 2026/779 od 2026-07-01 — art. 24a; 2026/1079 od 2026-09-10 — art. 21; 2026/846 od 2026-10-01 — art. 25b, 30f, 31d; 2026/1287 od 2026-11-01 — art. 52zt, 52zu; 2026/1371 od 2026-11-05 — art. 14, 22p, 23q, 23zf; 2026/1347 [OD 2026-12-01: 2026/1347] — art. 14; 2026/1098 [OD 2027-01-01: 2026/1098] — art. 2, 45ba, 45c, 45cd, 45ce, 45cf; 2026/1354 [OD 2027-01-01: 2026/1354] — art. 14; 2026/1123 [OD 2028-01-01: 2026/1123] — art. 21, 22).
**Akt:** CIT (ustawa o podatku dochodowym od osób prawnych) — t.j. Dz.U. 2026 poz. 554 (zm. po t.j.: 2026/779 od 2026-07-01 — art. 9, 38ab; 2026/912 od 2026-07-31 — art. 17; 2026/846 od 2026-10-01 — art. 24a, 24aa, 24m; 2026/1287 od 2026-11-01 — art. 38za, 38zb; 2026/1371 od 2026-11-05 — art. 11e, 11t, 12, 15d; 2026/1123 [OD 2028-01-01: 2026/1123] — art. 15).
**Akt:** PCC (ustawa o podatku od czynności cywilnoprawnych) — t.j. Dz.U. 2026 poz. 191 (zm. po t.j.: 2026/1354 od 2026-11-03 — art. 1, 9, 17).
**Akt:** Akcyza (ustawa o podatku akcyzowym) — t.j. Dz.U. 2026 poz. 412.
**Akt:** UKAS (ustawa o Krajowej Administracji Skarbowej) — t.j. Dz.U. 2026 poz. 1492.
**Akt:** URach (ustawa o rachunkowości) — t.j. Dz.U. 2026 poz. 522 (zm. po t.j.: 2026/640 od 2026-05-28 — art. 2, 66; 2026/644 od 2026-05-29 — art. 3, 45; 2026/1206 [OD 2027-01-11: 2026/1206] — art. 3, 64, 69).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

**Status:** nowy moduł 2026-06-09 (weryfikacja online — kluczowe interpretacje i definicje)
**Zakres:** Interpretacje podatkowe (tryb, skutki, baza EUREKA), kluczowe definicje
podatkowe, uchwały NSA, interpretacje ogólne MF 2024–2025, PKWiU 2025, schematy MDR,
ulgi innowacyjne, estoński CIT — definicje precyzowane przez KIS/MF/NSA.

**Źródła (weryfikuj w ELI (RZĄD 1)/bazach przed powołaniem):**

| Akt | Dz.U./źródło | Uwaga |
|---|---|---|
| Ordynacja podatkowa (Op) | Dz.U. 2026 poz. 622 t.j. ze zm. | art. 14a–14p (interpretacje), art. 86a–86o (MDR) |
| KPA | Dz.U. 2025 poz. 1691 t.j. | tryb posiłkowy w interpretacjach (ograniczony) |
| Baza EUREKA | podatki.gov.pl/eureka | wyszukiwarka interpretacji od 04.10.2021 |
| Baza interpretacji MF | interpretacje.podatki.gov.pl | dodatkowe szukanie |

```
⛔ HARD GATE: Sygnatury interpretacji KIS (0111-xxx, 0112-xxx, 0113-xxx, 0114-xxx, 0115-xxx)
  ZAKAZ cytowania z pamięci — każda sygnatura wymaga weryfikacji w:
  → podatki.gov.pl/eureka → wyszukaj sygn. lub tematykę
  → web_search: "[sygn.] interpretacja KIS"
  → interpretacje.podatki.gov.pl
```

---

## 1. SYSTEM INTERPRETACJI PODATKOWYCH — MAPA

```
INTERPRETACJA INDYWIDUALNA (art. 14b–14p Op):
  Organ: Dyrektor Krajowej Informacji Skarbowej (Dyrektor KIS)
  Wniosek: przez ePUAP lub podatki.gov.pl
  Opłata: 40 zł za każdy stan faktyczny / zdarzenie przyszłe
  Termin na wydanie: 3 miesiące od złożenia (art. 14d Op)
    → Milczenie organu w terminie = interpretacja zgodna z wnioskiem podatnika
    → Uwaga: organ może żądać uzupełnienia — termin biegnie od uzupełnienia
  Skutek ochronny: wiąże organ podatkowy jeśli:
    → Podatnik ZASTOSOWAŁ SIĘ do niej przed wszczęciem kontroli / postępowania
    → Interpretacja była wydana dla wnioskodawcy
    → Nie zmieniono przepisów / stanu faktycznego
  Zaskarżenie: skarga do WSA — **30 DNI** od doręczenia interpretacji (art. 53 § 1 PPSA, który obejmuje wprost akty z art. 3 § 2 pkt 4a — interpretacje indywidualne; od 26.06.2026 także opinie z art. 3 § 2 pkt 4b — `Dz.U. 2026 poz. 846`) — ✅ [VER] RZĄD 1 2026-09-16m
    ⛔ KOREKTA: poprzednio „14 dni (nie 30!) — art. 53 § 3 PPSA" — błędne (§ 3 dotyczy
    prokuratora, RPO i RPD — 6 miesięcy)
  Zmiana / wygaśnięcie:
    → Organ zmienia z urzędu lub na wniosek (art. 14e Op)
    → Wygasa gdy zmieniona / uchylona przez WSA/NSA
    → NIE wygasa gdy zmiana przepisów (chroni do wejścia w życie zmian)

INTERPRETACJA OGÓLNA (art. 14a Op):
  Organ: Minister Finansów / Szef KAS
  Kiedy: niejednolite stosowanie przepisów lub potrzeba wyjaśnienia
  Wiąże: organy podatkowe (w sprawach tego rodzaju)
  Podatnik: nie może jej zaskarżyć, ale może się na nią powołać
  Baza: mf.gov.pl + podatki.gov.pl → Interpretacje ogólne

OBJAŚNIENIA PODATKOWE (art. 14la Op — od 2019):
  Organ: Minister Finansów
  Charakter: wyjaśnienia praktyczne sposobu stosowania przepisów
  Skutek ochronny: jak interpretacja ogólna + element "dobrej wiary" podatnika
  Kluczowe: Objaśnienia IP BOX z 15.07.2019 r. — fundament stosowania ulgi IP Box

OPINIA ZABEZPIECZAJĄCA (art. 119w Op):
  Organ: Szef KAS
  Cel: ochrona przed zastosowaniem GAAR do opisanej transakcji
  Termin: 6 miesięcy od złożenia wniosku
  Opłata: 25 000 zł (i więcej dla złożonych transakcji — weryfikuj)
  Warunek: czynność jeszcze nie dokonana LUB w toku
  Odmowa opinii: gdy GAAR zastosuje się (ryzyko podatkowe)

WIĄŻĄCA INFORMACJA STAWKOWA (WIS) — VAT:
  Organ: Dyrektor KIS
  Przedmiot: klasyfikacja towaru/usługi na potrzeby VAT + stawka
  Termin: 3 miesiące
  Skutek: wiąże organy podatkowe i celno-skarbowe
  Ważność: bezterminowa (aż do zmiany przepisów lub wycofania)
  Zmiana PKWiU: WIS wydane pod PKWiU 2015 zachowują ważność do 31.12.2027
    (VAT: PKWiU 2015 stosowane do końca 2027 r.) — weryfikuj

WIĄŻĄCA INFORMACJA AKCYZOWA (WIA):
  Jak WIS, ale dla akcyzy → mod-ustawa-akcyzowa-i-clo-UCC
```

---

## 2. KLUCZOWE DEFINICJE — ORZECZNICTWO NSA / INTERPRETACJE

### 2A. Definicja działalności gospodarczej — granica najem prywatny

```
⚠️ KLUCZOWE DLA: PIT (źródło przychodów), VAT (limit zwolnienia
   podmiotowego z art. 113 ust. 1 — ⭐ SPROSTOWANE 2026-08-12:
   **240 000 zł**, nie 200 000 zł; podwyżka ustawą z 24.06.2025 r.,
   Dz.U. 2025 poz. 896; szczegóły i przepisy przejściowe w
   mod-VAT-podatek-od-towarow-i-uslug.md), ryczałt

UCHWAŁA NSA II FPS 1/21 z 24.05.2021 r. (weryfikuj: orzeczenia.nsa.gov.pl):
  Teza: "Przychody z najmu, podnajmu, dzierżawy (…) są zaliczane do źródła przychodów
         (najem), CHYBA ŻE stanowią składnik majątkowy mienia osoby fizycznej, który
         został przez nią wprowadzony do majątku związanego z działalnością gospodarczą."
  Konsekwencja:
  → Brak formalnej rejestracji działalności + brak wprowadzenia do majątku firmowego
    = najem prywatny (ryczałt) niezależnie od LICZBY nieruchomości
  → Kryterium: czy nieruchomość jest w majątku firmowym (EŚT), nie rozmiar najmu

  UWAGA po 01.01.2023:
  → Najem prywatny: WYŁĄCZNIE ryczałt 8,5% / 12,5% (brak wyboru formy opodatkowania)
  → Najem w działalności: zasady ogólne / liniowy / ryczałt (jeśli w zakresie DG)

UCHWAŁA NSA III FPS 2/24 z 21.10.2024 r. — PODATEK OD NIERUCHOMOŚCI:
  Teza: Zajęcie budynku/lokalu mieszkalnego przez przedsiębiorcę na wynajem mieszkalny
        NIE oznacza automatycznie "zajęcia na prowadzenie działalności gospodarczej"
        (wyższa stawka PON) — zależy od faktycznego sposobu korzystania przez najemcę
  Konsekwencja: Wynajem mieszkań przez spółkę/przedsiębiorcę = stawka MIESZKALNA
        jeśli faktycznie służy potrzebom mieszkaniowym najemców
  Weryfikuj: orzeczenia.nsa.gov.pl → sygn. III FPS 2/24
```

### 2B. Definicja rezydenta podatkowego / miejsce zamieszkania

⭐ ODESŁANIE (dodano 2026-08-12): PEŁNA, znacznie ROZBUDOWANA treść
(z konkretnym wyrokiem NSA II FSK 2653/16, koncepcją "łamanej
rezydencji", mechanizmem rozstrzygania KONFLIKTU rezydencji między
państwami) — patrz mod-PIT-podatek-dochodowy-fizyczne.md, sekcja 1a
(osoby fizyczne) oraz mod-CIT-podatek-dochodowy-prawne.md, sekcja 1a
(osoby prawne — siedziba LUB zarząd, z DOMNIEMANIEM z art. 3 ust. 1a
CIT). PONIŻSZA treść to SKRÓCONY punkt wyjścia.

```
PODSTAWA (art. 3 ust. 1a ustawy o PIT — weryfikuj Dz.U. 2025 w ELI (RZĄD 1)):
  Rezydent = osoba mająca miejsce zamieszkania w Polsce:
  KRYTERIUM 1: Centrum interesów osobistych lub gospodarczych (ośrodek interesów życiowych) LUB
  KRYTERIUM 2: Pobyt w Polsce > 183 dni w roku podatkowym

ORZECZNICTWO KIS/NSA — kluczowe linie (weryfikuj interpretacje.podatki.gov.pl):
  → Centrum interesów: rodzina w PL, nieruchomość, konto bankowe, lekarze, znajomi
  → Centrum gospodarcze: spółka, kontrakty, dochody w PL
  → 183 dni: liczy się każdy dzień (w tym dni przyjazdu/wyjazdu)
  → UWAGA: umowy o unikaniu podwójnego opodatkowania (UPO) mogą modyfikować zasady
    → weryfikuj właściwą UPO dla kraju (baza MF: https://www.gov.pl/web/finanse/umowy-o-unikaniu-podwojnego-opodatkowania)

OBJAŚNIENIE PODATKOWE MF: interpretacja ośrodka interesów życiowych — weryfikuj bieżące
  → web_search: "ośrodek interesów życiowych rezydent podatkowy MF objaśnienie 2024 2025"
```

### 2C. Kwalifikowane prawa własności intelektualnej (IP Box — art. 30ca PIT)

```
PODSTAWA: art. 30ca–30cb ustawy o PIT + art. 24d–24e CIT + Objaśnienia IP BOX z 15.07.2019
STAWKA: 5% od dochodu z kwalifikowanego IP

DEFINICJA KWALIFIKOWANEGO IP (art. 30ca ust. 2 PIT — weryfikuj ISAP):
  Pkt 8 — AUTORSKIE PRAWO DO PROGRAMU KOMPUTEROWEGO (najczęstsze)
  Inne: patenty, wzory użytkowe, topografie układów scalonych itp.

WARUNKI (linia interpretacyjna KIS 2024–2026):
  □ Działalność B+R (badawczo-rozwojowa) — twórcza, systematyczna, wyniki niepewne
  □ Program komputerowy = utwór w rozumieniu PrAut (art. 1 ust. 2 pkt 1 PrAut)
  □ EWIDENCJA (art. 30cb PIT) — warunek sine qua non:
    → Odrębna od PKPiR ewidencja per kwalifikowane IP
    → Wyodrębnienie przychodów, kosztów, dochodu per kwalifikowane IP
    → Śledzenie kosztów (wskaźnik Nexus)
  □ Wskaźnik Nexus (art. 30ca ust. 4 PIT) = a/(a+b+c+d) gdzie:
    a = koszty własnej działalności B+R
    b = koszty B+R nabyte od powiązanych
    c = koszty nabycia wyników B+R od podmiotów niepowiązanych
    d = koszty nabycia kwalifikowanego IP

LINIA KIS 2024–2026 — KLUCZOWE USTALENIA:
  → Brak wyodrębnionego wynagrodzenia za prawa autorskie na fakturze NIE dyskwalifikuje
    IP Box, jeśli umowa stanowi o przeniesieniu praw (KIS sygn. 0115-KDWT.4011.252.2025)
  → Kluczowe: charakter twórczy i systematyczny pracy, NIE forma kontraktu
  → Działalność B+R programisty B2B: TAK, gdy innowacja w skali przedsiębiorcy
  → Podwykonawstwo dla zagranicznego klienta: TAK, gdy własna twórczość
  → Weryfikuj bieżące: web_search "IP Box programista interpretacja KIS 2024 2025 2026"
  → Baza EUREKA: szukaj "IP Box autorskie prawo do programu komputerowego"

OBJAŚNIENIA IP BOX z 15.07.2019:
  → Nadal aktualne i wiążące dla organów
  → Mf.gov.pl lub web_search: "objaśnienia podatkowe IP Box MF 15 lipca 2019"
```

### 2D. Ulga B+R (art. 26e PIT / art. 18d CIT) — definicja działalności B+R

```
DEFINICJA DZIAŁALNOŚCI B+R (art. 4a pkt 26 CIT = art. 5a pkt 38 PIT — weryfikuj ISAP):
  Działalność twórcza + systematyczna = JEDEN z rodzajów:
  (a) Badania naukowe (podstawowe / stosowane / przemysłowe)
  (b) Prace rozwojowe

KOSZTY KWALIFIKOWANE (art. 26e ust. 2 PIT — weryfikuj aktualne brzmienie):
  → Wynagrodzenia pracownicze (w części dotyczącej B+R)
  → Nabycie materiałów i surowców bezpośrednio używanych w B+R
  → Nabycie sprzętu specjalistycznego
  → Odpisy amortyzacyjne od ŚT i WNiP (w części B+R)
  → Usługi badawczo-rozwojowe od podmiotów zewnętrznych
  → Koszty uzyskania patentów, praw ochronnych

ODLICZENIE:
  → Zasada: do 200% kosztów kwalifikowanych (w 2025/2026 — weryfikuj!)
  → Małe/średnie: do 150% (weryfikuj)
  → INTERPRETACJA OGÓLNA MF dot. ulgi B+R:
    → web_search: "interpretacja ogólna MF ulga B+R objaśnienia 2024 2025 sygn"
    → Wynagrodzenia: KIS potwierdziło przychody pracownika B+R (KIS 2025)

ŁĄCZENIE IP Box + B+R: TAK (stackowanie ulg) — koszty B+R obniżają podstawę,
  a IP Box stosuje niską stawkę do dochodu z kwalifikowanego IP
```

### 2E. Estoński CIT — kluczowe definicje i interpretacje

```
INTERPRETACJA OGÓLNA MF DD8.8203.1.2023 z 25.01.2024:
  Przedmiot: przejście na estoński CIT w trakcie roku podatkowego
  Teza: Możliwe jest przejście na estoński CIT w każdym momencie roku podatkowego
        (art. 28j ust. 5 CIT) — po zamknięciu ksiąg, złożeniu zawiadomienia
        i sporządzeniu sprawozdania finansowego w ciągu 3 miesięcy.
  Weryfikuj: mf.gov.pl → Interpretacje ogólne lub web_search "DD8.8203.1.2023 MF"

INTERPRETACJA KIS 0111-KDIB2-1.4010.342.2021 z 09.06.2025:
  Przedmiot: zysk zgromadzony na kapitale zapasowym a rezygnacja z estońskiego CIT
  Teza: Rezygnacja z estońskiego CIT powoduje obowiązek zapłaty podatku CIT od dochodu
        z tytułu zysku netto, w tym zysku zgromadzonego na kapitale zapasowym
        w czasie korzystania z estońskiego CIT.
  ⚠️ Pułapka: niepodzielone zyski na kapitale zapasowym = ryzyko CIT przy rezygnacji
  Weryfikuj: web_search "0111-KDIB2-1.4010.342.2021 estoński CIT rezygnacja kapitał"

DEFINICJA UKRYTEGO ZYSKU (art. 28m ust. 3 CIT — weryfikuj ISAP):
  → "Transakcja z podmiotem powiązanym, której warunki nie są rynkowe" = dystrybucja zysku
  → Linia KIS: kara umowna płacona przez spółkę gdy pracownik pojawia się pijany
    u kontrahenta = ukryty zysk (estoński CIT) — wyrok KIS (weryfikuj)
  → Weryfikuj: web_search "ukryty zysk estoński CIT definicja interpretacja KIS 2024 2025"
```

---

## 3. SCHEMATY PODATKOWE (MDR) — DEFINICJE I KLUCZOWE INTERPRETACJE

```
PODSTAWA: art. 86a–86o Op (Dz.U. 2026 poz. 622 t.j.) + dyrektywa DAC6

DEFINICJA SCHEMATU PODATKOWEGO (art. 86a §1 Op — weryfikuj):
  Uzgodnienie spełniające kryterium głównej korzyści LUB inny szczególny wyróżnik
  → Kryterium głównej korzyści: główna lub jedna z głównych korzyści = korzyść podatkowa

KTO MA OBOWIĄZEK RAPORTOWANIA:
  → Promotor (kancelaria, doradca, bank — organizuje schemat)
  → Korzystający (podatnik stosujący schemat)
  → Wspomagający (notariusz, biegły rewident wspierający schemat)
  → Organ: Szef KAS (numer NSP po raportowaniu)

INTERPRETACJA OGÓLNA MF DTS5.8092.2.2025 z 05.03.2025 — TAJEMNICA ZAWODOWA:
  Teza: Tajemnica zawodowa doradcy podatkowego ORAZ rzecznika patentowego = ochrona
        równa adwokatowi i radcy prawnemu w zakresie MDR.
  Konsekwencja: Doradca podatkowy/rzecznik patentowy mogą powołać się na tajemnicę
    zawodową → obowiązek raportowania zastępują POWIADOMIENIEM innych uczestników.
  Weryfikuj: web_search "DTS5.8092.2.2025 tajemnica zawodowa MDR doradca podatkowy"

INTERPRETACJA OGÓLNA MF DTS5.8092.3.2025 z 29.07.2025 — PODWYŻSZENIE KAPITAŁU:
  Teza: Podwyższenie kapitału zakładowego pokryte wkładem niepieniężnym (jeśli podlega VAT)
        lub pieniężnym (jeśli PCC prawidłowo zapłacony) = NIE jest schematem podatkowym.
  WYJĄTEK: Celowe zaniżenie wartości podwyższenia vs. wniesiony wkład = może być schemat.
  Weryfikuj: web_search "DTS5.8092.3.2025 podwyższenie kapitału MDR schemat podatkowy"

INTERPRETACJA OGÓLNA MF DTS5.8092.4.2024 z 24.12.2024 — LEASING:
  Teza: Klasyczna umowa leasingu operacyjnego NIE jest schematem podatkowym.
  Weryfikuj: web_search "DTS5.8092.4.2024 leasing operacyjny schemat podatkowy"

⚡ PLANOWANE ZMIANY MDR (od 01.07.2026 — weryfikuj!):
  → Projekt ustawy z 28.03.2025 / 04.08.2025
  → Zmiany w zakresie raportowania, rozszerzenie definicji
  → web_search: "MDR zmiana przepisów 2026 projekt ustawy Ordynacja podatkowa"
```

---

## 4. KLASYFIKACJE STATYSTYCZNE — PKWiU / CN / PKOB / KŚT

> Wydzielone do osobnego modułu (2026-06-14, NOTA-4): zawartość PKWiU 2025
> przejście, PKOB, CN — patrz mod-PKWiU-klasyfikacje-statystyczne.md
> (temat przekrojowy, referencjonowany przez mod-VAT/mod-PIT/mod-CIT).

---

## 5. KLUCZOWE DEFINICJE PODATKOWE — ZESTAWIENIE

> Definicje "DZIAŁALNOŚĆ GOSPODARCZA" i "REZYDENT PODATKOWY" — kanoniczna
> wersja w prawo-polskie-v2/krajowe/shared/definicje/DEF-PODATKOWE.md (BLOK G). Poniżej tylko
> dopowiedzenie specyficzne dla interpretacji/orzecznictwa (NSA II FPS 1/21
> dla działalności gospodarczej — patrz też sekcja 2A; rezydent — patrz 2B).

```
MAŁY PODATNIK CIT/PIT (weryfikuj aktualne progi — ZMIENIAJĄ SIĘ):
  → Przychody za rok poprzedni ≤ 2 mln EUR (po kursie NBP z 01.10.)
  → Skutki: niższe zaliczki kwartalne, możliwość kasy jednorazowej, niższe stawki
  → Stawka CIT: 9% (mały podatnik) vs 19% (standardowy) — weryfikuj art. 19 CIT

PODMIOT POWIĄZANY (art. 11a CIT — weryfikuj):
  → Udział ≥ 25% w kapitale, prawach głosu, udziale w zysku LUB
  → Faktyczny wpływ na decyzje / kierownictwo wspólne
  → Istotne przy: cenach transferowych (TP), GAAR, estońskim CIT (ukryty zysk)

STAŁY ZAKŁAD (permanent establishment) dla potrzeb CIT/UPO:
  → Brak definicji w ustawie CIT → stosuje się Komentarz OECD do modelu konwencji
  → Linia KIS/NSA: praca zdalna zagranicznego pracownika w Polsce może tworzyć StZ
  → Weryfikuj: web_search "stały zakład praca zdalna nierezydent Polska 2024 2025 NSA KIS"

PRZYCHÓD Z DZIAŁALNOŚCI WYKONYWANEJ OSOBIŚCIE vs. B2B (art. 13 PIT):
  → Kryterium: umowa B2B z kontraktorem IT = działalność gosp. lub "umowa o świadczenie usług
    w warunkach art. 13 pkt 9 PIT"?
  → Linia organów: samozatrudniony wykonujący te same zadania co pracownik = ryzyko
    przekwalifikowania na stosunek pracy (art. 22 §1 KP / art. 13 pkt 9 PIT)
  → Weryfikuj: web_search "B2B przekwalifikowanie stosunek pracy KIS interpretacja 2024 2025"
```

---

## 6. BAZA EUREKA — JAK KORZYSTAĆ

```
Dostęp: https://eureka.mf.gov.pl/ (⚠️ POPRAWIONE 2026-08-12: poprzednio
  "podatki.gov.pl/eureka" — TEN adres jest NIEPRECYZYJNY, POPRAWNY,
  konsekwentnie potwierdzony URL to eureka.mf.gov.pl; zastąpiło SIP
  od 04.10.2021 r.)
⚠️ ZASTRZEŻENIE Z PRAKTYKI (potwierdzone 2026-08-12, cytat prof.
  Wojciecha Morawskiego UMK): DOŚWIADCZENI doradcy podatkowi
  ZGŁASZAJĄ trudności Z EFEKTYWNYM korzystaniem Z wyszukiwarki —
  "Eureka to bardzo POTRZEBNY system... niestety TO wszystko
  pozytywnego, CO mogę o NIM powiedzieć" — TRAKTUJ jako
  UZUPEŁNIAJĄCE, nie jedyne źródło weryfikacji

JAK WYSZUKIWAĆ:
  → Po sygnaturze: wpisz np. "0114-KDIP3-1.4011.84.2026"
  → Po tematyce: wpisz słowa kluczowe (np. "IP Box program komputerowy")
  → Po przepisie: wpisz "art. 30ca" (filtruje interpretacje dotyczące przepisu)
  → Filtry: typ dokumentu (indywidualna / ogólna / WIS), data, organ

SKRÓTY SYGNATUR KIS (format 0XXX-KDXX):
  → 0111-KD... : Bydgoszcz
  → 0112-KD... : Gdańsk (KDSL — Środkowy Lwów)
  → 0113-KD... : Katowice
  → 0114-KD... : Warszawa
  → 0115-KD... : Wrocław
  Nota: sygnatura zaczyna się od numeru urzędu i zawiera typ podatku

INTERPRETACJE OGÓLNE MF:
  → https://www.gov.pl/web/finanse/interpretacje-ogolne
  → Wydawane pod sygnaturami: "DD8.", "PT8.", "DTS5." itp.

OBJAŚNIENIA PODATKOWE:
  → https://www.gov.pl/web/finanse/objasnienia-podatkowe

AKTUALNE SZUKANIA (generuj web_search gdy sprawdzasz konkretny temat):
  web_search: "[sygn. interpretacji] interpretacja KIS treść"
  web_search: "[temat] interpretacja ogólna MF [rok]"
  web_search: "[temat] uchwała NSA [sygn.] teza"
```

---

## 7. QUALITY GATE

```
□ Sygnatura interpretacji zweryfikowana w EUREKA lub web_search (zakaz z pamięci)?
□ Interpretacja dotyczy wnioskodawcy lub stanu analogicznego?
□ Interpretacja wydana po ostatniej zmianie przepisów (nie stała się nieaktualna)?
□ Czy interpretacja ogólna MF jest aktualna (nie zmieniona/wycofana)?
□ PKWiU: która wersja ma zastosowanie dla danego podatku i roku? (2015 vs 2025)
□ Estoński CIT: czy sprawdzono ryzyko "ukrytego zysku" i konsekwencje rezygnacji?
□ IP Box: czy jest odrębna ewidencja per kwalifikowane IP (warunek konieczny)?
□ MDR: czy transakcja objęta tajemnicą zawodową (po interpretacji ogólnej DTS5.8092.2.2025)?
□ Rezydencja: czy sprawdzono kryterium centrum interesów (nie tylko 183 dni)?
```

---

## POWIĄZANIA

| Temat | Skill / Moduł |
|---|---|
| Interpretacja indywidualna — odwołanie do WSA | `dr-05-prawo-administracyjne-sadowoadministracyjne/modules/mod-KPA-postepowanie-administracyjne.md` + `pisma-procesowe-v3` |
| IP Box — ewidencja, ulga B+R | `mod-PIT-podatek-dochodowy-fizyczne` + `mod-CIT-podatek-dochodowy-prawne` |
| PKWiU i stawki VAT | `mod-VAT-podatek-od-towarow-i-uslug` |
| WIS — wiążąca informacja stawkowa | `mod-VAT-podatek-od-towarow-i-uslug` |
| MDR — schematy podatkowe | `mod-OP-ordynacja-podatkowa` |
| Estoński CIT | `mod-CIT-podatek-dochodowy-prawne` |
| Opinia zabezpieczająca (GAAR) | `mod-OP-ordynacja-podatkowa` |
| Najem prywatny vs działalność | `mod-PIT-podatek-dochodowy-fizyczne` + `dr-02/mod-J1-najem` |
| Ceny transferowe / podmiot powiązany | `mod-CIT-podatek-dochodowy-prawne` |
| Prawa autorskie / IP (kwalifikowane) | `dr-11/mod-PrAut-wlasnosc-intelektualna-IP` |
| Definicje kanoniczne: przychód, KUP, rezydent, działalność gospodarcza | `prawo-polskie-v2/krajowe/shared/definicje/DEF-PODATKOWE.md` (BLOK G) |

---

## ŹRÓDŁA ONLINE

```
podatki.gov.pl/eureka          → Baza EUREKA (interpretacje od 10.2021)
interpretacje.podatki.gov.pl   → alternatywna wyszukiwarka
mf.gov.pl → Interpretacje ogólne
mf.gov.pl → Objaśnienia podatkowe
orzeczenia.nsa.gov.pl          → Wyroki NSA i WSA (PPSA)

Kluczowe interpretacje ogólne MF (weryfikuj przez web_search przed powołaniem):
  → DTS5.8092.2.2025 (tajemnica zawodowa promotora MDR)
  → DTS5.8092.3.2025 (podwyższenie kapitału a MDR)
  → DTS5.8092.4.2024 (leasing operacyjny a MDR)
  → DD8.8203.1.2023 (przejście na estoński CIT w trakcie roku)

Kluczowe uchwały NSA (weryfikuj przez orzeczenia.nsa.gov.pl):
  → II FPS 1/21 z 24.05.2021 (najem prywatny vs działalność gospodarcza)
  → III FPS 2/24 z 21.10.2024 (podatek od nieruchomości przy wynajmie mieszkalnym przez przedsiębiorcę)

Objaśnienia podatkowe (mf.gov.pl):
  → IP BOX z 15.07.2019 (kluczowe dla stosowania IP Box)
  → Inne: web_search "objaśnienia podatkowe MF [temat] data"

PKWiU:
  → PKWiU 2015: isap.sejm.gov.pl → Dz.U. 2015 poz. 1676 (stosowane do celów VAT do 31.12.2027, PIT/CIT/ryczałt do 31.12.2028)
  → PKWiU 2025: isap.sejm.gov.pl → Dz.U. 2025 (Rozp. RM z 17.12.2025) — od 01.01.2026 (statystyka); od 01.01.2028 (VAT); od 01.01.2029 (PIT/CIT/ryczałt)
```

---
*mod-interpretacje-definicje-podatkowe.md · DR-06 · 2026-06-09*
*Podstawa: Op (Dz.U. 2026 poz. 622 t.j.) + EUREKA (podatki.gov.pl) + Uchwały NSA + Interpretacje ogólne MF*
*Weryfikuj sygnatury ZAWSZE przed powołaniem: podatki.gov.pl/eureka lub web_search*
