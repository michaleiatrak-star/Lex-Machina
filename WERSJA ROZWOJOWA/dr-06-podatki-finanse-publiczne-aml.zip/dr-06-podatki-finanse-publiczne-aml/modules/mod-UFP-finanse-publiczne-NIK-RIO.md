# mod-DE-finanse-publiczne-nik-rio-dyscyplina — Finanse publiczne, NIK, RIO i dyscyplina finansów publicznych

Status modułu: pełny moduł prawa polskiego klasy wzorcowej — analogiczny funkcjonalnie do modułów prawa pracy i prawa karnego.
Data wdrożenia: 2026-05-28
Źródło prawa: ISAP jako źródło podstawowe; LEX/Legalis pomocniczo wyłącznie przy braku bezpośredniego dostępu do aktu lub komentarza.

## 1. CORE

### Zakres
Moduł obejmuje finanse publiczne, budżety jednostek, dotacje, subwencje, środki publiczne, kontrolę NIK/RIO, odpowiedzialność za naruszenie dyscypliny finansów publicznych, gospodarkę finansową JST oraz kontrole wydatkowania środków.

### Akty i źródła kontrolne
- Ustawa o finansach publicznych — tekst ujednolicony ISAP, WDU20091571240; ISAP wskazuje aktualizację opracowania 2026-05-22.
- Ustawa o odpowiedzialności za naruszenie dyscypliny finansów publicznych — WDU20050140114; ISAP tekst ujednolicony opracowany 2025-10-31.
- Ustawa o NIK — WDU19950130059, tekst ujednolicony w ISAP.
- Ustawa o regionalnych izbach obrachunkowych — WDU19920850428, tekst ujednolicony w ISAP.
- Akty wykonawcze budżetowe i sprawozdawcze — kontrola ISAP przed użyciem.

### Zasada aktualności
Przed użyciem przepisu, podstawy prawnej, Dz.U., terminu lub cytatu należy wykonać kontrolę według:

- `shared/ISAP-AUDIT-PROTOCOL.md`,
- `shared/TEMPORAL-LAW-CHECK.md`,
- `shared/LEGAL-LIFECYCLE-MANAGEMENT.md`,
- `shared/LEGAL-QUALITY-GATE.md`.

Nie wolno rekonstruować literalnego brzmienia przepisu z pamięci modelu.

## 2. INTAKE

Ustal obowiązkowo:

1. kto jest klientem i jaki ma status procesowy lub administracyjny;
2. jaki akt, czynność, decyzja, uchwała, zaniechanie albo orzeczenie jest kwestionowane;
3. datę doręczenia, publikacji, ogłoszenia, wejścia w życie albo dokonania czynności;
4. organ właściwy i tryb kontroli;
5. czy sprawa jest materialna, proceduralna, dyscyplinarna, kontrolna, nadzorcza, konstytucyjna, europejska albo egzekucyjna;
6. czy istnieje termin zawity, prekluzja, środek zaskarżenia, skarga albo wniosek o zabezpieczenie;
7. jakie dowody istnieją, jaką mają moc i czy są kompletne;
8. jaki jest realny cel: uchylenie, zmiana, stwierdzenie naruszenia, odszkodowanie, zabezpieczenie, dostęp do akt, wstrzymanie wykonania, unieważnienie albo sankcja.

## 3. PROCEDURA

### Mapa proceduralna
- ustalenie jednostki sektora finansów publicznych i osoby odpowiedzialnej
- kontrola podstawy wydatku lub zaciągnięcia zobowiązania
- kontrola uchwał budżetowych i WPF przez RIO
- postępowanie kontrolne NIK: wystąpienie pokontrolne, zastrzeżenia, odpowiedź
- postępowanie dyscyplinarne finansów publicznych: rzecznik, komisja, odwołanie
- skarga do WSA przy aktach nadzoru lub kontroli dopuszczalnych sądowoadministracyjnie

### Warunki skuteczności
Sprawdź: właściwość organu/sądu, legitymację, termin, formę, opłatę, podpis, załączniki, pełnomocnictwo, odpisy, tryb doręczenia, żądanie, podstawę faktyczną, podstawę prawną, dowody i właściwy środek zaskarżenia.

## 4. DOWODY

### Matryca dowodowa
- uchwały budżetowe, zarządzenia, umowy, faktury, protokoły odbioru
- sprawozdania budżetowe i finansowe
- wystąpienia pokontrolne NIK/RIO
- korespondencja z organem kontroli
- dowody działania w granicach upoważnienia
- dowody braku winy, należytej staranności lub braku szkody dla finansów publicznych

### Ocena dowodów
Każdy dowód przypisz do konkretnej tezy. Oddziel fakty od ocen. Oznacz dowody bezpośrednie, pośrednie, urzędowe, prywatne, elektroniczne, eksperckie i osobowe. Wskaż luki dowodowe i sposób ich usunięcia.

## 5. STRATEGIA

### Strategia procesowa i kancelaryjna
- oddzielić naruszenie dyscypliny od zwykłej nieprawidłowości rachunkowej
- ustalić osobę odpowiedzialną i zakres kompetencji
- w zastrzeżeniach do kontroli atakować ustalenia faktyczne, metodologię i podstawę prawną
- w obronie wskazywać brak winy, brak związku z obowiązkiem, niejasność normy, działanie w zaufaniu do opinii lub uchwały
- przy dotacjach rozdzielić zwrot środków, odpowiedzialność dyscyplinarną i odpowiedzialność karną

### Kontrargumenty przeciwnika/organu
Dla każdej tezy przewidź: zarzut braku legitymacji, przekroczenia terminu, niewłaściwego trybu, braku interesu prawnego, nieudowodnienia szkody, braku związku przyczynowego, braku kompetencji organu, związania organu przepisem albo niedopuszczalności środka.

## 6. ORZECZNICTWO

Orzecznictwo dobieraj wyłącznie z realnych źródeł. Preferuj: TK, SN, NSA, TSUE, ETPC, sądy apelacyjne i WSA/SO zgodnie z właściwością dziedziny. Nie wolno tworzyć fikcyjnych sygnatur. Cytat z orzeczenia wymaga pobrania z publicznego źródła albo zweryfikowanej bazy.

## 7. RYZYKA

- ryzyko personalizacji odpowiedzialności kierownika jednostki
- ryzyko równoległości kontroli NIK/RIO/KAS/prokuratury
- ryzyko błędnego trybu zaskarżenia zaleceń pokontrolnych
- ryzyko potraktowania uchybienia formalnego jako naruszenia dyscypliny
- ryzyko terminów przedawnienia karalności dyscyplinarnej

## 8. CHECKLISTA WYJŚCIOWA

Przed wygenerowaniem pisma lub analizy odpowiedz:

- Jaki jest tryb i organ?
- Jaki jest termin?
- Jaki przepis został zweryfikowany w ISAP?
- Czy brzmienie przepisu jest aktualne na dzień czynności?
- Jakie fakty są udowodnione?
- Jakie fakty są tylko twierdzeniem?
- Jakie dowody są decydujące?
- Jakie są trzy najsilniejsze argumenty przeciwnika?
- Jakie jest największe ryzyko oddalenia, odrzucenia albo zwrotu?
- Jaka jest rekomendowana czynność procesowa?

## 9. POWIĄZANIA

- `dr-06-podatki-finanse-publiczne-aml/modules/mod-OP-ordynacja-podatkowa.md`
- `dr-06-podatki-finanse-publiczne-aml/modules/mod-OP-ordynacja-podatkowa.md`
- `dr-07-zamowienia-publiczne-fundusze-ue/modules/mod-PZP-zamowienia-publiczne-KIO.md`
- `dr-08-samorzad-terytorialny-prawo-lokalne/modules/mod-nadzor-wojewody-RIO-legalnosc-uchwal.md`

## 10. OUTPUT

Wynik pracy modułu powinien mieć strukturę: stan faktyczny → kwalifikacja prawna → tryb → terminy → dowody → zarzuty → kontrargumenty → ryzyka → strategia → wnioski → lista czynności.

---

## QUALITY GATE — LISTA KONTROLNA

Przed wygenerowaniem pisma lub analizy odpowiedz na każde pytanie:

- [ ] Jaki jest tryb i organ (NIK / RIO / postępowanie dyscyplinarne / WSA)?
- [ ] Jaki jest termin (zastrzeżenia do protokołu / odwołanie w postęp. dyscyplinarnym)?
- [ ] Jakie przepisy zastosowane — zweryfikowane w ISAP?
- [ ] Czy brzmienie przepisu jest aktualne na dzień czynności i orzekania?
- [ ] Jakie fakty są udowodnione, a jakie tylko twierdzeniami strony?
- [ ] Czy oddzielono naruszenie dyscypliny finansów publicznych od zwykłego uchybienia?
- [ ] Jakie są trzy najsilniejsze argumenty organu kontrolującego?
- [ ] Jakie jest największe ryzyko personalizacji odpowiedzialności?
- [ ] Czy zbadano ryzyko równoległości kontroli (NIK + RIO + KAS + prokuratura)?
- [ ] Jaka jest rekomendowana czynność (zastrzeżenia / zażalenie / WSA / informacja o realizacji)?

## STATUS KANCELARSKI

**Status:** moduł klasy kancelaryjnej — poziom DR-03
**Źródło weryfikacji:** UFP — **Dz.U. 2026 poz. 1447 t.j.** ✅ [VER] RZĄD 1 ELI 2026-11-11 (obwieszczenie 2.10.2026, stan na 27.09.2026; obejmuje 2021/2054 z 2025/1844, 2025/1846, 2026/426, 635, 680, 912; poprzednio t.j. 2025 poz. 1483). Zmiana istotna dla relacji z art. 242–244: art. 243 ust. 3 pkt 1a — z ograniczenia wyłączono wykupy papierów wartościowych emitowanych w związku z umową na program, projekt lub zadanie finansowane ze środków z art. 5 ust. 1 pkt 2, wraz z odsetkami i dyskontem. | Ustawa o dyscyplinie finansów publicznych — weryfikuj aktualny t.j. w ISAP | Ustawa o NIK — weryfikuj aktualny t.j. w ISAP | Ustawa o RIO — weryfikuj aktualny t.j. w ISAP
**Data weryfikacji online:** 2026-06-05

---

## ⭐⭐⭐ 11z. REGIONALNA IZBA OBRACHUNKOWA (RIO) — TREŚĆ MERYTORYCZNA
(dodane 2026-08-12, na żądanie użytkownika — TA SAMA logika co
sekcja 11 NIŻEJ: dotąd RIO było TYLKO WZMIANKOWANE przelotnie w
CAŁYM module, mimo że tytuł modułu OBIECUJE "NIK-RIO")

```
⭐⭐ ORGANIZACJA: RIO PODLEGA prezesowi RADY MINISTRÓW — organy IZBY:
  (1) KOLEGIUM izby (prezes + CZŁONKOWIE powoływani PRZEZ prezesa
  RM oraz sejmiki SAMORZĄDOWE), (2) KOMISJA orzekająca W sprawach O
  naruszenie DYSCYPLINY finansów publicznych — POSIEDZENIA kolegium
  zwoływane PRZEZ prezesa izby, NIE rzadziej niż RAZ na KWARTAŁ

⭐⭐ ZAKRES KONTROLI uchwał JST — RIO BADA uchwały organów JST W
  SPRAWACH: procedury UCHWALANIA i zmian BUDŻETU, zaciągania
  ZOBOWIĄZAŃ wpływających NA wysokość DŁUGU publicznego JST i
  udzielania POŻYCZEK, zasad i zakresu PRZYZNAWANIA dotacji,
  podatków/opłat LOKALNYCH, absolutorium

⭐ KRYTERIA kontroli: ZGODNOŚĆ Z PRAWEM + zgodność DOKUMENTACJI ze
  stanem FAKTYCZNYM — DLA zadań Z zakresu administracji RZĄDOWEJ
  (zlecone JST ustawami/porozumieniami) — DODATKOWO kryteria
  CELOWOŚCI, rzetelności I gospodarności

⭐⭐⭐ MECHANIZM NADZORCZY nad uchwałami — DWA POZIOMY reakcji:
  → NARUSZENIE ISTOTNE: izba ORZEKA o NIEWAŻNOŚCI uchwały W CAŁOŚCI
    LUB odpowiedniej CZĘŚCI
  → NARUSZENIE NIEISTOTNE: izba NIE stwierdza nieważności — TYLKO
    WSKAZUJE, że uchwałę WYDANO z naruszeniem PRAWA
  → ⭐⭐ SZCZEGÓLNY TRYB dla UCHWAŁ BUDŻETOWYCH: izba WSKAZUJE
    organowi STANOWIĄCEMU JST, NA CZYM POLEGA naruszenie prawa
    ORAZ sposób i TERMIN jego USUNIĘCIA — DOPIERO GDY
    nieprawidłowości NIE ZOSTANĄ usunięte W terminie — dalsze
    działania NADZORCZE
  → ⭐ ZAWIESZENIE terminu: WSKAZANIE nieprawidłowości ZAWIESZA bieg
    **30-DNIOWEGO** terminu Z art. 91 ustawy O samorządzie gminnym
    (analogicznie art. 79 ustawy O samorządzie powiatowym, art. 82
    ustawy O samorządzie województwa) — dotyczącego SKUTKÓW
    sprzeczności uchwał Z prawem

⭐⭐⭐ NAJMOCNIEJSZE UPRAWNIENIE ZASTĘPCZE — USTALENIE BUDŻETU PRZEZ
  IZBĘ ZAMIAST JST:
  → JEŻELI organ STANOWIĄCY JST NIE PODEJMIE uchwały budżetowej DO
    **31 STYCZNIA** roku BUDŻETOWEGO — IZBA SAMA USTALA budżet TEJ
    jednostki, W TERMINIE DO KOŃCA **LUTEGO** roku budżetowego (W
    ZAKRESIE zadań WŁASNYCH oraz ZLECONYCH)
  → ⭐ ANALOGICZNIE: izba USTALA budżet TAKŻE GDY JST NIE ZACHOWAŁA
    zasad Z art. 242-244 ustawy O finansach PUBLICZNYCH (relacja
    DOCHODY bieżące ≥ WYDATKI bieżące i POWIĄZANE ograniczenia)
  → W PRZYPADKU stwierdzenia NIEWAŻNOŚCI uchwały BUDŻETOWEJ W
    CAŁOŚCI lub CZĘŚCI — budżet (LUB jego CZĘŚĆ) dotknięty
    nieważnością USTALA kolegium IZBY
  → PRZEPISY te STOSUJE SIĘ odpowiednio DO związków JST

⭐ DZIAŁALNOŚĆ OPINIODAWCZA: RIO WYDAJE opinie DO projektu uchwały W
  sprawie wieloletniej PROGNOZY finansowej (WPF) LUB jej ZMIANY,
  przedstawionej WRAZ z projektem uchwały BUDŻETOWEJ — ZE
  SZCZEGÓLNYM uwzględnieniem PRZESTRZEGANIA przepisów DOT.
  uchwalania/wykonywania BUDŻETÓW W kolejnych LATACH — RÓWNIEŻ
  opinia W sprawie PRAWIDŁOWOŚCI planowanej KWOTY DŁUGU JST

⭐ RAPORT O STANIE GOSPODARKI FINANSOWEJ (art. 10a ustawy o RIO): NA
  PODSTAWIE wyników działalności NADZORCZEJ/kontrolnej/
  opiniodawczej — W RAZIE potrzeby WSKAZANIA powtarzających SIĘ
  nieprawidłowości LUB zagrożenia NIEWYKONANIA ustawowych zadań —
  izba PRZEDSTAWIA raport — decyzję O sporządzeniu, ZAKRES i termin
  USTALA kolegium izby uchwałą

Potwierdzone w 7+ zgodnych źródeł, w tym BEZPOŚREDNIO dosłowny
tekst ustawy o RIO (lexlege.pl, rio.gov.pl — Krajowa Rada RIO) oraz
konsekwentne, wielokrotnie POWTARZAJĄCE się cytaty NA stronach
poszczególnych, REGIONALNYCH izb (Katowice, Opole).
```

## ⭐⭐ 11. WYSTĄPIENIE POKONTROLNE NIK — TREŚĆ MERYTORYCZNA (dodane 2026-07-21)

> Sekcje 1-10 wyżej to OGÓLNY szkielet proceduralny (NAZYWAJĄCY kroki:
> "wystąpienie pokontrolne, zastrzeżenia, odpowiedź"). TU konkretna,
> merytoryczna treść tych kroków — odpowiedź na pytanie użytkownika
> czy interpretacje/prawa związane z NIK są rzeczywiście obecne w
> module, nie tylko nazwane.

### 11.1 Elementy wystąpienia pokontrolnego (art. 53 ustawy o NIK)

```
Kontroler PRZYGOTOWUJE wystąpienie pokontrolne, KTÓRE ZAWIERA:
  1) numer i TYTUŁ kontroli
  2) imię/nazwisko + stanowisko KONTROLERA, nazwę JEDNOSTKI kontrolnej,
     numer i datę UPOWAŻNIENIA do przeprowadzenia kontroli
  3) oznaczenie JEDNOSTKI kontrolowanej, jej adres, imię/nazwisko
     KIEROWNIKA
  4) ZWIĘZŁY opis USTALONEGO stanu FAKTYCZNEGO i OCENĘ kontrolowanej
     działalności — W TYM ustalone NIEPRAWIDŁOWOŚCI, ich PRZYCZYNY,
     ZAKRES i SKUTKI ORAZ osoby ZA NIE odpowiedzialne
  5) UWAGI i WNIOSKI w sprawie USUNIĘCIA stwierdzonych nieprawidłowości
  6) wzmiankę o PRZEKAZANIU informacji o zagrożeniu życia/zdrowia/mienia
     (jeśli dotyczy) oraz o PODJĘTYCH działaniach zapobiegających
  7) POUCZENIE o PRAWIE zgłoszenia ZASTRZEŻEŃ
```

### 11.2 ⭐⭐ Zastrzeżenia do wystąpienia — termin 21 dni

```
□ KIEROWNIKOWI jednostki kontrolowanej PRZYSŁUGUJE prawo ZGŁOSZENIA
  NA PIŚMIE UMOTYWOWANYCH zastrzeżeń do wystąpienia pokontrolnego, w
  TERMINIE 21 DNI od dnia JEGO PRZEKAZANIA
□ ⭐ ADRESAT zastrzeżeń ZALEŻY od RANGI podmiotu:
  □ ZWYKŁE jednostki kontrolowane → zastrzeżenia do DYREKTORA
    WŁAŚCIWEJ jednostki kontrolnej NIK (NIE do samego kontrolera)
  □ Prezes NBP, kierownicy NACZELNYCH/CENTRALNYCH organów administracji
    rządowej, kierownicy PODMIOTÓW o SZCZEGÓLNYM statusie (art. 4 ust.
    1 ustawy o NIK) → zastrzeżenia SKŁADA SIĘ do PREZESA Najwyższej
    Izby Kontroli BEZPOŚREDNIO (NIE do Kolegium NIK, jak WCZEŚNIEJ
    przed nowelizacją z 2010 r.)
□ ⭐ MOŻLIWA ODMOWA PRZYJĘCIA zastrzeżeń — gdy: zgłoszone przez OSOBĘ
  NIEUPRAWNIONĄ, PO UPŁYWIE terminu (21 dni), LUB są NIEDOPUSZCZALNE z
  mocy ustawy — na POSTANOWIENIE o odmowie przyjęcia PRZYSŁUGUJE
  ZAŻALENIE do Prezesa NIK
□ ROZPATRZENIE zastrzeżeń: przez KOMISJĘ ROZSTRZYGAJĄCĄ (skład
  3-OSOBOWY) — o TERMINIE posiedzenia ZAWIADAMIA SIĘ OBIE strony
  (kontrolującą i kontrolowaną)
□ ⭐ Przewodniczący komisji MOŻE zarządzić rozpatrzenie na POSIEDZENIU
  NIEJAWNYM, jeśli UZNA zastrzeżenia za W PEŁNI uzasadnione
□ UCHWAŁA komisji jest OSTATECZNA, DORĘCZANA WRAZ z uzasadnieniem
  zgłaszającemu — zgodnie z uchwałą DYREKTOR jednostki kontrolnej NIK
  DOKONUJE ZMIAN w wystąpieniu pokontrolnym
```

### 11.3 ⭐ Obowiązek poinformowania NIK o realizacji wniosków

```
⚠️ ODNOTOWANA ROZBIEŻNOŚĆ ŹRÓDEŁ co do DOKŁADNEGO terminu — jedno
źródło (infor.pl) wskazuje SZTYWNY termin "30 DNI od dnia DORĘCZENIA
wystąpienia pokontrolnego"; INNE źródła (w tym analiza historyczna
zmian ustawy) wskazują, że TERMIN jest USTALANY W SAMYM wystąpieniu,
NIE KRÓTSZY jednak niż 14 DNI — NIE wybrano ARBITRALNIE jednej wersji,
ZWERYFIKUJ dokładne, AKTUALNE brzmienie na ISAP przy konkretnej sprawie

□ NIEZALEŻNIE od dokładnego terminu — MECHANIZM jest JASNY: kierownik
  jednostki kontrolowanej (lub organ, KTÓREMU przekazano wystąpienie)
  jest OBOWIĄZANY poinformować NIK o SPOSOBIE wykorzystania uwag i
  WYKONANIA wniosków ORAZ o PODJĘTYCH działaniach LUB przyczynach ICH
  NIEPODJĘCIA
□ ⭐ JEŚLI zgłoszono zastrzeżenia — TERMIN na tę informację LICZY SIĘ
  DOPIERO od dnia OTRZYMANIA OSTATECZNEJ uchwały komisji/Kolegium (NIE
  od pierwotnego doręczenia wystąpienia)
```

### 11.4 Rodzaje kontroli NIK (kontekst dla oceny sprawy)

```
□ KONTROLE PLANOWE — wynikające z ROCZNEGO planu pracy (uchwalanego
  przez Kolegium NIK pod koniec roku na rok następny)
□ KONTROLE DORAŹNE — w tym:
  □ KONTROLA SPECJALNA — pilna potrzeba zbadania AKTUALNYCH zagadnień
    o SZCZEGÓLNYM znaczeniu dla funkcjonowania państwa
  □ KONTROLA ROZPOZNAWCZA — WSTĘPNE badanie PRZED kontrolą planową
  □ KONTROLA SPRAWDZAJĄCA — badanie SPOSOBU wykorzystania uwag/wniosków
    z WCZEŚNIEJSZYCH wystąpień pokontrolnych
□ Kontrole doraźne bywają WYNIKIEM SKARG i WNIOSKÓW wpływających do NIK
  (⭐ analogicznie do skarg z Działu VIII KPA, patrz `mod-KPA-
  postepowanie-administracyjne.md`, DR-05 — INNY organ, PODOBNA
  logika reagowania na zgłoszenia obywateli)
```

### 11.5 Checklist praktyczny

```
□ Czy klient jest ZWYKŁĄ jednostką czy PODMIOTEM o szczególnym statusie
  (art. 4 ust. 1 ustawy o NIK) — WPŁYWA na to, DO KOGO kierować
  zastrzeżenia (dyrektor jednostki NIK vs bezpośrednio Prezes NIK)
□ Czy TERMIN 21 DNI na zastrzeżenia jest ZACHOWANY — po UPŁYWIE organ
  NIK ODMÓWI przyjęcia (z prawem ZAŻALENIA do Prezesa NIK na SAMĄ
  odmowę)
□ Czy zastrzeżenia są NALEŻYCIE UMOTYWOWANE — atakuj USTALENIA
  faktyczne, METODOLOGIĘ kontroli, oraz PODSTAWĘ prawną
□ Czy KLIENT rozumie DOKŁADNY termin na poinformowanie NIK o realizacji
  wniosków — ZWERYFIKUJ na ISAP (odnotowana rozbieżność 14 vs 30 dni)
□ Czy sprawa dotyczy KONTROLI DORAŹNEJ (specjalnej/rozpoznawczej/
  sprawdzającej) czy PLANOWEJ — wpływa na KONTEKST oceny zasadności
```

### 11.6 Literatura i źródła (zweryfikowane online 2026-07-21)

- bip.nik.gov.pl — nowelizacja z 2010 r. (termin 21 dni, adresat
  zastrzeżeń wg rangi podmiotu, odmowa przyjęcia + zażalenie).
- arslege.pl, sip.lex.pl — pełna treść art. 53 (elementy wystąpienia
  pokontrolnego).
- nik.gov.pl (poradnik kontrolowanego) — komisja rozstrzygająca,
  rodzaje kontroli (planowa/specjalna/rozpoznawcza/sprawdzająca).
- prawo.uwb.edu.pl — kontekst ustrojowy (podległość Sejmowi, skład
  komisji rozstrzygającej).
- ksiegowosc.infor.pl — termin 30 dni na informację o realizacji
  wniosków (⚠️ możliwa rozbieżność z innymi źródłami, patrz 11.3).
