# mod-prawo-bankowe-KNF-BFG

**Akt:** OP — t.j. Dz.U. 2026 poz. 622 (zm. po t.j.: 2026/1154 od 2026-09-16 — art. 299; 2026/825 od 2026-09-24 — art. 14i, 14j; 2026/846 od 2026-10-01 — art. 11j, 12, 14b, 17, 17a, 18c, 21, 23v, 52, 59, 60, 62, 62b, 63, 67a, 67d, 74, 75, 76b, 77; 2026/875 [OD 2027-01-01: 2026/875] — art. 67a; 2026/1098 [OD 2027-01-01: 2026/1098] — art. 3b, 297, 298, 299, 299c, 306; 2026/1206 [OD 2027-01-11: 2026/1206] — art. 119zg).
**Akt:** AML (ustawa o przeciwdziałaniu praniu pieniędzy oraz finansowaniu terroryzmu) — t.j. Dz.U. 2025 poz. 644 (zm. po t.j.: 2025/1669 od 2026-06-30 — art. 72; 2026/875 [OD 2027-01-01: 2026/875] — art. 129f, 129h; 2026/1206 [OD 2027-01-11: 2026/1206] — art. 2, 89).
**Akt:** UKAS (ustawa o Krajowej Administracji Skarbowej) — t.j. Dz.U. 2026 poz. 1492.
**Akt:** o Bankowym Funduszu Gwarancyjnym, systemie gwarantowania depozytów oraz przymusowej restru — t.j. Dz.U. 2026 poz. 620 (zm. po t.j.: 2026/1206 od 2026-09-29 — art. 2, 98, 99a; 2026/644 [OD 2030-01-10: 2026/644] — art. 2, 99a, 99b, 109, 113, 154a, 154b, 339).
**Akt:** o nadzorze nad rynkiem finansowym — t.j. Dz.U. 2026 poz. 935 (zm. po t.j.: 2026/1206 od 2026-09-29 — art. 2, 6b, 8, 9, 9a, 10, 12, 14, 14a, 15, 15a, 17ca, 17g, 19c, 20; 2026/1003 od 2026-10-28 — art. 17g, 17h; 2026/1098 [OD 2027-01-01: 2026/1098] — art. 1, 6, 6b).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

**Status:** moduł klasy kancelaryjnej — poziom DR-03
**Źródło weryfikacji:** Prawo bankowe — **Dz.U. 2026 poz. 38 t.j.** (nowelizacje 2025: poz. 1170, 1191) ✅ VER: 2026-06-05 | KNF — Dz.U. 2026 poz. 935 t.j. | BFG — Dz.U. 2026 poz. 620 t.j.
**Zasada:** Każde brzmienie przepisu przed powołaniem → isap.sejm.gov.pl

---

## 1. CORE

### Zakres
Prawo bankowe (czynności bankowe, tajemnica bankowa, kredyty, gwarancje), nadzór KNF (licencje, sankcje, lista ostrzeżeń), BFG (gwarancja depozytów do 100 000 EUR, resolution), gry hazardowe (KAS jako organ nadzoru).

### Akty

| Akt | Dz.U. | Uwaga |
|---|---|---|
| Prawo bankowe | Dz.U. 2026 poz. 38 t.j. | Poprzedni t.j.: Dz.U. 2024 poz. 1646; zm. 2025: poz. 1170, 1191 |
| Ustawa o nadzorze nad rynkiem finansowym | Dz.U. 2026 poz. 935 t.j. | |
| Ustawa o BFG | Dz.U. 2026 poz. 620 t.j. | |
| Ustawa o grach hazardowych | Dz.U. 2025 poz. 595 t.j. ze zm. | KAS jako organ nadzoru |

---

## 2. PRAWO BANKOWE — ZASADY ABSOLUTNE

```
Czynności bankowe zastrzeżone (art. 5 PrBank):
  → Tylko bank może przyjmować depozyty / udzielać kredytów bankowych
  → Naruszenie → odpowiedzialność karna (art. 171 PrBank)

Tajemnica bankowa (art. 104 PrBank):
  → Ujawnienie tylko na podstawie przepisów ustawy (US, prokurator, sąd, KNF, ABW, UIF)
  → Ujawnienie bez podstawy = przestępstwo

Fundusz Gwarancyjny BFG:
  → Gwarancja do 100 000 EUR na jedną osobę / jeden bank
  → Małżonkowie: każdy osobno do 100 000 EUR
  → Termin wypłaty: 7 dni roboczych
  → Specjalne: do 200 000 EUR przez 3 miesiące (sprzedaż nieruchomości, odprawa)
  → ⚠️ Weryfikuj aktualne kwoty w ustawie o BFG
```

---

## 3. NOWELIZACJE PRAWA BANKOWEGO 2025

```
Dz.U. 2025 poz. 1170 i poz. 1191 (ustawa z 25.07.2025) — OBOWIĄZUJĄ:
  → Obowiązek zgody KNF na powołanie członków zarządu dużych banków
  → Limity kadencji i zakaz "drzwi obrotowych" dla byłych urzędników KNF
  → Nowe wymogi ESG (ryzyko środowiskowe, społeczne, ładu korporacyjnego)
  → Reżim dla zagranicznych instytucji z państw trzecich (obowiązek oddziału + zezwolenie KNF)
⚠️ Weryfikuj aktualne przepisy w Dz.U. 2026 poz. 38 t.j. w ELI (RZĄD 1).
```

---

## 4. NADZÓR KNF — ZAKRES I UPRAWNIENIA

```
Nadzoruje:
  Banki i SKOK-i
  Zakłady ubezpieczeń i reasekuracji
  Fundusze inwestycyjne i emerytalne (OFE, PPK, PPE)
  Domy maklerskie i GPW
  Instytucje płatnicze
  Dostawcy kryptoaktywów (CASP — po wdrożeniu MiCA)

Uprawnienia KNF:
  □ Wydawanie zezwoleń na działalność regulowaną
  □ Kontrole na miejscu i zdalnie
  □ Cofnięcie zezwolenia, kara pieniężna, zakaz działalności
  □ Publikacja listy ostrzeżeń (podmioty bez licencji / fraud)
  □ Zgoda na powołanie zarządu dużych banków (od 2025 r.)

Rejestr i lista ostrzeżeń: https://knf.gov.pl
```

---

## 5. RESOLUTION — PRZYMUSOWA RESTRUKTURYZACJA (BFG)

```
Przesłanki resolution:
  □ Bank grozi upadłością + brak środków prywatnych + interes publiczny

Narzędzia:
  1. Sprzedaż przedsiębiorstwa bankowego (tzw. bank bridge)
  2. Instytucja pomostowa
  3. Wydzielenie aktywów (bad bank)
  4. Umorzenie lub konwersja zobowiązań (bail-in) → akcjonariusze i wierzyciele ponoszą koszty

Organ resolution: BFG
```

---

## 6. GWARANCJA DEPOZYTÓW — TABELA

| Rodzaj | Kwota gwarancji | Termin wypłaty |
|---|---|---|
| Standardowy depozyt | do 100 000 EUR | 7 dni roboczych |
| Po sprzedaży nieruchomości | do 200 000 EUR przez 3 miesiące | 7 dni roboczych |
| Po odprawie pracowniczej | do 200 000 EUR przez 3 miesiące | 7 dni roboczych |

⭐ TERMIN PRZEDAWNIENIA roszczeń deponenta (dodano 2026-08-12, na
żądanie użytkownika — brakujący dotąd element): roszczenia
DEPONENTA z TYTUŁU gwarancji PRZEDAWNIAJĄ SIĘ po upływie **5 LAT**
OD dnia SPEŁNIENIA warunku GWARANCJI — potwierdzone bezpośrednio
gov.pl/finanse (Rząd 1)

⚠️⚠️ ŚWIEŻA, dotąd NIEUWZGLĘDNIONA dyrektywa UE (dodano 2026-08-12):
NOWA dyrektywa Parlamentu Europejskiego i Rady, formalnie PRZYJĘTA
**30.03.2026 R.** (dokument Rady PE-CONS 19/26, COM(2026) 124
final), ZMIENIAJĄCA dyrektywę 2014/49/UE "W ODNIESIENIU DO ZAKRESU
ochrony DEPOZYTÓW, wykorzystywania ŚRODKÓW z systemów GWARANCJI
depozytów, WSPÓŁPRACY transgranicznej i PRZEJRZYSTOŚCI" — ⚠️ SAMA
TREŚĆ merytorycznych ZMIAN (czy PODWYŻSZA konkretne kwoty
gwarancji, czy ZMIENIA zakres) NIE ZWERYFIKOWANA w tej sesji —
DOKUMENT znaleziony to głównie CZĘŚĆ proceduralna/preambuła —
WYMAGA dedykowanego badania PRZED zastosowaniem w konkretnej
sprawie, ZWŁASZCZA że TERMIN transpozycji do prawa POLSKIEGO
prawdopodobnie jeszcze NIE upłynął (dyrektywa PRZYJĘTA dopiero
30.03.2026) — web_search: "dyrektywa 2026 zmiana 2014/49 zakres
ochrony depozytów transpozycja Polska" PRZED cytowaniem w sprawie

> ⚠️ Weryfikuj aktualne kwoty w ustawie o BFG: https://ELI (RZĄD 1)/isap.nsf/DocDetails.xsp?id=WDU20240000487

---

## 7. MDR A TAJEMNICA BANKOWA — OD 1.10.2026

Art. 7 ustawy z 29.05.2026 r. (Dz.U. 2026 poz. 846) dodaje w art. 105
ust. 1 pkt 1k Prawa bankowego lit. c. Bank może udzielić Szefowi KAS
informacji objętych tajemnicą bankową w celu wykonania obowiązków z
działu III rozdziału 11a Ordynacji podatkowej, w zakresie informacji
o schematach podatkowych. Jest to szczególna podstawa ujawnienia, nie
generalne zniesienie tajemnicy bankowej.

## 8. QUALITY GATE / OUTPUT

**Quality gate:** Aktualny Dz.U. Prawa bankowego (2026 poz. 38) zweryfikowany? Nowelizacje 2025 uwzględnione? Kwoty BFG zweryfikowane?

**Output:** Kwalifikacja (czynność bankowa / nadzór KNF / depozyt) → prawa i obowiązki → środki ochrony → rekomendacja.

**Powiązania:** `mod-ustawa-AML-instytucje-obowiazkowe` | `mod-ustawa-rynek-kapitalowy-fundusze` | `dr-11` (cyberbezpieczeństwo w sektorze bankowym) | `pisma-procesowe-v3`

**Źródła:** https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20260000038 | https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20250000640 | https://knf.gov.pl | https://www.bfg.pl

---

## ANEKS — GRY HAZARDOWE (ustawa z 19.11.2009 r.)

**Akt:** Ustawa o grach hazardowych — Dz.U. 2025 poz. 595 t.j. ze zm.
✅ VER: isap.sejm.gov.pl [2026-06-05] — weryfikuj nowsze zmiany w ELI (RZĄD 1)

```
Organ nadzoru: KAS (Krajowa Administracja Skarbowa) — nie KNF

Zasady absolutne:
  □ Monopol państwowy: Totalizator Sportowy (lotto, loterie pieniężne)
  □ Zakaz reklamy hazardu poza dozwolonymi wyjątkami (weryfikuj w ustawie)
  □ Wiek: 18 lat — zakaz uczestnictwa osób niepełnoletnich (art. 15 ust. 1)
  □ Rejestr domen hazardowych KAS: blokada stron bez zezwolenia

Zezwolenia:
  → Minister Finansów: kasyna gry, salony gier, zakłady wzajemne
  → Urząd Celno-Skarbowy: rejestracja automatów poza kasynem → ZAKAZ od 2016

Sankcje:
  → Udział w nielegalnym hazardzie: grzywna do 240 stawek dziennych (KKS)
  → Przepadek wygranych z nielegalnego hazardu

Weryfikacja legalności podmiotu:
  web_search: "KAS rejestr domen hazardowych blokada 2025 2026"
  https://www.podatki.gov.pl (wyszukaj legalne podmioty)
```
