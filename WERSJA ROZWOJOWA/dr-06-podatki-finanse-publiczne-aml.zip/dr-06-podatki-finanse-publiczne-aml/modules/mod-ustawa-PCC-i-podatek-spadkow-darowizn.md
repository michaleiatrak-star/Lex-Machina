# mod-ustawa-PCC-i-podatek-spadkow-darowizn

**Akt:** OP — t.j. Dz.U. 2026 poz. 622 (zm. po t.j.: 2026/1154 od 2026-09-16 — art. 299; 2026/825 od 2026-09-24 — art. 14i, 14j; 2026/846 od 2026-10-01 — art. 11j, 12, 14b, 17, 17a, 18c, 21, 23v, 52, 59, 60, 62, 62b, 63, 67a, 67d, 74, 75, 76b, 77; 2026/875 [OD 2027-01-01: 2026/875] — art. 67a; 2026/1098 [OD 2027-01-01: 2026/1098] — art. 3b, 297, 298, 299, 299c, 306; 2026/1206 [OD 2027-01-11: 2026/1206] — art. 119zg).
**Akt:** VAT (ustawa o podatku od towarów i usług) — t.j. Dz.U. 2026 poz. 1263 (zm. po t.j.: 2026/1446 [OD 2026-11-18: 2026/1446] — art. 1, 2, 33, 33a, 33b, 34, 41, 52, 138i; 2026/1270 [OD 2027-01-01: 2026/1270] — art. 2, 12, 13, 14, 15, 15a, 17, 19a, 22, 29a, 33, 33a, 37, 41, 42, 43, 45, 83, 86, 88).
**Akt:** PIT (ustawa o podatku dochodowym od osób fizycznych) — t.j. Dz.U. 2026 poz. 592 (zm. po t.j.: 2026/779 od 2026-07-01 — art. 24a; 2026/1079 od 2026-09-10 — art. 21; 2026/846 od 2026-10-01 — art. 25b, 30f, 31d; 2026/1287 od 2026-11-01 — art. 52zt, 52zu; 2026/1371 od 2026-11-05 — art. 14, 22p, 23q, 23zf; 2026/1347 [OD 2026-12-01: 2026/1347] — art. 14; 2026/1098 [OD 2027-01-01: 2026/1098] — art. 2, 45ba, 45c, 45cd, 45ce, 45cf; 2026/1123 [OD 2028-01-01: 2026/1123] — art. 21, 22).
**Akt:** PCC (ustawa o podatku od czynności cywilnoprawnych) — t.j. Dz.U. 2026 poz. 191 (zm. po t.j.: 2026/1354 od 2026-11-03 — art. 9 pkt 6; art. 3 noweli wszedł po 14 dniach od ogłoszenia 19.10.2026 wg art. 11, metadane ELI podają 2027-01-01 dla całej ustawy; pozostałe przepisy ustawy 1354 — u.p.o.l., PIT art. 14 [OD 2027-01-01: 2026/1354]).
**Akt:** o podatku od spadków i darowizn — t.j. Dz.U. 2026 poz. 478 (zm. po t.j.: 2026/775 od 2026-06-16 — zakres: tekst nowelizacji w ELI).
**Moduł wskazuje przepis i jego funkcję (kwalifikator), nie zastępuje brzmienia.** Kwalifikatory sprawdzone z t.j. w ELI 2026-11-14 (W-1: terminy, progi i kwoty porównane z t.j.).

**Status:** moduł klasy kancelaryjnej — poziom DR-03
**Źródło weryfikacji:** PCC — Dz.U. 2026 poz. 191 t.j. ✅ VER: 2026-06-05; ⚡ zm. Dz.U. 2026 poz. 1354 art. 3 (od 2026-11-03) (art. 9 pkt 6: próg 1000 → 3000 zł od 3.11.2026) ✅ [VER: ELI DU/2026/1354 text.pdf, RZĄD 1, 2026-10-20] | Podatek SD — Dz.U. 2026 poz. 478 t.j. (⚠️ POPRAWIONE 2026-08-11: poprzednio "2024 poz. 1837 ze zm." — TEN numer był PRZESTARZAŁY, obwieszczenie z 27.03.2026 skonsolidowało poprzedni t.j. + nowelizacje z Dz.U. 2025 poz. 769, 1064, 1854 w JEDEN, nowy tekst jednolity — potwierdzone bezpośrednio ISAP) ✅ VER: 2026-08-11
**Zasada:** Każde brzmienie przepisu przed powołaniem → isap.sejm.gov.pl
**⚠️ Kwoty wolne od podatku SD — ZAWSZE weryfikuj aktualne przez web_search**

---

## 1. CORE

**PCC:** podatek od czynności cywilnoprawnych (umowy sprzedaży, pożyczki, spółki, hipoteki, depozytu nieprawidłowego).
**SD:** podatek od spadków i darowizn (nabytki od osób z poszczególnych grup pokrewieństwa).

---

## 2. PCC — STAWKI I PROCEDURA

### Stawki PCC (art. 7 ustawy o PCC — weryfikuj w ELI (RZĄD 1))

```
1%:    Umowy sprzedaży ruchomości
2%:    Umowy sprzedaży nieruchomości, praw spółdzielczych, użytkowania wieczystego
0,5%:  Umowy spółki, podwyższenie kapitału, zmiana umowy
0,5%:  Pożyczka osoby fizycznej dla osoby fizycznej
0,1%:  Hipoteka na sumie wierzytelności; 19 zł na kwotę nieokreśloną
```

### ⭐⭐⭐ PCC OD POŻYCZEK — SZCZEGÓŁY (dodano 2026-08-12, na żądanie
użytkownika — wcześniej TYLKO stawka 0,5% w tabeli, BEZ zwolnień i
sankcji)

```
⭐ PODSTAWOWA ZASADA: pożyczka PIENIĘŻNA podlega PCC (art. 1 ust. 1
  pkt 1 lit. b ustawy o PCC) — stawka **0,5%** kwoty pożyczki —
  ROZLICZA POŻYCZKOBIORCA (osoba OTRZYMUJĄCA, NIE dająca) — pożyczka
  TO NIE dochód W rozumieniu podatku DOCHODOWEGO — TU chodzi
  WYŁĄCZNIE o podatek OD SAMEJ czynności zawarcia UMOWY

⭐⭐⭐ ZWOLNIENIE RODZINNE (art. 9 pkt 10 lit. c ustawy o PCC) — DO
  KWOTY **36 120 ZŁ** (RÓWNEJ kwocie WOLNEJ I grupy podatkowej Z
  ustawy SD — patrz sekcja 3 NIŻEJ):
  → ⚠️ KRĄG uprawnionych JEST SZERSZY niż "grupa 0" — OBEJMUJE:
    małżonka, ZSTĘPNYCH, wstępnych, PASIERBA, rodzeństwo, OJCZYMA,
    macochę, ORAZ DODATKOWO zięcia, SYNOWĄ, teściów — ⭐ WAŻNE
    ROZRÓŻNIENIE: pojęcie "GRUPY 0" (bez limitu KWOTOWEGO) dotyczy
    WYŁĄCZNIE darowizn (SD-Z2), NIE stosuje SIĘ do pożyczek — DLA
    pożyczek OBOWIĄZUJE limit 36 120 ZŁ, NIEZALEŻNIE od stopnia
    pokrewieństwa W tym kręgu
  → LIMIT jest ŁĄCZNY: dotyczy SUMY pożyczek OTRZYMANYCH od TEJ
    SAMEJ osoby W roku, W KTÓRYM nastąpiła OSTATNIA pożyczka, ORAZ
    W okresie **5 LAT** POPRZEDZAJĄCYCH ten rok
  → DO kwoty 36 120 zł: zwolnienie BEZ konieczności składania
    deklaracji PCC-3, BEZ wymogu przekazania środków NA rachunek —
    MOŻE być NAWET pożyczka W gotówce

⭐⭐⭐ POWYŻEJ 36 120 ZŁ od najbliższej rodziny — zwolnienie NADAL
  MOŻLIWE, ALE pod DWOMA warunkami ŁĄCZNIE:
  1) złożenie deklaracji PCC-3 W TERMINIE **14 DNI** od DATY
     dokonania CZYNNOŚCI — ⭐⭐⭐ TERMIN NIEPRZYWRACALNY (potwierdzone
     wprost W oficjalnym Q&A podatki.gov.pl: "Termin TEN NIE
     PODLEGA przywróceniu")
  2) UDOKUMENTOWANIE otrzymania środków PRZELEWEM NA rachunek
     bankowy/SKOK LUB przekazem POCZTOWYM — GOTÓWKA NIE
     WYSTARCZY dla kwot POWYŻEJ limitu

⭐⭐⭐ SANKCJA — STAWKA KARNA 20%: STOSOWANA, GDY podatnik NIE
  zapłacił PCC W terminie, A NASTĘPNIE POWOŁAŁ SIĘ na FAKT zawarcia
  umowy pożyczki PRZED organem PODATKOWYM (W toku czynności
  sprawdzających, kontroli PODATKOWEJ, postępowania PODATKOWEGO LUB
  kontroli CELNO-SKARBOWEJ) — RÓWNIEŻ dotyczy sytuacji, GDY
  podatnik POWOŁUJE się NA zwolnienie rodzinne, ALE NIE
  UDOKUMENTOWAŁ wymaganego PRZELEWU — SKUTEK: UTRATA prawa DO
  zwolnienia, opodatkowanie WEDŁUG karnej stawki **20%** CAŁEJ
  kwoty pożyczki

⭐ KRĘGI OSÓB — RÓŻNICE PRAKTYCZNE:
  → ciotka/wujek/BRATANEK (II grupa PODATKOWA): NIGDY nie korzystają
    ze zwolnienia RODZINNEGO Z PCC, NIEZALEŻNIE od kwoty — ZAWSZE
    0,5%
  → konkubent/PARTNER w związku NIEFORMALNYM (III grupa): TAK SAMO,
    ZAWSZE 0,5%, BEZ zwolnienia

Potwierdzone w 7+ zgodnych, BARDZO aktualnych źródeł (gazetaprawna.pl
[×2, kwiecień-maj 2026], infor.pl [×2, kwiecień 2026], BEZPOŚREDNIO
podatki.gov.pl [Rząd 1, maj 2026, z oficjalnym Q&A], eksprespozyczka.pl
[maj 2026], pitax.pl [grudzień 2025]).
```

### PCC 6% — ZAKUP 2. I KOLEJNYCH MIESZKAŃ (od 31.08.2023!)

```
Przy zakupie 2. i więcej nieruchomości mieszkalnych przez osobę fizyczną:
  → 6% PCC od wartości rynkowej
  → ZWOLNIENIE: zakup 1. mieszkania (art. 9 pkt 17 ustawy o PCC)
  → Warunek zwolnienia: podatnik nie posiada żadnego innego lokalu/domu
  ⚠️ Weryfikuj aktualne warunki i wyjątki w ELI (RZĄD 1)
web_search: "PCC 6% mieszkanie 2025 warunki 2 lokal zwolnienie"
```

### Wyłączenia (nie podlega PCC)

```
□ Czynności podlegające VAT (zasada konkurencji VAT/PCC)
  WYJĄTEK: Sprzedaż nieruchomości zwolnionych z VAT → podlega PCC
□ Notariusz pobiera PCC przy aktach notarialnych (brak obowiązku deklaracji)
```

### ⚡ Sprzedaż rzeczy ruchomych — próg zwolnienia (art. 9 pkt 6) — ZMIANA OD 3.11.2026

```
DO 2.11.2026:  zwolniona sprzedaż rzeczy ruchomych, jeżeli podstawa
               opodatkowania nie przekracza 1000 zł (t.j. Dz.U. 2026 poz. 191)
OD 3.11.2026:  próg 3000 zł — art. 3 ustawy z 18.09.2026 (Dz.U. 2026 poz. 1354);
               wchodzi w życie po 14 dniach od ogłoszenia (ogł. 19.10.2026) —
               art. 11; reszta ustawy 1354 (u.p.o.l., PIT) dopiero 1.01.2027
INTERTEMPORALNIE: do czynności dokonanych przed 3.11.2026 — przepisy
               dotychczasowe, czyli próg 1000 zł (art. 10 ustawy 1354)
⛔ Decyduje DATA CZYNNOŚCI (zawarcia umowy), nie data złożenia PCC-3.
```
✅ [VER: ELI DU/2026/191 text.pdf (art. 9 pkt 6) i DU/2026/1354 text.pdf (art. 3, 10, 11), RZĄD 1, 2026-10-20]
⚠️ Data 3.11.2026 jest wyliczona z art. 11 i daty ogłoszenia. Metadane ELI podają dla całej ustawy `entryIntoForce` 2027-01-01, co jest niepełne.

### Termin i deklaracja

```
PCC-3: W terminie 14 dni od zawarcia umowy (gdy bez notariusza)
Opłata: samoobliczenie i zapłata równocześnie ze złożeniem deklaracji
Notariusz: pobiera PCC i odprowadza za podatnika
```

---

## 3. PODATEK SD — GRUPY PODATKOWE I ZWOLNIENIA

### Grupy podatkowe

```
GRUPA 0 (zwolniona — art. 4a SD):
  Małżonek, zstępni, wstępni, pasierb, rodzeństwo, ojczym, macocha
  → PEŁNE ZWOLNIENIE przy zgłoszeniu SD-Z2 w terminie 6 miesięcy

GRUPA I:
  Małżonek, zstępni, wstępni, pasierb, zięć, synowa, rodzeństwo, ojczym, macocha, teściowie

GRUPA II:
  Zstępni rodzeństwa, rodzeństwo rodziców, małżonkowie rodzeństwa,
  małżonkowie innych wstępnych

GRUPA III:
  Inni nabywcy (niespokrewnieni)
```

### ZWOLNIENIE GRUPY 0 — WARUNKI

```
⚠️ KRYTYCZNE: Zwolnienie wymaga ZGŁOSZENIA SD-Z2 w TERMINIE 6 MIESIĘCY od nabycia
  → Nabycie tytułem darowizny: 6 miesięcy od daty darowizny
  → Nabycie tytułem dziedziczenia: 6 miesięcy od uprawomocnienia stwierdzenia nabycia
  → Niezgłoszenie w terminie = UTRATA ZWOLNIENIA i obowiązek zapłaty podatku!

Przy darowiźnie środków pieniężnych:
  → Wymóg udokumentowania otrzymania na konto (przelew lub przekaz pocztowy)
```

### Kwoty wolne — ✅ ZWERYFIKOWANE 2026-07-27 (FAZA 3E/ZASADA 14)

```
Obowiązujące od 1.07.2023 r. (rozporządzenie MF z 28.06.2023, Dz.U.
2023 poz. 1226), NIEZMIENIONE do dnia weryfikacji (potwierdzone w 8+
zgodnych źródłach 2026 r.: rankomat.pl, ifirma.pl, infor.pl,
poradnikprzedsiebiorcy.pl, adwokatkaczorowska.pl, kancelaria-praga.pl,
jplegal.pl — łączna wartość nabyć od JEDNEJ OSOBY z ostatnich 5 lat):

  GRUPA I:   36 120 zł
  GRUPA II:  27 090 zł
  GRUPA III:  5 733 zł

Progi progresji stawek (wspólne dla wszystkich grup, licząc od
nadwyżki ponad kwotę wolną): 11 833 zł i 23 665 zł
Stawki: I grupa 3-7% | II grupa 7-12% | III grupa 12-20%

⚠️ Nowelizacja z 21.11.2025 r. (Dz.U. 2025 poz. 1854, w życie
7.01.2026 r.) — NIE zmieniła kwot ani stawek, tylko doprecyzowała
moment powstania obowiązku podatkowego przy dziedziczeniu i
ograniczyła ryzyko formalnej utraty zwolnień.

⚠️ MIMO POWYŻSZEGO — te kwoty bywały zmieniane rozporządzeniem MF w
przeszłości (poprzednio: 10 434 zł dla grupy I do 2023 r.) — WERYFIKUJ
ponownie, jeśli używasz tego po dłuższym czasie od daty weryfikacji.
```

### Terminy SD

```
SD-Z2 (zwolnienie gr. 0):  6 miesięcy od daty nabycia — ZAWITY
SD-3 (deklaracja):         1 miesiąc od powstania obowiązku
```

### ⭐⭐⭐ ULGA MIESZKANIOWA (art. 16 ustawy SD) — dodano 2026-08-11,
na żądanie użytkownika (kontynuacja badania pokrycia ustaw
podatkowych) — DOTĄD CAŁKOWICIE NIEOBECNA, mimo że to JEDEN Z
NAJSKUTECZNIEJSZYCH mechanizmów ograniczenia podatku SD

```
PODSTAWA: art. 16 ustawy SD (aktualny t.j. Dz.U. 2026 poz. 478,
  potwierdzone bezpośrednio OpenLEX)

⭐⭐⭐ ISTOTA: WYŁĄCZENIE Z PODSTAWY opodatkowania równowartości
  **110 M²** powierzchni UŻYTKOWEJ budynku LUB lokalu mieszkalnego
  — NADWYŻKA ponad TEN limit ORAZ GRUNT pod budynkiem — PODLEGAJĄ
  opodatkowaniu NA zasadach OGÓLNYCH

⭐⭐ KLUCZOWA WARTOŚĆ PRAKTYCZNA — DOSTĘPNA RÓWNIEŻ DLA DALSZYCH
  GRUP: ulga NIE JEST zarezerwowana WYŁĄCZNIE dla NAJBLIŻSZEJ
  rodziny (Grupa 0/I) — DOSTĘPNA RÓWNIEŻ dla Grupy II i III (np.
  siostrzeńcy, wujkowie, A NAWET osoby NIESPOKREWNIONE) — TO
  NAJSKUTECZNIEJSZY sposób NA UNIKNIĘCIE wysokiego podatku DLA
  osób z TYCH dalszych grup, KTÓRE NORMALNIE zapłaciłyby PEŁNĄ
  stawkę progresywną (7-20%)

⭐⭐⭐ WARUNKI (art. 16 ust. 2, WSZYSTKIE łącznie):
  1) nabywca NIE MOŻE BYĆ właścicielem ŻADNEGO innego budynku/
     lokalu MIESZKALNEGO (WYJĄTEK: WSPÓŁWŁASNOŚĆ innej
     nieruchomości NIE WYŁĄCZA prawa DO ulgi — POTWIERDZONE
     konsekwentnym stanowiskiem organów PODATKOWYCH, m.in.
     interpretacja z 20.06.2022 [0111-KDIB2-2.4015.46.2022.2.DR]
     ORAZ broszurą informacyjną MF)
  2) ZAMIESZKIWANIE (Z jednoczesnym zameldowaniem NA pobyt stały) W
     nabytym lokalu/budynku PRZEZ **5 LAT**, BEZ zbycia
  3) zgłoszenie NABYCIA w TERMINIE ustawowym (analogicznie do
     terminów SD wyżej)

⭐⭐ MOMENT ROZPOCZĘCIA 5-LETNIEGO OKRESU: OD DNIA złożenia
  zeznania SD-3 (JEŚLI nabywca JUŻ mieszka w LOKALU W TYM dniu) —
  JEŚLI wprowadza SIĘ PÓŹNIEJ: MA **ROK** od złożenia SD-3 NA
  zamieszkanie I zameldowanie, A SAM 5-letni okres LICZY SIĘ
  DOPIERO OD DNIA zameldowania — ⚠️ NIE WLICZA SIĘ okresów
  zamieszkiwania SPRZED daty złożenia zeznania

⭐ MOMENT OCENY spełnienia WARUNKÓW z art. 16 ust. 2: DLA spadku —
  DZIEŃ ŚMIERCI spadkodawcy (OTWARCIE spadku) — sądowe POSTANOWIENIE
  o stwierdzeniu NABYCIA spadku (LUB akt POŚWIADCZENIA dziedziczenia)
  MA CHARAKTER JEDYNIE deklaratoryjny, NIE wyznacza MOMENTU oceny

⭐ ZACHOWANIE ULGI PRZY SPRZEDAŻY i ZAKUPIE INNEJ nieruchomości
  (art. 16 ust. 3/7/8) — ulga NIE PRZEPADA automatycznie PRZY
  zbyciu odziedziczonej nieruchomości, JEŚLI ŁĄCZNIE: (a) sprzedaż
  BYŁA uzasadniona KONIECZNOŚCIĄ zmiany WARUNKÓW/miejsca
  zamieszkania, (b) środki UZYSKANE ze sprzedaży PRZEZNACZONO na
  nabycie INNEGO lokalu/budowę W CAŁOŚCI W CIĄGU **2 LAT** od dnia
  zbycia, (c) ŁĄCZNY okres zamieszkiwania W zbytym I W nabytym/
  wybudowanym lokalu WYNOSI **5 LAT**

⚠️ NIESPEŁNIENIE KTÓREGOKOLWIEK z warunków ART. 16 ust. 2 SKUTKUJE
  UTRATĄ ulgi — WARUNKI SĄ liczne I MUSZĄ być SPEŁNIONE łącznie —
  ⭐ CIEKAWY, DODATKOWY przypadek USTAWOWY: III grupa PODATKOWA —
  osoby, KTÓRE sprawowały OPIEKĘ nad WYMAGAJĄCYM takiej opieki
  spadkodawcą NA PODSTAWIE pisemnej UMOWY z podpisem NOTARIALNIE
  poświadczonym, PRZEZ CO NAJMNIEJ 2 LATA od DNIA poświadczenia
  podpisów — RÓWNIEŻ MOGĄ kwalifikować SIĘ do TEGO mechanizmu przy
  nabyciu W DRODZE dziedziczenia/zapisu

Potwierdzone w 7+ zgodnych źródeł, w tym BEZPOŚREDNIO OpenLEX
(dosłowny tekst art. 16, aktualny t.j. Dz.U. 2026 poz. 478) oraz
podatki.gov.pl [Rząd 1, maj 2026, z KONKRETNYM przykładem liczenia
terminu], poradnikprzedsiebiorcy.pl [×2], doradca.lublin.pl,
prawo-spadkowe-poznan.pl [styczeń 2026], kancelaria-praga.pl
[luty 2026].
```

---

## 4. STRATEGIA, QUALITY GATE, OUTPUT

**Strategia:** SD: sprawdź czy nabycie mieści się w grupie 0 i złóż SD-Z2 PRZED upływem 6 miesięcy. PCC: przy zakupie nieruchomości sprawdź czy jest to 1. czy 2.+ mieszkanie. Przy sporze z organem: termin 14 dni na odwołanie (Op).

**Quality gate:** Kwoty wolne SD — zweryfikowane (nie z pamięci)? SD-Z2 złożone w terminie 6 miesięcy? PCC 6% — sprawdzono czy jest to 2.+ nieruchomość?

**Output:** Kwalifikacja (PCC/SD) → stawka/kwota wolna → deklaracja → spór (termin 14 dni).

**Powiązania:** `mod-OP-ordynacja-podatkowa` | `dr-02` → `mod-KC-spadki` (nabycie majątku) | `dr-05` → `mod-ustawa-SKO` (odwołanie) | `pisma-procesowe-v3`

**Źródła:** https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20260000191 (PCC) | https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20241837 (SD)
