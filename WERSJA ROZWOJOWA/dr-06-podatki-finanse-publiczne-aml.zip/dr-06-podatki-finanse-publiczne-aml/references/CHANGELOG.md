# CHANGELOG — dr-06-podatki-finanse-publiczne-aml

- 3.99.10 (2026-11-04, AUDYT-2026-11-04): MAPA-AKTOW: KAS — zm. Dz.U. 2026 poz. 1281 art. 9 (art. 118, 122 ust. 4, 123 — kontrola operacyjna), w mocy 31.10.2026. 2026/1287 (w mocy 1.11.2026) i 2026/1354 art. 3 (PCC, w mocy 3.11.2026) — wpisy już z datami, bez zmian treści.
- 3.99.9 (2026-10-31, AUDYT-2026-10-31): Opłata skarbowa — nowy t.j. Dz.U. 2026 poz. 1395 (ELI RZĄD 1; obejmuje 2025/1795, 1847, 2026/846, 875, 912, 1206): mod-ustawa-oplata-skarbowa (art. 9 ust. 2a–2c — zwrot bez decyzji w 2 mies. od 1.10.2026 z przepisem przejściowym; ⏳ art. 1 ust. 3 od 1.01.2027), MAPA-AKTOW, SKILL.md.
- 3.99.8 (2026-10-20, LEXAGENTO-P2): MAPA-AKTOW: PIT - odpłatne zbycie mieszkania/nieruchomości (wcześniej dobierało VAT/akcyzę)
- 3.99.7 (2026-10-20, LEXAGENTO-P1): MAPA-POKRYCIA: pełna ścieżka modułu KKS
- 3.99.6 (2026-10-20, AUDYT-2026-10-20g): SKILL.md: znacznik `lex:wykonuje-aplikacja: REJESTR-MODULOW` nad rejestrem modułów — w trybie mechanicznym aplikacja podaje modelowi indeks nazw (moduły aktów dobiera z MAPA-AKTOW), w AUTO rejestr w całości
- 3.99.5 (2026-10-20, AUDYT-2026-10-20f): MAPA-AKTOW: pełne nazwy aktów w etykietach — „Ustawa o podatku od czynności cywilnoprawnych (PCC)”, u.p.o.l. — opłata miejscowa / uzdrowiskowa / targowa; resolver aplikacji rozpoznaje akt z pytania (wcześniej brak modułu dla „podatku od czynności cywilnoprawnych” i „opłaty miejscowej”)
- 3.99.4 (2026-10-20, AUDYT-2026-10-20d): KOREKTA part-01 VAT: rozp. 2023/2670 — 13 nowelizacji (było 9; brakowało 2026/418, 771, 1095, 1288), § 11b i § 11c (8% paliwa 3.10–31.12.2026); link ustawy o VAT na t.j. 2026/1263. DU/2026/1354 odczytana: PCC art. 9 pkt 6 — próg 3000 zł od 3.11.2026 (mod-PCC), nowa sekcja 6a opłata miejscowa/uzdrowiskowa od 1.01.2027 (mod-podatek-nieruchomosci-i-lokalne), PIT art. 14 ust. 2 pkt 10 lit. a; MAPA-AKTOW
- 3.99.3 (2026-10-20, AUDYT-2026-10-20c): DU/2026/1287 (podatek od nadzwyczajnych zysków ze zbycia paliw ciekłych) — część F mod-podatki-sektorowe, wiersze PIT (art. 52zu) i CIT (art. 38zb); DU/2026/1354 (u.p.o.l., PIT, PCC od 1.01.2027 / 3.11.2026) z metadanych — tekst w ELI nieopublikowany.

- 3.99.2 (2026-10-20, AUDYT-2026-10-20b): MAPA-AKTOW: PIT — DU/2026/1347 art. 2 (art. 14 ust. 2 pkt 14 lit. b uchylona) od 1.12.2026; DU/2026/1354 od 1.01.2027 odnotowana, treść nie badana.

- 3.99.1 (2026-10-15c, AUDYT-2026-10-15c): ⛔ KOREKTA: zmiana VAT z Dz.U. 2026 poz. 507 (art. 6 — art. 96 ust. 3e–3f) wchodzi w życie 1.11.2028 (art. 31 pkt 4), nie 14.10.2026 — MAPA-AKTOW, part-01 VAT, mod-VAT-kursy-walut, mod-VAT-platnicy, mod-VAT-import, mod-VAT-rejestracja (metryka t.j. 2026/1263, nie „po t.j.”), BAZA-AKTOW-OKOLOPODATKOWYCH. ELI 2026-10-15.

- 3.99 (2026-10-09g, AUDYT-2026-10-09g): VAT: nowa nowelizacja po t.j. 2026/1263 — Dz.U. 2026 poz. 1270 (od 1.12.2026/1.01.2027, dalsze etapy do 1.07.2028) w MAPA-AKTOW i 10 modułach VAT. ELI 2026-10-09.

- 3.98 (2026-10-09f, AUDYT-2026-10-09f): Doradztwo podatkowe: t.j. Dz.U. 2026 poz. 1274 w module i SKILL.md (było wygasłe 2021/2117); BAZA-AKTOW-OKOLOPODATKOWYCH: VAT t.j. 2026/1263 (było wygasłe 2025/775); odesłanie do `shared/SAMORZADY-ZAWODOWE-DOKUMENTY.md` (KIDP). ELI 2026-10-09.

- 3.97 (2026-10-09, AUDYT-2026-10-09): VAT — t.j. Dz.U. 2026 poz. 1263 (stan 26.08.2026; obejmuje 2025/894, 896, 1203, 1541, 1811, 2026/846) ⛔ zawiera 2026/507 w vacatio legis do 14.10.2026; doradztwo podatkowe — t.j. Dz.U. 2026 poz. 1274 ⛔ zawiera 2026/176 (od 18.02.2027). Zapisy odczytu ze starego t.j. VAT zachowane z adnotacją „obecny t.j.” (ELI 2026-10-09).

- 3.96 (2026-10-05l, AUDYT-2026-10-05l): mod-CIT-podatek-dochodowy-prawne: linia „Hasła spraw”. Treść prawna bez zmian.

- 3.95 (2026-10-04n, AUDYT-2026-10-04n): Historia zmian SKILL.md i modułów przeniesiona z plików roboczych do `references/HISTORIA-ZMIAN-PLIKOW.md` (plik historyczny, niewczytywany przez model). Treść robocza bez zmian.

- 3.94 (2026-10-04b, AUDYT-2026-10-04b): **Sieroty (F-225).** `references/BAZA-AKTOW-OKOLOPODATKOWYCH.md` i `BAZA-AKTOW-OKOLOAKCYZOWYCH.md` odsyłały wyłącznie do siebie nawzajem — podpięte pod „Lokalna mapa aktów prawnych” w SKILL.md. Odwołania do `shared/AKTY-PRAWNE-MASTER.md` (usunięty w shared 3.19) przeredagowane. Pełny opis: `audyt-systemu-v4/references/AUDIT-JOURNAL.md`, AUDYT-2026-10-04b.

- 3.93 (2026-09-27e, AUDYT-2026-09-27e): claude.ai po dodaniu marketplace instalował wyłącznie 4 z 32 pluginów (shared, prawny-router-v3, analizator-dowodow-v3, przesluchanie-swiadkow-v2-min90); jedyna cecha wspólna tych 4, nieobecna w żadnym z 28 pozostałych, to klucz `dependencies` we frontmatterze SKILL.md. Dodano go (`requires: [shared]` — zgodnie ze stanem faktycznym) oraz jawny manifest pluginu (name, description = description z SKILL.md, author, repository, license) — host nie musi niczego wnioskować z SKILL.md. `version` w manifeście = `version:` z SKILL.md (pilnuje T38 w audyt-systemu-v4) — host rozpoznaje aktualizację po podbiciu wersji. Treść skilla bez zmian.
- 3.92 (2026-09-23, AUDYT-2026-09-23c): SKILL.md: „Źródło podstawowe” — LEX/Legalis → ArsLege gdy aktu nie da się pobrać z RZĘDU 1 (awaria serwera, timeout, blokada); korekta użytkownika do warunku E-3.
- 3.91 (2026-09-23, AUDYT-2026-09-23b): kanon E-1…E-5 (`shared/HIERARCHIA-ZRODEL.md` 1.10): instrukcje weryfikacji „w ISAP” / „isap.sejm.gov.pl →” zamienione na „w ELI (RZĄD 1)” (28 plików); ISAP pozostaje adresem dla człowieka; wpisy historyczne („zweryfikowano w ISAP …”) bez zmian.
- 3.90 (2026-09-22, F-195): mod-OP-uzupelnienie-pokrycia 1.0→1.1 — tabela sześciu nowelizacji Ordynacji po t.j. 2026/622 z terminami z artykułów końcowych (RZĄD 1 ELI); ⛔ 2026/875 (art. 13, 67a — 1.01.2027), 2026/1098 (OKI — 1.01.2027) i 2026/1206 (art. 119zg — 11.01.2027) były nieśledzone; art. 67a — trzy wersje czasowe.
- 3.89 (2026-09-16, F-189): mod-OP-ordynacja-podatkowa i mod-interpretacje-definicje-podatkowe — ⛔ skarga na interpretację indywidualną: 30 dni (art. 53 § 1 PPSA, akty z art. 3 § 2 pkt 4a; od 26.06.2026 także pkt 4b), nie „14 dni z art. 53 § 3” (F-135, RZĄD 1).
- 3.88 (2026-09-16, F-189): mod-alkohol-tyton-regulacja-sprzedazy — ustawa tytoniowa: nowy t.j. `Dz.U. 2026 poz. 1214` (ogłoszony 16.09.2026; RZĄD 1 — status i metryka ELI); poprzedni `2024/1162` wygasły; zakres włączonych nowelizacji nieustalony (tekst jeszcze niedostępny).
- 3.87 (2026-09-16, F-189): ustawa-akcyzowa-clo/part-06 — tabela naruszeń KKS: ⛔ trzy błędy na pięć wierszy skorygowane (art. 86 — przemyt CELNY, nie akcyzowy; art. 87 — do 720 stawek albo pozbawienie wolności, nie „do 360 stawek”; art. 91 — paserstwo celne, pozbawienie wolności do 3 lat); dopisane art. 63, 63a, 65, 69a oraz progi art. 53 (F-135, RZĄD 1).
- 3.86 (2026-09-16, F-189): mod-VAT-sankcje-bony-odliczenia — rozporządzenie MF z 17.12.2015 (prewspółczynnik): chronologicznie sprzeczny zapis „t.j. 2021 z późniejszą zmianą 2020/289” skorygowany wg metryki ELI (2020/289 objęte t.j.); cytować t.j. `2021/999`; zawieszona rekomendacja zamknięta (T27).
- 3.85 (2026-09-16, F-189): NOWY moduł `mod-ustawa-oplata-skarbowa` (O-11(d); RZĄD 1 — t.j. Dz.U. 2025 poz. 1154, art. 1, 3–12; KPA art. 261 — t.j. 2025/1691): przedmiot, zobowiązani, powstanie obowiązku = termin zapłaty, zwolnienia podmiotowe, dowód zapłaty, zwrot (5 lat od końca roku), organ — wójt/burmistrz/prezydent, skutek braku opłaty. SKILL.md: licznik 46 → 47; MAPA-AKTOW: nowy wiersz.
- 3.84 (2026-09-16, F-189): NOWY moduł `mod-ustawa-podatek-wydobycie-kopalin` (F-190; RZĄD 1 — t.j. Dz.U. 2026 poz. 454): przedmiot, podatnik, obowiązek podatkowy, stawki (miedź i srebro jako wzory — progi waloryzowane corocznie; gaz 1,5/3 %, ropa 3/6 %), zwolnienia odwiertów, odliczenia (19 % straty, 40 % nakładów z oknem 2026–2028), deklaracja i zapłata do 25. dnia, organy (rozp. 2025/1850), pomiary. SKILL.md: licznik 45 → 46; MAPA-AKTOW: nowy wiersz.
- 3.83 (2026-09-16, F-189): mod-OP — zakres poz. 875 i 1098 ustalony (RZĄD 1) + art. 213 § 5 od 1.10.2026; wygasły t.j. Op `2025 poz. 111` → `2026 poz. 622` w 2 miejscach (mod-OP, mod-interpretacje-definicje-podatkowe), których nie objęła sesja 10l.
- 3.82 (2026-09-16, F-189): ODTWORZENIE utraconego wydania 3.81 (F-189), RZĄD 1 (Op Dz.U. 2026 poz. 622): termin odwołania — art. 223 § 2 (nie § 1) w 2 modułach; twierdzenia o „ugodzie podatkowej od 1.10.2026” i „uchyleniu art. 70 § 6 pkt 1” oznaczone jako niepotwierdzone (poz. 846 nie zmienia art. 70, nie zna ugody; art. 70 § 6 pkt 1 w mocy); KROK 2C: poz. 1154 (w życie 16.09.2026) — wyłącznie art. 299 § 3 pkt 17.
- 3.81 — LUKA JAWNA: wydanie AUDYT-2026-09-12i nieobecne na dysku — odtworzone w 3.82
- 3.80 (2026-09-10r, O-10): cezury czasowe dla aktow w vacatio legis: Dz.U. 2026 poz. 846 (w zycie 1.10.2026) i 2026 poz. 507 (14.10.2026) - wymieniane jako zmiany bez daty, wiec nie do odroznienia od zmian dzialajacych
- 3.79 (2026-09-10o, F-181): dwie przeterminowane podstawy: rozporzadzenie MRiF (rachunkowosc budzetowa) 2020/342 na 2026/909; UFP 2024/1530 na 2025/1483 (KROK 2C: 5 nowelizacji po t.j.)
- 3.78 (2026-09-10l, F-181): trzy przeterminowane podstawy: fundusze inwestycyjne 2024/1034 → 2026/60, obrót instrumentami 2023/646 → 2024/722 (⛔ 11 nowelizacji po t.j.), Ordynacja podatkowa 2025/111 → 2026/622
- 3.77 (2026-09-10g): MAPA-AKTOW: ustawa o VAT Dz.U. 2025 poz. 775 t.j. ✅ RZĄD 1 — dopisana lista 5 nowelizacji po tekście jednolitym (2025/894, 896, 1203, 1541, 1811)
- 3.76 (2026-08-27): dodano moduł uzupełniający Ordynację podatkową dla pozostałych działów, w tym STIR i trybów nadzwyczajnych; zsynchronizowano mapy/routing.

- 3.75 (2026-08-26): rozdzielono metrykę PKPiR (`2025/1299`) od dwóch
  powiązanych rozporządzeń, eliminując fałszywe przypisanie `2025/1294`.
- 3.74 (2026-08-26): skorygowano mapę aktów i metryki podatkowe, w tym aktualny
  t.j. podatku od niektórych instytucji finansowych (Dz.U. 2023 poz. 623),
  oraz odwzorowano skutki Dz.U. 2026 poz. 846 dla tajemnic sektorowych.
