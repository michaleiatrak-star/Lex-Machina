---
name: baza-aktow-okolopodatkowych
version: 1.0.0
utworzono: 2026-08-11 (na żądanie użytkownika, analogicznie do
  BAZA-AKTOW-OKOLOAKCYZOWYCH.md — kontynuacja tej samej naprawy)
status: production
przeznaczenie: |
  Ustrukturyzowana mapa głównych aktów podatkowych i okołopodatkowych,
  z metrykami Dz.U. zweryfikowanymi bezpośrednio na ISAP/obwieszczeniach
  Marszałka Sejmu w dniu utworzenia. Cel: ta sama naprawa co przy akcyzie
  — wykryto, że MAPA-AKTOW.md (DR-06) i ROUTING-MAP.md (prawo-polskie-v2)
  są dwoma niezależnie utrzymywanymi rejestrami tych samych faktów i
  mogą się rozjechać bez wzajemnej synchronizacji. Ten plik NIE zastępuje
  KROK 2C (prawo-polskie-v2/krajowe/shared/PRAWO-HARDGATE.md) — wskazuje kierunek, weryfikacja
  treści konkretnego artykułu i tak jest obowiązkowa przy każdym użyciu.
powiązane:
  - dr-06-podatki-finanse-publiczne-aml/MAPA-AKTOW.md
  - prawo-polskie-v2/ROUTING-MAP.md
  - dr-06-podatki-finanse-publiczne-aml/references/BAZA-AKTOW-OKOLOAKCYZOWYCH.md
  - prawo-polskie-v2/krajowe/shared/PRAWO-HARDGATE.md (KROK 2C)
  - (shared/AKTY-PRAWNE-MASTER.md — usunięty z shared w 3.19; rejestr Dz.U.: audyt-systemu-v4/references/mapa_dzu_*.md, metryki: prawo-polskie-v2/krajowe/shared/ISAP-METRYKI-AKTOW.md)
---

# Baza aktów okołopodatkowych

## 0a. ⛔ DRUGA TURA — spadki, darowizny i dalsza seria (data kontroli: 2026-08-11, ta sama sesja)

> Na żądanie użytkownika: "teraz darowizny, spadki i dalsza seria różnych
> podatkowych aktów". Zweryfikowano: podatek od spadków i darowizn, PCC,
> podatki i opłaty lokalne, ryczałt, ustawa o grach hazardowych.

| Akt | Oznaczenie w MAPA-AKTOW / ROUTING-MAP | ✅ Wynik weryfikacji (2026-08-11) | Status |
|---|---|---|---|
| Ustawa o podatku od spadków i darowizn | Dz.U. 2024 poz. 1837 t.j. | ⛔ NIEAKTUALNE — najnowszy t.j. to **Dz.U. 2026 poz. 478** (obwieszczenie 27.03.2026, publ. 07.04.2026). Uwaga merytoryczna: między starym a nowym t.j. weszły w życie istotne nowelizacje treściowe — ustawa z 25.07.2025 (Dz.U. poz. 1064, w życie 20.08.2025) i ustawa z 21.11.2025 (Dz.U. poz. 1854, w życie 7.01.2026, dodająca m.in. nowy art. 4c) — to nie tylko zmiana numeru technicznego, tylko realna zmiana treści w okresie, kiedy system wskazywał stary t.j. | ⛔ POPRAWIONO (ten sam wzorzec co akcyza) |
| Ustawa o podatku od czynności cywilnoprawnych (PCC) | Dz.U. 2026 poz. 191 t.j. | ✅ ZGODNE (obwieszczenie 17.02.2026, w życie 19.02.2026) | ✅ bez zmian |
| Ustawa o podatkach i opłatach lokalnych | Dz.U. 2025 poz. 707 t.j. | ✅ ZGODNE (obwieszczenie 21.05.2025) | ✅ bez zmian |
| Ustawa o zryczałtowanym podatku dochodowym (ryczałt) | Dz.U. 2025 poz. 843 t.j. | ✅ ZGODNE (obwieszczenie 13.06.2025) — nowelizacja poz. 779/2026 już wcześniej odnotowana (AUDYT-2026-08-11e) | ✅ bez zmian |
| Ustawa o grach hazardowych (część "podatki sektorowe") | Wcześniej BEZ przypisanego numeru — MAPA-AKTOW miała tylko "⚠️ zweryfikuj t.j. pozostałych 4 ustaw" | ✅ USTALONE: Dz.U. 2025 poz. 595 t.j. (obwieszczenie 10.04.2025) + nowelizacja Dz.U. 2026 poz. 176 (⛔ w życie 18.02.2027 — do tej daty NIE stosować) | ✅ uzupełniono (wcześniej całkowity brak) |

⚠️ **Nadal poza zakresem tej i poprzedniej tury** (jawnie odnotowane,
NIE zweryfikowane w tej sesji): podatek tonażowy (2006), opłata cukrowa
(ustawa o zdrowiu publicznym), podatek od sprzedaży detalicznej (2016),
ustawa o obligacjach, ustawa o usługach płatniczych, ustawa o biegłych
rewidentach, ustawa o doradztwie podatkowym, ustawa o finansach
publicznych (UFP). Priorytet do kolejnej tury: UFP i podatek od
instytucji finansowych — oznaczone 🔴 (najwyższe ryzyko dezaktualizacji)
w dawnej tabeli ryzyka `shared/AKTY-PRAWNE-MASTER.md` (plik usunięty
z shared w 3.19; priorytety kontroli — `prawo-polskie-v2/krajowe/shared/ISAP-METRYKI-AKTOW.md`).

---

## 0. ⛔ STATUS AKTUALNOŚCI — wynik weryfikacji online (data kontroli: 2026-08-11)

> Zweryfikowano na ISAP/obwieszczeniach Marszałka Sejmu tekst jednolity
> pięciu głównych aktów (VAT, PIT, CIT, Ordynacja podatkowa, KAS).
> **Wynik: w przeciwieństwie do akcyzy, te pięć pozycji w
> `MAPA-AKTOW.md` i `ROUTING-MAP.md` było AKTUALNYCH** (Dz.U. zgodne
> z najnowszym ogłoszonym t.j.) — ale w kilku miejscach brakowało
> odnotowania nowelizacji ogłoszonych PO tekście jednolitym, a w jednym
> przypadku (KAS) numer jednej z nowelizacji był rozbieżny ze
> zweryfikowanym źródłem.

| Akt | Oznaczenie w MAPA-AKTOW / ROUTING-MAP | ✅ Wynik weryfikacji (2026-08-11) | Status |
|---|---|---|---|
| Ustawa o VAT | Dz.U. 2025 poz. 775 (obecny t.j. Dz.U. 2026 poz. 1263) t.j. | ✅ ZGODNE (obwieszczenie 21.05.2025) — ⚠️ brakowało odnotowania nowelizacji po t.j.: Dz.U. 2025 poz. 1811 (7.11.2025), Dz.U. 2026 poz. 507 (⛔ art. 6 — art. 96 ust. 3e–3f — w życie dopiero 1.11.2028, art. 31 pkt 4; do tej daty NIE stosować; zawarte w t.j. 2026/1263), **Dz.U. 2026 poz. 846 (⛔ w życie 1.10.2026 — do tej daty NIE stosować)** (29.05.2026, zmiana Ordynacji podatkowej i "niektórych innych ustaw" — obejmuje też VAT) | ✅ t.j. aktualny / dodano nowelizacje |
| Ustawa o PIT | Dz.U. 2026 poz. 592 t.j. | ✅ ZGODNE (obwieszczenie 17.04.2026) — ⚠️ brakowało: Dz.U. 2026 poz. 779 (15.06.2026, ustawa zmieniająca jednocześnie PIT/CIT/ryczałt), **Dz.U. 2026 poz. 846 (⛔ w życie 1.10.2026 — do tej daty NIE stosować)** | ✅ t.j. aktualny / dodano nowelizacje |
| Ustawa o CIT | Dz.U. 2026 poz. 554 t.j. | ✅ ZGODNE (obwieszczenie 27.03.2026) — ⚠️ brakowało: Dz.U. 2026 poz. 779, **Dz.U. 2026 poz. 846 (⛔ w życie 1.10.2026 — do tej daty NIE stosować)** | ✅ t.j. aktualny / dodano nowelizacje |
| Ordynacja podatkowa | Dz.U. 2026 poz. 622 t.j. | ✅ ZGODNE (obwieszczenie 22.04.2026, publ. 11.05.2026) — ⚠️ brakowało: **Dz.U. 2026 poz. 846 (⛔ w życie 1.10.2026 — do tej daty NIE stosować)** (29.05.2026 — ustawa MACIERZYSTA tej nowelizacji, zmienia OP i "niektóre inne ustawy" — stąd pojawia się we wszystkich powyższych wierszach) | ✅ t.j. aktualny / dodano nowelizację |
| Ustawa o KAS | Dz.U. 2026 poz. 1492 t.j. | ✅ ZGODNE (obwieszczenie 22.10.2026, ELI 2026-11-14; zastępuje 2025/1131, obejmuje zmiany 2026/415, 483, 846, 1281) | po t.j.: 2026/1098 od 2027-01-01 |

⚠️ **Wspólny mianownik:** ustawa z 29 maja 2026 r. o zmianie ustawy —
Ordynacja podatkowa oraz niektórych innych ustaw (Dz.U. 2026 poz. 846 (⛔ w życie 1.10.2026 — do tej daty NIE stosować))
jest nowelizacją PRZEKROJOWĄ, dotykającą co najmniej VAT, PIT, CIT,
Ordynacji podatkowej i KAS jednocześnie — nie została jeszcze
uwzględniona w żadnym z pięciu t.j. powyżej (bo weszła w życie już po
nich). **Przy każdej sprawie dotykającej tych pięciu aktów sprawdź, czy
art., którego używasz, nie został zmieniony przez Dz.U. 2026 poz. 846 (⛔ w życie 1.10.2026 — do tej daty NIE stosować)**
— zakres tej nowelizacji nie został szczegółowo zbadany w tej sesji
(poza zakresem żądania), tylko odnotowany jako punkt do sprawdzenia
przy najbliższej sprawie, której dotyczy.

⚠️ **Poza zakresem tej weryfikacji** (nie sprawdzono w tej sesji —
pozostają z oznaczeniami z MAPA-AKTOW.md bez ponownej kontroli ISAP):
PCC, podatek od spadków i darowizn, podatki i opłaty lokalne, ryczałt
od przychodów ewidencjonowanych, podatki sektorowe (bankowy/gry/
tonażowy/cukrowy/detaliczny), ustawa o obligacjach, usługi płatnicze,
biegli rewidenci, doradztwo podatkowe, UFP. Do zrobienia w kolejnej
turze, jeśli sprawa tego wymaga — priorytet wg ryzyka dezaktualizacji
w dawnej tabeli `shared/AKTY-PRAWNE-MASTER.md` (plik usunięty z shared
w 3.19; zapis historyczny: 🔴 KAS/podatki = najwyższy priorytet
kontroli, co odpowiada temu, że to właśnie tu znaleziono rozbieżność).

---

## 1. Rdzeń systemu podatkowego (zweryfikowane 2026-08-11)

| Akt | Metryka Dz.U. (t.j.) | Uwaga |
|---|---|---|
| Ustawa z dnia 11 marca 2004 r. o podatku od towarów i usług (VAT) | ✅ Dz.U. 2026 poz. 1263 t.j. ✅ [VER] RZĄD 1 2026-10-09 (ELI) (poprzedni t.j. Dz.U. 2025 poz. 775 — wygaśnięcie aktu) | brzmienie art. czytaj z t.j. 2026/1263 |
| Ustawa z dnia 26 lipca 1991 r. o podatku dochodowym od osób fizycznych (PIT) | ✅ Dz.U. 2026 poz. 592 t.j. | + nowelizacje poz. 779/2026, 846/2026 |
| Ustawa z dnia 15 lutego 1992 r. o podatku dochodowym od osób prawnych (CIT) | ✅ Dz.U. 2026 poz. 554 t.j. | + nowelizacje poz. 779/2026, 846/2026 |
| Ustawa z dnia 29 sierpnia 1997 r. — Ordynacja podatkowa | ✅ Dz.U. 2026 poz. 622 t.j. | + nowelizacja poz. 846/2026 (macierzysta) |
| Ustawa z dnia 16 listopada 2016 r. o Krajowej Administracji Skarbowej (KAS) | ✅ Dz.U. 2026 poz. 1492 t.j. (obwieszczenie 22.10.2026; zastępuje 2025/1131) | po t.j.: 2026/1098 od 2027-01-01 (art. 35b, 35ca–35cc) |
| Ustawa z dnia 20 listopada 1998 r. o zryczałtowanym podatku dochodowym (ryczałt) | Dz.U. 2025 poz. 843 t.j. (zgodne z MAPA-AKTOW, niezweryfikowane ponownie w tej sesji poza potwierdzeniem z podatki.gov.pl przy okazji sprawdzania PIT) | + nowelizacja poz. 779/2026 |

## 2. Powiązania krzyżowe z modułami DR-06

```
VAT              → mod-VAT-podatek-od-towarow-i-uslug.md
                   mod-VAT-klasyfikacja-produktow-baza-niejednoznacznosci.md
PIT              → mod-PIT-podatek-dochodowy-fizyczne.md
CIT              → mod-CIT-podatek-dochodowy-prawne.md
Ordynacja        → mod-OP-ordynacja-podatkowa.md
KAS              → mod-KAS-kontrola-celno-skarbowa.md
Ryczałt          → mod-ustawa-ryczalt-przychody.md
```

Żaden z powyższych modułów nie był w tej sesji otwierany do weryfikacji
TREŚCI (tylko metryki Dz.U. na poziomie aktu) — jeśli któryś cytuje
konkretny artykuł zmieniony przez Dz.U. 2026 poz. 846 (⛔ w życie 1.10.2026 — do tej daty NIE stosować), wymaga to
osobnego przebiegu KROK 2C przy najbliższym użyciu.
